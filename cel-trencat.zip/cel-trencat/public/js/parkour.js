// ============================================================
//  PARKOUR: circuits de plataformes flotants, en 5 nivells
//  (compartit pel servidor, que porta els punts de control, i pel
//  navegador, que els dibuixa i hi fa la física del jugador)
// ============================================================
const TAU = Math.PI * 2;
export const PK = { x: 700, y: 40, z: 560 };
export const RACE_LIMIT = 420; // segons

// Tipus de plataforma:
//  base (normal) · beam (biga estreta) · move (es mou) · lift (ascensor) · blink (apareix i desapareix)
//  pad (trampolí; amb mush: és un bolet saltador) · crumble (s'esfondra quan hi trepitges)
//  spin (biga que gira com un molí)
// I a més: corrents d'aire (updrafts) que t'enlairen.

const LEVEL_DEFS = [
  {
    name: 'Camí dels Vents', diff: 1, tod: 0.33,
    desc: 'Pedres per saltar, una plataforma que es mou, un ascensor, plataformes que desapareixen, un trampolí i un gran salt planant.',
    theme: { top: '#7fd06a', side: '#a39274', rock: '#6d6a74', tile: '#ece0c0', accent: '#7ef0ff' },
    build(b) {
      b.add('base', 0, 0, 0, 14, 12, { start: true });
      b.cp(0, 0, 0, 7, 'Sortida');
      b.add('base', 2, 10, 0.4, 3, 3);
      b.add('base', -1.5, 15.5, 0.9, 3, 3);
      b.add('base', 1.5, 21, 1.4, 3, 3);
      b.add('base', -1, 26.5, 1.9, 3, 3);
      b.add('base', 0, 34, 2.4, 7, 7);
      b.cp(0, 34, 2.4, 3.6, 'Primeres passes');
      b.add('beam', 0, 45, 2.4, 1.3, 13);
      b.add('base', 0, 55, 2.4, 4, 4);
      b.add('move', 0, 64, 2.4, 4, 4, { move: { ax: 5, period: 4.5 } });
      b.add('base', 0, 73, 3, 7, 7);
      b.cp(0, 73, 3, 3.6, 'El pont estret');
      b.add('base', 0, 84, 4, 3.6, 3.6);
      b.add('base', 3, 93, 5, 3.6, 3.6);
      b.add('base', 0, 102, 6, 3.6, 3.6);
      b.add('lift', 0, 109, 10, 4, 4, { move: { ay: 4, period: 6, phase: -Math.PI / 2 } });
      b.add('base', 0, 117, 14, 7, 7);
      b.cp(0, 117, 14, 3.6, 'L\'ascensor');
      b.add('blink', 2, 125, 14, 3.2, 3.2, { blink: { on: 2.2, off: 1.3, phase: 0 } });
      b.add('blink', -2, 131, 14, 3.2, 3.2, { blink: { on: 2.2, off: 1.3, phase: 0.9 } });
      b.add('blink', 2, 137, 14, 3.2, 3.2, { blink: { on: 2.2, off: 1.3, phase: 1.8 } });
      b.add('blink', -2, 143, 14, 3.2, 3.2, { blink: { on: 2.2, off: 1.3, phase: 2.7 } });
      b.add('base', 0, 151, 14, 6, 6);
      b.add('pad', 0, 152, 14.2, 2.4, 2.4, { pad: { vy: 20, push: 9, dir: 0 } });
      b.add('base', 0, 163, 20.5, 7, 8);
      b.cp(0, 163, 20.5, 3.8, 'El trampolí');
      b.ring(0, 172, 19); b.ring(0, 178, 17); b.ring(0, 184, 15);
      b.add('base', 0, 196, 12, 11, 14);
      b.cp(0, 196, 12, 5.2, 'El gran planatge');
      for (let k = 0; k < 8; k++) b.add('base', k % 2 ? 3 : -3, 206 + k * 3.2, 13.3 + 1.3 * k, 3, 3);
      b.add('move', 0, 237, 22.4, 4, 4, { move: { az: 4, period: 5 } });
      b.add('base', 0, 251, 22.4, 12, 12, { finish: true });
      b.cp(0, 251, 22.4, 6, 'Meta');
      b.column(0, 217, 6);
    },
  },
  {
    name: 'Jardins Penjants', diff: 2, tod: 0.4,
    desc: 'Bolets saltadors, pedres que s\'esfondren quan les trepitges, un corrent d\'aire que t\'enlaira i bigues que giren com un molí.',
    theme: { top: '#9be86f', side: '#b49a7a', rock: '#6f6070', tile: '#fff0d8', accent: '#ff8fc8' },
    build(b) {
      b.add('base', 0, 0, 0, 14, 12, { start: true });
      b.cp(0, 0, 0, 7, 'Sortida');
      // bolets saltadors
      b.add('base', 0, 12, 0, 6, 6);
      b.add('pad', 0, 13.5, 0.2, 2.4, 2.4, { mush: true, pad: { vy: 16, push: 5, dir: 0 } });
      b.add('base', 0, 19.5, 4.5, 5, 6);
      b.add('pad', 0, 21, 4.7, 2.4, 2.4, { mush: true, pad: { vy: 16, push: 5, dir: 0 } });
      b.add('base', 0, 27, 9, 6, 6);
      b.cp(0, 27, 9, 3.4, 'Els bolets');
      // pedres que s'esfondren
      [[1.5, 34.5], [-1.5, 40], [1.5, 45.5], [-1.5, 51], [1.5, 56.5]].forEach(([x, z]) => b.add('crumble', x, z, 9, 3, 3, { crumble: { delay: 0.7, back: 4 } }));
      b.add('base', 0, 63.5, 9.5, 6, 6);
      b.cp(0, 63.5, 9.5, 3.4, 'Les pedres que cauen');
      // el corrent d'aire: salta-hi, puja i plana fins a la plataforma alta
      b.updraft(0, 81, 6, 22, 4);
      b.add('base', 0, 100, 15, 7, 7);
      b.cp(0, 100, 15, 3.6, 'El corrent d\'aire');
      // bigues que giren
      b.add('spin', 0, 113, 15, 12, 1.7, { spin: { speed: 0.4, phase: 0 } });
      b.add('base', 0, 123, 15, 6, 6);
      b.add('spin', 0, 133, 15, 10, 1.7, { spin: { speed: -0.4, phase: 0.6 } });
      b.add('base', 0, 143, 15.5, 5, 5);
      b.cp(0, 143, 15.5, 3, 'Les bigues que giren');
      // l'escalinata que s'esfondra i l'últim bolet
      b.add('crumble', 2, 150, 16.8, 3, 3, { crumble: { delay: 0.7, back: 4 } });
      b.add('crumble', -2, 155.5, 18.1, 3, 3, { crumble: { delay: 0.7, back: 4 } });
      b.add('crumble', 2, 161, 19.4, 3, 3, { crumble: { delay: 0.7, back: 4 } });
      b.add('base', 0, 168.5, 19.6, 5, 5);
      b.add('pad', 0, 169.5, 19.8, 2.4, 2.4, { mush: true, pad: { vy: 16, push: 5, dir: 0 } });
      b.add('base', 0, 179, 24, 12, 12, { finish: true });
      b.cp(0, 179, 24, 6, 'Meta');
    },
  },
  {
    name: 'Torres de Cristall', diff: 3, tod: 0.7,
    desc: 'Ascensors a contratemps, plataformes que van i vénen, una escala de vidre que s\'esvaeix, bigues estretes i un trampolí fins al cim.',
    theme: { top: '#b9e4ff', side: '#7d86b8', rock: '#4c4f7a', tile: '#e6f4ff', accent: '#b58cff' },
    build(b) {
      b.add('base', 0, 0, 0, 14, 12, { start: true });
      b.cp(0, 0, 0, 7, 'Sortida');
      // ascensors
      b.add('base', 0, 11, 0.6, 4, 4);
      b.add('lift', 0, 18, 4, 4, 4, { move: { ay: 3.5, period: 5.5, phase: -Math.PI / 2 } });
      b.add('base', 0, 25.5, 7.5, 5, 5);
      b.add('lift', 0, 33, 11, 4, 4, { move: { ay: 3.5, period: 5.5, phase: Math.PI / 2 } });
      b.add('base', 0, 40.5, 14.5, 6, 6);
      b.cp(0, 40.5, 14.5, 3.4, 'Els ascensors');
      // plataformes mòbils
      b.add('move', 0, 49, 14.5, 3.5, 3.5, { move: { ax: 4, period: 3.5 } });
      b.add('move', 0, 56, 14.5, 3.5, 3.5, { move: { ax: 4, period: 3.5, phase: Math.PI } });
      b.add('move', 0, 63, 14.5, 3.5, 3.5, { move: { az: 2.5, period: 3 } });
      b.add('base', 0, 72, 15, 6, 6);
      b.cp(0, 72, 15, 3.4, 'Les plataformes mòbils');
      // l'escala de vidre
      [[2, 79.5, 16.3, 0], [-2, 85, 17.6, 0.8], [2, 90.5, 18.9, 1.6], [-2, 96, 20.2, 2.4]].forEach(([x, z, top, ph]) => b.add('blink', x, z, top, 3, 3, { glass: true, blink: { on: 2.0, off: 1.2, phase: ph } }));
      b.add('base', 0, 104, 21.5, 6, 6);
      b.cp(0, 104, 21.5, 3.4, 'L\'escala de vidre');
      // el pont trencat
      b.add('beam', 0, 113.5, 21.5, 1.2, 10);
      b.add('base', 2.5, 124.5, 22.5, 2.6, 2.6);
      b.add('beam', 0, 133.5, 22.5, 1.2, 10);
      b.add('base', -2.5, 143, 23.5, 2.6, 2.6);
      b.add('base', 0, 151, 24, 6, 6);
      b.cp(0, 151, 24, 3.4, 'El pont trencat');
      b.add('pad', 0, 152.5, 24.2, 2.4, 2.4, { pad: { vy: 21, push: 7, dir: 0 } });
      b.add('base', 0, 166, 30.5, 12, 12, { finish: true });
      b.cp(0, 166, 30.5, 6, 'Meta');
      b.column(-9, 60, 10); b.column(9, 110, 14);
    },
  },
  {
    name: 'Ruta del Llamp', diff: 4, tod: 0.74,
    desc: 'Velocitat pura: una cursa de pedres que cauen, dos molins, una cadena de corrents d\'aire, plataformes fugaces i un salt final planant.',
    theme: { top: '#ffd36b', side: '#8a6a5a', rock: '#4a3c46', tile: '#fff2c8', accent: '#ffe066' },
    build(b) {
      b.add('base', 0, 0, 0, 14, 12, { start: true });
      b.cp(0, 0, 0, 7, 'Sortida');
      [[1.5, 10, 0], [-1.5, 16, 0.4], [1.5, 22, 0.8], [-1.5, 28, 0.4], [1.5, 34, 0], [-1.5, 40, 0.6], [1.5, 46, 1.2], [-1.5, 52, 1.2]]
        .forEach(([x, z, top]) => b.add('crumble', x, z, top, 2.8, 2.8, { crumble: { delay: 0.55, back: 4 } }));
      b.add('base', 0, 59, 1.5, 5, 5);
      b.cp(0, 59, 1.5, 3, 'Carrera de pedres');
      b.add('spin', 0, 70, 1.5, 12, 1.6, { spin: { speed: 0.7, phase: 0 } });
      b.add('base', 0, 80, 1.5, 3, 3);
      b.add('spin', 0, 90, 1.5, 12, 1.6, { spin: { speed: -0.7, phase: 0.4 } });
      b.add('base', 0, 100, 2, 5, 5);
      b.cp(0, 100, 2, 3, 'Els molins');
      b.updraft(0, 113, 0, 14, 4);
      b.add('base', 0, 135, 8, 5, 5);
      b.updraft(0, 148, 4, 20, 4);
      b.add('base', 0, 172, 14, 6, 6);
      b.cp(0, 172, 14, 3.4, 'Els corrents d\'aire');
      [[2, 180, 0], [-2, 185.5, 0.6], [2, 191, 1.2], [-2, 196.5, 1.8]].forEach(([x, z, ph]) => b.add('blink', x, z, 14, 3, 3, { blink: { on: 1.4, off: 1.0, phase: ph } }));
      b.add('move', 0, 203.5, 14, 3.5, 3.5, { move: { ax: 4.5, period: 3 } });
      b.add('base', 0, 212, 14.5, 6, 6);
      b.cp(0, 212, 14.5, 3.4, 'Plataformes fugaces');
      b.add('pad', 0, 213.5, 14.7, 2.4, 2.4, { pad: { vy: 20, push: 10, dir: 0 } });
      b.ring(0, 226, 21); b.ring(0, 233, 20);
      b.add('base', 0, 243, 18, 12, 12, { finish: true });
      b.cp(0, 243, 18, 6, 'Meta');
    },
  },
  {
    name: 'Cim de l\'Àliga', diff: 5, tod: 0.27,
    desc: 'Per a experts: pilars petits, un molí ràpid, pedres traïdores, ascensors, un corrent altíssim i una cadena de trampolins fins al cim.',
    theme: { top: '#f4f7ff', side: '#9a8f86', rock: '#5c5550', tile: '#ffffff', accent: '#ff9f6b' },
    build(b) {
      b.add('base', 0, 0, 0, 14, 12, { start: true });
      b.cp(0, 0, 0, 7, 'Sortida');
      [[0, 11, 1.5], [2.5, 18, 3], [-1, 25, 4.5], [1.5, 32, 6], [0, 39, 7.5]].forEach(([x, z, top]) => b.add('base', x, z, top, 2.2, 2.2));
      b.add('base', 0, 47, 8, 4, 4);
      b.cp(0, 47, 8, 2.6, 'Els pilars');
      b.add('spin', 0, 57, 8, 11, 1.3, { spin: { speed: 0.8, phase: 0 } });
      [[0, 66, 8.5], [2, 71, 9.5], [-2, 76, 10.5]].forEach(([x, z, top]) => b.add('crumble', x, z, top, 2.5, 2.5, { crumble: { delay: 0.55, back: 4 } }));
      b.add('base', 0, 83, 11, 4, 4);
      b.cp(0, 83, 11, 2.6, 'El molí');
      b.add('lift', 0, 90, 13, 3, 3, { move: { ay: 3, period: 4.5, phase: -Math.PI / 2 } });
      b.add('beam', 0, 98.5, 16, 1, 8);
      b.add('move', 0, 108, 16, 3, 3, { move: { ax: 5, period: 3 } });
      b.add('base', 0, 116, 17, 4, 4);
      b.cp(0, 116, 17, 2.6, 'Ascensors i bigues');
      b.updraft(0, 128, 10, 30, 3.5);
      b.add('base', 0, 160, 24, 4, 8);
      [[2, 168, 0], [-2, 173, 0.7], [2, 178, 1.4]].forEach(([x, z, ph]) => b.add('blink', x, z, 24, 2.6, 2.6, { blink: { on: 1.6, off: 1.0, phase: ph } }));
      b.add('base', 0, 186, 25, 4, 4);
      b.cp(0, 186, 25, 2.6, 'El gran corrent');
      b.add('pad', 0, 187, 25.2, 2, 2, { pad: { vy: 18, push: 6, dir: 0 } });
      b.add('base', 0, 195, 29, 4, 5);
      b.add('pad', 0, 196.5, 29.2, 2, 2, { pad: { vy: 18, push: 6, dir: 0 } });
      b.add('base', 0, 207, 33, 10, 10, { finish: true });
      b.cp(0, 207, 33, 5, 'El cim');
      b.column(0, 150, 16);
    },
  },
];

function buildLevel(def, n) {
  const L = { n, name: def.name, diff: def.diff, desc: def.desc, tod: def.tod, theme: def.theme, platforms: [], checkpoints: [], names: [], rings: [], updrafts: [], columns: [] };
  const b = {
    add(kind, lx, lz, top, w, d, extra = {}) {
      const p = { id: L.platforms.length, kind, x: PK.x + lx, z: PK.z + lz, top: PK.y + top, w, d, h: kind === 'beam' || kind === 'spin' ? 0.7 : kind === 'pad' ? 0.35 : 1.4, ...extra };
      L.platforms.push(p); return p;
    },
    cp(lx, lz, top, r, name) { L.checkpoints.push({ i: L.checkpoints.length, x: PK.x + lx, z: PK.z + lz, y: PK.y + top, r }); L.names.push(name); },
    ring(lx, lz, top) { L.rings.push({ x: PK.x + lx, z: PK.z + lz, y: PK.y + top }); },
    updraft(lx, lz, y0, y1, r) { L.updrafts.push({ x: PK.x + lx, z: PK.z + lz, y0: PK.y + y0, y1: PK.y + y1, r }); },
    column(lx, lz, top) { L.columns.push({ x: PK.x + lx, z: PK.z + lz, top: PK.y + top }); },
  };
  def.build(b);
  L.finish = L.checkpoints.length - 1;
  let minTop = Infinity, x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
  for (const p of L.platforms) {
    minTop = Math.min(minTop, p.top - (p.move && p.move.ay ? p.move.ay : 0));
    const ext = Math.max(p.w, p.d) / 2 + Math.abs((p.move && p.move.ax) || 0) + Math.abs((p.move && p.move.az) || 0) + 2;
    x0 = Math.min(x0, p.x - ext); x1 = Math.max(x1, p.x + ext); z0 = Math.min(z0, p.z - ext); z1 = Math.max(z1, p.z + ext);
  }
  L.killY = minTop - 10;
  L.bounds = { x0: x0 - 25, x1: x1 + 25, z0: z0 - 25, z1: z1 + 25 };
  return L;
}
export const LEVELS = LEVEL_DEFS.map((d, i) => buildLevel(d, i + 1));
export const levelOk = (n) => Math.max(1, Math.min(LEVELS.length, n | 0 || 1));
export function getLevel(n) { return LEVELS[levelOk(n) - 1]; }

// nivell actiu al navegador (el que es dibuixa i on hi ha física)
let ACTIVE = LEVELS[0];
export function setLevel(n) { ACTIVE = getLevel(n); crumbles.clear(); return ACTIVE; }
export function activeLevel() { return ACTIVE; }

export function inCourse(x, z) {
  const b = ACTIVE.bounds;
  return x > b.x0 && x < b.x1 && z > b.z0 && z < b.z1;
}

// pedres que s'esfondren: cada jugador porta les seves (al seu navegador)
const crumbles = new Map();
export function touchCrumble(p, t) { if (!crumbles.has(p.id)) crumbles.set(p.id, t); }
export function resetCrumbles() { crumbles.clear(); }

// estat d'una plataforma en un moment donat (sense crear objectes)
const S = { x: 0, z: 0, top: 0, on: true, k: 0, a: 0, shake: 0, fall: 0 };
export function platformState(p, t, out = S) {
  out.x = p.x; out.z = p.z; out.top = p.top; out.on = true; out.k = 0; out.a = 0; out.shake = 0; out.fall = 0;
  if (p.move) {
    const s = Math.sin((t / p.move.period) * TAU + (p.move.phase || 0));
    out.x += (p.move.ax || 0) * s; out.z += (p.move.az || 0) * s; out.top += (p.move.ay || 0) * s;
  }
  if (p.blink) {
    const c = p.blink.on + p.blink.off;
    const k = (((t + p.blink.phase) % c) + c) % c;
    out.on = k < p.blink.on; out.k = out.on ? k / p.blink.on : 0;
  }
  if (p.spin) out.a = p.spin.phase + p.spin.speed * t;
  if (p.crumble) {
    const t0 = crumbles.get(p.id);
    if (t0 !== undefined) {
      const el = t - t0;
      if (el < 0 || el > p.crumble.delay + p.crumble.back) crumbles.delete(p.id);
      else if (el < p.crumble.delay) out.shake = el / p.crumble.delay;
      else { out.on = false; out.fall = el - p.crumble.delay; }
    }
  }
  return out;
}

// és (x, z) a sobre de la plataforma (tenint en compte el gir)?
const PAD = 0.3;
function over(p, s, x, z) {
  let dx = x - s.x, dz = z - s.z;
  if (p.spin) { const c = Math.cos(s.a), sn = Math.sin(s.a); const lx = dx * c - dz * sn, lz = dx * sn + dz * c; dx = lx; dz = lz; }
  return Math.abs(dx) <= p.w / 2 + PAD && Math.abs(dz) <= p.d / 2 + PAD;
}

// la plataforma més alta sota (x, z) a la qual es pot arribar des de l'alçada y
export function platformAt(x, z, y, t) {
  if (!inCourse(x, z)) return null;
  let best = null, bt = -Infinity;
  for (const p of ACTIVE.platforms) {
    const s = platformState(p, t);
    if (!s.on || !over(p, s, x, z)) continue;
    if (y < s.top - 2.5 || s.top <= bt) continue;
    bt = s.top; best = p;
  }
  return best ? { p: best, top: bt } : null;
}

// corrent d'aire en aquest punt?
export function updraftAt(x, z, y) {
  for (const u of ACTIVE.updrafts) if (y > u.y0 - 1 && y < u.y1 + 0.5 && Math.hypot(x - u.x, z - u.z) < u.r) return u;
  return null;
}

// rellotge del circuit al navegador (el fixa el joc cada fotograma)
let courseT = 0;
export function setCourseTime(t) { courseT = t; }
export function courseTime() { return courseT; }
export function courseGround(x, z, y) { const r = platformAt(x, z, y, courseT); return r ? r.top : -Infinity; }

export const fmtTime = (s) => {
  if (s === null || s === undefined || s < 0) return '—';
  const m = Math.floor(s / 60), r = s - m * 60;
  return `${m}:${r < 10 ? '0' : ''}${r.toFixed(1)}`;
};
export const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
