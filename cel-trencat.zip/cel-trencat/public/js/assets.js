// Càrrega i preparació d'actius 3D
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { HumanoidAnimLib } from './anim.js';

export const BASE = new URL('../', import.meta.url).href; // carpeta public/
const url = (p) => BASE + p;

export const Assets = {
  gltf: {},
  models: {},       // nom -> Object3D (plantilla)
  textures: {},
  anims: null,      // HumanoidAnimLib
  kkClips: [],      // clips KayKit
  vrmBuffers: {},
  toonGradient: null,
};

const manager = new THREE.LoadingManager();
const loader = new GLTFLoader(manager);
loader.setMeshoptDecoder(MeshoptDecoder);
const texLoader = new THREE.TextureLoader(manager);

export function toonGradient() {
  if (Assets.toonGradient) return Assets.toonGradient;
  const data = new Uint8Array([70, 70, 70, 255, 150, 150, 150, 255, 215, 215, 215, 255, 255, 255, 255, 255]);
  const t = new THREE.DataTexture(data, 4, 1, THREE.RGBAFormat);
  t.minFilter = THREE.NearestFilter; t.magFilter = THREE.NearestFilter; t.generateMipmaps = false; t.needsUpdate = true;
  Assets.toonGradient = t;
  return t;
}

// converteix materials PBR a toon (estil anime) mantenint textures
export function toonify(root, opts = {}) {
  const cache = new Map();
  root.traverse((o) => {
    if (!o.isMesh) return;
    const conv = (m) => {
      if (!m || m.isMeshToonMaterial || m.isShaderMaterial) return m;
      if (cache.has(m)) return cache.get(m);
      const t = new THREE.MeshToonMaterial({
        color: m.color ? m.color.clone() : new THREE.Color(1, 1, 1), map: m.map || null, gradientMap: toonGradient(),
        transparent: !!m.transparent && !opts.noTransparent, alphaTest: m.alphaTest || (m.map && m.transparent ? 0.45 : 0), side: m.side,
        emissive: m.emissive ? m.emissive.clone() : new THREE.Color(0), emissiveMap: m.emissiveMap || null, emissiveIntensity: m.emissiveIntensity ?? 1,
        vertexColors: !!m.vertexColors,
        normalMap: opts.normals !== false ? (m.normalMap || null) : null,
      });
      if (t.normalMap && m.normalScale) t.normalScale.copy(m.normalScale);
      if (t.alphaTest > 0) { t.transparent = false; t.side = THREE.DoubleSide; }
      if (opts.tint) t.color.multiply(new THREE.Color(opts.tint));
      t.name = m.name;
      cache.set(m, t);
      return t;
    };
    o.material = Array.isArray(o.material) ? o.material.map(conv) : conv(o.material);
    o.castShadow = opts.castShadow !== false;
    o.receiveShadow = opts.receiveShadow !== false;
  });
  return root;
}

// Llegeix un fitxer binari. A les còpies on només es poden servir fitxers de text
// (p. ex. l'artifact), els models es publiquen codificats en base64 amb extensió .txt.
const TEXT_ASSETS = typeof window !== 'undefined' && !!window.CT_TEXT_ASSETS;
async function readStream(r, onProgress) {
  const total = +r.headers.get('content-length') || 0;
  if (!r.body || !total || !onProgress) return new Uint8Array(await r.arrayBuffer());
  const reader = r.body.getReader(); const chunks = []; let got = 0;
  for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); got += value.length; onProgress(Math.min(1, got / total)); }
  const out = new Uint8Array(got); let o = 0; for (const c of chunks) { out.set(c, o); o += c.length; }
  return out;
}
export async function fetchBinary(path, onProgress) {
  const r = await fetch(url(TEXT_ASSETS ? path + '.txt' : path));
  if (!r.ok) throw new Error('No s\'ha trobat ' + path);
  const bytes = await readStream(r, onProgress);
  if (!TEXT_ASSETS) return bytes.buffer;
  const bin = atob(new TextDecoder().decode(bytes).trim());
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

async function loadGLTF(path) {
  const buf = await fetchBinary(path);
  return new Promise((ok, ko) => loader.parse(buf, url(path).replace(/[^/]*$/, ''), ok, ko));
}

// Llista d'actius base
const LIST = [
  ['natura', 'assets/mon/natura.glb'],
  ['vila', 'assets/mon/vila.glb'],
  ['ruines', 'assets/mon/ruines.glb'],
  ['megakit', 'assets/mon/megakit.glb'],
  ['armes', 'assets/mon/armes.glb'],
  ['imp', 'assets/monstres/imp.glb'],
  ['puglin', 'assets/monstres/puglin.glb'],
  ['drac', 'assets/monstres/drac.glb'],
  ['golem', 'assets/monstres/golem.glb'],
  ['esquelet_dd', 'assets/monstres/esquelet_dd.glb'],
  ['ganfaul', 'assets/monstres/ganfaul.glb'],
  ['kk_anims', 'assets/kaykit/kk_anims.glb'],
  ['skeleton_warrior', 'assets/kaykit/skeleton_warrior.glb'],
  ['skeleton_mage', 'assets/kaykit/skeleton_mage.glb'],
  ['skeleton_rogue', 'assets/kaykit/skeleton_rogue.glb'],
  ['skeleton_minion', 'assets/kaykit/skeleton_minion.glb'],
  ['knight', 'assets/kaykit/knight.glb'],
  ['mage', 'assets/kaykit/mage.glb'],
  ['barbarian', 'assets/kaykit/barbarian.glb'],
  ['rogue_hooded', 'assets/kaykit/rogue_hooded.glb'],
];
const TEX = [
  ['puglin_vermell', 'assets/monstres/tex/puglin_vermell.jpg'],
  ['puglin_blau', 'assets/monstres/tex/puglin_blau.jpg'],
  ['puglin_oliva', 'assets/monstres/tex/puglin_oliva.jpg'],
  ['imp_verd', 'assets/monstres/tex/imp_verd.jpg'],
  ['imp_blau', 'assets/monstres/tex/imp_blau.jpg'],
  ['autumn', 'assets/mon/tex/fulles_tardor.png'],
  ['desert', 'assets/mon/tex/roca_desert.jpg'],
];

export async function loadAll(onProgress) {
  let done = 0;
  const total = LIST.length + TEX.length + 1;
  const tick = (label) => { done++; onProgress && onProgress(done / total, label); };
  const jobs = [];
  jobs.push(HumanoidAnimLib.load(url('assets/anims/humanoid.json')).then((a) => { Assets.anims = a; tick('Animacions'); }));
  for (const [name, path] of LIST) {
    jobs.push(loadGLTF(path).then((g) => { Assets.gltf[name] = g; tick(name); }).catch((e) => { console.warn('No s\'ha pogut carregar', path, e); tick(name); }));
  }
  for (const [name, path] of TEX) {
    jobs.push(new Promise((ok) => texLoader.load(url(path), (t) => { t.colorSpace = THREE.SRGBColorSpace; t.flipY = false; Assets.textures[name] = t; tick(name); ok(); }, undefined, () => { tick(name); ok(); })));
  }
  await Promise.all(jobs);
  // separa models dels paquets en plantilles per nom
  for (const pack of ['natura', 'vila', 'ruines', 'armes', 'megakit']) {
    const g = Assets.gltf[pack];
    if (!g) continue;
    for (const child of [...g.scene.children]) {
      Assets.models[({ natura: 'n:', vila: 'v:', ruines: 'r:', armes: 'a:', megakit: 'k:' })[pack] + child.name] = child;
    }
  }
  if (Assets.gltf.kk_anims) Assets.kkClips = Assets.gltf.kk_anims.animations;
  return Assets;
}

export function model(name) {
  const m = Assets.models[name];
  return m ? m : null;
}

export function cloneSkinned(name) {
  const g = Assets.gltf[name];
  if (!g) return null;
  return SkeletonUtils.clone(g.scene);
}

// VRM: es carrega de nou per a cada instància (els VRM no es poden clonar amb seguretat)
const vrmLoader = new GLTFLoader();
vrmLoader.register((p) => new VRMLoaderPlugin(p));
export async function loadVRM(hero, onProgress) {
  if (!Assets.vrmBuffers[hero]) {
    Assets.vrmBuffers[hero] = fetchBinary(`assets/herois/${hero}.vrm`, onProgress);
  }
  const buf = await Assets.vrmBuffers[hero];
  const gltf = await new Promise((ok, ko) => vrmLoader.parse(buf.slice(0), '', ok, ko));
  const vrm = gltf.userData.vrm;
  VRMUtils.removeUnnecessaryVertices(gltf.scene);
  VRMUtils.combineSkeletons ? VRMUtils.combineSkeletons(gltf.scene) : null;
  vrm.scene.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = false; o.frustumCulled = false; } });
  return vrm;
}

// Contorn negre d'estil anime (tècnica de la carcassa invertida, gruix constant en pantalla)
export const OUTLINE = { width: { value: 0.0032 }, aspect: { value: 1 }, enabled: true };
const outlineMats = new Map();
function outlineMaterial(color) {
  if (outlineMats.has(color)) return outlineMats.get(color);
  const m = new THREE.MeshBasicMaterial({ color, side: THREE.BackSide });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uOutline = OUTLINE.width; sh.uniforms.uAspect = OUTLINE.aspect;
    sh.vertexShader = 'uniform float uOutline;\nuniform float uAspect;\n' + sh.vertexShader.replace('#include <project_vertex>', `#include <project_vertex>
      {
        #ifdef USE_SKINNING
          vec3 oN = objectNormal;
        #else
          vec3 oN = normal;
        #endif
        vec4 cN = projectionMatrix * vec4(normalize(normalMatrix * oN), 0.0);
        float l = length(cN.xy);
        if (l > 1e-5) {
          float w = uOutline * clamp(28.0 / gl_Position.w, 0.25, 1.0);
          gl_Position.xy += cN.xy / l * w * gl_Position.w * vec2(uAspect, 1.0);
        }
      }`);
  };
  m.customProgramCacheKey = () => 'outline';
  outlineMats.set(color, m);
  return m;
}
export function addOutline(root, color = '#1b1020') {
  if (!OUTLINE.enabled) return;
  const meshes = [];
  root.traverse((o) => { if (o.isMesh && !o.userData.isOutline && o.visible && o.geometry && o.geometry.attributes.normal) meshes.push(o); });
  for (const o of meshes) {
    const mat = outlineMaterial(color);
    let ol;
    if (o.isSkinnedMesh) { ol = new THREE.SkinnedMesh(o.geometry, mat); ol.bind(o.skeleton, o.bindMatrix); }
    else ol = new THREE.Mesh(o.geometry, mat);
    ol.userData.isOutline = true; ol.castShadow = false; ol.receiveShadow = false; ol.frustumCulled = false;
    ol.renderOrder = -1;
    o.add(ol);
  }
}

export function fitHeight(obj, h) {
  obj.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(obj, true);
  const cur = box.max.y - box.min.y;
  if (cur > 0.01) obj.scale.multiplyScalar(h / cur);
  return obj;
}
