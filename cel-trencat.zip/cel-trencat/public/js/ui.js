// ============================================================
//  Interfície: HUD, menús i finestres
// ============================================================
import * as THREE from 'three';
import {
  MODES, CLASSES, ABILITIES, ELEMENTS, STORY, BOUNTIES, SHOP, SKINS, NPCS, RARITIES, XP_TABLE, CUSTOM_FORMS, CUSTOM_ELEMENTS, CUSTOM_POWER,
  buildCustomAbility, computeStats, MAX_LEVEL, statLabel, activeSlots, slotChoices, powerMult, TALENT_INFO, SKILL_TREES, RUNES, RUNE_SLOT2_LVL, MAX_LOADOUTS, MAX_GRIMORI, validRunes, abilityFor, GAME_VERSION } from './data.js';
import { WAYSTONES, ZONES, CAMPS, ISLAND, STRUCTURES } from './worldgen.js';
import { LEARN_ICON, TIER_LVL, TIER_PTS, canLearn, skillPointsTotal, skillSpent, branchSpent } from './skills.js';
import { LEVELS, activeLevel, platformState, courseTime, fmtTime, stars } from './parkour.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const AB_ICON = {
  espurna: '✨', bola_foc: '🔥', meteorit: '☄️', anell_flames: '💥', impuls_ardent: '💨', fenix: '🦅',
  fragment: '❄️', llanca_gel: '🔱', tempesta_neu: '🌨️', nova_glacada: '🧊', escut_cristall: '🛡️', hivern: '🌬️',
  guspira: '⚡', cadena_llamps: '🌩️', llamp_celestial: '🌟', pas_tempesta: '🌀', sobrecarrega: '🔋', senyor_tempesta: '👑',
  tall: '⚔️', tall_runic: '🌙', remoli: '🌪️', embestida: '🐗', crit_guerra: '📯', titan: '🗿', custom: '✦',
  ...LEARN_ICON,
};
// dany real d'una habilitat amb les estadístiques actuals
export function realDmg(ab, stats) {
  const k = powerMult(stats ? stats.poder : 0);
  if (ab.combo) return ab.combo.map((c) => Math.round(c.dmg * k)).join('/');
  return ab.dmg ? Math.round(ab.dmg * k) : 0;
}
export const CLS_ICON = { foc: '🔥', gel: '❄️', llamp: '⚡', guerrer: '⚔️' };
const ITEM_ICON = { staff: '🪄', wand: '🪄', spellbook_open: '📖', sword_2handed: '🗡️', sword_1handed: '🗡️', axe_1handed: '🪓', armadura: '🥋', amulet: '📿' };
const STAT_NAME = { poder: 'Poder', vida: 'Vida', def: 'Defensa', mana: 'Manà', crit: 'Crític %', cdr: 'Recàrrega -%' };
const rar = (id) => RARITIES.find((r) => r.id === id) || RARITIES[0];

export class UI {
  constructor(game) {
    this.g = game;
    this.modalStack = null;
    this.labels = [];
    this.lastHp = 1;
    this.toastQ = [];
    this.cdState = {};
    $('#version').textContent = `v${GAME_VERSION} · Cel Trencat`;
    $('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') this.closeModal(); });
    document.querySelectorAll('#menuBtns [data-m]').forEach((b) => b.addEventListener('click', (e) => {
      e.stopPropagation();
      if (document.pointerLockElement) document.exitPointerLock();
      const m = b.dataset.m;
      if (m === 'grim') this.openGrimori(); else if (m === 'char') this.openCharacter(); else if (m === 'inv') this.openInventory(); else if (m === 'map') this.openMap();
    }));
  }

  // ---------------- pantalles ----------------
  loading(p, label) {
    $('#loadBar').style.width = Math.round(p * 100) + '%';
    if (label) $('#loadLabel').textContent = label;
  }
  tip(t) { $('#loadTip').textContent = t; }
  show(id, on = true) { $(id).classList.toggle('hidden', !on); }

  // punts per gastar als botons del menú
  updateBadges(save) {
    const set = (m, n) => {
      const b = document.querySelector(`#menuBtns [data-m="${m}"]`); if (!b) return;
      let el = b.querySelector('.badge');
      if (n > 0) { if (!el) { el = document.createElement('span'); el.className = 'badge'; b.appendChild(el); } if (el.textContent !== String(n)) el.textContent = n; } else if (el) el.remove();
    };
    set('char', save.talentPts | 0);
    set('grim', skillPointsTotal(save.level) - skillSpent(save.skills));
  }

  // ---------------- HUD ----------------
  setupHud(save) {
    const c = CLASSES[save.cls];
    $('#portrait').firstChild.textContent = CLS_ICON[save.cls];
    $('#portrait').style.setProperty('--c', c.color);
    $('#pname').textContent = save.name;
    $('#pclass').textContent = c.name;
    this.buildBar(save);
  }

  buildBar(save) {
    const c = CLASSES[save.cls];
    const slots = activeSlots(save);
    const items = [['basic', c.basic, 'Clic', true], ...slots.map((s, i) => ['ab' + i, s, String(i + 1)]), ['ult', c.ult, 'R', true]];
    const bar = $('#bar');
    bar.innerHTML = '';
    this.abEls = {};
    for (const [slot, key, k, big] of items) {
      const ab = abilityFor(save, key);
      const el = document.createElement('div');
      el.className = 'ab' + (big ? ' big' : '') + (slot === 'ult' ? ' ult' : '');
      const elem = ab ? ab.el : 'arca';
      el.style.setProperty('--c', (ELEMENTS[elem] || ELEMENTS.arca).color);
      el.innerHTML = `<span class="key">${k}</span>${AB_ICON[key] || '✦'}<div class="cd"></div><div class="cdt"></div>${ab && ab.mana ? `<span class="cost">${ab.mana}</span>` : ''}`;
      el.title = ab ? `${ab.name}: ${ab.desc}` : '';
      bar.appendChild(el);
      this.abEls[slot] = { el, key, ab };
    }
    const pots = document.createElement('div');
    pots.style.display = 'flex'; pots.style.gap = '6px'; pots.style.marginLeft = '10px';
    pots.innerHTML = `<div class="ab pot" style="--c:#ff4d6d"><span class="key">G</span>❤️<span class="cnt" id="potHp">0</span></div><div class="ab pot" style="--c:#4cc3ff"><span class="key">H</span>💧<span class="cnt" id="potMana">0</span></div>`;
    bar.appendChild(pots);
  }

  updateHud(p, save, now) {
    if (!save) return;
    const hpK = Math.max(0, p.hp / p.mhp), mK = Math.max(0, p.mana / p.mmana);
    $('#hpBar').style.transform = `scaleX(${hpK})`;
    if (hpK !== this.lastHp) {
      if (hpK > this.lastHp) $('#hpLag').style.transform = `scaleX(${hpK})`;
      else { clearTimeout(this._lagT); this._lagT = setTimeout(() => { $('#hpLag').style.transform = `scaleX(${hpK})`; }, 350); }
      this.lastHp = hpK;
    }
    $('#hpTxt').textContent = `${Math.ceil(p.hp)} / ${p.mhp}`;
    $('#manaBar').style.transform = `scaleX(${mK})`;
    $('#manaTxt').textContent = `${Math.floor(p.mana)} / ${p.mmana}`;
    $('#auraBar').style.transform = `scaleX(${p.aura / 100})`;
    $('#auraWrap').classList.toggle('full', p.aura >= 100);
    $('#lvl').textContent = save.level;
    $('#xpFill').style.width = (save.level >= MAX_LEVEL ? 100 : Math.min(100, save.xp / XP_TABLE(save.level) * 100)) + '%';
    $('#gold').textContent = `${save.gold} 🪙`;
    $('#potHp') && ($('#potHp').textContent = save.potions.vida || 0);
    $('#potMana') && ($('#potMana').textContent = save.potions.mana || 0);
    // cooldowns
    for (const [slot, a] of Object.entries(this.abEls || {})) {
      if (!a.ab) continue;
      let left = 0, total = a.ab.cd || 1;
      const ready = p.cds[a.key] || 0;
      if (ready > now) left = ready - now;
      if (slot === 'ult') {
        a.el.classList.toggle('full', p.aura >= 100);
        a.el.querySelector('.cd').style.setProperty('--p', p.aura >= 100 ? '0%' : (100 - p.aura) + '%');
        a.el.querySelector('.cdt').textContent = p.tr ? Math.ceil(p.tr.t) : '';
        continue;
      }
      const pct = left > 0 ? Math.min(100, left / Math.max(0.1, p.cdTotal[a.key] || total) * 100) : 0;
      a.el.querySelector('.cd').style.setProperty('--p', pct + '%');
      a.el.querySelector('.cdt').textContent = left > 0.9 ? Math.ceil(left) : '';
      a.el.classList.toggle('nomana', (a.ab.mana || 0) > p.mana);
      const was = this.cdState[slot];
      if (was && left <= 0) { a.el.classList.remove('ready'); void a.el.offsetWidth; a.el.classList.add('ready'); }
      this.cdState[slot] = left > 0;
    }
    // buffs
    const bb = [];
    if (p.tr) bb.push(['Transformat', '#f0abfc', p.tr.t]);
    for (const [k, v] of Object.entries(p.buffs || {})) bb.push([{ shield: 'Escut', haste: 'Sobrecàrrega', guard: 'Guàrdia' }[k] || k, '#7ef0ff', v.t]);
    for (const [k, v] of Object.entries(p.statuses || {})) bb.push([{ burn: 'Cremat', slow: 'Alentit', stun: 'Atordit', freeze: 'Congelat', poison: 'Enverinat', shock: 'Electrocutat' }[k] || k, '#ff8fa3', v]);
    const html = bb.map(([n, c, t]) => `<span class="buff" style="--c:${c}">${n} ${Math.ceil(t)}s</span>`).join('');
    if (html !== this._buffHtml) { $('#buffs').innerHTML = html; this._buffHtml = html; }
  }

  quests(save) {
    const out = [];
    const ch = STORY[save.story.idx];
    if (ch) {
      if (!save.story.accepted) out.push(`<div class="q"><h3>${esc(ch.title)}</h3><div class="obj">Parla amb la Sàvia Elna a la vila</div></div>`);
      else {
        const done = ch.objectives.every((o, i) => (save.story.progress[i] || 0) >= o.n);
        out.push(`<div class="q"><h3>${esc(ch.title)}</h3>${ch.objectives.map((o, i) => `<div class="obj ${(save.story.progress[i] || 0) >= o.n ? 'done' : ''}">${esc(o.text)} (${Math.min(o.n, save.story.progress[i] || 0)}/${o.n})</div>`).join('')}${done ? '<div class="obj" style="color:var(--gold2)">Torna amb la Sàvia Elna</div>' : ''}</div>`);
      }
    } else out.push('<div class="q"><h3>Història completada</h3><div class="obj">Has salvat l\'Alba! Continua explorant.</div></div>');
    if (save.bounty) {
      const b = BOUNTIES.find((x) => x.id === save.bounty.id);
      if (b) out.push(`<div class="q"><h3>Recompensa: ${esc(b.title)}</h3><div class="obj ${save.bounty.progress >= b.obj.n ? 'done' : ''}">${esc(b.obj.text)} (${Math.min(b.obj.n, save.bounty.progress)}/${b.obj.n})</div>${save.bounty.progress >= b.obj.n ? '<div class="obj" style="color:var(--gold2)">Torna amb el Capità Bru</div>' : ''}</div>`);
    }
    const html = out.join('');
    if (html !== this._qHtml) { $('#quests').innerHTML = html; this._qHtml = html; }
  }

  party(list) {
    const html = list.map((m) => `<div class="pm panel ${m.dead ? 'dead' : ''}"><div style="display:flex;justify-content:space-between"><span>${CLS_ICON[m.cls] || ''} ${esc(m.name)}</span><span style="color:var(--dim)">Nv ${m.level}</span></div><div class="sbar hp"><i class="v" style="transform:scaleX(${Math.max(0, m.hp / m.maxHp)})"></i></div></div>`).join('');
    if (html !== this._partyHtml) { $('#party').innerHTML = html; this._partyHtml = html; }
  }

  boss(b) {
    if (!b) { $('#bossBar').classList.add('hidden'); return; }
    $('#bossBar').classList.remove('hidden');
    $('#bossName').textContent = b.name; $('#bossTitle').textContent = b.title || '';
    $('#bossHp').style.transform = `scaleX(${Math.max(0, b.hp / b.maxHp)})`;
    $('#bossTxt').textContent = `${Math.max(0, Math.ceil(b.hp)).toLocaleString('ca')} / ${b.maxHp.toLocaleString('ca')}`;
  }

  prompt(text) {
    const p = $('#prompt');
    if (!text) { p.classList.add('hidden'); this._prompt = ''; return; }
    if (text !== this._prompt) { p.innerHTML = text; this._prompt = text; }
    p.classList.remove('hidden');
  }

  toast(text, cls = '') {
    const d = document.createElement('div'); d.className = 'toast ' + cls; d.innerHTML = text;
    $('#toasts').appendChild(d); setTimeout(() => d.remove(), 3100);
    while ($('#toasts').children.length > 4) $('#toasts').firstChild.remove();
  }
  feed(text) { const d = document.createElement('div'); d.innerHTML = text; $('#feed').appendChild(d); setTimeout(() => d.remove(), 5000); while ($('#feed').children.length > 6) $('#feed').firstChild.remove(); }
  chat(name, text, sys = false) {
    const d = document.createElement('div');
    d.innerHTML = sys ? `<span class="sys">${esc(text)}</span>` : `<b>${esc(name)}:</b> ${esc(text)}`;
    const log = $('#chatLog'); log.appendChild(d); log.scrollTop = log.scrollHeight;
    while (log.children.length > 60) log.firstChild.remove();
  }

  minimap(world, me, others, enemies, yaw, zone, save) {
    const cv = $('#minimap'); const g = cv.getContext('2d');
    const W = cv.width; const mm = world.minimap;
    if (!mm) return;
    const range = 120; // metres visibles
    g.save();
    g.clearRect(0, 0, W, W);
    g.beginPath(); g.arc(W / 2, W / 2, W / 2, 0, Math.PI * 2); g.clip();
    g.fillStyle = '#2f7fb7'; g.fillRect(0, 0, W, W);
    const s = mm.n / mm.size; // px per metre al canvas
    const scale = W / (range * 2);
    g.translate(W / 2, W / 2);
    g.rotate(yaw - Math.PI);
    g.drawImage(mm.canvas, (-mm.size / 2 - me.x) * scale, (-mm.size / 2 - me.z) * scale, mm.size * scale, mm.size * scale);
    void s;
    const dot = (x, z, c, r) => { g.fillStyle = c; g.beginPath(); g.arc((x - me.x) * scale, (z - me.z) * scale, r, 0, Math.PI * 2); g.fill(); };
    // illes que queden fora del mapa pintat (p. ex. l'arena)
    for (const is of Object.values(ISLAND)) {
      if (Math.abs(is.x) < mm.size / 2 && Math.abs(is.z) < mm.size / 2) continue;
      if (Math.hypot(is.x - me.x, is.z - me.z) > range * 1.6 + is.r) continue;
      g.fillStyle = '#8f89a8'; g.beginPath(); g.arc((is.x - me.x) * scale, (is.z - me.z) * scale, is.r * scale, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#7ef0ff'; g.lineWidth = 1.5; g.beginPath(); g.arc((is.x - me.x) * scale, (is.z - me.z) * scale, is.r * 0.55 * scale, 0, Math.PI * 2); g.stroke();
    }
    if (world.course && world.course.visible) {
      const st = {}; const t = courseTime();
      for (const p of activeLevel().platforms) {
        platformState(p, t, st); if (!st.on) continue;
        g.fillStyle = p.kind === 'pad' ? '#ffb347' : p.kind === 'blink' ? '#c9a2ff' : p.move ? '#8fd3ff' : p.finish ? '#ffd166' : '#d9cfae';
        g.fillRect((st.x - p.w / 2 - me.x) * scale, (st.z - p.d / 2 - me.z) * scale, Math.max(2, p.w * scale), Math.max(2, p.d * scale));
      }
    }
    for (const w of WAYSTONES) if (save.waystones.includes(w.id)) { g.fillStyle = '#ffd166'; g.font = 'bold 12px Nunito'; g.fillText('◆', (w.x - me.x) * scale - 5, (w.z - me.z) * scale + 4); }
    for (const n of NPCS) dot(n.x, n.z, '#ffe7a8', 3);
    for (const e of enemies) if (!e.dead) dot(e.obj.position.x, e.obj.position.z, e.def.boss ? '#ff2b2b' : '#ff6b6b', e.def.boss ? 5 : 2.4);
    for (const o of others) dot(o.obj.position.x, o.obj.position.z, '#7ef0ff', 4);
    // objectiu
    const gt = this.guideTarget;
    if (gt) {
      let x = (gt.x - me.x) * scale, z = (gt.z - me.z) * scale;
      const d = Math.hypot(x, z), R = W / 2 - 12;
      g.fillStyle = '#ffd166'; g.strokeStyle = '#3a2600'; g.lineWidth = 2;
      if (d > R) {
        x *= R / d; z *= R / d;
        const a = Math.atan2(z, x);
        g.save(); g.translate(x, z); g.rotate(a);
        g.beginPath(); g.moveTo(9, 0); g.lineTo(-6, -7); g.lineTo(-3, 0); g.lineTo(-6, 7); g.closePath(); g.stroke(); g.fill(); g.restore();
      } else {
        g.save(); g.translate(x, z); g.rotate(-(yaw - Math.PI));
        g.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 3.2 : 7.5, a = i / 10 * Math.PI * 2 - Math.PI / 2; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.stroke(); g.fill(); g.restore();
      }
    }
    g.restore();
    // jugador
    g.fillStyle = '#fff'; g.strokeStyle = '#000'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(W / 2, W / 2 - 8); g.lineTo(W / 2 + 6, W / 2 + 6); g.lineTo(W / 2, W / 2 + 3); g.lineTo(W / 2 - 6, W / 2 + 6); g.closePath(); g.stroke(); g.fill();
    g.fillStyle = '#ffe7a8'; g.font = 'bold 13px Cinzel'; g.textAlign = 'center'; g.fillText('N', W / 2 + Math.sin(-(yaw - Math.PI) + Math.PI) * (W / 2 - 10), W / 2 + Math.cos(-(yaw - Math.PI) + Math.PI) * (W / 2 - 10) + 4);
    if (zone && zone.name !== this._zone) { $('#zoneName').textContent = zone.name; this._zone = zone.name; }
  }
  clock(tod) {
    const h = Math.floor(tod * 24), m = Math.floor((tod * 24 - h) * 60);
    $('#clock').textContent = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')} ${h >= 6 && h < 20 ? '☀️' : '🌙'}`;
  }

  // ---------------- etiquetes 3D ----------------
  addLabel(obj, html, cls, offY = 2.1, maxDist = 60) {
    const el = document.createElement('div'); el.className = 'label ' + cls; el.innerHTML = html;
    $('#labels').appendChild(el);
    const L = { el, obj, offY, maxDist, visible: true };
    this.labels.push(L);
    return L;
  }
  removeLabel(L) { if (!L) return; L.el.remove(); const i = this.labels.indexOf(L); if (i >= 0) this.labels.splice(i, 1); }
  updateLabels(camera, w, h) {
    const v = new THREE.Vector3();
    for (const L of this.labels) {
      if (L.hidden) { L.el.style.display = 'none'; continue; }
      L.obj.getWorldPosition ? L.obj.getWorldPosition(v) : v.copy(L.obj.position);
      v.y += L.offY;
      const d = v.distanceTo(camera.position);
      v.project(camera);
      if (v.z > 1 || d > L.maxDist) { L.el.style.display = 'none'; continue; }
      L.el.style.display = '';
      L.el.style.transform = `translate(${(v.x * 0.5 + 0.5) * w}px, ${(-v.y * 0.5 + 0.5) * h}px) translate(-50%, -100%) scale(${Math.max(0.65, Math.min(1.1, 14 / d))})`;
    }
  }

  // ---------------- finestres ----------------
  modalOpen() { return !$('#modal').classList.contains('hidden') || !$('#chatIn').classList.contains('hidden'); }
  openModal(html, cls = '', onClose) {
    const body = $('#modalBody');
    body.className = 'panel ' + cls;
    body.innerHTML = `<button class="close" data-x>×</button>` + html;
    body.querySelector('[data-x]').onclick = () => this.closeModal();
    $('#modal').classList.remove('hidden');
    this._onClose = onClose;
    if (document.pointerLockElement) document.exitPointerLock();
    this.g.audio.play('ui');
    return body;
  }
  closeModal() {
    if ($('#modal').classList.contains('hidden')) return;
    $('#modal').classList.add('hidden');
    this.refresh = null;
    const f = this._onClose; this._onClose = null; if (f) f();
  }

  itemIcon(it) { return it.slot === 'arma' ? ITEM_ICON[it.model] || '🗡️' : ITEM_ICON[it.slot]; }
  itemTip(it, cmp) {
    if (!it) return '<div class="hint">Passa el ratolí per sobre d\'un objecte.</div>';
    const r = rar(it.rar);
    const lines = Object.entries(it.stats).map(([k, v]) => {
      const c = cmp && cmp.stats ? v - (cmp.stats[k] || 0) : null;
      return `<div class="st">+${v} ${STAT_NAME[k] || k} ${c !== null && c !== 0 ? `<span style="color:${c > 0 ? 'var(--ok)' : '#ff8fa3'}">(${c > 0 ? '+' : ''}${c})</span>` : ''}</div>`;
    }).join('');
    return `<div style="--r:${r.color}"><h3>${esc(it.name)}</h3><div class="hint">${r.name} · Nivell ${it.lvl} · ${it.slot}</div>${lines}<div class="hint" style="margin-top:6px">Valor: ${Math.round(it.price * 0.4)} 🪙</div></div>`;
  }

  openInventory() {
    const g = this.g; const s = g.save;
    const render = () => {
      const st = computeStats(s.cls, s.level, s.talents, s.equip, { skills: s.skills });
      const body = this.openModal(`
        <h2>Inventari</h2>
        <div class="grid2" style="margin-top:14px">
          <div>
            <div class="equip">${['arma', 'armadura', 'amulet'].map((sl) => { const it = s.equip[sl]; return `<div class="eq"><div class="it" data-eq="${sl}" style="--r:${it ? rar(it.rar).color : 'rgba(255,255,255,.12)'}">${it ? this.itemIcon(it) : '·'}</div><div><b style="text-transform:capitalize">${sl}</b><div class="hint">${it ? esc(it.name) : 'Buit'}</div></div></div>`; }).join('')}</div>
            <div class="stats" style="margin-top:14px"><span>Vida</span><b>${st.maxHp}</b><span>Manà</span><b>${st.maxMana}</b><span>Poder</span><b>${st.poder}</b><span>Defensa</span><b>${st.def}</b><span>Crític</span><b>${st.crit.toFixed(1)}%</b><span>Reducció de recàrrega</span><b>${st.cdr.toFixed(0)}%</b></div>
          </div>
          <div>
            <div class="inv">${Array.from({ length: 24 }, (_, i) => { const it = s.inv[i]; return `<div class="it" data-i="${i}" style="--r:${it ? rar(it.rar).color : 'rgba(255,255,255,.08)'}">${it ? this.itemIcon(it) : ''}${it ? `<small>${it.lvl}</small>` : ''}</div>`; }).join('')}</div>
            <div class="tt" id="tt" style="margin-top:10px">${this.itemTip(null)}</div>
            <div class="hint" style="margin-top:6px">Clic: equipar · Clic dret: llençar</div>
          </div>
        </div>`);
      body.querySelectorAll('[data-i]').forEach((el) => {
        const it = s.inv[+el.dataset.i]; if (!it) return;
        el.onmouseenter = () => { body.querySelector('#tt').innerHTML = this.itemTip(it, s.equip[it.slot]); };
        el.onclick = () => { g.net.send('inv', { a: 'equip', id: it.id }); g.audio.play('item'); setTimeout(render, 120); };
        el.oncontextmenu = (e) => {
          e.preventDefault();
          if (el.dataset.armed) { g.net.send('inv', { a: 'drop', id: it.id }); g.audio.play('ui'); setTimeout(render, 120); return; }
          el.dataset.armed = '1'; el.style.outline = '2px solid #ff4d6d';
          body.querySelector('#tt').innerHTML = `<b style="color:#ff8fa3">Clic dret de nou per llençar ${esc(it.name)}</b>`;
          setTimeout(() => { if (el.isConnected) { delete el.dataset.armed; el.style.outline = ''; } }, 2500);
        };
      });
      body.querySelectorAll('[data-eq]').forEach((el) => {
        const it = s.equip[el.dataset.eq]; if (!it) return;
        el.onmouseenter = () => { body.querySelector('#tt').innerHTML = this.itemTip(it); };
        el.onclick = () => { g.net.send('inv', { a: 'unequip', slot: el.dataset.eq }); setTimeout(render, 120); };
      });
    };
    render();
    this.refresh = render;
  }

  openCharacter() {
    const g = this.g;
    const render = () => {
      const s = g.save;
      const st = computeStats(s.cls, s.level, s.talents, s.equip, { skills: s.skills });
      const base = computeStats(s.cls, s.level, {}, {}, {});
      const c = CLASSES[s.cls];
      const spent = Object.values(s.talents || {}).reduce((a, b) => a + (b | 0), 0);
      const sp = skillPointsTotal(s.level) - skillSpent(s.skills);
      const L = (k) => statLabel(s.cls, k);
      const melee = !!c.melee;
      const TD = { ...Object.fromEntries(Object.entries(TALENT_INFO).map(([k, v]) => [k, v.desc])),
        ...(melee ? { poder: '+4 de força: tots els cops i habilitats fan més mal', saviesa: '+20 d\'energia, −1% de recàrrega i +1,2% d\'àrea' } : {}) };
      const val = { poder: `+${(s.talents.poder || 0) * TALENT_INFO.poder.poder} ${L('poder').toLowerCase()}`, vitalitat: `+${(s.talents.vitalitat || 0) * TALENT_INFO.vitalitat.hp} vida`, agilitat: `+${(s.talents.agilitat || 0) * TALENT_INFO.agilitat.crit}% crític`, saviesa: `−${(s.talents.saviesa || 0) * TALENT_INFO.saviesa.cdr}% recàrr.` };
      const slots = activeSlots(s);
      const body = this.openModal(`
        <h2>${esc(s.name)} · ${c.name}</h2>
        <div class="hint">Nivell ${s.level} · ${s.xp} / ${XP_TABLE(s.level)} XP · Rècord PvP: ${s.pvp.wins} victòries, ${s.pvp.kills} eliminacions</div>
        <div class="grid2" style="margin-top:14px">
          <div><h3 style="color:var(--gold2);font-size:15px;margin-bottom:8px">Estadístiques</h3>
            <div class="ptsbox"><div class="${s.talentPts > 0 ? 'hot' : ''}"><b>${s.talentPts}</b>punts per pujar</div><div><b>${spent}</b>punts pujats</div></div>
            ${['poder', 'vitalitat', 'agilitat', 'saviesa'].map((k) => { const n = s.talents[k] || 0; return `<div class="talent"><div style="flex:1"><b>${k === 'poder' || k === 'saviesa' ? L(k) : TALENT_INFO[k].name}: ${n} ${n === 1 ? 'punt' : 'punts'}</b><small>${TD[k]}</small><div class="pts">${Array.from({ length: Math.max(n, 0) }, () => '<i class="on"></i>').join('')}${Array.from({ length: Math.min(s.talentPts, 12) }, () => '<i></i>').join('')}</div></div><div class="tv">${n ? val[k] : ''}</div><button class="pbtn" data-t="${k}" ${s.talentPts > 0 ? '' : 'disabled'}>+</button></div>`; }).join('')}
            <div class="stats" style="margin-top:12px">
              <span>Vida</span><b>${st.maxHp}${st.maxHp > base.maxHp ? ` <small style="color:#7ef0a0">(+${st.maxHp - base.maxHp})</small>` : ''}</b>
              <span>${L('mana')}</span><b>${st.maxMana}</b>
              <span>${L('poder')}</span><b>${st.poder}${st.poder > base.poder ? ` <small style="color:#7ef0a0">(+${st.poder - base.poder})</small>` : ''}</b>
              <span>Dany de les habilitats</span><b>×${powerMult(st.poder).toFixed(2)}</b>
              <span>Defensa</span><b>${st.def}</b><span>Crític</span><b>${st.crit.toFixed(1)}%</b>
              <span>Recàrrega</span><b>−${st.cdr.toFixed(0)}%</b><span>Velocitat</span><b>${st.speed.toFixed(1)}</b>
            </div>
            <div class="row" style="margin-top:10px"><button class="pbtn ghost" data-treset ${spent ? '' : 'disabled'} style="padding:6px 10px">Reiniciar estadístiques</button></div>
          </div>
          <div><h3 style="color:var(--gold2);font-size:15px;margin-bottom:8px">Habilitats</h3>
            <div class="abil-list">${[c.basic, ...slots, c.ult].map((k) => { const ab = abilityFor(s, k); if (!ab) return ''; const d = realDmg(ab, st); return `<div><b>${AB_ICON[k] || '✦'} ${esc(ab.name)}</b><span>${esc(ab.desc)}${d ? ` <i style="color:#ffd7a8">${d} de dany</i>` : ''}${ab.cd >= 0.5 ? ` (${ab.cd}s${ab.mana ? `, ${ab.mana} manà` : ''})` : ''}</span></div>`; }).join('')}</div>
            <p class="hint" style="margin-top:12px">El dany mostrat ja inclou ${melee ? 'la teva força' : 'el teu poder'}: com més ${melee ? 'força' : 'poder'}, més fortes són totes les habilitats.${melee ? ' La Forma Titànica multiplica totes les estadístiques.' : ''}</p>
            <button class="pbtn ${sp > 0 ? 'gold' : ''}" data-tree style="margin-top:6px">🌳 Branques d'habilitats${sp > 0 ? ` (${sp} punts)` : ''}</button>
          </div>
        </div>`);
      body.querySelectorAll('[data-t]').forEach((b) => { b.onclick = () => { g.net.send('inv', { a: 'talent', stat: b.dataset.t }); g.audio.play('ui'); }; });
      const tr = body.querySelector('[data-treset]'); if (tr) tr.onclick = () => { if (tr.dataset.sure) { g.net.send('inv', { a: 'talentReset' }); } else { tr.dataset.sure = 1; tr.textContent = 'Clica una altra vegada per confirmar'; } };
      body.querySelector('[data-tree]').onclick = () => this.openGrimori('tree');
    };
    render();
    this.refresh = render;
  }

  openMap() {
    const g = this.g; const w = g.world; const mm = w.minimap;
    const body = this.openModal(`<h2>Mapa del regne</h2><div class="hint" style="margin-bottom:10px">◆ pedres de portal · <span style="color:#ff4d4d">★</span> caps · 🏰 fortaleses · <span style="color:#ffd166">★</span> el teu objectiu</div><canvas id="mapCanvas" width="640" height="640"></canvas>`, 'mapm');
    const cv = body.querySelector('#mapCanvas'); const c = cv.getContext('2d');
    const S = 640, sc = S / mm.size;
    c.fillStyle = '#2f7fb7'; c.fillRect(0, 0, S, S);
    c.drawImage(mm.canvas, 0, 0, S, S);
    const P = (x, z) => [(x + mm.size / 2) * sc, (z + mm.size / 2) * sc];
    c.font = 'bold 15px Cinzel'; c.textAlign = 'center';
    for (const z of ZONES) { if (z.id === 'arena' || z.id === 'niu' || z.id === 'parkour') continue; const [x, y] = P(z.x, z.id === 'cel' ? 300 : z.z); c.fillStyle = 'rgba(0,0,0,.55)'; c.fillText(z.name, x + 1, y + 1); c.fillStyle = '#fff3c4'; c.fillText(z.name, x, y); }
    for (const is of Object.values(ISLAND)) { if (is.id === 'arena') continue; const [x, y] = P(is.x, is.z); c.strokeStyle = 'rgba(255,255,255,.7)'; c.setLineDash([4, 4]); c.beginPath(); c.arc(x, y, is.r * sc, 0, 7); c.stroke(); c.setLineDash([]); }
    c.font = 'bold 16px Nunito';
    for (const ws of WAYSTONES) { const [x, y] = P(ws.x, ws.z); c.fillStyle = g.save.waystones.includes(ws.id) ? '#ffd166' : 'rgba(255,255,255,.35)'; c.fillText('◆', x, y + 5); }
    for (const cp of CAMPS) if (cp.boss) { const [x, y] = P(cp.x, cp.z); c.fillStyle = '#ff4d4d'; c.fillText('★', x, y + 5); }
    for (const n of NPCS) { const [x, y] = P(n.x, n.z); c.fillStyle = '#ffe7a8'; c.fillText('•', x, y + 5); }
    // fortaleses
    c.font = 'bold 13px Cinzel';
    for (const st of STRUCTURES) { const [x, y] = P(st.x, st.z); c.fillStyle = 'rgba(0,0,0,.6)'; c.fillText('🏰 ' + st.name, x + 1, y - 13); c.fillStyle = '#ffd7a8'; c.fillText('🏰 ' + st.name, x, y - 14); }
    const gt = this.guideTarget;
    if (gt) { const [x, y] = P(gt.final ? gt.final.x : gt.x, gt.final ? gt.final.z : gt.z); c.strokeStyle = '#ffd166'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, 12, 0, 7); c.stroke(); c.fillStyle = '#ffd166'; c.font = 'bold 18px Nunito'; c.fillText('★', x, y + 6); }
    const ch = STORY[g.save.story.idx];
    if (false && ch && g.save.story.accepted) {
      const tgt = { c1: [0, -150], c2: [190, -50], c3: [-190, -40], c4: [0, 150], c5: [84, 392] }[ch.id];
      if (g.save.story.idx === 3 && g.save.flags.pedraVent) tgt[1] = 330;
      if (tgt) { const [x, y] = P(tgt[0], tgt[1]); c.fillStyle = '#ffde59'; c.font = 'bold 28px Cinzel'; c.fillText('!', x, y + 10); }
    }
    for (const o of g.others.values()) { const [x, y] = P(o.obj.position.x, o.obj.position.z); c.fillStyle = '#7ef0ff'; c.beginPath(); c.arc(x, y, 5, 0, 7); c.fill(); }
    const [px, py] = P(g.player.pos.x, g.player.pos.z);
    c.save(); c.translate(px, py); c.rotate(-g.player.yaw + Math.PI); c.fillStyle = '#fff'; c.strokeStyle = '#000'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(0, 10); c.lineTo(7, -7); c.lineTo(0, -3); c.lineTo(-7, -7); c.closePath(); c.stroke(); c.fill(); c.restore();
  }

  // ---------------- diàlegs amb NPC ----------------
  openNpc(id) {
    const n = NPCS.find((x) => x.id === id);
    if (id === 'elna') return this.dialogElna(n);
    if (id === 'bru') return this.openBounties(n);
    if (id === 'oleguer') return this.openShop(n);
    if (id === 'rina') return this.openRina(n);
  }

  dialog(n, lines, opts) {
    let i = 0;
    const render = () => {
      const last = i >= lines.length - 1;
      const body = this.openModal(`<div class="who">${esc(n.name)}</div><div class="role">${esc(n.role)}</div><div class="txt">${esc(lines[i] || '')}</div><div class="opts" id="dopts"></div>`, 'dialog');
      const o = body.querySelector('#dopts');
      if (!last) { const b = document.createElement('button'); b.className = 'pbtn gold'; b.textContent = 'Continuar ▸'; b.onclick = () => { i++; render(); }; o.appendChild(b); }
      else for (const [label, fn, cls] of opts) { const b = document.createElement('button'); b.className = 'pbtn ' + (cls || ''); b.textContent = label; b.onclick = fn; o.appendChild(b); }
    };
    render();
  }

  dialogElna(n) {
    const g = this.g; const s = g.save; const ch = STORY[s.story.idx];
    const editor = ['Grimori: branques, habilitats i runes', () => this.openGrimori(CLASSES[g.save.cls].melee ? 'tree' : 'spells'), ''];
    const bye = ['Adéu', () => this.closeModal(), 'ghost'];
    if (!ch) return this.dialog(n, ['El cel està en calma gràcies a tu. Però sempre hi ha nous encanteris per descobrir.'], [editor, bye]);
    if (!s.story.accepted) return this.dialog(n, ch.intro, [['Accepto la missió', () => { g.net.send('npc', { npc: 'elna', a: 'accept' }); g.audio.play('quest'); this.toast(ch.title, 'big'); this.closeModal(); }, 'gold'], editor, bye]);
    const done = ch.objectives.every((o, i) => (s.story.progress[i] || 0) >= o.n);
    if (done) return this.dialog(n, ch.done, [['Recollir la recompensa', () => { g.net.send('npc', { npc: 'elna', a: 'turnin' }); this.closeModal(); }, 'gold']]);
    return this.dialog(n, ['Encara hi ha feina a fer:', ...ch.objectives.map((o, i) => `${o.text}: ${Math.min(o.n, s.story.progress[i] || 0)} de ${o.n}.`)].slice(0, 1).concat([ch.objectives.map((o, i) => `• ${o.text} (${Math.min(o.n, s.story.progress[i] || 0)}/${o.n})`).join('  ')]), [editor, bye]);
  }

  openBounties(n) {
    const g = this.g; const s = g.save;
    const render = () => {
      const cur = s.bounty && BOUNTIES.find((b) => b.id === s.bounty.id);
      const body = this.openModal(`<div class="who">${esc(n.name)}</div><div class="role">${esc(n.role)}</div>
        <div class="txt" style="font-size:15px">${cur ? `Estàs treballant en <b>${esc(cur.title)}</b>: ${Math.min(cur.obj.n, s.bounty.progress)}/${cur.obj.n}.` : 'El tauler de recompenses està ple. Tria una feina, aventurer.'}</div>
        <div class="shop" style="margin-top:12px">${BOUNTIES.map((b) => `<div class="card"><h3>${esc(b.title)}</h3><p>${esc(b.obj.text)}</p><span class="pr">${b.reward.gold} 🪙 · ${b.reward.xp} XP${b.reward.item ? ' · objecte' : ''}</span>
          ${cur && cur.id === b.id ? (s.bounty.progress >= b.obj.n ? `<button class="pbtn gold" data-done>Cobrar</button>` : `<button class="pbtn ghost" data-ab>Abandonar</button>`) : `<button class="pbtn" data-b="${b.id}" ${cur ? 'disabled' : ''}>Acceptar</button>`}</div>`).join('')}</div>`, 'dialog');
      body.querySelectorAll('[data-b]').forEach((b) => { b.onclick = () => { g.net.send('npc', { npc: 'bru', a: 'bounty', id: b.dataset.b }); g.audio.play('quest'); setTimeout(render, 150); }; });
      const d = body.querySelector('[data-done]'); if (d) d.onclick = () => { g.net.send('npc', { npc: 'bru', a: 'bountyDone' }); setTimeout(render, 150); };
      const a = body.querySelector('[data-ab]'); if (a) a.onclick = () => { g.net.send('npc', { npc: 'bru', a: 'abandon' }); setTimeout(render, 150); };
    };
    render(); this.refresh = render;
  }

  openShop(n) {
    const g = this.g; const s = g.save;
    let tab = 'buy';
    const render = () => {
      const body = this.openModal(`<div class="who">${esc(n.name)}</div><div class="role">${esc(n.role)} · Tens ${s.gold} 🪙</div>
        <div class="tabs"><button class="pbtn ${tab === 'buy' ? 'sel' : ''}" data-tab="buy">Comprar</button><button class="pbtn ${tab === 'sell' ? 'sel' : ''}" data-tab="sell">Vendre</button></div>
        ${tab === 'buy' ? `<div class="shop">${SHOP.map((it) => `<div class="card"><h3>${esc(it.name)}</h3><p>${esc(it.desc)}</p><span class="pr">${it.price} 🪙</span><button class="pbtn" data-buy="${it.id}" ${s.gold < it.price ? 'disabled' : ''}>Comprar</button></div>`).join('')}</div>`
        : `<div class="inv">${s.inv.map((it, i) => `<div class="it" data-sell="${i}" style="--r:${rar(it.rar).color}" title="${esc(it.name)}">${this.itemIcon(it)}<small>${Math.round(it.price * 0.4)}</small></div>`).join('') || '<div class="hint">No tens res per vendre.</div>'}</div><div class="hint" style="margin-top:8px">Clic per vendre.</div>`}`, 'dialog');
      body.querySelectorAll('[data-tab]').forEach((b) => { b.onclick = () => { tab = b.dataset.tab; render(); }; });
      body.querySelectorAll('[data-buy]').forEach((b) => { b.onclick = () => { g.net.send('shop', { a: 'buy', id: b.dataset.buy }); g.audio.play('coin'); setTimeout(render, 150); }; });
      body.querySelectorAll('[data-sell]').forEach((b) => { b.onclick = () => { const it = s.inv[+b.dataset.sell]; if (it) { g.net.send('shop', { a: 'sell', id: it.id }); g.audio.play('coin'); setTimeout(render, 150); } }; });
    };
    render(); this.refresh = render;
  }

  openRina(n) {
    const g = this.g; const s = g.save;
    let tab = 'portals';
    const render = () => {
      const cats = [['aura', 'Aures'], ['arma', 'Armes'], ['ales', 'Ales']];
      let content = '';
      if (tab === 'portals') {
        content = `<div class="shop">${WAYSTONES.map((w) => { const un = s.waystones.includes(w.id); return `<div class="card"><h3>${esc(w.name)}</h3><p>${un ? 'Pedra descoberta' : 'Encara no l\'has trobada'}</p><button class="pbtn" data-tp="${w.id}" ${un ? '' : 'disabled'}>Viatjar</button></div>`; }).join('')}</div>`;
      } else {
        const list = SKINS[tab];
        content = `<div class="shop">${list.map((sk) => { const own = (s.owned[tab] || []).includes(sk.id); const on = s.skins[tab] === sk.id; return `<div class="card" style="${sk.color ? `border-color:${sk.color}` : ''}"><h3>${esc(sk.name)}</h3><p>${sk.color ? `<span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:${sk.color};vertical-align:middle"></span>` : ''} ${own ? (on ? 'Equipat' : 'En propietat') : `${sk.price} 🪙`}</p><button class="pbtn ${on ? 'gold' : ''}" data-sk="${sk.id}" ${!own && s.gold < sk.price ? 'disabled' : ''}>${own ? (on ? 'Equipat' : 'Equipar') : 'Comprar'}</button></div>`; }).join('')}</div>`;
      }
      const body = this.openModal(`<div class="who">${esc(n.name)}</div><div class="role">${esc(n.role)} · Tens ${s.gold} 🪙</div>
        <div class="tabs"><button class="pbtn ${tab === 'portals' ? 'sel' : ''}" data-tab="portals">Portals</button>${cats.map(([k, l]) => `<button class="pbtn ${tab === k ? 'sel' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>${content}
        <p class="hint">Les ales apareixen quan planes (mantén Espai a l'aire).</p>`, 'dialog');
      body.querySelectorAll('[data-tab]').forEach((b) => { b.onclick = () => { tab = b.dataset.tab; render(); }; });
      body.querySelectorAll('[data-tp]').forEach((b) => { b.onclick = () => { g.net.send('shop', { a: 'teleport', id: b.dataset.tp }); this.closeModal(); }; });
      body.querySelectorAll('[data-sk]').forEach((b) => { b.onclick = () => { g.net.send('shop', { a: 'skin', cat: tab, id: b.dataset.sk }); g.audio.play('coin'); setTimeout(render, 150); }; });
    };
    render(); this.refresh = render;
  }

  openWaystone(id) {
    const g = this.g; const s = g.save;
    const body = this.openModal(`<h2>Pedra de portal</h2><p class="hint">Viatja a qualsevol pedra que hagis descobert.</p><div class="shop">${WAYSTONES.map((w) => { const un = s.waystones.includes(w.id); return `<div class="card"><h3>${esc(w.name)}</h3><button class="pbtn" data-tp="${w.id}" ${un && w.id !== id ? '' : 'disabled'}>${w.id === id ? 'Ets aquí' : un ? 'Viatjar' : 'Bloquejat'}</button></div>`; }).join('')}</div>`, 'dialog');
    body.querySelectorAll('[data-tp]').forEach((b) => { b.onclick = () => { g.net.send('shop', { a: 'teleport', id: b.dataset.tp }); this.closeModal(); }; });
  }

  // ---------------- Grimori: habilitats, runes, encanteris propis i conjunts ----------------
  openEditor() { return this.openGrimori('spells'); }

  openGrimori(tab) {
    const g = this.g; const c = () => CLASSES[g.save.cls];
    if (!tab) tab = skillPointsTotal(g.save.level) - skillSpent(g.save.skills) > 0 ? 'tree' : 'abil';
    this._grimTab = tab;
    let pick = null; // { key, slot } quan es tria una runa
    const send = (m) => { g.net.send('inv', m); g.audio.play('ui'); };
    const statLine = (ab) => {
      if (!ab) return '';
      const parts = [];
      const stt = g.player && g.player.stats ? g.player.stats : computeStats(g.save.cls, g.save.level, g.save.talents, g.save.equip, { skills: g.save.skills });
      const rd = realDmg(ab, stt);
      if (rd) parts.push(`${rd}${ab.hits > 1 ? '×' + ab.hits : ''}${ab.multi ? ' ×' + ab.multi + ' (' + Math.round((ab.multiDmg || 1) * 100) + '%)' : ''} dany`);
      if (ab.cd >= 0.5) parts.push(`${ab.cd} s`);
      if (ab.mana) parts.push(`${ab.mana} manà`);
      if (ab.radius) parts.push(`radi ${ab.radius} m`);
      if (ab.dur && ab.kind !== 'transform') parts.push(`${ab.dur} s de durada`);
      if (ab.leech) parts.push('🩸 cura ' + Math.round(ab.leech * 100) + '%');
      return parts.join(' · ');
    };
    const render = () => {
      const s = g.save; const cl = c(); tab = this._grimTab;
      const slots = activeSlots(s).slice();
      const spLeft = skillPointsTotal(s.level) - skillSpent(s.skills);
      if (cl.melee && tab === 'spells') tab = this._grimTab = 'abil';
      const tabs = `<div class="tabs">${[['tree', `🌳 Branques${spLeft > 0 ? ` (${spLeft})` : ''}`], ['abil', cl.melee ? '⚔️ Habilitats i runes' : '✦ Habilitats i runes'], ...(cl.melee ? [] : [['spells', '📜 Encanteris propis']]), ['sets', '💾 Conjunts guardats']].map(([k, n]) => `<button class="pbtn ${tab === k ? 'sel' : ''}" data-tab="${k}">${n}</button>`).join('')}</div>`;
      let html = '';
      if (tab === 'tree') {
        const trees = SKILL_TREES[s.cls] || [];
        html += `<div class="ptsbox"><div class="${spLeft > 0 ? 'hot' : ''}"><b>${spLeft}</b>punts d'habilitat per gastar</div><div><b>${skillSpent(s.skills)}</b>punts gastats</div><div><b>${s.level < 20 ? s.level + 1 : '—'}</b>proper punt al nivell</div></div>
          <p class="hint">Guanyes 1 punt d'habilitat cada nivell. Cada fila s'obre en arribar al nivell indicat i quan tens prou punts a la branca. A la 3a fila aprens una habilitat nova i la 5a és la millora definitiva.</p>
          <div class="trees">${trees.map((t) => {
            const bs = branchSpent(s.skills, s.cls, t.id);
            return `<div class="tree"><h3>${t.icon} ${esc(t.name)} <small style="color:var(--dim);font-size:12px">· ${bs} punts</small></h3><div class="tdesc">${esc(t.desc)}</div>
              ${t.nodes.map((n) => {
                const r = (s.skills && s.skills[n.id]) | 0;
                const why = canLearn(s, n.id);
                const cls = [r ? 'has' : '', r >= n.max ? 'max' : '', !why ? 'can' : '', why && !r ? 'lock' : '', n.tier === 5 ? 'cap' : ''].join(' ');
                const req = s.level < TIER_LVL[n.tier] ? `Nivell ${TIER_LVL[n.tier]}` : bs < TIER_PTS[n.tier] ? `${TIER_PTS[n.tier]} punts a la branca` : '';
                return `<div class="tier"><div class="tl">Nv ${TIER_LVL[n.tier]}</div><button class="node ${cls}" data-node="${n.id}" title="${esc(why || 'Clica per aprendre')}"><span class="ni">${n.icon}</span><b>${esc(n.name)} <span class="rk">${r}/${n.max}</span></b><small>${esc(n.desc)}${req && !r ? ` <i style="color:#ff9f9f">· ${req}</i>` : ''}</small></button></div>`;
              }).join('')}</div>`;
          }).join('')}</div>
          <div class="row" style="margin-top:10px"><button class="pbtn ghost" data-sreset ${skillSpent(s.skills) ? '' : 'disabled'} style="padding:6px 12px">Reiniciar branques</button></div>`;
      } else if (tab === 'abil') {
        const max = s.level >= RUNE_SLOT2_LVL ? 2 : 1;
        const rows = [['basic', cl.basic, 'Clic'], ...slots.map((k, i) => ['s' + i, k, String(i + 1)]), ['ult', cl.ult, 'R']];
        html += `<p class="hint">Cada habilitat accepta ${max === 2 ? 'dues runes' : `una runa (la segona ranura s'obre al nivell ${RUNE_SLOT2_LVL})`}. Les runes canvien el dany, la recàrrega, l'àrea o l'element. Tria també quina habilitat va a cada tecla.</p>`;
        html += rows.map(([rk, key, kb]) => {
          const ab = abilityFor(s, key);
          if (!ab) return '';
          const runes = validRunes(ab, s.runes && s.runes[key], s.level);
          const choose = rk.startsWith('s') ? `<select data-slot="${rk.slice(1)}">${slotChoices(s).map((k) => `<option value="${k}" ${k === key ? 'selected' : ''}>${AB_ICON[k] || '✦'} ${esc(k === 'custom' ? buildCustomAbility(s.custom).name : ABILITIES[k].name)}</option>`).join('')}</select>` : '';
          const rs = [0, 1].map((i) => {
            if (i >= max) return `<button class="rslot lock" disabled>🔒 Nv ${RUNE_SLOT2_LVL}</button>`;
            const r = runes[i];
            const on = pick && pick.key === key && pick.slot === i;
            return `<button class="rslot ${r ? 'on' : ''}" data-rk="${key}" data-ri="${i}" style="${on ? 'outline:2px solid #ffd166' : ''}">${r ? RUNES[r].icon + ' ' + RUNES[r].name : '+ Runa'}</button>`;
          }).join('');
          return `<div class="grim-row"><div class="ic">${AB_ICON[key] || '✦'}</div><div><div class="nm"><kbd>${kb}</kbd> ${esc(ab.name)} ${choose}</div><div class="st">${esc(statLine(ab))}</div></div><div class="rslots">${rs}</div></div>`;
        }).join('');
        if (pick) {
          const base = pick.key === 'custom' ? buildCustomAbility(s.custom) : ABILITIES[pick.key];
          const cur = validRunes(base, s.runes && s.runes[pick.key], s.level);
          html += `<div class="card"><h3>Tria una runa per a ${esc(base.name)}</h3><div class="runepick">
            <button data-rune="">✖ <b>Cap runa</b>Treu la runa d'aquesta ranura.</button>
            ${Object.entries(RUNES).map(([rid, R]) => {
              const ok = R.kinds.includes(base.kind);
              const lockLv = s.level < R.lvl;
              const dup = cur.includes(rid) && cur[pick.slot] !== rid;
              const elDup = R.el && cur.some((x, j) => j !== pick.slot && RUNES[x] && RUNES[x].el);
              const dis = !ok || lockLv || dup || elDup;
              return `<button data-rune="${rid}" ${dis ? 'disabled' : ''}><b>${R.icon} ${R.name}${lockLv ? ` · Nv ${R.lvl}` : ''}</b>${esc(!ok ? 'No serveix per a aquesta habilitat.' : R.desc)}</button>`;
            }).join('')}</div></div>`;
        }
      } else if (tab === 'spells') {
        const spec = this._spec || (this._spec = { form: 'projectil', el: cl.element === 'arca' ? 'arca' : cl.element, pow: 1, name: '', ...(s.custom || {}) });
        const ab = buildCustomAbility(spec);
        html += `<p class="hint">Crea encanteris combinant forma, element i potència. En pots guardar fins a ${MAX_GRIMORI} al teu grimori i equipar-ne un a qualsevol tecla.</p>
        <div class="grid2">
          <div style="display:flex;flex-direction:column;gap:10px">
            <input class="txt" id="spName" maxlength="24" placeholder="Nom de l'encanteri" value="${esc(spec.name || '')}">
            <div><div class="hint">Forma</div><div class="tabs">${Object.entries(CUSTOM_FORMS).map(([k, f]) => `<button class="pbtn ${spec.form === k ? 'sel' : ''}" data-f="${k}">${f.name}</button>`).join('')}</div></div>
            <div><div class="hint">Element</div><div class="tabs">${Object.keys(CUSTOM_ELEMENTS).map((k) => `<button class="pbtn ${spec.el === k ? 'sel' : ''}" data-e="${k}" style="color:${ELEMENTS[k].color}">${ELEMENTS[k].icon} ${ELEMENTS[k].name}</button>`).join('')}</div></div>
            <div><div class="hint">Potència</div><div class="tabs">${CUSTOM_POWER.map((p, i) => `<button class="pbtn ${spec.pow === i ? 'sel' : ''}" data-p="${i}">${p.name}</button>`).join('')}</div></div>
          </div>
          <div class="card" style="border-color:${ELEMENTS[spec.el].color}">
            <h3 style="color:${ELEMENTS[spec.el].color}">✦ ${esc(spec.name || ab.name)}</h3>
            <p>${esc(ab.desc)}</p>
            <div class="stats"><span>Dany base</span><b>${ab.dmg}${ab.hits > 1 ? ' ×' + ab.hits : ''}</b><span>Recàrrega</span><b>${ab.cd} s</b><span>Manà</span><b>${ab.mana}</b>${ab.radius ? `<span>Radi</span><b>${ab.radius} m</b>` : ''}${ab.range ? `<span>Abast</span><b>${ab.range} m</b>` : ''}</div>
            <div class="row"><button class="pbtn gold" data-gsave="-1" ${(s.grimori || []).length >= MAX_GRIMORI ? 'disabled' : ''}>Guardar al grimori</button>${this._specIdx >= 0 ? `<button class="pbtn" data-gsave="${this._specIdx}">Sobreescriure</button>` : ''}</div>
          </div>
        </div>
        <h3 style="color:var(--gold2);margin:14px 0 8px">El teu grimori (${(s.grimori || []).length}/${MAX_GRIMORI})</h3>
        ${(s.grimori || []).length ? '' : '<p class="hint">Encara no hi has guardat cap encanteri.</p>'}
        <div class="shop">${(s.grimori || []).map((sp, i) => { const a2 = buildCustomAbility(sp); const eq = s.custom && JSON.stringify(s.custom) === JSON.stringify(sp); return `<div class="card" style="border-color:${ELEMENTS[a2.el].color}55"><h3>${ELEMENTS[a2.el].icon} ${esc(sp.name)}${eq ? ' <small style="color:#7ef0a0">· equipat</small>' : ''}</h3><p>${esc(a2.desc)}</p><p>${a2.dmg} dany · ${a2.cd} s · ${a2.mana} manà</p>
          <div class="hint">Equipar a la tecla:</div><div class="tabs" style="margin:2px 0">${[0, 1, 2, 3].map((k) => `<button class="pbtn" data-guse="${i}" data-gslot="${k}" style="padding:5px 10px">${k + 1}</button>`).join('')}</div>
          <div class="row"><button class="pbtn ghost" data-gedit="${i}" style="padding:6px 10px">Editar</button><button class="pbtn ghost" data-gdel="${i}" style="padding:6px 10px">Esborrar</button></div></div>`; }).join('')}</div>`;
      } else {
        const L = s.loadouts || [];
        html += `<p class="hint">Un conjunt guarda quines habilitats tens a cada tecla, les runes de cada habilitat i l'encanteri propi equipat. En pots tenir ${MAX_LOADOUTS} i canviar-hi en qualsevol moment.</p>
        <div class="row" style="margin:8px 0 14px"><input class="txt" id="loName" maxlength="20" placeholder="Nom del conjunt (p. ex. Caps, Multitud…)" style="flex:1"><button class="pbtn gold" data-lsave="-1" ${L.length >= MAX_LOADOUTS ? 'disabled' : ''}>Desar el conjunt actual</button></div>
        ${L.length ? '' : '<p class="hint">Encara no tens cap conjunt guardat.</p>'}
        <div class="shop">${L.map((lo, i) => {
          const sl = lo.slots || cl.abilities;
          const nR = Object.values(lo.runes || {}).reduce((a, b) => a + (b ? b.length : 0), 0);
          return `<div class="card"><h3>💾 ${esc(lo.name)}</h3><p>${sl.map((k) => (AB_ICON[k] || '✦')).join(' ')} · ${nR} runes${lo.custom ? ' · ✦ ' + esc(lo.custom.name || '') : ''}</p>
          <div class="row"><button class="pbtn gold" data-lload="${i}" style="padding:6px 12px">Equipar</button><button class="pbtn ghost" data-lsave="${i}" style="padding:6px 10px">Sobreescriure</button><button class="pbtn ghost" data-ldel="${i}" style="padding:6px 10px">Esborrar</button></div></div>`;
        }).join('')}</div>`;
      }
      const body = this.openModal(`<h2>📖 Grimori</h2>${tabs}${html}`, 'grim');
      body.querySelectorAll('[data-tab]').forEach((b) => { b.onclick = () => { this._grimTab = b.dataset.tab; pick = null; render(); }; });
      // branques
      body.querySelectorAll('[data-node]').forEach((b) => { b.onclick = () => { const why = canLearn(g.save, b.dataset.node); if (why) { this.toast(why, 'warn'); g.audio.play('deny'); return; } send({ a: 'skill', id: b.dataset.node }); }; });
      const sr = body.querySelector('[data-sreset]'); if (sr) sr.onclick = () => { if (sr.dataset.sure) send({ a: 'skillReset' }); else { sr.dataset.sure = 1; sr.textContent = 'Clica una altra vegada per confirmar'; } };
      // habilitats
      body.querySelectorAll('select[data-slot]').forEach((sel) => { sel.onchange = () => { const sl = slots.slice(); const i = +sel.dataset.slot; const j = sl.indexOf(sel.value); if (j >= 0 && j !== i) sl[j] = sl[i]; sl[i] = sel.value; send({ a: 'slots', slots: sl }); }; });
      body.querySelectorAll('[data-rk]').forEach((b) => { b.onclick = () => { pick = { key: b.dataset.rk, slot: +b.dataset.ri }; render(); }; });
      body.querySelectorAll('[data-rune]').forEach((b) => { b.onclick = () => {
        const base = pick.key === 'custom' ? buildCustomAbility(g.save.custom) : ABILITIES[pick.key];
        const cur = validRunes(base, g.save.runes && g.save.runes[pick.key], g.save.level).slice();
        if (b.dataset.rune) cur[pick.slot] = b.dataset.rune; else cur.splice(pick.slot, 1);
        send({ a: 'runes', key: pick.key, runes: cur.filter(Boolean) }); pick = null;
      }; });
      // encanteris propis
      const spec = this._spec;
      const sn = body.querySelector('#spName'); if (sn) sn.oninput = (e) => { spec.name = e.target.value; };
      body.querySelectorAll('[data-f]').forEach((b) => { b.onclick = () => { spec.form = b.dataset.f; render(); }; });
      body.querySelectorAll('[data-e]').forEach((b) => { b.onclick = () => { spec.el = b.dataset.e; render(); }; });
      body.querySelectorAll('[data-p]').forEach((b) => { b.onclick = () => { spec.pow = +b.dataset.p; render(); }; });
      body.querySelectorAll('[data-gsave]').forEach((b) => { b.onclick = () => { send({ a: 'grimori', op: 'save', idx: +b.dataset.gsave, spec: { ...spec, name: spec.name || buildCustomAbility(spec).name } }); this.toast('Encanteri guardat al grimori'); }; });
      body.querySelectorAll('[data-gedit]').forEach((b) => { b.onclick = () => { const i = +b.dataset.gedit; this._spec = { ...g.save.grimori[i] }; this._specIdx = i; render(); }; });
      body.querySelectorAll('[data-gdel]').forEach((b) => { b.onclick = () => { send({ a: 'grimori', op: 'del', idx: +b.dataset.gdel }); this._specIdx = -1; }; });
      body.querySelectorAll('[data-guse]').forEach((b) => { b.onclick = () => {
        const sl = slots.map((x, j) => (x === 'custom' ? c().abilities[j] : x)); sl[+b.dataset.gslot] = 'custom';
        send({ a: 'grimori', op: 'use', idx: +b.dataset.guse, slots: sl }); this.toast('Encanteri equipat a la tecla ' + (+b.dataset.gslot + 1));
      }; });
      // conjunts
      body.querySelectorAll('[data-lsave]').forEach((b) => { b.onclick = () => { const nm = (body.querySelector('#loName') || {}).value; const i = +b.dataset.lsave; send({ a: 'loadout', op: 'save', idx: i, name: nm || (i >= 0 && g.save.loadouts[i] ? g.save.loadouts[i].name : '') || `Conjunt ${(g.save.loadouts || []).length + 1}` }); this.toast('Conjunt desat'); }; });
      body.querySelectorAll('[data-lload]').forEach((b) => { b.onclick = () => send({ a: 'loadout', op: 'load', idx: +b.dataset.lload }); });
      body.querySelectorAll('[data-ldel]').forEach((b) => { b.onclick = () => send({ a: 'loadout', op: 'del', idx: +b.dataset.ldel }); });
    };
    this._specIdx = -1; this._spec = null;
    render();
    this.refresh = render;
  }

  openEditorOld() {
    const g = this.g; const s = g.save; const c = CLASSES[s.cls];
    const spec = { form: 'projectil', el: c.element === 'arca' ? 'arca' : c.element, pow: 1, name: '', ...(s.custom || {}) };
    let slots = (s.slots && s.slots.length === 4 ? s.slots : c.abilities).slice();
    const render = () => {
      const ab = buildCustomAbility(spec);
      const body = this.openModal(`<h2>Editor d'encanteris</h2>
        <p class="hint">Combina una forma, un element i una potència. Després tria en quina tecla el vols (substitueix una habilitat de classe).</p>
        <div class="grid2">
          <div style="display:flex;flex-direction:column;gap:10px">
            <input class="txt" id="spName" maxlength="24" placeholder="Nom de l'encanteri" value="${esc(spec.name || '')}">
            <div><div class="hint">Forma</div><div class="tabs">${Object.entries(CUSTOM_FORMS).map(([k, f]) => `<button class="pbtn ${spec.form === k ? 'sel' : ''}" data-f="${k}">${f.name}</button>`).join('')}</div></div>
            <div><div class="hint">Element</div><div class="tabs">${Object.keys(CUSTOM_ELEMENTS).map((k) => `<button class="pbtn ${spec.el === k ? 'sel' : ''}" data-e="${k}" style="color:${ELEMENTS[k].color}">${ELEMENTS[k].icon} ${ELEMENTS[k].name}</button>`).join('')}</div></div>
            <div><div class="hint">Potència</div><div class="tabs">${CUSTOM_POWER.map((p, i) => `<button class="pbtn ${spec.pow === i ? 'sel' : ''}" data-p="${i}">${p.name}</button>`).join('')}</div></div>
          </div>
          <div class="card" style="border-color:${ELEMENTS[spec.el].color}">
            <h3 style="color:${ELEMENTS[spec.el].color}">✦ ${esc(ab.name)}</h3>
            <p>${esc(ab.desc)}</p>
            <div class="stats"><span>Dany base</span><b>${ab.dmg}${ab.hits > 1 ? ' ×' + ab.hits : ''}</b><span>Recàrrega</span><b>${ab.cd} s</b><span>Manà</span><b>${ab.mana}</b>${ab.radius ? `<span>Radi</span><b>${ab.radius} m</b>` : ''}${ab.range ? `<span>Abast</span><b>${ab.range} m</b>` : ''}</div>
            <div class="hint" style="margin-top:8px">Col·loca'l a la tecla:</div>
            <div class="tabs">${[0, 1, 2, 3].map((i) => `<button class="pbtn ${slots[i] === 'custom' ? 'sel' : ''}" data-s="${i}">${i + 1}: ${slots[i] === 'custom' ? '✦' : (AB_ICON[slots[i]] || '') + ' ' + (ABILITIES[slots[i]] ? ABILITIES[slots[i]].name : '')}</button>`).join('')}</div>
            <button class="pbtn ghost" data-reset>Restaurar habilitats de classe</button>
          </div>
        </div>
        <div class="row" style="margin-top:14px"><button class="pbtn gold" data-save>Desar l'encanteri</button></div>`);
      body.querySelector('#spName').oninput = (e) => { spec.name = e.target.value; };
      body.querySelectorAll('[data-f]').forEach((b) => { b.onclick = () => { spec.form = b.dataset.f; render(); }; });
      body.querySelectorAll('[data-e]').forEach((b) => { b.onclick = () => { spec.el = b.dataset.e; render(); }; });
      body.querySelectorAll('[data-p]').forEach((b) => { b.onclick = () => { spec.pow = +b.dataset.p; render(); }; });
      body.querySelectorAll('[data-s]').forEach((b) => { b.onclick = () => { const i = +b.dataset.s; slots = slots.map((x, j) => (x === 'custom' ? c.abilities[j] : x)); slots[i] = 'custom'; render(); }; });
      body.querySelector('[data-reset]').onclick = () => { slots = c.abilities.slice(); render(); };
      body.querySelector('[data-save]').onclick = () => {
        g.net.send('npc', { npc: 'elna', a: 'custom', spec: { ...spec, name: spec.name || ab.name }, slots });
        g.audio.play('quest'); this.toast('Encanteri desat!', '');
        setTimeout(() => { g.ui.buildBar(g.save); }, 250);
        this.closeModal();
      };
    };
    render();
  }

  openOptions(inGame) {
    const g = this.g; const st = g.settings;
    const body = this.openModal(`<h2>${inGame ? 'Pausa' : 'Opcions'}</h2>
      <div class="grid2" style="margin-top:12px">
        <div>
          <div class="opt"><span>Qualitat gràfica</span><select class="txt" id="oQ"><option value="baixa">Baixa</option><option value="mitjana">Mitjana</option><option value="alta">Alta</option></select></div>
          <div class="opt"><span>Sensibilitat del ratolí</span><input type="range" id="oS" min="0.3" max="2.5" step="0.05" value="${st.sens}"></div>
          <div class="opt"><span>Invertir eix vertical</span><input type="checkbox" id="oI" ${st.invertY ? 'checked' : ''}></div>
          <div class="opt"><span>Volum dels efectes</span><input type="range" id="oV" min="0" max="1" step="0.05" value="${st.sfx}"></div>
          <div class="opt"><span>Volum de la música</span><input type="range" id="oM" min="0" max="1" step="0.05" value="${st.music}"></div>
          <div class="opt"><span>Mostrar FPS</span><input type="checkbox" id="oF" ${st.fps ? 'checked' : ''}></div>
          <p class="hint">La densitat del bosc i de l'herba canvia en tornar a carregar la pàgina.</p>
          ${inGame ? `<div class="row" style="margin-top:10px"><button class="pbtn gold" data-resume>Continuar</button>${g.room ? '<button class="pbtn" data-room>Tornar a la sala</button>' : ''}${g.room && g.room.leader === g.myId ? '<button class="pbtn" data-endall>Acabar per a tothom</button>' : ''}<button class="pbtn ghost" data-leave>${g.room ? 'Sortir de la sala' : 'Sortir al menú'}</button></div>` : ''}
        </div>
        <div>
          <h3 style="color:var(--gold2);font-size:15px;margin-bottom:8px">Controls</h3>
          <div class="keys">
            <kbd>WASD</kbd><span>Moure's</span><kbd>Ratolí</kbd><span>Girar la càmera</span><kbd>Clic</kbd><span>Atac bàsic</span><kbd>Clic dret</kbd><span>Bloquejar</span>
            <kbd>1-4</kbd><span>Habilitats (les de zona: mantén i deixa anar)</span><kbd>R</kbd><span>Transformació (aura plena)</span><kbd>Espai</kbd><span>Saltar, doble salt, mantenir per planar</span>
            <kbd>Maj</kbd><span>Córrer</span><kbd>Q</kbd><span>Esquivar</span><kbd>F</kbd><span>Interactuar / reviure</span><kbd>Tab</kbd><span>Fixar objectiu</span>
            <kbd>G / H</kbd><span>Pocions de vida / manà</span><kbd>I</kbd><span>Inventari</span><kbd>C</kbd><span>Personatge i talents</span><kbd>K</kbd><span>Grimori: branques, runes, encanteris i conjunts</span><kbd>M</kbd><span>Mapa</span><kbd>Enter</kbd><span>Xat</span><kbd>T</kbd><span>Ballar</span>
          </div>
        </div>
      </div>`);
    body.querySelector('#oQ').value = st.quality;
    const save = () => { g.saveSettings(); };
    body.querySelector('#oQ').onchange = (e) => { st.quality = e.target.value; save(); if (g.applyQuality) g.applyQuality(); };
    body.querySelector('#oS').oninput = (e) => { st.sens = +e.target.value; save(); };
    body.querySelector('#oI').onchange = (e) => { st.invertY = e.target.checked; save(); };
    body.querySelector('#oV').oninput = (e) => { st.sfx = +e.target.value; g.audio.setVolumes(st.sfx, st.music); save(); };
    body.querySelector('#oM').oninput = (e) => { st.music = +e.target.value; g.audio.setVolumes(st.sfx, st.music); save(); };
    body.querySelector('#oF').onchange = (e) => { st.fps = e.target.checked; save(); };
    const r = body.querySelector('[data-resume]'); if (r) r.onclick = () => this.closeModal();
    const l = body.querySelector('[data-leave]'); if (l) l.onclick = () => { this.closeModal(); g.leaveGame(); };
    const rb = body.querySelector('[data-room]'); if (rb) rb.onclick = () => { this.closeModal(); g.remote.roomBack(); };
    const ea = body.querySelector('[data-endall]'); if (ea) ea.onclick = () => { this.closeModal(); g.remote.roomEnd(); };
  }

  credits() {
    this.openModal(`<h2>Crèdits</h2>
      <div style="line-height:1.7;margin-top:12px">
      <b>Joc i codi:</b> creat amb Claude per a tu.<br>
      <b>Herois:</b> els teus personatges de VRoid Studio.<br>
      <b>Animacions:</b> Mixamo (Adobe) i Universal Animation Library de Quaternius (CC0).<br>
      <b>Monstres:</b> Bestiary – Dungeon Monsters Kit de Quaternius i KayKit Skeletons de Kay Lousberg (CC0).<br>
      <b>Natura:</b> Stylized Nature MegaKit de Quaternius (CC0).<br>
      <b>Vila, ruïnes i armes:</b> KayKit Medieval Hexagon, Dungeon Remastered i Adventurers de Kay Lousberg (CC0).<br>
      <b>Cases i fortaleses:</b> Medieval Village MegaKit de Quaternius (CC0).<br>
      <b>Drac:</b> «Dragon» de Bernardo Ferreira Baptista (CC BY 4.0, Sketchfab).<br>
      <b>Gòlems:</b> «Golem Rigged» de FourthGreen (CC BY 4.0, Sketchfab).<br>
      <b>Esquelets guerrers i piromants:</b> «D&amp;D Heroes (2003) – Skeleton» de Ziggertron (CC BY 4.0, Sketchfab).<br>
      <b>Ganfaul i bruixots:</b> personatge de Mixamo (Adobe).<br>
      <b>Motor:</b> three.js i three-vrm (MIT).<br>
      <b>Música i sons:</b> generats en temps real amb Web Audio.
      </div>`);
  }

  pvpBoard(info, me) {
    if (!info) return;
    const mode = info.mode || 'pvp';
    const row = (p) => `<div>${p.id === me ? '▶ ' : ''}${esc(p.name)} — ${p.k}/${p.d}</div>`;
    this.toastQ = [];
    if (mode === 'ffa') {
      const list = [...info.players].sort((a, b) => b.k - a.k);
      $('#quests').innerHTML = `<h3>💥 Tots contra tots · primer a ${info.target}</h3>${list.map((p, i) => `<div class="mrow"><span>${i + 1}. ${p.id === me ? '<b>' + esc(p.name) + '</b>' : esc(p.name)}</span><b>${p.k} / ${p.d}</b></div>`).join('')}`;
    } else if (mode === 'turo') {
      const a = info.scores[1] || 0, b = info.scores[2] || 0;
      const zt = info.zone === 1 ? '<span style="color:#7fc0ff">Blau té el turó</span>' : info.zone === 2 ? '<span style="color:#ff8f8f">Vermell té el turó</span>' : info.zone === -1 ? 'Turó disputat!' : 'Turó lliure: entra al cercle';
      $('#quests').innerHTML = `<h3>🚩 Rei del turó · ${info.target} punts</h3><div class="hillbar"><i style="width:${a}%;background:#4da3ff"></i></div><div class="mrow"><span style="color:#7fc0ff">Blau</span><b>${a}</b></div><div class="hillbar"><i style="width:${b}%;background:#ff5a5a"></i></div><div class="mrow"><span style="color:#ff8f8f">Vermell</span><b>${b}</b></div><div class="hint" style="margin-top:4px">${zt}</div>`;
    } else {
      const t1 = info.players.filter((p) => p.team === 1), t2 = info.players.filter((p) => p.team === 2);
      $('#quests').innerHTML = `<h3>⚔️ Arena · primer a ${info.target}</h3><div class="score"><div class="team1"><b>Blau ${info.scores[1] || 0}</b>${t1.map(row).join('')}</div><div class="team2"><b>Vermell ${info.scores[2] || 0}</b>${t2.map(row).join('')}</div></div>`;
    }
    this._qHtml = '';
  }

  // tauler de les partides contra monstres
  matchPanel(m, me) {
    if (!m) return;
    if (m.mode === 'parkour') return this.racePanel(m, me);
    const M = MODES[m.mode] || {};
    const tm = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
    let big = '', rows = '';
    if (m.state === 'countdown') big = `Comença en ${Math.ceil(m.time)}`;
    else if (m.mode === 'hordes') { big = `Onada ${m.wave}`; rows = `<div class="mrow"><span>Enemics</span><b>${m.left}</b></div><div class="mrow"><span>Temps</span><b>${tm(m.time)}</b></div><div class="mrow"><span>Morts</span><b>${m.kills}</b></div>${m.boss ? `<div class="mrow"><span>Cap</span><b>${esc(m.boss)}</b></div>` : ''}`; }
    else if (m.mode === 'caps') { big = `Cap ${Math.min(m.total, m.bosses + 1)} / ${m.total}`; rows = `<div class="mrow"><span>${esc(m.boss || '')}</span><b></b></div><div class="mrow"><span>Temps</span><b>${tm(m.time)}</b></div>`; }
    else if (m.mode === 'crono') { big = `${m.score} punts`; rows = `<div class="mrow"><span>Temps restant</span><b style="color:${m.time < 20 ? '#ff8f8f' : '#fff'}">${tm(m.time)}</b></div><div class="mrow"><span>Morts</span><b>${m.kills}</b></div><div class="mrow"><span>Ratxa</span><b>${m.combo > 1 ? '×' + (1 + (m.combo - 1) * 0.1).toFixed(1) + ` (${m.combo})` : '—'}</b></div>`; }
    if (m.state === 'over') big = 'Partida acabada';
    $('#quests').innerHTML = `<div class="match"><h3>${M.icon || ''} ${M.name || ''}</h3><div class="mbig">${big}</div>${rows}</div>`;
    this._qHtml = '';
  }

  racePanel(m, me) {
    const M = MODES.parkour; const LV = activeLevel(); const FINISH = LV.finish, CP_NAMES = LV.names;
    const racers = m.racers || [];
    const mine = racers.find((r) => r[0] === me) || [me, 0, -1, ''];
    let big;
    if (m.state === 'countdown') big = `Comença en ${Math.ceil(m.time)}`;
    else if (m.state === 'over') big = 'Cursa acabada';
    else big = mine[2] >= 0 ? `🏁 ${fmtTime(mine[2])}` : fmtTime(m.time);
    let rows = `<div class="mrow"><span>Punt de control</span><b>${Math.min(mine[1], FINISH - 1)} / ${FINISH - 1}</b></div>`;
    if (mine[1] < FINISH && m.state === 'running') rows += `<div class="mrow"><span>Següent</span><b>${esc(CP_NAMES[mine[1] + 1] || '')}</b></div>`;
    if (m.left > 0) rows += `<div class="mrow"><span>Temps per acabar</span><b style="color:#ff8f8f">${Math.ceil(m.left)} s</b></div>`;
    if (racers.length > 1) {
      const order = [...racers].sort((a, b) => (a[2] < 0) - (b[2] < 0) || (a[2] >= 0 ? a[2] - b[2] : b[1] - a[1]));
      rows += order.map((r, i) => `<div class="mrow"><span>${i + 1}. ${r[0] === me ? '<b>' + esc(r[3]) + '</b>' : esc(r[3])}</span><b>${r[2] >= 0 ? fmtTime(r[2]) : `PC ${r[1]}/${FINISH - 1}`}</b></div>`).join('');
    }
    $('#quests').innerHTML = `<div class="match"><h3>${M.icon} Nivell ${LV.n}: ${esc(LV.name)}</h3><div class="mbig">${big}</div>${rows}</div>`;
    this._qHtml = '';
  }

  // tria del nivell de parkour (els nivells s'obren superant l'anterior)
  levelPicker(chars, onPick) {
    const best = LEVELS.map((L, i) => { let b = 0; for (const c of chars) { const R = c.records && c.records.parkour; const t = R ? (R.times ? R.times[i] : i === 0 ? R.time : 0) : 0; if (t > 0 && (!b || t < b)) b = t; } return b; });
    const open = (i) => i === 0 || best[i - 1] > 0;
    const body = this.openModal(`<h2>🏃 Parkour · tria el nivell</h2>
      <div class="hint">Supera un nivell per obrir el següent. En multijugador, el líder de la sala pot triar qualsevol nivell.</div>
      <div class="lvlist">${LEVELS.map((L, i) => `<button class="lvrow" data-lv="${L.n}" ${open(i) ? '' : 'disabled'}>
        <span class="num">${open(i) ? L.n : '🔒'}</span>
        <span><b>${esc(L.name)}<span class="st">${'★'.repeat(L.diff)}<i>${'★'.repeat(5 - L.diff)}</i></span></b><p>${open(i) ? esc(L.desc) : `Supera el nivell ${L.n - 1} (${esc(LEVELS[i - 1].name)}) per obrir-lo.`}</p></span>
        <span class="bt">${best[i] ? '🏆 ' + fmtTime(best[i]) : ''}</span></button>`).join('')}</div>`, 'dialog');
    body.querySelectorAll('[data-lv]').forEach((b) => { b.onclick = () => { this.g.audio.play('ui'); this.closeModal(); onPick(+b.dataset.lv); }; });
  }

  // resultats d'una partida
  matchResults(d, me) {
    const g = this.g; const M = MODES[d.mode] || {};
    const LV = activeLevel(); const FINISH = LV.finish;
    const mine = (d.results || []).find((r) => r.id === me) || {};
    const tm = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
    const race = d.mode === 'parkour';
    const main = race ? (mine.time !== null && mine.time !== undefined ? `Has arribat a la meta en ${fmtTime(mine.time)}${(d.results || []).length > 1 ? ` · ${mine.place}a posició` : ''}` : `Has arribat al punt de control ${mine.cp || 0} de ${FINISH - 1}`) : d.mode === 'hordes' ? `Has arribat a l'onada ${d.wave} (${d.score} superades)` : d.mode === 'caps' ? (d.win ? `Has derrotat els ${d.total} caps en ${tm(d.time)}!` : `Has derrotat ${d.bosses} de ${d.total} caps`) : `${d.score} punts amb ${d.kills} morts`;
    const finished = race && mine.time !== null && mine.time !== undefined;
    const nextLv = race && LV.n < LEVELS.length ? LEVELS[LV.n] : null;
    const leaderOrSolo = !g.room || g.room.leader === g.myId;
    const title = race ? (finished ? (mine.place === 1 && (d.results || []).length > 1 ? 'Has guanyat la cursa!' : `Nivell ${LV.n} superat!`) : 'Temps esgotat') : d.win ? (d.mode === 'crono' ? 'Temps!' : 'Victòria!') : 'Fi de la partida';
    const body = this.openModal(`<h2>${M.icon || ''} ${title}</h2>
      <div class="mbig" style="font-family:Cinzel,serif;font-size:22px;color:#ffe08a;margin-top:8px">${main}</div>
      ${mine.best ? '<div style="color:#7ef0a0;font-weight:900;margin-top:6px">🏆 Nou rècord personal!</div>' : ''}
      <div class="results">${(d.results || []).map((r, i) => `<div class="rr"><span>${race ? `${i + 1}. ` : ''}${r.id === me ? '▶ ' : ''}${esc(r.name)}${r.best ? ' 🏆' : ''}${race ? ` · ${r.time !== null && r.time !== undefined ? fmtTime(r.time) : `${r.cp}/${FINISH - 1}`}` : ''}</span><b>+${r.gold} 🪙 · +${r.xp} XP</b></div>`).join('')}</div>
      ${race ? (finished && nextLv && !g.room ? `<div style="color:#7ef0a0;font-weight:900;margin-top:6px">🔓 Nivell ${nextLv.n} obert: ${esc(nextLv.name)}</div>` : '') : '<div class="hint">També has guanyat l\'XP, l\'or i els objectes de cada enemic.</div>'}
      ${g.room && g.room.leader !== g.myId ? '<div class="hint" data-results>El líder (👑) decideix si torneu a jugar o si torneu tots a la sala.</div>' : ''}
      <div class="row" style="margin-top:12px" data-results>${nextLv && leaderOrSolo && (finished || g.room) ? `<button class="pbtn gold" data-next>Nivell següent: ${esc(nextLv.name)}</button>` : ''}${leaderOrSolo ? `<button class="pbtn ${nextLv && (finished || g.room) ? '' : 'gold'}" data-again>${race ? 'Repetir el nivell' : 'Tornar a jugar'}</button>` : ''}${g.room ? `<button class="pbtn" data-toroom>${g.room.leader === g.myId ? 'Tornar tots a la sala' : 'Tornar a la sala'}</button>` : ''}<button class="pbtn ghost" data-out>${g.room ? 'Sortir de la sala' : 'Sortir al menú'}</button></div>`, 'dialog');
    const ag = body.querySelector('[data-again]'); if (ag) ag.onclick = () => { g.net.send('match', { a: 'restart' }); this.closeModal(); };
    const nx = body.querySelector('[data-next]'); if (nx) nx.onclick = () => { g.net.send('match', { a: 'restart', level: nextLv.n }); this.closeModal(); };
    const tr = body.querySelector('[data-toroom]'); if (tr) tr.onclick = () => { this.closeModal(); if (g.room.leader === g.myId) g.remote.roomEnd(); else g.remote.roomBack(); };
    body.querySelector('[data-out]').onclick = () => { this.closeModal(); g.leaveGame(); };
  }

}
