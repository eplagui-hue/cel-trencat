// ============================================================
//  CEL TRENCAT — bucle principal del client
// ============================================================
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { loadAll, OUTLINE } from './assets.js';
import { World } from './world.js';
import { FX } from './fx.js';
import { HeroAvatar, MonsterAvatar } from './characters.js';
import { Input, LocalPlayer } from './player.js';
import { UI, AB_ICON, CLS_ICON } from './ui.js';
import { Audio } from './audio.js';
import { LocalServer, RemoteServer, serverAvailable } from './net.js';
import { P2PNet, artifactRoom } from './p2p.js';
import { LEVELS, getLevel, setLevel, activeLevel, platformState, setCourseTime, resetCrumbles, fmtTime } from './parkour.js';
import { MODES, CLASSES, ABILITIES, ELEMENTS, ENEMIES, STORY, NPCS, SKINS, RARITIES, BOUNTIES, buildCustomAbility, abilityFor, activeSlots, newCharacter, computeStats, GAME_VERSION } from './data.js';
import { groundAt, height, zoneAt, ISLAND, LAUNCHPADS, WAYSTONES, ZONE } from './worldgen.js';
import { questTarget } from './guide.js';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SAVE_KEY = 'celtrencat_saves_v1';
const SET_KEY = 'celtrencat_settings_v1';
const TIPS = [
  'Combina elements: el gel sobre un enemic cremat fa una explosió de vapor.',
  'Mantén Espai a l\'aire per planar. Les illes del cel t\'esperen.',
  'Esquiva amb Q just abans d\'un cop: durant la voltereta ets invulnerable.',
  'Quan l\'aura s\'omple, prem R per transformar-te.',
  'Els cofres antics de les Ruïnes amaguen cristalls d\'aura.',
  'Bloqueja amb el clic dret: redueix molt el dany frontal.',
  'Prem F a prop d\'un company caigut per reviure\'l.',
  'La Sàvia Elna et deixa crear els teus propis encanteris.',
];
const QUALITY = {
  baixa: { pr: 0.75, shadows: false, shadowRes: 1024, trees: 0.5, grass: 0.35, bloom: false, detail: 0.5 },
  mitjana: { pr: 1, shadows: true, shadowRes: 1024, trees: 0.8, grass: 0.75, bloom: true, detail: 0.8 },
  alta: { pr: 1.5, shadows: true, shadowRes: 2048, trees: 1, grass: 1, bloom: true, detail: 1 },
};

class Game {
  constructor() {
    let stored = {};
    try { stored = JSON.parse(localStorage.getItem(SET_KEY) || '{}') || {}; } catch { stored = {}; }
    this.settings = { quality: 'mitjana', sens: 1, invertY: false, sfx: 0.6, music: 0.35, fps: false, server: '', ...stored };
    if (!QUALITY[this.settings.quality]) this.settings.quality = 'mitjana';
    this.q = QUALITY[this.settings.quality];
    OUTLINE.enabled = this.settings.quality !== 'baixa';
    OUTLINE.aspect.value = innerHeight / innerWidth;
    const canvas = $('#c');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: this.q.pr >= 1, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.q.pr));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = this.q.shadows;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.info.autoReset = false;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 3000);
    this.camera.position.set(30, 20, 40);
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    if (this.q.bloom) { this.bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), 0.42, 0.45, 0.9); this.composer.addPass(this.bloom); }
    this.composer.addPass(new OutputPass());
    addEventListener('resize', () => this.resize());
    this.input = new Input(canvas);
    this.ui = new UI(this);
    this.audio = new Audio();
    this.audio.setVolumes(this.settings.sfx, this.settings.music);
    this.lastFrame = performance.now();
    this.now = 0;
    this.others = new Map();
    this.enemies = new Map();
    this.einfo = new Map();
    this.lootObjs = new Map();
    this.state = 'loading';
    this.serverT = 0; this.renderT = 0;
    this.saves = this.loadSaves();
    this.fpsT = 0; this.frames = 0;
    document.addEventListener('pointerdown', () => this.audio.init(), { once: false });
    // si es perd el bloqueig del ratolí (Esc) durant la partida, obre el menú de pausa
    document.addEventListener('pointerlockchange', () => {
      if (document.pointerLockElement || this.state !== 'playing' || !this.player || this.player.dead) return;
      setTimeout(() => { if (!document.pointerLockElement && this.state === 'playing' && !this.ui.modalOpen() && !this.player.dead) this.ui.openOptions(true); }, 60);
    });
  }

  resize() {
    OUTLINE.aspect.value = innerHeight / innerWidth;
    this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight); this.composer.setSize(innerWidth, innerHeight);
  }
  // aplica en calent el que es pot canviar sense recarregar (la densitat del bosc i l'herba requereixen recarregar)
  applyQuality() {
    const q = QUALITY[this.settings.quality] || QUALITY.mitjana;
    this.q = q;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q.pr));
    if (this.renderer.shadowMap.enabled !== q.shadows) {
      this.renderer.shadowMap.enabled = q.shadows;
      if (this.world && this.world.sun) this.world.sun.castShadow = q.shadows;
      this.scene.traverse((o) => { if (o.material) for (const m of (Array.isArray(o.material) ? o.material : [o.material])) m.needsUpdate = true; });
    }
    if (q.bloom && !this.bloom) {
      this.bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), 0.42, 0.45, 0.9);
      this.composer.insertPass(this.bloom, 1);
    }
    if (this.bloom) this.bloom.enabled = q.bloom;
    this.resize();
  }
  saveSettings() { try { localStorage.setItem(SET_KEY, JSON.stringify(this.settings)); } catch { /* sense emmagatzematge */ } }
  loadSaves() {
    try { const s = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}'); s.chars = Array.isArray(s.chars) ? s.chars : []; s.token = s.token || (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2)); return s; }
    catch { return { chars: [], token: String(Math.random()).slice(2) }; }
  }
  persist() {
    if (this.save) {
      const i = this.saves.chars.findIndex((c) => c.created === this.save.created);
      if (i >= 0) this.saves.chars[i] = this.save; else this.saves.chars.push(this.save);
    }
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.saves)); } catch (e) { console.warn(e); }
  }

  // ------------------------------------------------------------------ arrencada
  async boot() {
    this.ui.tip(TIPS[Math.floor(Math.random() * TIPS.length)]);
    this.loop();
    try {
      await loadAll((p, l) => this.ui.loading(p * 0.7, 'Carregant ' + l + '…'));
      this.world = new World(this.renderer, this.scene, { ...this.q });
      await this.world.build((p, l) => this.ui.loading(0.7 + p * 0.3, l + '…'));
      this.fx = new FX(this.scene, $('#dmgLayer'));
      this.fx.followPos = (id) => { const av = this.avatarOf(id); return av ? av.obj.position : null; };
      this.fx.onShake = (s, pos) => { if (this.player && pos && this.player.pos.distanceTo(pos) < 30) this.player.shake = Math.min(1, (this.player.shake || 0) + s); };
      this.renderer.compile(this.scene, this.camera);
    } catch (e) {
      console.error(e);
      this.ui.loading(1, 'Error carregant el joc: ' + e.message);
      return;
    }
    this.ui.show('#loading', false);
    this.showTitle();
    let sala = '';
    try { sala = new URLSearchParams(location.search).get('sala') || ''; } catch { /* res */ }
    if (/^[0-9]{4}$/.test(sala)) this.showLobby(null, sala);
  }

  // ------------------------------------------------------------------ menús
  showTitle() {
    this.state = 'title';
    this.ui.show('#title', true); this.ui.show('#charScreen', false); this.ui.show('#lobby', false); this.ui.show('#modesScreen', false); this.ui.show('#roomScreen', false); this.ui.show('#hud', false);
    $('#version').classList.remove('hidden');
    document.querySelectorAll('#title [data-act]').forEach((b) => {
      b.onclick = async () => {
        this.audio.init(); this.audio.play('ui');
        const a = b.dataset.act;
        if (a === 'solo') { this.playMode = 'coop'; this.showChars('solo'); }
        else if (a === 'modes') this.showModes();
        else if (a === 'online') this.showLobby(null);
        else if (a === 'options') this.ui.openOptions(false);
        else if (a === 'credits') this.ui.credits();
      };
    });
  }

  // pantalla de modes de joc
  showModes() {
    this.state = 'modes';
    this.ui.show('#title', false); this.ui.show('#modesScreen', true);
    const best = (k) => {
      let r = null;
      for (const c of this.saves.chars) {
        const x = c.records && c.records[k]; if (!x) continue;
        if (k === 'hordes' && (!r || x.wave > r.wave)) r = x;
        if (k === 'caps' && (!r || x.bosses > r.bosses || (x.bosses === r.bosses && x.time < r.time))) r = x;
        if (k === 'crono' && (!r || x.score > r.score)) r = x;
        if (k === 'parkour') { const n = (x.times || [x.time]).filter((t) => t > 0).length; if (!r || n > r.n) r = { n }; }
      }
      if (!r) return '';
      if (k === 'hordes') return `Rècord: onada ${r.wave}`;
      if (k === 'caps') return `Rècord: ${r.bosses} de 7 caps${r.bosses >= 7 ? ` en ${Math.floor(r.time / 60)}:${String(r.time % 60).padStart(2, '0')}` : ''}`;
      if (k === 'crono') return `Rècord: ${r.score} punts`;
      if (k === 'parkour') return r.n ? `Nivells superats: ${r.n} de ${LEVELS.length}` : '';
      return '';
    };
    const wins = this.saves.chars.reduce((a, c) => a + ((c.pvp && c.pvp.wins) || 0), 0);
    const tag = (m) => (m.kind === 'race' ? 'PARKOUR' : 'CONTRA MONSTRES');
    $('#modeList').innerHTML = Object.entries(MODES).filter(([k, m]) => k !== 'coop' && m.solo).map(([k, m]) => `<div class="mode"><span class="tag">${tag(m)}</span><h3><i>${m.icon}</i>${m.name}</h3><p>${m.desc}</p>
      <div class="rec">${best(k)}</div>
      <div class="row"><button class="pbtn gold" data-solo="${k}">Jugar</button></div></div>`).join('')
      + `<div class="mode note"><span class="tag pvp">AMB AMICS</span><h3><i>👥</i>Multijugador</h3><p>Per jugar amb amics (i als modes contra altres jugadors: ${Object.values(MODES).filter((m) => m.kind === 'pvp').map((m) => m.name).join(', ')}), ves a <b>Multijugador</b>, crea una sala i el líder hi tria el mode.</p>
      <div class="rec">${wins ? `Victòries PvP: ${wins}` : ''}</div>
      <div class="row"><button class="pbtn" data-online>Anar a Multijugador</button></div></div>`;
    document.querySelectorAll('#modeList [data-solo]').forEach((b) => {
      b.onclick = () => {
        this.audio.play('ui');
        const go = () => { this.playMode = b.dataset.solo; this.ui.show('#modesScreen', false); this.showChars('solo'); };
        // parkour: primer es tria el nivell
        if (b.dataset.solo === 'parkour') this.ui.levelPicker(this.saves.chars, (n) => { this.pkLevel = n; go(); });
        else go();
      };
    });
    document.querySelector('#modeList [data-online]').onclick = () => { this.audio.play('ui'); this.ui.show('#modesScreen', false); this.showLobby(null); };
    $('#modesBack').onclick = () => this.showTitle();
  }

  showChars(mode, after) {
    this.state = 'chars';
    this.ui.show('#title', false); this.ui.show('#lobby', false); this.ui.show('#modesScreen', false); this.ui.show('#charScreen', true);
    this.charMode = mode; this.afterChar = after;
    $('#charRoomNote').classList.add('hidden');
    let sel = this.saves.chars.length ? this.saves.chars[this.saves.chars.length - 1] : null;
    let creating = !sel;
    let newHero = 'heroi1', newCls = 'foc';
    const renderSlots = () => {
      $('#slots').innerHTML = this.saves.chars.map((c, i) => `<div class="slot ${sel === c ? 'sel' : ''}" data-i="${i}" style="--c:${CLASSES[c.cls].color}"><div class="ico">${CLS_ICON[c.cls]}</div><div><b>${esc(c.name)}</b><span>${CLASSES[c.cls].name} · Nivell ${c.level} · ${STORY[c.story.idx] ? STORY[c.story.idx].title.split('—')[0] : 'Història completa'}</span></div><span class="del" data-del="${i}">Esborrar</span></div>`).join('') || '<div class="hint">Encara no tens cap heroi. Crea\'n un!</div>';
      document.querySelectorAll('#slots [data-i]').forEach((el) => { el.onclick = (e) => { if (e.target.dataset.del !== undefined) return; sel = this.saves.chars[+el.dataset.i]; creating = false; refresh(); }; });
      document.querySelectorAll('#slots [data-del]').forEach((el) => {
        el.onclick = () => {
          // confirmació en dos clics (els diàlegs del navegador no sempre funcionen)
          if (!el.dataset.armed) { el.dataset.armed = '1'; el.textContent = 'Segur? Clica de nou'; el.classList.add('armed'); setTimeout(() => { if (el.isConnected) { delete el.dataset.armed; el.textContent = 'Esborrar'; el.classList.remove('armed'); } }, 3000); return; }
          this.saves.chars.splice(+el.dataset.del, 1); this.persist(); sel = this.saves.chars[0] || null; creating = !sel; refresh();
        };
      });
    };
    const renderNew = () => {
      $('#heroPick').innerHTML = ['heroi1', 'heroi2', 'heroi3'].map((h, i) => `<button class="pbtn ${newHero === h ? 'sel' : ''}" data-h="${h}">Heroi ${i + 1}</button>`).join('');
      $('#classPick').innerHTML = Object.entries(CLASSES).map(([k, c]) => `<div class="cls ${newCls === k ? 'sel' : ''}" data-c="${k}" style="--c:${c.color}"><h3>${CLS_ICON[k]} ${c.name}</h3><p>${c.desc}</p></div>`).join('');
      document.querySelectorAll('#heroPick [data-h]').forEach((b) => { b.onclick = () => { newHero = b.dataset.h; this.audio.play('ui'); refresh(); }; });
      document.querySelectorAll('#classPick [data-c]').forEach((b) => { b.onclick = () => { newCls = b.dataset.c; this.audio.play('ui'); refresh(); }; });
    };
    const classInfo = (cls) => {
      const c = CLASSES[cls];
      $('#classInfo').innerHTML = `<h2 style="color:${c.color}">${CLS_ICON[cls]} ${c.name}</h2><div class="hint">${c.desc}</div>
        <div class="stats" style="margin:8px 0"><span>Vida</span><b>${c.stats.hp}</b><span>Manà</span><b>${c.stats.mana}</b><span>Poder</span><b>${c.stats.poder}</b><span>Defensa</span><b>${c.stats.def}</b></div>
        <div class="abil-list">${[c.basic, ...c.abilities, c.ult].map((k) => `<div><b>${AB_ICON[k]} ${ABILITIES[k].name}</b><span>${ABILITIES[k].desc}</span></div>`).join('')}</div>`;
    };
    const refresh = () => {
      renderSlots();
      $('#newChar').classList.toggle('hidden', !creating);
      if (creating) renderNew();
      $('#playChar').disabled = creating || !sel;
      const hero = creating ? newHero : sel.hero, cls = creating ? newCls : sel.cls;
      classInfo(cls);
      this.previewHero(hero, cls);
    };
    $('#newCharBtn').onclick = () => { creating = true; refresh(); };
    $('#cancelChar').onclick = () => { creating = !this.saves.chars.length; sel = this.saves.chars[0] || null; refresh(); };
    $('#createChar').onclick = () => {
      const name = $('#charName').value.trim() || 'Heroi';
      if (this.saves.chars.length >= 6) { $('#charErr').textContent = 'Màxim 6 herois. Esborra\'n un.'; return; }
      const c = newCharacter(name, newCls, newHero);
      this.saves.chars.push(c); this.persist();
      sel = c; creating = false; this.audio.play('quest'); refresh();
    };
    $('#playChar').onclick = () => { if (!sel) return; this.save = sel; this.audio.play('ui'); if (this.afterChar) this.afterChar(sel); else this.startGame(this.charMode); };
    $('#backTitle').onclick = () => { this.clearPreview(); if (mode === 'online' && this.remote) { this.ui.show('#charScreen', false); this.state = 'lobby'; this.ui.show('#lobby', true); } else this.showTitle(); };
    refresh();
  }

  async previewHero(hero, cls) {
    const key = hero + cls;
    if (this.previewKey === key) return;
    this.previewKey = key;
    const tok = Symbol(); this.previewTok = tok;
    const av = await HeroAvatar.create(hero, cls);
    if (this.previewTok !== tok) return;
    this.clearPreview();
    this.previewKey = key;
    this.preview = av;
    const x = -1, z = 19, y = height(x, z);
    av.obj.position.set(x, y, z); av.obj.rotation.y = 0;
    this.scene.add(av.obj);
    av.anim.play(cls === 'guerrer' ? 'sword_c' : 'magic_2h_b', { speed: 1.2 });
    av.setExpression('happy', 1, 1800);
  }
  clearPreview() { if (this.preview) { this.scene.remove(this.preview.obj); this.preview = null; } this.previewKey = null; }

  async showLobby(mode, presetCode) {
    this.state = 'lobby';
    this.lobbyMode = mode;
    const visit = this.lobbyVisit = (this.lobbyVisit || 0) + 1;
    this.ui.show('#title', false); this.ui.show('#modesScreen', false); this.ui.show('#charScreen', false); this.ui.show('#lobby', true);
    $('#lobbyTitle').textContent = 'Multijugador';
    $('#lobbyErr').textContent = 'Preparant el multijugador…'; $('#codeErr').textContent = ''; $('#lobbyStatus').textContent = '';
    $('#serverUrl').value = this.settings.server || '';
    $('#lobbyBody').classList.remove('hidden');
    $('#lobbyAdv').open = false;
    const codeIn = $('#roomCode'), joinBtn = $('#joinRoom'), createBtn = $('#createRoom');
    const setCode = (v) => {
      codeIn.value = String(v || '').replace(/[^0-9]/g, '').slice(0, 4);
      joinBtn.disabled = codeIn.value.length !== 4;
      codeIn.classList.remove('bad'); $('#codeErr').textContent = '';
    };
    const notReady = () => {
      $('#lobbyErr').innerHTML = this.lobbyKind === 'none'
        ? 'Aquí no es pot jugar en línia. Obre el joc des de Claude o des de la teva adreça de Render (fitxer <b>DESPLEGAR.md</b>).'
        : 'Encara s\'està connectant… espera un moment.';
    };
    const tryJoin = async () => {
      const code = codeIn.value;
      if (code.length !== 4 || joinBtn.dataset.busy) return;
      if (!this.remote) return notReady();
      joinBtn.dataset.busy = '1'; joinBtn.disabled = true; $('#codeErr').textContent = 'Buscant la sala…';
      const r = await this.remote.check(code);
      delete joinBtn.dataset.busy; joinBtn.disabled = false;
      if (this.state !== 'lobby' || visit !== this.lobbyVisit) return;
      if (!r || !r.ok) {
        $('#codeErr').textContent = !r ? 'El servidor no respon. Potser encara té la versió antiga del joc: torna a pujar els fitxers a GitHub.' : r.error || 'No s\'ha trobat la sala';
        codeIn.classList.remove('bad'); void codeIn.offsetWidth; codeIn.classList.add('bad');
        this.audio.play('deny'); return;
      }
      this.audio.play('ui');
      this.pickAndJoin(r.code);
    };
    codeIn.oninput = () => setCode(codeIn.value);
    codeIn.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter') tryJoin(); };
    setCode(presetCode || '');
    joinBtn.onclick = tryJoin;
    createBtn.onclick = async () => {
      if (!this.remote) return notReady();
      if (createBtn.dataset.busy) return;
      this.audio.play('ui');
      createBtn.dataset.busy = '1'; createBtn.disabled = true; $('#lobbyErr').textContent = 'Creant la sala…';
      const r = await this.remote.create({ mode: mode || 'coop', name: '' });
      delete createBtn.dataset.busy; createBtn.disabled = false;
      if (this.state !== 'lobby' || visit !== this.lobbyVisit) return;
      if (r && r.ok) { $('#lobbyErr').textContent = ''; this.pickAndJoin(r.code, true); }
      else $('#lobbyErr').textContent = (r && r.error) || 'No s\'ha pogut crear la sala';
    };
    $('#lobbyBack').onclick = () => { if (this.remote) { this.remote.close(); this.remote = null; } if (mode) this.showModes(); else this.showTitle(); };
    // connexió amb un servidor propi (Render o aquest mateix)
    const connect = async () => {
      $('#lobbyErr').textContent = 'Connectant… (Render gratuït pot trigar fins a un minut a despertar-se)';
      const url = $('#serverUrl').value.trim().replace(/\/$/, '');
      this.settings.server = url; this.saveSettings();
      try {
        if (this.remote) this.remote.close();
        this.remote = null;
        const remote = new RemoteServer(url || '');
        await remote.connect();
        if (visit !== this.lobbyVisit) { remote.close(); return; }
        this.remote = remote; this.lobbyKind = 'server';
        $('#lobbyErr').textContent = '';
        const sv = await remote.hello();
        if (sv !== GAME_VERSION) {
          $('#lobbyErr').innerHTML = `⚠️ El servidor té una versió antiga del joc (${sv ? 'v' + sv : 'anterior a la v1.6'}) i aquest joc és la <b>v${GAME_VERSION}</b>. Puja els fitxers nous a GitHub i espera que Render posi <b>Live</b>; després recarrega la pàgina.`;
        }
        if (codeIn.value.length === 4) tryJoin(); else codeIn.focus();
      } catch (e) { $('#lobbyErr').textContent = e.message; }
    };
    $('#connectBtn').onclick = connect;
    // quin multijugador hi ha: servidor propi, sales dins de Claude o cap
    const local = await serverAvailable();
    const roomNs = local ? null : await artifactRoom();
    if (this.state !== 'lobby' || visit !== this.lobbyVisit) return;
    if (local || (!roomNs && this.settings.server)) {
      this.lobbyKind = 'server';
      $('#lobbyStatus').textContent = 'Connexió: servidor propi';
      $('#lobbyHint').innerHTML = 'Per jugar amb amics feu servir un <b>codi de sala</b>: un de vosaltres crea la sala i els altres hi entren escrivint el codi. Dins la sala, el líder tria el mode i comença la partida.';
      connect();
    } else if (roomNs) {
      this.lobbyKind = 'p2p';
      $('#lobbyStatus').textContent = 'Connexió: sales de Claude';
      if (this.remote) this.remote.close();
      this.remote = new P2PNet(roomNs);
      $('#lobbyErr').textContent = '';
      $('#lobbyHint').innerHTML = 'Jugueu junts aquí mateix: un de vosaltres <b>crea la sala</b> i els altres hi entren amb el <b>codi</b>. Dins la sala, el líder tria el mode i comença. Els teus amics han de poder obrir aquest joc a Claude: comparteix-lo amb ells amb el botó <b>Compartir</b>.';
      if (codeIn.value.length === 4) tryJoin(); else codeIn.focus();
    } else {
      this.lobbyKind = 'none';
      $('#lobbyStatus').textContent = 'Connexió: cap (aquí no es pot jugar en línia)';
      $('#lobbyAdv').open = true;
      $('#lobbyErr').textContent = '';
      $('#lobbyHint').innerHTML = 'Aquesta còpia del joc no té servidor, així que des d\'aquí no es pot jugar en línia. Obre el joc des de Claude o des de la teva adreça de Render (fitxer <b>DESPLEGAR.md</b>), o escriu aquí sota l\'adreça del servidor.';
    }
  }
  pickAndJoin(code, created) {
    this.ui.show('#lobby', false);
    this.showChars('online', (save) => { this.save = save; this.joinRoom(code); });
    const note = $('#charRoomNote');
    note.innerHTML = created
      ? `Sala creada! El codi és <b class="rcode">${esc(code)}</b>. Passa'l als teus amics i tria el teu heroi per entrar-hi.`
      : `Entrant a la sala <b class="rcode">${esc(code)}</b>: tria el teu heroi.`;
    note.classList.remove('hidden');
  }

  // ------------------------------------------------------------------ sala multijugador
  async joinRoom(code) {
    const remote = this.remote;
    this.clearPreview();
    this.ui.show('#charScreen', false);
    const r = await remote.join({ code, save: this.save, token: this.saves.token, name: this.save.name, cls: this.save.cls, hero: this.save.hero });
    if (!r || !r.ok) { this.state = 'lobby'; this.ui.show('#lobby', true); $('#lobbyErr').textContent = (r && r.error) || 'No s\'ha pogut entrar a la sala'; return; }
    this.room = r; this.myId = r.id;
    $('#rsChatLog').innerHTML = '';
    for (const t of ['room', 'roomStart', 'roomLobby', 'roomChat', 'disconnect', 'warn']) remote.off(t);
    remote.on('warn', (m) => { if (remote === this.remote) this.ui.toast(m, 'warn'); });
    remote.on('room', (d) => { if (remote !== this.remote) return; this.room = d; if (this.state === 'room') this.renderRoom(); });
    remote.on('roomStart', () => { if (remote === this.remote && this.state === 'room') this.enterRoomGame(); });
    remote.on('roomLobby', () => { if (remote === this.remote) this.backToRoom(); });
    remote.on('roomChat', (d) => { const log = $('#rsChatLog'); log.insertAdjacentHTML('beforeend', `<div><b>${esc(d.name)}:</b> ${esc(d.text)}</div>`); log.scrollTop = log.scrollHeight; if (this.state === 'playing') this.ui.chat(d.name, d.text); });
    remote.on('disconnect', () => { if (remote !== this.remote) return; this.ui.toast(remote.p2p ? remote.disconnectMsg : 'S\'ha perdut la connexió amb el servidor', 'warn'); setTimeout(() => this.leaveGame(), 1500); });
    this.showRoom();
    // si la partida ja està en marxa, hi entres directament
    if (r.state === 'playing') this.enterRoomGame();
  }
  showRoom() {
    this.state = 'room';
    this.ui.show('#roomScreen', true); this.ui.show('#lobby', false); this.ui.show('#title', false); this.ui.show('#hud', false);
    $('#rsErr').textContent = '';
    const copy = (btn, text, label) => { try { navigator.clipboard.writeText(text); btn.textContent = 'Copiat!'; setTimeout(() => { btn.textContent = label; }, 1500); } catch { /* res */ } };
    $('#rsCopy').textContent = 'Copiar codi';
    $('#rsCopy').onclick = () => copy($('#rsCopy'), this.room.code, 'Copiar codi');
    // si el joc s'obre des del mateix servidor, també es pot passar un enllaç directe a la sala
    const sameOrigin = !this.remote.p2p && !this.settings.server && /^https?:/.test(location.protocol);
    $('#rsLink').classList.toggle('hidden', !sameOrigin);
    $('#rsLink').textContent = 'Copiar enllaç';
    $('#rsLink').onclick = () => copy($('#rsLink'), `${location.origin}${location.pathname}?sala=${this.room.code}`, 'Copiar enllaç');
    const ci = $('#rsChatIn');
    ci.onkeydown = (e) => { if (e.key === 'Enter') { const v = ci.value.trim(); if (v) this.remote.roomChat(v); ci.value = ''; } e.stopPropagation(); };
    this.renderRoom();
  }
  renderRoom() {
    const R = this.room; if (!R) return;
    const me = this.myId, leader = R.leader === me;
    $('#rsCode').textContent = R.code;
    $('#rsCount').textContent = `${R.members.length}/${R.max}`;
    const lead = R.members.find((m) => m.id === R.leader);
    $('#rsWho').textContent = leader ? '· tu tries' : `· tria ${lead ? lead.name : 'el líder'}`;
    $('#rsNote').textContent = this.remote && this.remote.p2p && leader ? '🖥️ La partida funciona des del teu navegador: no tanquis aquesta pestanya ni la deixis amagada mentre jugueu.' : '';
    $('#rsMembers').innerHTML = R.members.map((m) => `<div class="member ${m.id === me ? 'me' : ''}" style="--c:${(CLASSES[m.cls] || CLASSES.foc).color}"><div class="ci">${CLS_ICON[m.cls] || '✦'}</div><div><b>${m.id === R.leader ? '👑 ' : ''}${esc(m.name)}${m.id === me ? ' (tu)' : ''}</b><span>${(CLASSES[m.cls] || CLASSES.foc).name} · Nivell ${m.level}</span></div>${m.inGame ? '<span class="st">JUGANT</span>' : ''}</div>`).join('')
      + Array.from({ length: Math.max(0, R.max - R.members.length) }, () => '<div class="member empty">Lloc lliure</div>').join('');
    const playing = R.state === 'playing';
    $('#rsModes').innerHTML = Object.entries(MODES).filter(([, m]) => m.multi).map(([k, m]) => `<button class="rmode ${R.mode === k ? 'sel' : ''}" data-rm="${k}" ${leader && !playing ? '' : 'disabled'}>${m.kind === 'pvp' ? '<span class="pv">PvP</span>' : ''}<b>${m.icon} ${m.name}</b><span>${m.desc}</span></button>`).join('');
    document.querySelectorAll('#rsModes [data-rm]').forEach((b) => { b.onclick = () => { this.audio.play('ui'); this.remote.roomMode(b.dataset.rm); }; });
    // parkour: el líder tria el nivell
    const lv = $('#rsLevels');
    lv.classList.toggle('hidden', R.mode !== 'parkour');
    if (R.mode === 'parkour') {
      lv.innerHTML = '<span>Nivell:</span>' + LEVELS.map((L) => `<button class="rlv ${(R.level || 1) === L.n ? 'sel' : ''}" data-rl="${L.n}" ${leader && !playing ? '' : 'disabled'}>${L.n}. ${esc(L.name)}<small>${'★'.repeat(L.diff)}</small></button>`).join('');
      lv.querySelectorAll('[data-rl]').forEach((b) => { b.onclick = () => { this.audio.play('ui'); this.remote.roomMode('parkour', +b.dataset.rl); }; });
    }
    const M = MODES[R.mode];
    const need2 = M.kind === 'pvp' && R.members.length < 2;
    let btns = '';
    if (playing) {
      const meIn = R.members.find((m) => m.id === me && m.inGame);
      btns += `<button class="pbtn gold" id="rsEnter" ${meIn ? 'disabled' : ''}>Entrar a la partida (${M.icon} ${M.name})</button>`;
      if (leader) btns += '<button class="pbtn" id="rsEnd">Acabar la partida per a tothom</button>';
    } else if (leader) btns += `<button class="pbtn gold" id="rsStart" ${need2 ? 'disabled' : ''}>Començar: ${M.icon} ${M.name}${R.mode === 'parkour' ? ` · nivell ${R.level || 1}` : ''}</button>${need2 ? '<span class="hint">Aquest mode necessita com a mínim 2 jugadors.</span>' : ''}`;
    else btns += `<span class="hint">Esperant que ${esc(lead ? lead.name : 'el líder')} comenci la partida…</span>`;
    btns += `<button class="pbtn ghost" id="rsLeave">${this.remote && this.remote.p2p && leader ? 'Tancar la sala' : 'Sortir de la sala'}</button>`;
    $('#rsButtons').innerHTML = btns;
    const st = $('#rsStart'); if (st) st.onclick = async () => { st.disabled = true; const r = await this.remote.roomStart(); if (!r || !r.ok) { $('#rsErr').textContent = (r && r.error) || 'No s\'ha pogut començar'; st.disabled = false; } };
    const en = $('#rsEnter'); if (en) en.onclick = () => this.enterRoomGame();
    const ed = $('#rsEnd'); if (ed) ed.onclick = () => this.remote.roomEnd();
    $('#rsLeave').onclick = () => { this.audio.play('ui'); if (this.remote) { this.remote.close(); this.remote = null; } this.room = null; this.showTitle(); };
  }
  enterRoomGame() {
    if (this.state === 'playing' || this.state === 'joining') return;
    this.ui.show('#roomScreen', false);
    this.startGame('online', this.remote, this.room.code);
  }
  // torna a la sala després d'una partida (sense desconnectar)
  backToRoom() {
    if (!this.room) return;
    if (this.state === 'playing' || this.state === 'joining') this.cleanupGame();
    this.ui.closeModal();
    this.showRoom();
  }

  // ------------------------------------------------------------------ partida
  async startGame(mode, remote, code) {
    this.ui.show('#charScreen', false); this.ui.show('#title', false); this.ui.show('#lobby', false);
    this.clearPreview();
    this.state = 'joining';
    this.ui.show('#loading', true); this.ui.loading(0.1, 'Entrant al món…');
    this.net = remote || new LocalServer(this.playMode || 'coop', { level: this.pkLevel || 1 });
    this.mode = remote ? (this.lobbyMode || 'coop') : (this.playMode || 'coop');
    this.myId = null;
    this.player = new LocalPlayer(this);
    this.player.stats = computeStats(this.save.cls, this.save.level, this.save.talents, this.save.equip, { skills: this.save.skills });
    this.player.cdTotal = {};
    // els esdeveniments que arriben mentre es carrega l'heroi s'encuen
    this.ready = false; this.evQueue = [];
    const net = this.net;
    net.off('ev'); net.off('snap'); if (!remote) net.off('disconnect');
    net.on('ev', (evs) => { if (net !== this.net) return; if (!this.ready) { this.evQueue.push(...evs); return; } this.processEvents(evs); });
    net.on('snap', (s) => { if (net === this.net && this.ready) this.onSnap(s); });
    const payload = { code, save: this.save, token: this.saves.token, name: this.save.name, cls: this.save.cls, hero: this.save.hero };
    const r = remote ? await net.enter(payload) : await net.join(payload);
    if (!r || !r.ok) {
      this.player = null;
      this.ui.show('#loading', false);
      if (remote && this.room) { this.showRoom(); $('#rsErr').textContent = (r && r.error) || 'No s\'ha pogut entrar a la partida'; return; }
      this.net = null; this.state = 'lobby'; this.ui.show('#lobby', true);
      $('#lobbyErr').textContent = (r && r.error) || 'No s\'ha pogut entrar a la sala';
      return;
    }
    this.roomCode = r.code;
    if (r.id) this.myId = r.id;
    if (r.mode) this.mode = r.mode;
    this.modeKind = (MODES[this.mode] || MODES.coop).kind;
    this.myCp = 0; this.matchState = null;
    this.pk = { activeLevel, setLevel, platformState, setCourseTime }; // ajuda per a proves
    this.pkLevelCur = 0;
    if (this.mode === 'parkour') this.applyPkLevel((remote ? this.room && this.room.level : this.pkLevel) || 1);
    else this.world.showCourse(false);
    this.avatar = await HeroAvatar.create(this.save.hero, this.save.cls, { onProgress: (p) => this.ui.loading(0.1 + p * 0.8, 'Carregant el teu heroi…') });
    this.scene.add(this.avatar.obj);
    this.applySkins(this.avatar, this.save.skins, this.save.cls, this.save.equip && this.save.equip.arma);
    this.ui.setupHud(this.save);
    this.ready = true;
    const q = this.evQueue; this.evQueue = [];
    this.processEvents(q);
    this.ui.show('#loading', false); this.ui.show('#hud', true); $('#version').classList.add('hidden');
    this.state = 'playing';
    this.input.wantLock = true;
    if ('ontouchstart' in window && matchMedia('(pointer: coarse)').matches) this.setupTouch();
    const MI = MODES[this.mode] || MODES.coop;
    if (this.mode === 'parkour') setTimeout(() => this.ui.chat('', 'Parkour: Espai per saltar (i un altre cop a l\'aire per al doble salt), mantén Espai mentre caus per planar, Maj per córrer. Els trampolins i els bolets et llancen amunt, les plataformes liles desapareixen, les pedres esquerdades cauen i els corrents d\'aire t\'enlairen.', true), 600);
    this.ui.chat('', remote ? `Has entrat a la sala ${this.roomCode} (${MI.icon} ${MI.name}). Comparteix el codi amb els teus amics!` : this.modeKind === 'story' ? 'Benvingut a l\'Alba! Clica la pantalla per controlar la càmera. Prem Esc per al menú.' : `${MI.icon} ${MI.name}: ${MI.desc}`, true);
    this.setHill(this.mode === 'turo');
    let tag = document.getElementById('roomTag');
    if (!tag) { tag = document.createElement('div'); tag.id = 'roomTag'; Object.assign(tag.style, { position: 'absolute', right: '214px', top: '20px', font: '800 12px Nunito, sans-serif', color: '#ffe7a8', background: 'rgba(20,16,40,.72)', border: '1px solid rgba(255,214,120,.45)', borderRadius: '8px', padding: '4px 10px', letterSpacing: '.08em', pointerEvents: 'none' }); $('#hud').appendChild(tag); }
    tag.textContent = remote ? `SALA ${this.roomCode}` : '';
    tag.style.display = remote ? '' : 'none';
    this.world.timeOfDay = this.mode === 'parkour' ? getLevel(this.pkLevelCur).tod : 0.33;
    if (this.modeKind === 'story' && !this.save.story.accepted && this.save.story.idx === 0) setTimeout(() => this.ui.toast('Parla amb la Sàvia Elna (!) per començar', ''), 1500);
  }

  // nivell de parkour: el dibuixa, hi posa la física i l'hora del dia
  applyPkLevel(n) {
    const L = setLevel(n);
    this.pkLevelCur = L.n; this.myCp = 0;
    ZONE.parkour.name = L.name;
    this.world.showCourse(true, L.n);
    this.world.timeOfDay = L.tod;
    if (this.state === 'playing') { this.ui.toast(`Nivell ${L.n}: ${L.name}`, 'big'); }
  }
  pkTip(L, cp) {
    const names = { 'El trampolí': 'Consell: corre, salta des de la vora i mantén Espai per planar. Quan siguis just a sobre de la plataforma de baix, deixa anar Espai per caure-hi.',
      'Les pedres que cauen': 'Consell: salta dins del corrent d\'aire i deixa\'t pujar. Després plana fins a la plataforma alta.',
      'El corrent d\'aire': 'Consell: les bigues giren. Puja-hi quan apuntin cap a tu, corre fins al mig i espera que l\'altre extrem apunti a la plataforma.',
      'Els molins': 'Consell: entra a cada corrent d\'aire, puja fins dalt de tot i plana fins a la següent plataforma.',
      'Ascensors i bigues': 'Consell: el corrent d\'aire és molt alt. Puja fins dalt i plana fins a la plataforma petita; deixa anar Espai a temps!' };
    return names[L.names[cp]] || '';
  }

  leaveGame() {
    this.cleanupGame();
    if (this.net) this.net.close();
    if (this.remote && this.remote !== this.net) this.remote.close();
    this.net = null; this.remote = null; this.room = null;
    this.showTitle();
  }
  // treu tot el que és de la partida (heroi, enemics, botí, HUD) sense desconnectar
  cleanupGame() {
    this.persist();
    this.ready = false; this.evQueue = [];
    if (!$('#modal').classList.contains('hidden')) this.ui.closeModal();
    if (this.avatar) { this.avatar.dispose(); this.avatar = null; }
    for (const o of this.others.values()) this.removeOther(o.id);
    for (const e of this.enemies.values()) if (e) { e.dispose(); this.ui.removeLabel(e.label); }
    this.enemies.clear(); this.einfo.clear();
    for (const l of this.lootObjs.values()) { this.scene.remove(l.obj); this.ui.removeLabel(l.label); }
    this.lootObjs.clear();
    this.ui.boss(null);
    this.setHill(false); $('#bigmsg').textContent = '';
    this.ui.show('#hud', false); this.ui.show('#deathScreen', false); this.ui.show('#touch', false);
    this.player = null; this.guide = null; this.world.setBeacon(null); this.world.showCourse(false);
    if (document.pointerLockElement) document.exitPointerLock();
    this.input.wantLock = false;
    this.state = 'menu';
  }

  applySkins(av, skins, cls, weapon) {
    if (!av || !skins) return;
    const aura = SKINS.aura.find((s) => s.id === skins.aura);
    av.trColor.set(aura && aura.color ? aura.color : CLASSES[cls].color);
    av.setWeapon(weapon ? weapon.model : null, skins.arma);
    const ales = SKINS.ales.find((s) => s.id === skins.ales);
    av.wingSkin = ales && ales.id !== 'cap' ? (ales.color || (aura && aura.color) || CLASSES[cls].color) : null;
  }

  // ------------------------------------------------------------------ esdeveniments
  me() { return this.myId || (this.net ? this.net.id : null); }

  processEvents(evs) { for (const [t, d] of evs) { try { this.onEvent(t, d); } catch (e) { console.error('[ev]', t, e); } } }

  // ganxos que fa servir el jugador local per a les animacions
  avatarAction(name, opts) { if (this.avatar) this.avatar.anim.play(name, opts || {}); }
  avatarBase(name) { if (this.avatar) this.avatar.anim.play(name, { speed: 1.6 }); }
  avatarLand(fall) {
    if (!this.avatar) return;
    if (fall > 7) { this.avatar.anim.play('jump_land', { speed: 1.5 }); this.audio.play('land', 1); this.player.shake = Math.min(1, (this.player.shake || 0) + Math.min(0.5, fall / 30)); this.fx.parts.burst(this.player.pos.clone().setY(this.player.pos.y + 0.1), 14, new THREE.Color('#d8c8a8'), { speed: 3, up: 0.5, size: 0.7, life: 0.6, grav: 1 }); }
    else { if (this.avatar.anim.overlayName === 'jump_start' || this.avatar.anim.overlayName === 'double_jump') this.avatar.anim.stopOverlay(0.1); if (fall > 1.2) this.audio.play('land', 0.5); }
  }

  onEvent(t, d) {
    const fx = this.fx, me = this.me();
    switch (t) {
      case 'welcome': {
        this.myId = d.id;
        if (this.net && !this.net.id) this.net.id = d.id;
        this.removeOther(d.id);
        const created = this.save && this.save.created;
        this.save = JSON.parse(JSON.stringify(d.save)); if (created) this.save.created = created;
        this.persist();
        this.player.team = d.team;
        this.player.pos.set(d.x, d.y, d.z);
        if (d.mode === 'parkour') { this.player.camYaw = 0; this.player.yaw = 0; if (d.match && d.match.level) this.applyPkLevel(d.match.level); }
        this.serverT = d.t; this.renderT = d.t - 0.12;
        for (const p of d.players) if (p.id !== d.id) this.addOther(p);
        for (const e of d.enemies) this.addEnemy(e);
        for (const l of d.loot) this.addLoot(l);
        for (const f of d.fields) fx.field(f);
        if (d.pvp) this.ui.pvpBoard(d.pvp, d.id);
        if (d.match) { this.matchState = d.match.state; this.ui.matchPanel(d.match, d.id); }
        this.ui.setupHud(this.save);
        break;
      }
      case 'pjoin': if (d.id !== me) { this.addOther(d); this.ui.chat('', `${d.name} s'ha unit a la partida.`, true); } break;
      case 'pleave': { const o = this.others.get(d.id); if (o) this.ui.chat('', `${o.name} ha marxat.`, true); this.removeOther(d.id); break; }
      case 'espawn': this.addEnemy(d); break;
      case 'edie': {
        this.einfo.delete(d.id);
        const e = this.enemies.get(d.id); if (!e) { this.enemies.delete(d.id); break; }
        e.die(); this.ui.removeLabel(e.label); e.label = null;
        if (this.player && this.player.lockTarget === e) this.player.lockTarget = null;
        fx.parts.burst(e.obj.position.clone().setY(e.obj.position.y + 1), 26, new THREE.Color(e.def.rig === 'kk' ? '#bfffe6' : '#ffb07a'), { speed: 4, size: 0.6, life: 0.9 });
        if (e.def.boss) { this.audio.play('boss'); this.bossId = null; this.ui.boss(null); }
        setTimeout(() => { e.dispose(); if (this.enemies.get(d.id) === e) this.enemies.delete(d.id); }, 4200);
        break;
      }
      case 'eatk': {
        const e = this.enemies.get(d.id);
        if (e) e.playAttack(d.a, d.w);
        if (d.tele) {
          if (d.tele.pts) for (const [x, z] of d.tele.pts) fx.telegraph(new THREE.Vector3(x, d.y, z), d.tele.r, '#ff3b3b', d.w, true);
          else if (d.tele.line) fx.lineTelegraph(d.tele.x, d.y, d.tele.z, d.tele.line[0], d.tele.line[1], d.tele.r, d.w);
          else if (d.tele.cone) {
            const [a, len, half] = d.tele.cone;
            const rad = e ? e.def.radius || 2 : 2;
            const ox = d.tele.x + Math.sin(a) * rad * 0.8, oz = d.tele.z + Math.cos(a) * rad * 0.8;
            fx.coneTelegraph(ox, d.y, oz, a, len, half, d.w);
            if (d.k === 'breath' && e) {
              const head = e.headBone;
              const origin = (v) => { if (head) head.getWorldPosition(v); else v.set(ox, d.y + 4, oz); };
              fx.fireBreath(origin, a, half, len, d.w, 1.3);
              setTimeout(() => this.audio.play('cast_foc', 0.9), d.w * 1000);
            }
          }
          else fx.telegraph(new THREE.Vector3(d.tele.x, d.y, d.tele.z), d.tele.r, '#ff3b3b', d.w, true);
        }
        if (e && e.def.boss && (d.k === 'summon' || d.k === 'clones' || d.k === 'nova')) this.audio.play('roar', 0.7);
        break;
      }
      case 'impact': fx.explosion(new THREE.Vector3(d.x, d.y + 0.3, d.z), d.r * 0.8, d.el === 'fisic' ? 'arca' : d.el); this.audio.play('explosion', 0.8); break;
      case 'eblink': { fx.parts.burst(new THREE.Vector3(...d.from).setY(d.from[1] + 1.5), 40, new THREE.Color('#9b3dff'), { speed: 5, size: 0.8 }); break; }
      case 'summon': { const e = this.enemies.get(d.id); if (e) fx.ring(e.obj.position, 8, new THREE.Color('#9b3dff'), 0.8); break; }
      case 'aggro': { const e = this.enemies.get(d.id); if (e && e.def.boss) { this.bossId = d.id; this.audio.play('boss'); this.ui.toast(`${e.def.name}${e.def.title ? ' · ' + e.def.title : ''}`, 'big'); } break; }
      case 'bossPhase': { const e = this.enemies.get(d.id); if (e) { this.ui.toast(d.phase === 3 ? `${e.def.name} s'enfureix!` : `${e.def.name} canvia de tàctica!`, 'warn'); this.audio.play('roar'); } break; }
      case 'bossDown': this.ui.toast(`${d.name} derrotat!`, 'big'); this.audio.play('levelup'); break;
      case 'bossReset': if (this.bossId === d.id) { this.bossId = null; this.ui.boss(null); } break;
      case 'cast': this.onCast(d); break;
      case 'proj': fx.projectile(d); if (d.oe) this.audio.play('cast_' + (d.el || 'arca'), 0.4); break;
      case 'projEnd': fx.projectileEnd(d); if (d.ex) this.audio.play('explosion', 0.6); break;
      case 'zap': fx.zap(d.pts, d.el, d.fx === 'strike'); this.audio.play('zap', 0.6); break;
      case 'ground': fx.groundCast(d); break;
      case 'nova': fx.nova(d); this.audio.play(d.fx === 'spin' ? 'slash' : 'explosion', 0.6); break;
      case 'field': fx.field(d); break;
      case 'beam': fx.beam(d); this.audio.play(d.el === 'llamp' ? 'zap' : 'explosion', 0.5); break;
      case 'slash': {
        fx.slash(new THREE.Vector3(d.x, d.y, d.z), d.ry, d.step, d.el, d.big);
        if (d.big && d.hit) { fx.ring(new THREE.Vector3(d.x + Math.sin(d.ry) * 2.6, d.y, d.z + Math.cos(d.ry) * 2.6), 3.2, new THREE.Color('#e8d6b0'), 0.4); if (fx.onShake) fx.onShake(0.25, new THREE.Vector3(d.x, d.y, d.z)); }
        this.audio.play('slash', d.p === me ? 0.7 : 0.35);
        break;
      }
      case 'dash': {
        fx.dash(d.from, d.to, d.el);
        if (d.p !== me) { /* els altres ja es mouen per instantànies */ }
        this.audio.play('whoosh');
        break;
      }
      case 'buff': {
        const av = this.avatarOf(d.p);
        if (av) { fx.ring(av.obj.position, 3, new THREE.Color((ELEMENTS[d.el] || ELEMENTS.arca).color), 0.6); fx.parts.burst(av.obj.position.clone().setY(av.obj.position.y + 1), 30, new THREE.Color((ELEMENTS[d.el] || ELEMENTS.arca).glow), { speed: 3, up: 3 }); }
        this.audio.play('cast_' + (d.el || 'arca'));
        if (d.buff === 'shield' && av) this.addShield(av, d.dur);
        break;
      }
      case 'transform': {
        const av = this.avatarOf(d.p);
        if (av) {
          av.setTransform(true); av.setExpression('angry', 1, 2500);
          if (d.key === 'titan') av.scaleTarget = ABILITIES.titan.scale || 1.25;
          if (d.key === 'fenix') av.setWings(true, '#ff7a2a');
          fx.ring(av.obj.position, 7, new THREE.Color((ELEMENTS[d.el] || ELEMENTS.arca).color), 0.7);
          fx.parts.burst(av.obj.position.clone().setY(av.obj.position.y + 1), 40, new THREE.Color((ELEMENTS[d.el] || ELEMENTS.arca).color), { speed: 7, up: 2, size: 0.6, life: 0.7, col2: new THREE.Color((ELEMENTS[d.el] || ELEMENTS.arca).glow) });
          fx.levelUp(av.obj.position);
        }
        this.audio.play('transform');
        if (d.p === me) this.ui.toast(ABILITIES[d.key].name + '!', 'big');
        break;
      }
      case 'untransform': { const av = this.avatarOf(d.p); if (av) { av.setTransform(false); av.scaleTarget = 1; av.setWings(false); } break; }
      case 'potion': { const av = this.avatarOf(d.id); if (av) fx.heal(av.obj.position.clone().setY(av.obj.position.y + 1)); if (d.id === me) this.audio.play('heal'); break; }
      case 'hit': this.onHit(d); break;
      case 'miss': fx.nums.add(new THREE.Vector3(d.x, d.y, d.z), 'Esquivat!', 'miss'); break;
      case 'heal': fx.nums.add(new THREE.Vector3(d.x, d.y, d.z), '+' + d.d, 'heal'); if (d.t === me) this.player.hp = Math.min(this.player.mhp, this.player.hp + d.d); break;
      case 'pdie': {
        const who = d.id === me ? null : this.others.get(d.id);
        if (d.id === me) {
          this.player.dead = true; this.player.hp = 0; this.player.respawnAt = this.now + d.rt;
          this.ui.show('#deathScreen', true); $('#deathBy').textContent = d.by ? `Derrotat per ${d.by}` : '';
          $('#respawnBtn').disabled = true;
          $('#respawnBtn').onclick = () => this.net.send('respawn', {});
          this.avatar.anim.play('death_back', { hold: true }); this.audio.play('death');
          if (document.pointerLockElement) document.exitPointerLock();
        } else if (who) { who.dead = true; if (who.avatar) who.avatar.anim.play('death_fwd', { hold: true }); this.ui.feed(`💀 ${esc(who.name)} ha caigut${d.by ? ' (' + esc(d.by) + ')' : ''}`); }
        break;
      }
      case 'prespawn': {
        if (d.id === me) {
          this.player.dead = false; this.player.hp = d.hp; this.ui.show('#deathScreen', false);
          this.avatar.anim.stopOverlay(0.2);
          if (d.revivedBy) this.ui.toast(`${d.revivedBy} t'ha reviscut!`, '');
        } else { const o = this.others.get(d.id); if (o) { o.dead = false; if (o.avatar) o.avatar.anim.stopOverlay(0.2); } }
        const av = this.avatarOf(d.id); if (av) this.fx.heal(av.obj.position.clone().setY(av.obj.position.y + 1));
        break;
      }
      case 'loot': this.addLoot(d); break;
      case 'unloot': this.removeLoot(d.id, d.by); break;
      case 'pick': this.onPick(d); break;
      case 'xp': if (this.player) this.fx.nums.add(this.player.pos.clone().setY(this.player.pos.y + 2.4), `+${d.xp} XP`, 'xp'); break;
      case 'lvl': {
        const av = this.avatarOf(d.id); if (av) fx.levelUp(av.obj.position);
        if (d.id === me) { this.ui.toast(`Nivell ${d.level}!`, 'big'); this.audio.play('levelup'); this.ui.chat('', 'Has guanyat 1 punt d\'estadística (prem C) i 1 punt d\'habilitat per a les branques (prem K).', true); if (this.avatar) this.avatar.setExpression('happy', 1, 2000); }
        else { const o = this.others.get(d.id); if (o) { o.level = d.level; this.ui.feed(`⭐ ${esc(o.name)} puja al nivell ${d.level}`); } }
        break;
      }
      case 'quest': {
        const prev = JSON.stringify(this.save.story.progress) + JSON.stringify(this.save.bounty);
        this.save.story = d.story; this.save.bounty = d.bounty;
        if (prev !== JSON.stringify(d.story.progress) + JSON.stringify(d.bounty)) {
          const ch = STORY[d.story.idx];
          if (ch && d.story.accepted) {
            const done = ch.objectives.every((o, i) => (d.story.progress[i] || 0) >= o.n);
            if (done) { this.ui.toast('Objectius completats! Torna amb la Sàvia Elna', ''); this.audio.play('quest'); }
          }
        }
        break;
      }
      case 'chapter': { const ch = STORY.find((c) => c.id === d.done); this.ui.toast(`${ch ? ch.title : 'Capítol'} completat!`, 'big'); this.audio.play('levelup'); break; }
      case 'reward': this.ui.feed(`🏆 Recompensa: ${d.gold || 0} 🪙 · ${d.xp || 0} XP${d.item ? ' · objecte' : ''}`); break;
      case 'save': {
        const keepCreated = this.save && this.save.created;
        const sig = (x) => JSON.stringify([x && x.slots, x && x.runes, x && x.custom, x && x.level, x && x.skills, x && x.talents]);
        const changedBuild = sig(this.save) !== sig(d);
        this.save = JSON.parse(JSON.stringify(d)); if (keepCreated) this.save.created = keepCreated;
        this.persist();
        if (changedBuild) this.ui.buildBar(this.save);
        if (this.ui.refresh && !$('#modal').classList.contains('hidden')) this.ui.refresh();
        break;
      }
      case 'me': this.onMe(d); break;
      case 'note': this.ui.toast(d.msg); this.audio.play('ui'); break;
      case 'deny': this.ui.toast(d.msg, 'warn'); this.audio.play('deny'); if (d.key && this.player) delete this.player.cds[d.key]; break;
      case 'pk': {
        if (d.id === me) {
          this.myCp = d.cp;
          const pos = this.player ? this.player.pos.clone() : null;
          if (d.fin) {
            this.bigMsg('META!'); this.audio.play('levelup');
            this.ui.toast(`Temps: ${fmtTime(d.t)}${this.others.size ? ` · ${d.place}a posició` : ''}`, 'big');
            if (pos) { this.fx.levelUp(pos); this.fx.parts.burst(pos.clone().setY(pos.y + 2), 90, new THREE.Color('#ffd166'), { speed: 8, up: 6, size: 0.8, life: 1.6, col2: new THREE.Color('#7ef0ff') }); }
          } else {
            const LV = activeLevel();
            this.ui.toast(`Punt de control ${d.cp}/${LV.finish - 1}: ${LV.names[d.cp]} · ${fmtTime(d.t)}`, '');
            this.audio.play('quest');
            if (pos) this.fx.ring(pos, 4, new THREE.Color('#ffd166'), 0.7);
            const tip = this.pkTip(LV, d.cp); if (tip) setTimeout(() => this.ui.chat('', tip, true), 800);
          }
        } else if (d.fin) this.ui.feed(`🏁 ${esc(d.name)} arriba a la meta (${d.place}a) · ${fmtTime(d.t)}`);
        break;
      }
      case 'pkLevel': this.applyPkLevel(d.level); break;
      case 'tp': if (this.player) { if (this.mode === 'parkour') resetCrumbles(); this.player.pkReset = 0; this.player.plat = null; if (this.mode === 'parkour') { this.player.camYaw = 0; this.player.yaw = 0; } this.player.pos.set(d.x, d.y, d.z); this.player.vel.set(0, 0, 0); this.player._camInit = false; this.fx.ring(this.player.pos, 3, new THREE.Color('#ffd166'), 0.8); } break;
      case 'chest': this.world.openChest(d.id); this.audio.play('chest'); break;
      case 'waystone': this.ui.toast(`Pedra de portal descoberta: ${d.name}`, ''); this.audio.play('quest'); break;
      case 'launch': {
        const lp = LAUNCHPADS.find((l) => l.id === d.id);
        if (d.p === me && lp && this.player) {
          const is = ISLAND[lp.to];
          this.player.launch({ x: is.x, y: is.top, z: is.z });
          this.audio.play('launch');
          this.fx.parts.burst(this.player.pos.clone(), 60, new THREE.Color('#8ff7ff'), { speed: 6, up: 8, size: 0.7, life: 1.2 });
          if (lp.id === 'pedra_vent') this.ui.toast('La Pedra de Vent desperta!', 'big');
        }
        break;
      }
      case 'skin': { if (d.id === me) { this.save.skins = d.skins; this.applySkins(this.avatar, d.skins, this.save.cls, this.save.equip.arma); } else { const o = this.others.get(d.id); if (o && o.avatar) { o.skins = d.skins; this.applySkins(o.avatar, d.skins, o.cls, null); } } break; }
      case 'equip': { if (d.id === me) { this.avatar && this.avatar.setWeapon(d.weapon, this.save.skins.arma); } else { const o = this.others.get(d.id); if (o && o.avatar) o.avatar.setWeapon(d.weapon, o.skins && o.skins.arma); } break; }
      case 'chat': this.ui.chat(d.name, d.text); if (d.id !== me) { const o = this.others.get(d.id); if (o && o.label) { o.bubble = d.text; o.bubbleT = this.now + 5; } } break;
      case 'pvp': this.ui.pvpBoard(d, me); if (this.hill) this.hillOwner(d.zone); break;
      case 'match': {
        this.matchState = d.state;
        if (d.level && this.mode === 'parkour' && d.level !== this.pkLevelCur) this.applyPkLevel(d.level);
        if (d.racers) { const r = d.racers.find((x) => x[0] === me); if (r) this.myCp = r[1]; }
        this.ui.matchPanel(d, me);
        if (d.state === 'countdown' && document.querySelector('#modal [data-results]')) this.ui.closeModal();
        if (d.msg) {
          const big = /^[0-9]$/.test(d.msg) || /^Onada|^Cap |^Som-hi/.test(d.msg);
          if (big) this.bigMsg(d.msg); else this.ui.toast(d.msg, '');
          this.audio.play(/^[0-9]$/.test(d.msg) ? 'ui' : /Cap |—/.test(d.msg) ? 'boss' : 'quest');
        }
        break;
      }
      case 'matchEnd': this.ui.show('#deathScreen', false); this.ui.matchResults(d, me); this.audio.play(d.win ? 'levelup' : 'death'); break;
      case 'pvpEnd': { const myTeam = this.player.team; this.ui.toast(d.winner === myTeam ? 'Victòria!' : 'Derrota…', 'big'); this.audio.play(d.winner === myTeam ? 'levelup' : 'death'); this.ui.pvpBoard(d.info, me); break; }
      case 'status': break;
      default:
    }
  }

  onMe(d) {
    const p = this.player; if (!p) return;
    p.hp = d.hp; p.mhp = d.mhp; p.mana = d.mana; p.mmana = d.mmana; p.aura = d.aura; p.stats = d.stats;
    p.tr = d.tr; p.buffs = d.buffs || {}; p.statuses = d.st || {};
    if (this.avatar) {
      const glide = p.gliding;
      const wing = (p.tr && p.tr.key === 'fenix') ? '#ff7a2a' : this.avatar.wingSkin;
      if (!(p.tr && p.tr.key === 'fenix')) this.avatar.setWings(!!(glide && wing) || (glide && !wing), wing || '#cfefff');
    }
  }

  onCast(d) {
    const me = this.me();
    const isMe = d.p === me;
    const o = isMe ? null : this.others.get(d.p);
    const av = isMe ? this.avatar : o && o.avatar;
    const ab = d.ab || ABILITIES[d.key];
    if (!ab) return;
    if (!isMe && av) {
      let anim = ab.anim, speed = ab.animSpeed || 1;
      if (ab.kind === 'melee' && d.step !== undefined) { const s = ab.combo[d.step]; anim = s.anim; speed = s.animSpeed; }
      const moving = o && o.moving;
      av.anim.play(anim, { speed, upper: !!(ab.upper && moving) });
      av.obj.rotation.y = Math.atan2(d.aim[0], d.aim[2]);
    }
    if (av && ab.kind !== 'melee') {
      const hand = av.obj.position.clone().setY(av.obj.position.y + 1.3);
      this.fx.parts.burst(hand, 12, new THREE.Color((ELEMENTS[ab.el] || ELEMENTS.arca).glow), { speed: 2, up: 1, size: 0.5, life: 0.5 });
    }
    if (ab.kind !== 'melee') this.audio.play('cast_' + (ab.el === 'fisic' ? 'arca' : ab.el), isMe ? 0.8 : 0.35);
  }

  onHit(d) {
    const me = this.me();
    const pos = new THREE.Vector3(d.x, d.y, d.z);
    if (d.e) {
      const e = this.enemies.get(d.t);
      if (e) {
        e.hitFlash(); e.hp = d.hp;
        e.showHpUntil = this.now + 6;
        if (!d.dot && d.by === me) { this.fx.parts.burst(pos, d.c ? 16 : 8, new THREE.Color((ELEMENTS[d.el] || ELEMENTS.fisic).color), { speed: 4, size: 0.45, life: 0.4 }); }
      }
      const mine = d.by === me;
      const cls = (d.c ? 'crit ' : '') + (d.el && d.el !== 'fisic' ? d.el : '') + (mine ? '' : ' small');
      this.fx.nums.add(pos, d.c ? `${d.d}!` : String(d.d), cls, mine ? 1 : 0.8);
      if (d.cb) { this.fx.nums.add(pos.clone().setY(pos.y + 0.8), d.cb, 'combo'); this.audio.play('crit', 0.6); }
      if (mine && !d.dot) { this.audio.play(d.c ? 'crit' : 'hit', 0.5); this.hitStop = d.c ? 0.06 : 0.025; }
    } else {
      const isMe = d.t === me;
      const av = this.avatarOf(d.t);
      if (av) av.hitFlash();
      if (isMe) {
        this.player.hp = d.hp;
        if (d.d > 0) this.fx.nums.add(pos, '-' + d.d, 'taken');
        if (d.b) { this.audio.play('block'); this.fx.parts.burst(pos, 10, new THREE.Color('#ffffff'), { speed: 4, size: 0.4, life: 0.3 }); }
        else if (d.d > 0) { this.audio.play('hurt', 0.7); this.player.shake = Math.min(1, (this.player.shake || 0) + 0.35); this.flashScreen(); }
        if (d.kx || d.kz) this.player.knock.set(d.kx * 2.2, 0, d.kz * 2.2);
        if (d.st && this.avatar) this.avatar.anim.play(Math.random() < 0.5 ? 'hit_front' : 'hit_large', { speed: 1.4 });
      } else if (d.d > 0) {
        this.fx.nums.add(pos, String(d.d), 'small ' + (d.el || ''), 0.7);
        const o = this.others.get(d.t); if (o) o.hp = d.hp;
      }
    }
  }

  flashScreen() {
    let v = document.getElementById('vignette');
    if (!v) { v = document.createElement('div'); v.id = 'vignette'; Object.assign(v.style, { position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 8, boxShadow: 'inset 0 0 160px rgba(255,0,40,0.65)', opacity: 0, transition: 'opacity .35s' }); document.body.appendChild(v); }
    v.style.transition = 'none'; v.style.opacity = 1; requestAnimationFrame(() => { v.style.transition = 'opacity .5s'; v.style.opacity = 0; });
  }

  onPick(d) {
    if (d.kind === 'gold') { this.ui.feed(`+${d.amount} 🪙${d.full ? ' (inventari ple)' : ''}`); this.audio.play('coin'); }
    if (d.kind === 'potion') { this.ui.feed(`Poció de ${d.potion === 'vida' ? 'vida ❤️' : 'manà 💧'}`); this.audio.play('item'); }
    if (d.kind === 'item') { const r = RARITIES.find((x) => x.id === d.item.rar); this.ui.feed(`<span style="color:${r.color}">${esc(d.item.name)}</span>`); this.audio.play('item'); if (d.item.rar === 'epic' || d.item.rar === 'llegendari') this.ui.toast(`<span style="color:${r.color}">${esc(d.item.name)}</span>`, ''); }
    if (d.kind === 'cristall') { this.ui.toast('Cristall d\'aura recuperat!', ''); this.audio.play('quest'); }
  }

  avatarOf(id) { if (id === this.me()) return this.avatar; const o = this.others.get(id); return o && o.avatar; }

  addShield(av, dur) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(1.25, 24, 16), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uT: { value: 0 } }, vertexShader: 'varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }',
      fragmentShader: 'uniform float uT; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0-abs(dot(vN,vV)), 2.5); gl_FragColor = vec4(0.6,0.9,1.0, f*0.9*(1.0-uT)); }' }));
    m.position.y = 1;
    av.obj.add(m);
    const start = this.now;
    const tick = () => { const k = (this.now - start) / dur; if (k >= 1 || !av.obj.parent) { av.obj.remove(m); return; } m.material.uniforms.uT.value = Math.max(0, k * 2 - 1); m.rotation.y += 0.02; requestAnimationFrame(tick); };
    tick();
  }

  // ------------------------------------------------------------------ altres jugadors
  async addOther(p) {
    if (this.others.has(p.id)) return;
    const o = { id: p.id, name: p.name, cls: p.cls, hero: p.hero, level: p.level, hp: p.hp, maxHp: p.maxHp, buf: [], dead: false, team: p.team, skins: p.skins, avatar: null };
    this.others.set(p.id, o);
    const av = await HeroAvatar.create(p.hero, p.cls);
    if (!this.others.has(p.id)) return;
    o.avatar = av; av.obj.position.set(p.x, p.y, p.z);
    this.scene.add(av.obj);
    this.applySkins(av, p.skins, p.cls, null);
    const teamCls = this.modeKind === 'pvp' && this.player && p.team !== this.player.team ? 'enemy' : 'ally';
    o.label = this.ui.addLabel(av.obj, `<div class="nm">${CLS_ICON[p.cls]} ${esc(p.name)}</div><div class="hpb"><i></i></div>`, teamCls, 2.05, 80);
  }
  removeOther(id) { const o = this.others.get(id); if (!o) return; if (o.avatar) o.avatar.dispose(); this.ui.removeLabel(o.label); this.others.delete(id); }

  // ------------------------------------------------------------------ enemics
  // els avatars dels enemics només es creen quan són a prop (rendiment)
  addEnemy(info) {
    this.einfo.set(info.id, { ...info });
    this.cullEnemies(true, info.id);
  }
  cullEnemies(onlyOne, oneId) {
    const p = this.player; if (!p) return;
    const list = onlyOne ? [[oneId, this.einfo.get(oneId)]] : [...this.einfo];
    for (const [id, info] of list) {
      if (!info) continue;
      const e = this.enemies.get(id);
      if (e) { info.x = e.obj.position.x; info.y = e.obj.position.y; info.z = e.obj.position.z; info.ry = e.obj.rotation.y; info.hp = e.hp; }
      const d = Math.hypot(info.x - p.pos.x, info.z - p.pos.z);
      const boss = ENEMIES[info.type] && ENEMIES[info.type].boss;
      const rin = boss ? 170 : 105, rout = boss ? 220 : 135;
      if (!this.enemies.has(id) && d < rin) this.createEnemyAvatar(info);
      else if (e && !e.dead && d > rout && this.bossId !== id) {
        e.dispose(); this.ui.removeLabel(e.label);
        if (p.lockTarget === e) p.lockTarget = null;
        this.enemies.delete(id);
      }
    }
  }
  async createEnemyAvatar(info) {
    const def = ENEMIES[info.type];
    if (!def) return;
    this.enemies.set(info.id, null);
    const e = await MonsterAvatar.create(info);
    if (!this.enemies.has(info.id) || this.enemies.get(info.id) !== null || !this.einfo.has(info.id)) { e.dispose(); return; }
    this.enemies.set(info.id, e);
    if (info.hp !== undefined) e.hp = info.hp;
    this.scene.add(e.obj);
    const elite = !!(info.v && info.name !== def.name);
    if (!def.boss) e.label = this.ui.addLabel(e.obj, `<div>${esc(info.name)} <span style="opacity:.7">Nv ${info.lvl}</span></div><div class="hpb"><i></i></div>`, 'enemy' + (elite ? ' elite' : ''), def.height + 0.35, 45);
    e.boss = def.boss; e.title = def.title; e.name = info.name;
    info.s = 'idle';
  }

  // ------------------------------------------------------------------ botí
  addLoot(l) {
    if (this.lootObjs.has(l.id)) return;
    const g = new THREE.Group();
    let mesh;
    if (l.kind === 'gold') mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.08, 16), new THREE.MeshToonMaterial({ color: '#ffd166', emissive: '#a86b00', emissiveIntensity: 0.6 }));
    else if (l.kind === 'potion') mesh = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), new THREE.MeshToonMaterial({ color: l.potion === 'vida' ? '#ff4d6d' : '#4cc3ff', emissive: l.potion === 'vida' ? '#600' : '#035', emissiveIntensity: 0.8 }));
    else mesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.32, 0), new THREE.MeshToonMaterial({ color: '#e8d8ff', emissive: '#8a4dff', emissiveIntensity: 0.8 }));
    if (l.kind === 'gold') mesh.rotation.x = Math.PI / 2;
    g.add(mesh);
    const glow = this.world.makeGlowSprite(l.kind === 'gold' ? '#ffd166' : l.kind === 'potion' ? (l.potion === 'vida' ? '#ff6b8a' : '#6bd0ff') : '#c09bff', 1.6);
    g.add(glow);
    if (l.kind === 'item') {
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.25, 6, 8, 1, true), new THREE.MeshBasicMaterial({ color: '#c09bff', transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }));
      beam.position.y = 3; g.add(beam);
    }
    g.position.set(l.x, l.y + 0.6, l.z);
    g.userData.base = l.y + 0.6;
    this.scene.add(g);
    this.lootObjs.set(l.id, { obj: g, mesh, kind: l.kind });
  }
  removeLoot(id, by) {
    const l = this.lootObjs.get(id); if (!l) return;
    if (by) this.fx.parts.burst(l.obj.position, 10, new THREE.Color(l.kind === 'gold' ? '#ffd166' : '#c09bff'), { speed: 3, up: 2, size: 0.4, life: 0.5 });
    this.scene.remove(l.obj); this.lootObjs.delete(id);
  }

  // ------------------------------------------------------------------ instantànies
  onSnap(s) {
    this.serverT = s.t;
    if (Math.abs(this.renderT - (s.t - 0.12)) > 0.6) this.renderT = s.t - 0.12;
    for (const a of s.P) {
      const o = this.others.get(a[0]); if (!o) continue;
      o.buf.push({ t: s.t, x: a[1], y: a[2], z: a[3], ry: a[4] }); if (o.buf.length > 8) o.buf.shift();
      o.anim = a[5]; o.hp = a[6]; o.maxHp = a[7]; o.flags = a[8]; o.dead = !!(a[8] & 1);
    }
    for (const a of s.E) {
      const e = this.enemies.get(a[0]);
      if (!e) { const info = this.einfo.get(a[0]); if (info) { info.x = a[1]; info.y = a[2]; info.z = a[3]; info.ry = a[4]; info.hp = a[6]; info.maxHp = a[7]; } continue; }
      e.pushSnap(s.t, a[1], a[2], a[3], a[4], ['idle', 'move', 'windup', 'recover', 'hit', 'dead', 'spawn', 'stun', 'return', 'cast'][a[5]], a[6], a[7], a[8]);
    }
  }

  // ------------------------------------------------------------------ accions del jugador
  tryCast(kind, slot) {
    const p = this.player, s = this.save;
    if (!p || p.dead || this.ui.modalOpen()) return;
    if (p.statuses.stun || p.statuses.freeze) return;
    const c = CLASSES[s.cls];
    let key;
    if (kind === 'basic') key = c.basic;
    else if (kind === 'ult') key = c.ult;
    else { const slots = activeSlots(s); key = slots[slot]; }
    const ab = abilityFor(s, key);
    if (!ab) return;
    if ((p.cds[key] || 0) > this.now) return;
    if (ab.kind === 'transform' && p.aura < 100) { this.ui.toast('L\'aura encara no està carregada', 'warn'); return; }
    if ((ab.mana || 0) > p.mana) { this.ui.toast(c.melee ? 'No tens prou energia' : 'No tens prou manà', 'warn'); this.audio.play('deny'); return; }
    // cooldown local (el servidor el confirma)
    const haste = p.buffs.haste ? 0.45 : 0;
    let cd = ab.cd * (1 - (p.stats ? p.stats.cdr : 0) / 100);
    let step = null;
    if (ab.kind === 'melee') {
      const trs = p.tr && p.tr.sm ? 1 / (1 + (p.tr.sm - 1) * 0.5) : 1;
      if (ab.single) { step = ab.combo[0]; cd = Math.max(cd, step.time * trs); }
      else {
        if (this.now - (p.comboT || -9) > 1.15) p.combo = 0;
        step = ab.combo[(p.combo || 0) % ab.combo.length];
        cd = step.time * (1 - haste * 0.6) * trs;
        p.combo = ((p.combo || 0) + 1) % ab.combo.length; p.comboT = this.now;
      }
    } else if (kind === 'basic') cd *= (1 - haste);
    p.cds[key] = this.now + cd; p.cdTotal[key] = cd;
    const aim = p.aimDir.toArray().map((v) => Math.round(v * 1000) / 1000);
    const tgt = (this.targetPoint || p.aimPoint).toArray().map((v) => Math.round(v * 100) / 100);
    this.net.send('act', { k: kind, slot, aim, tgt, pos: [p.pos.x, p.pos.y, p.pos.z] });
    // predicció local: animació i moviment
    const moving = p.moveSpeed > 1;
    let anim = ab.anim, speed = ab.animSpeed || 1;
    if (step) { anim = step.anim; speed = step.animSpeed; }
    this.avatar.anim.play(anim, { speed, upper: !!(ab.upper && moving) });
    p.castLock = Math.max(0.35, (step ? step.release : ab.release || 0.3) + 0.15);
    p.yaw = Math.atan2(aim[0], aim[2]);
    if (ab.kind === 'dash' || ab.kind === 'blink') p.startDash(ab, aim);
    if (ab.kind !== 'melee' && ab.kind !== 'transform') this.avatar.setExpression('angry', 0.6, 600);
  }

  handleInput(dt) {
    const inp = this.input, p = this.player;
    if (!p) return;
    const ui = this.ui;
    // finestres
    if (inp.pressed.has('Escape')) {
      if (!$('#chatIn').classList.contains('hidden')) { $('#chatIn').classList.add('hidden'); $('#chatIn').blur(); }
      else if (!$('#modal').classList.contains('hidden')) ui.closeModal();
      else ui.openOptions(true);
    }
    if (ui.modalOpen()) { this.targetPoint = null; return; }
    if (inp.hit('inv')) return ui.openInventory();
    if (inp.hit('grim')) return ui.openGrimori();
    if (inp.hit('char')) return ui.openCharacter();
    if (inp.hit('map')) return ui.openMap();
    if (inp.hit('chat')) { const ci = $('#chatIn'); ci.classList.remove('hidden'); ci.focus(); if (document.pointerLockElement) document.exitPointerLock(); return; }
    if (p.dead) return;
    // combat
    if (inp.mouse.left && (inp.locked || this.touchMode || !this.input.wantLock || inp.mouse.leftPressed)) this.tryCast('basic');
    if (inp.hit('ult')) this.tryCast('ult');
    for (let i = 0; i < 4; i++) {
      const name = 'ab' + (i + 1);
      const key = this.slotKey(i);
      const ab = abilityFor(this.save, key);
      const ground = ab && (ab.kind === 'ground' || (ab.kind === 'field' && !ab.follow));
      if (ground) {
        if (inp.hit(name)) this.targeting = { slot: i, ab };
        if (inp.up(name) && this.targeting && this.targeting.slot === i) { this.tryCast('ab', i); this.targeting = null; }
      } else if (inp.hit(name)) this.tryCast('ab', i);
    }
    if (inp.hit('potionHp')) this.net.send('act', { k: 'potion', kind: 'vida' });
    if (inp.hit('potionMana')) this.net.send('act', { k: 'potion', kind: 'mana' });
    if (inp.hit('lock')) this.cycleLock();
    if (inp.hit('emote') && p.onGround) this.avatar.anim.play('dance', { speed: 1, loop: true });
    if (this.avatar.anim.overlayName === 'dance' && (p.moveSpeed > 0.5 || inp.mouse.left)) this.avatar.anim.stopOverlay(0.2);
    // interaccions
    this.updateInteract(dt);
  }

  slotKey(i) { return activeSlots(this.save)[i]; }

  cycleLock() {
    const p = this.player;
    const cands = [...this.enemies.values()].filter((e) => e && !e.dead && e.obj.position.distanceTo(p.pos) < 32);
    if (!cands.length) { p.lockTarget = null; return; }
    const fwd = new THREE.Vector3(Math.sin(p.camYaw), 0, Math.cos(p.camYaw));
    cands.sort((a, b) => score(a) - score(b));
    function score(e) { const d = e.obj.position.clone().sub(p.pos); const dist = d.length(); d.y = 0; d.normalize(); return dist * (2 - d.dot(fwd)); }
    const i = p.lockTarget ? cands.indexOf(p.lockTarget) : -1;
    p.lockTarget = cands[(i + 1) % cands.length];
    if (i >= 0 && (i + 1) % cands.length === 0 && cands.length > 1) p.lockTarget = null;
    this.audio.play('ui');
  }

  updateInteract(dt) {
    const p = this.player;
    let best = null, bd = 1e9;
    for (const it of this.world.interactables) {
      const d = Math.hypot(it.x - p.pos.x, it.z - p.pos.z);
      if (d < it.r && Math.abs(it.y - p.pos.y) < 4 && d < bd) { bd = d; best = it; }
    }
    // reviure companys
    let revive = null;
    for (const o of this.others.values()) if (o.dead && o.avatar && o.avatar.obj.position.distanceTo(p.pos) < 3 && this.modeKind !== 'pvp') revive = o;
    if (revive) {
      const holding = this.input.is('interact');
      this.reviveT = holding ? (this.reviveT || 0) + dt : 0;
      this.ui.prompt(`<kbd>F</kbd> Mantén per reviure ${esc(revive.name)} <div id="reviveBar"><i style="width:${Math.min(100, (this.reviveT || 0) / 2.5 * 100)}%"></i></div>`);
      if (this.reviveT > 2.5) { this.net.send('act', { k: 'revive', target: revive.id }); this.reviveT = 0; }
      return;
    }
    if (!best) { this.ui.prompt(null); return; }
    this.ui.prompt(`<kbd>F</kbd> ${esc(best.label)}`);
    if (this.input.hit('interact')) {
      this.audio.play('ui');
      if (best.type === 'npc') this.ui.openNpc(best.id);
      else if (best.type === 'chest') this.net.send('act', { k: 'interact', what: 'chest', id: best.id });
      else if (best.type === 'waystone') { this.net.send('act', { k: 'interact', what: 'waystone', id: best.id }); setTimeout(() => this.ui.openWaystone(best.id), 150); }
      else if (best.type === 'launch') this.net.send('act', { k: 'interact', what: 'launch', id: best.id });
    }
  }

  // ------------------------------------------------------------------ controls tàctils
  setupTouch() {
    this.touchMode = true; this.input.touchMode = true;
    const t = $('#touch'); t.classList.remove('hidden');
    t.innerHTML = `<div class="stick"><div class="knob"></div></div>`;
    const btn = (label, right, bottom, fn, size = 62) => { const b = document.createElement('div'); b.className = 'tb'; b.textContent = label; Object.assign(b.style, { right: right + 'px', bottom: bottom + 'px', width: size + 'px', height: size + 'px' }); t.appendChild(b); b.addEventListener('touchstart', (e) => { e.preventDefault(); fn(true); }); b.addEventListener('touchend', (e) => { e.preventDefault(); fn(false); }); return b; };
    btn('⚔', 30, 40, (d) => { this.input.mouse.left = d; }, 84);
    btn('1', 130, 30, (d) => { if (d) this.input.pressed.add('Digit1'); else this.input.released.add('Digit1'); });
    btn('2', 130, 105, (d) => { if (d) this.input.pressed.add('Digit2'); else this.input.released.add('Digit2'); });
    btn('3', 60, 140, (d) => { if (d) this.input.pressed.add('Digit3'); else this.input.released.add('Digit3'); });
    btn('4', 200, 70, (d) => { if (d) this.input.pressed.add('Digit4'); else this.input.released.add('Digit4'); });
    btn('R', 210, 145, (d) => { if (d) this.input.pressed.add('KeyR'); });
    btn('⤒', 30, 220, (d) => { if (d) { this.input.pressed.add('Space'); this.input.down.add('Space'); } else this.input.down.delete('Space'); });
    btn('↺', 110, 200, (d) => { if (d) this.input.pressed.add('KeyQ'); });
    btn('F', 30, 300, (d) => { if (d) { this.input.pressed.add('KeyF'); this.input.down.add('KeyF'); } else this.input.down.delete('KeyF'); }, 50);
    const stick = t.querySelector('.stick'), knob = t.querySelector('.knob');
    let sid = null, sx = 0, sy = 0;
    stick.addEventListener('touchstart', (e) => { const tt = e.changedTouches[0]; sid = tt.identifier; const r = stick.getBoundingClientRect(); sx = r.left + r.width / 2; sy = r.top + r.height / 2; e.preventDefault(); });
    let lid = null, lx = 0, ly = 0;
    $('#c').addEventListener('touchstart', (e) => { for (const tt of e.changedTouches) if (tt.clientX > innerWidth * 0.35 && lid === null) { lid = tt.identifier; lx = tt.clientX; ly = tt.clientY; } });
    addEventListener('touchmove', (e) => {
      for (const tt of e.changedTouches) {
        if (tt.identifier === sid) { const dx = tt.clientX - sx, dy = tt.clientY - sy; const l = Math.min(55, Math.hypot(dx, dy)); const a = Math.atan2(dy, dx); knob.style.transform = `translate(${Math.cos(a) * l}px, ${Math.sin(a) * l}px)`; this.input.touch.active = true; this.input.touch.move.set(Math.cos(a) * l / 55, -Math.sin(a) * l / 55); }
        if (tt.identifier === lid) { this.input.mouse.dx += (tt.clientX - lx) * 1.6; this.input.mouse.dy += (tt.clientY - ly) * 1.6; lx = tt.clientX; ly = tt.clientY; }
      }
    }, { passive: true });
    addEventListener('touchend', (e) => { for (const tt of e.changedTouches) { if (tt.identifier === sid) { sid = null; knob.style.transform = ''; this.input.touch.active = false; this.input.touch.move.set(0, 0); } if (tt.identifier === lid) lid = null; } });
  }

  // ------------------------------------------------------------------ bucle
  loop() {
    requestAnimationFrame(() => this.loop());
    const nowMs = performance.now();
    let dt = Math.min(0.05, Math.max(0, (nowMs - this.lastFrame) / 1000));
    this.lastFrame = nowMs;
    if (this.hitStop > 0) { this.hitStop -= dt; dt *= 0.15; }
    this.now += dt;
    this.renderT += dt;
    if (this.renderT > this.serverT) this.renderT = this.serverT;
    if (this.state === 'loading') { this.renderer.setClearColor('#0b0a18'); this.renderer.clear(); return; }
    const W = innerWidth, H = innerHeight;
    if (this.state === 'playing' && this.player) this.updatePlaying(dt);
    else this.updateMenu(dt);
    this.audio.update();
    this.renderer.info.reset();
    this.composer.render(dt);
    this.input.endFrame();
    if (this.settings.fps) {
      this.frames++; this.fpsT += dt;
      if (this.fpsT > 0.5) { let el = $('#fps'); if (!el) { el = document.createElement('div'); el.id = 'fps'; Object.assign(el.style, { position: 'fixed', left: '50%', top: '4px', transform: 'translateX(-50%)', font: '700 12px Nunito', color: '#9f9', zIndex: 50, textShadow: '0 1px 2px #000' }); document.body.appendChild(el); } el.textContent = Math.round(this.frames / this.fpsT) + ' FPS · ' + this.renderer.info.render.calls + ' crides'; this.frames = 0; this.fpsT = 0; }
    }
    void W; void H;
  }

  updateMenu(dt) {
    if (!this.world) return;
    const t = this.now * 0.04;
    if (this.state === 'chars') {
      const p = this.preview ? this.preview.obj.position : new THREE.Vector3(-1, height(-1, 19), 19);
      this.camera.position.lerp(new THREE.Vector3(p.x - 1.2, p.y + 1.45, p.z + 3.6), Math.min(1, dt * 3));
      this.camera.lookAt(p.x - 0.5, p.y + 1.05, p.z);
      if (this.preview) {
        this.preview.obj.rotation.y = Math.sin(this.now * 0.35) * 0.45;
        this.preview.update(dt, this.camera);
        if (!this.preview.anim.busy() && Math.random() < dt * 0.15) this.preview.anim.play(['magic_2h_b', 'yes', 'cast_1h', 'sword_c', 'magic_area_a'][Math.floor(Math.random() * 5)], { speed: 1.2 });
      }
    } else {
      const c = new THREE.Vector3(Math.sin(t) * 70, 30 + Math.sin(t * 0.7) * 6, Math.cos(t) * 70 - 10);
      this.camera.position.lerp(c, Math.min(1, dt * 2));
      this.camera.lookAt(0, 8, -15);
    }
    this.world.timeOfDay = (this.world.timeOfDay + dt / 900) % 1;
    this.world.update(dt, this.now, this.camera, this.preview ? this.preview.obj.position : new THREE.Vector3(0, 2, 0), ZONE.vila);
    if (this.fx) this.fx.update(dt, this.camera, innerWidth, innerHeight);
  }

  updatePlaying(dt) {
    const p = this.player, cam = this.camera;
    // si va lent, suggereix baixar la qualitat (una sola vegada)
    if (!this._perfHint && this.settings.quality !== 'baixa') {
      this._perfN = (this._perfN || 0) + 1; this._perfT = (this._perfT || 0) + dt;
      if (this._perfT > 12) {
        if (this._perfN / this._perfT < 24) { this._perfHint = true; this.ui.toast('Va lent? Prova la qualitat <b>Baixa</b> a Opcions (Esc)', 'warn'); }
        this._perfN = 0; this._perfT = 0;
      }
    }
    this.handleInput(dt);
    const enemies = [...this.enemies.values()].filter(Boolean);
    p.computeAim(cam, enemies);
    if (this.mode === 'parkour') {
      this.courseT = this.renderT + 0.12;
      setCourseTime(this.courseT);
      this.world.updateCourse(this.courseT, this.myCp || 0);
    }
    p.update(dt, this.input, cam);
    p.scale = this.avatar ? this.avatar.scaleCur : 1;
    p.updateCamera(cam, dt);
    // avatar local
    const av = this.avatar;
    if (av) {
      av.obj.position.copy(p.pos);
      av.obj.rotation.y = p.yaw;
      this.driveLocomotion(av, p.anim, p.moveSpeed, this.save.cls);
      const glide = p.gliding;
      const fen = p.tr && p.tr.key === 'fenix';
      av.setWings(fen || (glide), fen ? '#ff7a2a' : (av.wingSkin || '#d6f3ff'));
      if (p.tr) this.auraParticles(av, p.tr.key, dt);
      av.update(dt, cam);
    }
    // altres jugadors
    for (const o of this.others.values()) {
      if (!o.avatar) continue;
      this.interpOther(o, dt);
      if (o.anim === 'roll' && o.lastAnim !== 'roll') o.avatar.anim.play('roll', { speed: 1.35 });
      if (o.anim === 'jump' && o.lastAnim !== 'jump') o.avatar.anim.play('jump_start', { speed: 1.6 });
      o.lastAnim = o.anim;
      this.driveLocomotion(o.avatar, o.dead ? 'dead' : o.anim || 'idle', o.speed || 0, o.cls);
      o.avatar.setWings(!!(o.flags & 16) || !!(o.flags & 2 && o.cls === 'foc'), o.avatar.wingSkin || '#d6f3ff');
      if (o.flags & 2) this.auraParticles(o.avatar, CLASSES[o.cls].ult, dt);
      o.avatar.update(dt, cam);
      if (o.label) { const i = o.label.el.querySelector('i'); if (i) i.style.width = Math.max(0, o.hp / o.maxHp * 100) + '%'; }
    }
    // enemics
    let boss = null;
    for (const e of enemies) {
      e.update(dt, this.renderT, cam);
      if (e.label) {
        const show = (e.hp < e.maxHp) || e === p.aimTarget || e === p.lockTarget;
        e.label.hidden = !show && e.obj.position.distanceTo(p.pos) > 14;
        const i = e.label.el.querySelector('i'); if (i) i.style.width = Math.max(0, e.hp / e.maxHp * 100) + '%';
      }
      if (e.boss && !e.dead && (this.bossId === e.id || e.hp < e.maxHp) && e.obj.position.distanceTo(p.pos) < 70) boss = e;
    }
    this.ui.boss(boss ? { name: boss.name, title: boss.title, hp: boss.hp, maxHp: boss.maxHp } : null);
    // marcador d'objectiu
    this.updateTargetMarker(p);
    // botí
    for (const l of this.lootObjs.values()) { l.obj.position.y = l.obj.userData.base + Math.sin(this.now * 2.5 + l.obj.id) * 0.15; l.mesh.rotation.y += dt * 2.5; }
    // món
    const zone = zoneAt(p.pos.x, p.pos.z, p.pos.y);
    if (zone !== this.zone) {
      this.zone = zone;
      this.ui.toast(zone.name, 'zone');
      const w = WAYSTONES.find((x) => x.id === zone.id);
      void w;
    }
    this.world.timeOfDay = (this.world.timeOfDay + dt / 1080) % 1;
    const sky = this.world.update(dt, this.now, cam, p.pos, zone);
    this.fx.ambient(dt, p.pos, zone, sky.night);
    this.fx.update(dt, cam, innerWidth, innerHeight);
    const inCombat = enemies.some((e) => !e.dead && e.obj.position.distanceTo(p.pos) < 25 && (e.serverState === 'move' || e.serverState === 'windup'));
    this.audio.setZone(zone.id, inCombat, !!boss);
    // HUD
    this.ui.updateHud(p, this.save, this.now);
    this.ui.updateLabels(cam, innerWidth, innerHeight);
    this.updateGuide(dt, cam, p);
    this.hudT = (this.hudT || 0) - dt;
    if (this.hudT <= 0) {
      this.hudT = 0.1;
      this.ui.minimap(this.world, p.pos, [...this.others.values()].filter((o) => o.avatar).map((o) => o.avatar), enemies, p.camYaw, zone, this.save);
      this.ui.clock(this.world.timeOfDay);
      if (this.modeKind === 'story' || !this.modeKind) this.ui.quests(this.save);
      this.cullT = (this.cullT || 0) - 1;
      if (this.cullT <= 0) { this.cullT = 4; this.cullEnemies(); }
      this.ui.party([...this.others.values()].filter((o) => this.modeKind !== 'pvp' || (this.mode !== 'ffa' && o.team === this.player.team)).map((o) => ({ name: o.name, cls: o.cls, level: o.level, hp: o.hp, maxHp: o.maxHp, dead: o.dead })));
      this.updateNpcMarkers();
      this.ui.updateBadges(this.save);
      $('#crosshair').classList.toggle('target', !!p.aimTarget);
      if (p.dead && p.respawnAt) { const left = Math.ceil(p.respawnAt - this.now); $('#respawnBtn').disabled = left > 0; $('#respawnBtn').textContent = left > 0 ? `Reaparèixer (${left})` : 'Reaparèixer'; }
    }
    // xat
    const ci = $('#chatIn');
    if (!ci._bound) { ci._bound = true; ci.addEventListener('keydown', (e) => { if (e.key === 'Enter') { const v = ci.value.trim(); if (v) this.net.send('chat', { text: v }); ci.value = ''; ci.classList.add('hidden'); ci.blur(); } e.stopPropagation(); }); }
  }

  driveLocomotion(av, anim, speed, cls) {
    const c = CLASSES[cls];
    const map = { idle: c.idle, walk: 'walk', run: 'run', sprint: 'sprint', back: 'walk_back', left: 'run_left', right: 'run_right', jump: 'jump_loop', fall: 'fall', glide: 'glide', roll: null, block: c.block, stun: 'hit_large', dead: null };
    const name = map[anim];
    if (anim === 'dead' || anim === 'roll') return;
    if (!name) return;
    let sp = 1;
    if (anim === 'run' || anim === 'left' || anim === 'right') sp = Math.max(0.8, Math.min(1.35, speed / 6.4));
    if (anim === 'walk') sp = Math.max(0.7, Math.min(1.3, speed / 2.8));
    if (anim === 'sprint') sp = Math.max(0.8, Math.min(1.3, speed / 9.5));
    av.anim.setBase(name, anim === 'jump' || anim === 'fall' ? 0.15 : 0.22, sp);
  }

  interpOther(o, dt) {
    const t = this.renderT;
    const b = o.buf;
    if (!b.length) return;
    let a0 = b[0], a1 = b[b.length - 1];
    for (let i = 0; i < b.length - 1; i++) if (b[i].t <= t && b[i + 1].t >= t) { a0 = b[i]; a1 = b[i + 1]; break; }
    const k = a1.t > a0.t ? Math.max(0, Math.min(1.25, (t - a0.t) / (a1.t - a0.t))) : 1;
    const pos = o.avatar.obj.position;
    const prev = pos.clone();
    pos.set(a0.x + (a1.x - a0.x) * k, a0.y + (a1.y - a0.y) * k, a0.z + (a1.z - a0.z) * k);
    let d = a1.ry - o.avatar.obj.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d));
    o.avatar.obj.rotation.y += d * Math.min(1, dt * 12);
    const sp = Math.hypot(pos.x - prev.x, pos.z - prev.z) / Math.max(dt, 1e-3);
    o.speed = (o.speed || 0) + (sp - (o.speed || 0)) * Math.min(1, dt * 8);
    o.moving = o.speed > 1;
  }

  auraParticles(av, key, dt) {
    const ab = ABILITIES[key]; if (!ab) return;
    const c = av.trColor;
    const pos = av.obj.position;
    for (let i = 0; i < 3; i++) {
      const a = Math.random() * Math.PI * 2, r = 0.5 + Math.random() * 0.4;
      this.fx.parts.emit(pos.x + Math.cos(a) * r, pos.y + Math.random() * 1.8, pos.z + Math.sin(a) * r, 0, 1.5 + Math.random() * 1.5, 0, c, 0.5, 0.6, 0.5, 0.5);
    }
    if (key === 'hivern' && Math.random() < 0.5) { const a = Math.random() * 6.28, r = Math.random() * 8; this.fx.parts.emit(pos.x + Math.cos(a) * r, pos.y + 0.2, pos.z + Math.sin(a) * r, 0, 0.8, 0, new THREE.Color('#bff3ff'), 0.6, 1.2, 0, 0.5); }
    void dt;
  }

  updateTargetMarker(p) {
    if (!this.targetRing) {
      this.targetRing = new THREE.Mesh(new THREE.RingGeometry(0.8, 1, 32), new THREE.MeshBasicMaterial({ color: '#ff5a5a', transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
      this.targetRing.rotation.x = -Math.PI / 2; this.scene.add(this.targetRing);
      this.groundAim = new THREE.Mesh(new THREE.RingGeometry(0.94, 1, 48), new THREE.MeshBasicMaterial({ color: '#ffe08a', transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }));
      this.groundAim.rotation.x = -Math.PI / 2; this.scene.add(this.groundAim);
    }
    const t = p.lockTarget || p.aimTarget;
    this.targetRing.visible = !!t && !t.dead;
    if (t) { const tp = t.obj.position; this.targetRing.position.set(tp.x, groundAt(tp.x, tp.z, tp.y + 1) + 0.08, tp.z); this.targetRing.scale.setScalar(t.def.radius * 1.4 + 0.4); this.targetRing.material.color.set(p.lockTarget ? '#ffcf4a' : '#ff5a5a'); }
    // previsualització d'habilitats de zona
    if (this.targeting) {
      const ab = this.targeting.ab;
      const ap = p.aimPoint.clone();
      const d = Math.hypot(ap.x - p.pos.x, ap.z - p.pos.z);
      if (d > ab.range) { ap.x = p.pos.x + (ap.x - p.pos.x) / d * ab.range; ap.z = p.pos.z + (ap.z - p.pos.z) / d * ab.range; }
      ap.y = groundAt(ap.x, ap.z, p.pos.y + 4);
      this.groundAim.visible = true; this.groundAim.position.set(ap.x, ap.y + 0.1, ap.z); this.groundAim.scale.setScalar(ab.radius);
      this.groundAim.material.color.set((ELEMENTS[ab.el] || ELEMENTS.arca).color);
      this.targetPoint = ap;
    } else { this.groundAim.visible = false; this.targetPoint = null; }
  }

  updateNpcMarkers() {
    const s = this.save; const ch = STORY[s.story.idx];
    let elna = '';
    if (ch) { if (!s.story.accepted) elna = '!'; else if (ch.objectives.every((o, i) => (s.story.progress[i] || 0) >= o.n)) elna = '?'; }
    this.world.setMarker('elna', elna, '#ffd166');
    let bru = '';
    if (!s.bounty) bru = '!'; else { const b = this.findBounty(s.bounty.id); if (b && s.bounty.progress >= b.obj.n) bru = '?'; }
    this.world.setMarker('bru', bru, '#9fe8ff');
    this.world.setMarker('oleguer', '', ''); this.world.setMarker('rina', '', '');
    if (!this._npcLabels) {
      this._npcLabels = true;
      for (const n of NPCS) { const w = this.world.npcs[n.id]; if (w) this.ui.addLabel(w.obj, `${esc(n.name)}<small>${esc(n.role)}</small>`, 'npc', 2.35, 30); }
    }
  }
  findBounty(id) { return BOUNTIES.find((b) => b.id === id); }

  // missatge gran al centre de la pantalla (compte enrere, onades…)
  bigMsg(text) {
    const el = $('#bigmsg'); el.textContent = text; el.style.opacity = 1;
    clearTimeout(this._bigT); this._bigT = setTimeout(() => { el.style.opacity = 0; }, 1600);
  }
  // Rei del turó: cercle de llum al centre de l'arena
  setHill(on) {
    if (!on) { if (this.hill) { this.scene.remove(this.hill); this.hill = null; } return; }
    if (this.hill) return;
    const is = ISLAND.arena;
    const g = new THREE.Group();
    const ring = new THREE.Mesh(new THREE.RingGeometry(7.4, 8, 64), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.85, side: THREE.DoubleSide, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.45; g.add(ring);
    const disc = new THREE.Mesh(new THREE.CircleGeometry(7.4, 48), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.12, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    disc.rotation.x = -Math.PI / 2; disc.position.y = 0.42; g.add(disc);
    const col = new THREE.Mesh(new THREE.CylinderGeometry(7.6, 7.6, 14, 48, 1, true), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    col.position.y = 7; g.add(col);
    g.position.set(is.x, is.top, is.z);
    this.scene.add(g); this.hill = g; this.hillOwner(0);
  }
  hillOwner(z) {
    if (!this.hill) return;
    const c = new THREE.Color(z === 1 ? '#4da3ff' : z === 2 ? '#ff5a5a' : z === -1 ? '#c78bff' : '#ffffff');
    this.hill.children.forEach((m) => m.material.color.copy(c));
  }

  // guia cap a l'objectiu actual: brúixola, marcador a la pantalla, columna de llum i rastre
  updateGuide(dt, cam, p) {
    this.guideT = (this.guideT || 0) - dt;
    if (this.guideT <= 0) {
      this.guideT = 0.3;
      if (this.mode === 'parkour') {
        const LV = activeLevel();
        const c = LV.checkpoints[Math.min(LV.finish, (this.myCp || 0) + 1)];
        this.guide = this.myCp >= LV.finish ? null : { x: c.x, z: c.z, y: c.y, text: c.i === LV.finish ? 'Arriba a la meta!' : `Punt de control ${c.i}: ${LV.names[c.i]}`, noTrail: true };
      } else this.guide = (this.modeKind && this.modeKind !== 'story') || this.settings.guide === false ? null : questTarget(this.save, p.pos);
    }
    const g = this.guide;
    const box = $('#guide'), wp = $('#waypoint');
    if (!g) { box.classList.add('hidden'); wp.classList.add('hidden'); this.world.setBeacon(null); this.ui.guideTarget = null; return; }
    const gy = g.y !== undefined ? g.y : g.island ? ISLAND[g.island].top : height(g.x, g.z);
    const dx = g.x - p.pos.x, dz = g.z - p.pos.z, dist = Math.hypot(dx, dz);
    this.ui.guideTarget = g;
    box.classList.remove('hidden');
    box.classList.toggle('low', !$('#bossBar').classList.contains('hidden'));
    const via = g.via === 'Pedra de Vent' ? ' — ves a la Pedra de Vent' : g.via === 'corrent de vent' ? ' — agafa el corrent de vent' : g.via ? ' — ' + g.via : '';
    const txt = g.text + via;
    if (this._guideTxt !== txt) { $('#guideText').textContent = txt; this._guideTxt = txt; }
    $('#guideDist').textContent = dist < 6 ? 'Hi ets!' : `${Math.round(dist)} m`;
    const rel = Math.atan2(dx, dz) - p.camYaw;
    $('#guideArrow').style.transform = `rotate(${(-rel * 180 / Math.PI).toFixed(1)}deg)`;
    // marcador a la pantalla (o fletxa a la vora si queda fora)
    if (dist < 6) wp.classList.add('hidden');
    else {
      wp.classList.remove('hidden');
      const v = this._wpV || (this._wpV = new THREE.Vector3());
      v.set(g.x, gy + 2.5, g.z).project(cam);
      const W = innerWidth, H = innerHeight, m = 46;
      let sx = (v.x * 0.5 + 0.5) * W, sy = (-v.y * 0.5 + 0.5) * H;
      const behind = v.z > 1;
      const on = !behind && sx > m && sx < W - m && sy > m + 40 && sy < H - m - 80;
      wp.classList.toggle('edge', !on);
      if (!on) {
        let ex = sx - W / 2, ey = sy - H / 2;
        if (behind) { ex = -ex; ey = -ey; if (Math.abs(ey) < 1) ey = H; }
        const k = Math.min((W / 2 - m) / Math.max(1e-3, Math.abs(ex)), (H / 2 - m - 60) / Math.max(1e-3, Math.abs(ey)));
        sx = W / 2 + ex * k; sy = H / 2 + ey * k;
        wp.style.setProperty('--rot', (Math.atan2(ex, -ey) * 180 / Math.PI).toFixed(1) + 'deg');
      }
      wp.style.transform = `translate(${sx.toFixed(0)}px, ${sy.toFixed(0)}px) translate(-50%, -100%)`;
      $('#wpDist').textContent = `${Math.round(dist)} m`;
    }
    this.world.setBeacon(dist > 10 ? { x: g.x, y: gy, z: g.z } : null);
    // rastre d'espurnes daurades a terra que marca el camí
    this.trailT = (this.trailT || 0) - dt;
    if (this.trailT <= 0 && dist > 14 && !p.dead && !g.noTrail) {
      this.trailT = 0.09;
      const ux = dx / dist, uz = dz / dist;
      const t = 3 + Math.random() * Math.min(22, dist - 6);
      const x = p.pos.x + ux * t, z = p.pos.z + uz * t;
      const y = groundAt(x, z, p.pos.y + 2) + 0.25;
      this.fx.parts.emit(x, y, z, ux * 0.6, 0.5 + Math.random() * 0.4, uz * 0.6, this._trailCol || (this._trailCol = new THREE.Color('#ffd27a')), 0.42, 1.1, 0.3, 0.5);
    }
  }
}


const game = new Game();
window.game = game;
game.boot();
