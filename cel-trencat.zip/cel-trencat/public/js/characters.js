// ============================================================
//  Personatges: herois VRM, monstres i les seves animacions
// ============================================================
import * as THREE from 'three';
import { Assets, loadVRM, cloneSkinned, toonify, fitHeight, model, toonGradient, addOutline } from './assets.js';
import { rigFromVRM, rigFromUAL, rigFromMap } from './anim.js';
import { dragonClips, golemClips } from './procanim.js';
import { CLASSES, ENEMIES, ELEMENTS, SKINS } from './data.js';

const LOOPING = new Set(['idle', 'idle_look', 'idle_sword', 'idle_ual', 'walk', 'walk_back', 'run', 'run_left', 'run_right', 'sprint', 'jog', 'jump_loop', 'glide', 'fall', 'spell_idle', 'block_idle', 'sword_block', 'dance', 'cheer', 'zombie_walk', 'zombie_idle']);

// ---------------- controlador d'animacions genèric ----------------
class Animator {
  constructor(root, buildClip) {
    this.mixer = new THREE.AnimationMixer(root);
    this.build = buildClip; // (name, mode) => clip
    this.cache = new Map();
    this.base = null; this.baseName = '';
    this.overlay = null; this.overlayName = ''; this.overlayW = 0; this.overlayTarget = 0; this.overlayEnd = 0;
    this.time = 0;
  }
  action(name, mode = 'full') {
    const k = name + ':' + mode;
    if (this.cache.has(k)) return this.cache.get(k);
    const clip = this.build(name, mode);
    const a = clip ? this.mixer.clipAction(clip) : null;
    this.cache.set(k, a);
    return a;
  }
  setBase(name, fade = 0.22, speed = 1, loop) {
    if (this.baseName === name) { if (this.base) this.base.timeScale = speed; return; }
    const a = this.action(name);
    if (!a) return;
    a.reset(); a.enabled = true; a.setEffectiveWeight(1); a.timeScale = speed;
    const lp = loop !== undefined ? loop : (LOOPING.has(name) || name.startsWith('Idle') || name.startsWith('Walk') || name.startsWith('Run') || !!(a.getClip().userData && a.getClip().userData.loop));
    a.setLoop(lp ? THREE.LoopRepeat : THREE.LoopOnce, Infinity);
    a.clampWhenFinished = true;
    a.play();
    if (this.base && fade > 0) this.base.crossFadeTo(a, fade, false);
    else if (this.base) this.base.stop();
    this.base = a; this.baseName = name;
  }
  // acció superposada (atac, encanteri...). upper=true només afecta la meitat superior
  play(name, { speed = 1, upper = false, hold = false, loop = false } = {}) {
    const a = this.action(name, upper ? 'upper' : 'full');
    if (!a) return 0;
    if (this.overlay && this.overlay !== a) this.overlay.stop();
    a.reset(); a.enabled = true; a.timeScale = speed;
    a.setLoop(loop ? THREE.LoopRepeat : THREE.LoopOnce, Infinity); a.clampWhenFinished = true;
    a.setEffectiveWeight(0.01); a.play();
    this.overlay = a; this.overlayName = name; this.overlayW = 0.01; this.overlayTarget = 14; this.overlayHold = hold || loop;
    const dur = a.getClip().duration / Math.max(0.01, speed);
    this.overlayEnd = loop ? Infinity : this.time + dur;
    return dur;
  }
  stopOverlay(fade = 0.15) { if (this.overlay) { this.overlayEnd = this.time; this.overlayHold = false; this.fadeOut = fade; } }
  busy() { return this.overlay && this.time < this.overlayEnd; }
  update(dt) {
    this.time += dt;
    if (this.overlay) {
      const fo = this.fadeOut || 0.15;
      const ending = !this.overlayHold && this.time > this.overlayEnd - fo;
      if (!ending) this.overlayW = Math.min(this.overlayTarget, this.overlayW + dt * this.overlayTarget / 0.08);
      else this.overlayW = Math.max(0, this.overlayW - dt * this.overlayTarget / fo);
      if (ending && this.overlayW <= 0.02) { this.overlay.stop(); this.overlay = null; this.overlayName = ''; this.fadeOut = 0; }
      else this.overlay.setEffectiveWeight(Math.max(0.001, this.overlayW));
    }
    this.mixer.update(dt);
  }
}

// ---------------- etiquetes ----------------
export function makeLabel(text, cls = '') {
  const d = document.createElement('div');
  d.className = 'label ' + cls;
  d.innerHTML = text;
  return d;
}

// ---------------- ales ----------------
function makeWings(color) {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0); shape.bezierCurveTo(0.4, 0.5, 1.2, 0.9, 1.9, 1.1); shape.bezierCurveTo(1.6, 0.7, 1.75, 0.45, 1.55, 0.25);
  shape.bezierCurveTo(1.35, 0.15, 1.45, -0.1, 1.2, -0.25); shape.bezierCurveTo(0.95, -0.35, 0.9, -0.6, 0.55, -0.7); shape.bezierCurveTo(0.3, -0.5, 0.15, -0.2, 0, 0);
  const geo = new THREE.ShapeGeometry(shape, 12);
  const mat = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
    uniforms: { uCol: { value: new THREE.Color(color) }, uTime: { value: 0 }, uA: { value: 0 } },
    vertexShader: 'varying vec2 vP; void main(){ vP = position.xy; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: `uniform vec3 uCol; uniform float uTime, uA; varying vec2 vP;
      void main(){ float d = length(vP); float f = sin(d*14.0 - uTime*6.0)*0.5+0.5; float a = (0.35 + f*0.45) * smoothstep(2.0, 0.2, d) * uA;
        gl_FragColor = vec4(mix(uCol, vec3(1.0), f*0.35), a); }` });
  const g = new THREE.Group();
  const l = new THREE.Mesh(geo, mat); const r = new THREE.Mesh(geo, mat);
  r.scale.x = -1;
  l.position.x = 0.08; r.position.x = -0.08;
  g.add(l); g.add(r);
  g.userData = { l, r, mat };
  return g;
}

// ============================================================
//  HEROI (VRM)
// ============================================================
export class HeroAvatar {
  static async create(hero, cls, opts = {}) {
    const vrm = await loadVRM(hero, opts.onProgress);
    return new HeroAvatar(vrm, hero, cls, opts);
  }

  constructor(vrm, hero, cls, opts) {
    this.vrm = vrm; this.hero = hero; this.cls = cls; this.opts = opts;
    this.obj = new THREE.Group();
    this.obj.add(vrm.scene);
    this.inner = vrm.scene;
    this.rig = rigFromVRM(vrm);
    this.anim = new Animator(vrm.scene, (name, mode) => Assets.anims.build(name, this.rig, mode));
    this.anim.setBase(CLASSES[cls] ? CLASSES[cls].idle : 'idle', 0);
    this.blinkT = 2 + Math.random() * 3; this.blink = 0;
    this.expr = { angry: 0, happy: 0, surprised: 0, sad: 0 };
    this.exprTarget = { angry: 0, happy: 0, surprised: 0, sad: 0 };
    this.flash = 0;
    this.scaleTarget = 1; this.scaleCur = 1;
    this.lookTarget = new THREE.Object3D();
    vrm.lookAt && (vrm.lookAt.target = this.lookTarget);
    this.materials = [];
    vrm.scene.traverse((o) => { if (o.isMesh) for (const m of (Array.isArray(o.material) ? o.material : [o.material])) if (!this.materials.includes(m)) this.materials.push(m); });
    this.baseRim = this.materials.map((m) => (m.parametricRimColorFactor ? m.parametricRimColorFactor.clone() : null));
    this.baseEm = this.materials.map((m) => (m.emissive ? m.emissive.clone() : null));
    this.wings = null;
    this.weapon = null;
    this.setWeapon();
    if (opts.tint) this.applyTint(opts.tint);
    this.trColor = new THREE.Color(CLASSES[cls] && CLASSES[cls].melee ? '#ffbf4a' : (ELEMENTS[CLASSES[cls] ? CLASSES[cls].element : 'arca'] || ELEMENTS.arca).color);
    this.transformed = false;
    this.height = this.measure();
  }

  measure() {
    const head = this.vrm.humanoid.getNormalizedBoneNode('head');
    this.obj.updateMatrixWorld(true);
    const p = new THREE.Vector3(); head.getWorldPosition(p);
    return p.y - this.obj.position.y + 0.25;
  }

  applyTint(tint) {
    const c = new THREE.Color(tint);
    this.materials.forEach((m) => {
      if (m.color) m.color.lerp(c, 0.65).multiplyScalar(0.55);
      if (m.shadeColorFactor) m.shadeColorFactor.lerp(c, 0.7).multiplyScalar(0.4);
      if (m.parametricRimColorFactor) m.parametricRimColorFactor.copy(c);
      if (m.emissive) m.emissive.copy(c).multiplyScalar(0.15);
    });
    this.baseRim = this.materials.map((m) => (m.parametricRimColorFactor ? m.parametricRimColorFactor.clone() : null));
    this.baseEm = this.materials.map((m) => (m.emissive ? m.emissive.clone() : null));
  }

  setWeapon(modelName, skin) {
    if (this.weapon) { this.weapon.parent && this.weapon.parent.remove(this.weapon); this.weapon = null; }
    const c = CLASSES[this.cls];
    if (!c) return;
    const name = modelName || c.weapon;
    const tpl = model('a:' + name);
    if (!tpl) return;
    const w = tpl.clone(true);
    toonify(w);
    if (skin && skin !== 'base') {
      const sk = SKINS.arma.find((s) => s.id === skin);
      if (sk && sk.color) w.traverse((o) => { if (o.isMesh) { o.material = o.material.clone(); o.material.color.set(sk.color); o.material.emissive = new THREE.Color(sk.color).multiplyScalar(0.25); } });
    }
    const h = this.vrm.humanoid;
    const melee = /sword|axe|dagger/.test(name);
    if (melee) {
      const hand = h.getNormalizedBoneNode('rightHand');
      w.scale.setScalar(name === 'sword_2handed' ? 0.56 : 0.62);
      w.rotation.set(Math.PI / 2, 0, 0);
      w.position.set(-0.075, -0.025, 0.0);
      hand.add(w);
    } else {
      const back = h.getNormalizedBoneNode('upperChest') || h.getNormalizedBoneNode('chest');
      w.scale.setScalar(name === 'staff' ? 0.62 : 0.8);
      w.rotation.set(0, 0, name === 'spellbook_open' ? 0 : 0.6);
      w.position.set(0, name === 'spellbook_open' ? 0 : 0.05, -0.17);
      if (name === 'spellbook_open') { w.rotation.set(0, Math.PI, 0); w.position.set(0.18, -0.25, -0.05); const hip = h.getNormalizedBoneNode('hips'); hip.add(w); this.weapon = w; return; }
      back.add(w);
    }
    this.weapon = w;
  }

  setWings(on, color) {
    if (on && !this.wings) {
      this.wings = makeWings(color || '#9fe9ff');
      const chest = this.vrm.humanoid.getNormalizedBoneNode('upperChest') || this.vrm.humanoid.getNormalizedBoneNode('chest');
      this.wings.position.set(0, 0.05, -0.16);
      chest.add(this.wings);
    }
    if (this.wings) {
      this.wings.userData.on = on;
      if (color) this.wings.userData.mat.uniforms.uCol.value.set(color);
    }
  }

  setTransform(on, color) {
    this.transformed = on;
    if (color) this.trColor.set(color);
    this.materials.forEach((m, i) => {
      if (m.parametricRimColorFactor) { if (on) m.parametricRimColorFactor.copy(this.trColor).multiplyScalar(1.6); else if (this.baseRim[i]) m.parametricRimColorFactor.copy(this.baseRim[i]); }
      if (m.parametricRimFresnelPowerFactor !== undefined) m.parametricRimFresnelPowerFactor = on ? 2.0 : (m._rimPow ?? (m._rimPow = m.parametricRimFresnelPowerFactor));
      if (m.parametricRimLiftFactor !== undefined) m.parametricRimLiftFactor = on ? 0.2 : 0;
    });
  }

  hitFlash() { this.flash = 1; this.exprTarget.surprised = 1; setTimeout(() => { this.exprTarget.surprised = 0; }, 350); }
  setExpression(name, v, ms = 0) { if (name in this.exprTarget) { this.exprTarget[name] = v; if (ms) setTimeout(() => { this.exprTarget[name] = 0; }, ms); } }

  update(dt, camera) {
    this.anim.update(dt);
    // parpelleig
    this.blinkT -= dt;
    if (this.blinkT < 0) { this.blink = 1; this.blinkT = 2.5 + Math.random() * 4; }
    this.blink = Math.max(0, this.blink - dt * 7);
    const em = this.vrm.expressionManager;
    if (em) {
      const b = this.blink > 0.5 ? (1 - this.blink) * 2 : this.blink * 2;
      try {
        em.setValue('blink', Math.min(1, b * 1.2));
        for (const k in this.expr) { this.expr[k] += (this.exprTarget[k] - this.expr[k]) * Math.min(1, dt * 8); em.setValue(k, this.expr[k] * 0.8); }
      } catch (e) { /* expressions opcionals */ }
    }
    if (camera) this.lookTarget.position.copy(camera.position);
    // flash de cop
    if (this.flash > 0) {
      this.flash = Math.max(0, this.flash - dt * 5);
      this.materials.forEach((m, i) => { if (m.emissive && this.baseEm[i]) m.emissive.copy(this.baseEm[i]).lerp(new THREE.Color('#ffffff'), this.flash * 0.6); });
    }
    // escala (forma titànica)
    this.scaleCur += (this.scaleTarget - this.scaleCur) * Math.min(1, dt * 4);
    this.inner.scale.setScalar(this.scaleCur);
    if (this.wings) {
      const u = this.wings.userData; const on = u.on;
      u.mat.uniforms.uA.value += ((on ? 1 : 0) - u.mat.uniforms.uA.value) * Math.min(1, dt * 5);
      u.mat.uniforms.uTime.value += dt;
      const f = Math.sin(this.anim.time * (on ? 5 : 2)) * 0.25;
      u.l.rotation.y = -0.5 + f; u.r.rotation.y = 0.5 - f;
      this.wings.visible = u.mat.uniforms.uA.value > 0.02;
    }
    this.vrm.update(dt);
  }

  dispose() { this.obj.parent && this.obj.parent.remove(this.obj); }
}

// ============================================================
//  MONSTRES
// ============================================================
const clipCache = new Map();
// roca amb esquerdes de lava que bateguen (gòlem de magma)
const MAGMA_T = { value: 0 };
function magmaMaterial(m) {
  m.color.multiply(new THREE.Color('#4a3634'));
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uT = MAGMA_T;
    sh.fragmentShader = 'uniform float uT;\n' + sh.fragmentShader.replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
      #ifdef USE_MAP
        vec4 txM = texture2D(map, vMapUv);
        float lumM = dot(txM.rgb, vec3(0.299, 0.587, 0.114));
        float crack = smoothstep(0.145, 0.1, lumM);
        totalEmissiveRadiance += vec3(1.0, 0.32, 0.04) * (crack * (2.2 + 0.9 * sin(uT * 2.6 + vMapUv.x * 23.0 + vMapUv.y * 17.0)) + 0.05);
      #endif`);
  };
  m.customProgramCacheKey = () => 'magma';
}

export class MonsterAvatar {
  static async create(info) {
    const def = ENEMIES[info.type];
    if (def.rig === 'vrm') {
      const hero = def.model.split(':')[1];
      const h = await HeroAvatar.create(hero, 'llamp', { tint: '#5a1f9e' });
      const m = new MonsterAvatar(info, def, null, h);
      return m;
    }
    return new MonsterAvatar(info, def);
  }

  constructor(info, def, _unused, heroAvatar) {
    this.info = info; this.def = def; this.id = info.id;
    this.obj = new THREE.Group();
    this.hero = heroAvatar || null;
    this.dead = false; this.deadT = 0; this.freeze = false;
    this.flash = 0;
    if (heroAvatar) {
      this.inner = heroAvatar.obj;
      this.obj.add(this.inner);
      this.inner.scale.setScalar(def.height / Math.max(1.2, heroAvatar.height));
      this.anim = heroAvatar.anim;
      heroAvatar.setTransform(true, '#9b3dff');
      heroAvatar.setWings(true, '#9b3dff');
    } else if (def.model === 'totem') {
      this.inner = buildTotem();
      this.obj.add(this.inner);
      this.anim = null;
    } else {
      const src = def.model;
      this.inner = cloneSkinned(src);
      if (!this.inner) { this.inner = new THREE.Mesh(new THREE.CapsuleGeometry(0.4, 1, 4, 8), new THREE.MeshToonMaterial({ color: 'red' })); }
      this.prepareMaterials(info);
      fitHeight(this.inner, def.height);
      this.obj.add(this.inner);
      // armes KayKit
      if (def.rig === 'kk') {
        this.inner.traverse((o) => { if (/Skeleton_.*_(Helmet|Cape)$/.test(o.name) && def.boss) o.visible = true; });
        this.attach('handslot.r', def.weapon); this.attach('handslot.l', def.offhand);
      } else if (def.weapon && def.weaponBone) this.attach(def.weaponBone, def.weapon, def.weaponPose);
      if (def.crown) this.addCrown();
      const key = def.model + ':' + def.rig;
      const own = (Assets.gltf[src] && Assets.gltf[src].animations) || [];
      if (def.rig === 'ual' || def.rig === 'map') {
        if (!clipCache.has(key)) { const rig = def.rig === 'ual' ? rigFromUAL(this.inner) : rigFromMap(this.inner, def.bonemap); clipCache.set(key, { rig, clips: new Map() }); }
        const cc = clipCache.get(key);
        this.anim = new Animator(this.inner, (name, mode) => {
          if (name.startsWith('own:')) return THREE.AnimationClip.findByName(own, name.slice(4));
          const k = name + mode; if (!cc.clips.has(k)) cc.clips.set(k, Assets.anims.build(name, cc.rig, mode)); return cc.clips.get(k);
        });
      } else if (def.rig === 'own') {
        this.anim = new Animator(this.inner, (name) => THREE.AnimationClip.findByName(own, name));
      } else if (def.rig === 'golem') {
        if (!clipCache.has(key)) clipCache.set(key, golemClips(this.inner, own));
        const cc = clipCache.get(key);
        this.anim = new Animator(this.inner, (name) => cc[name] || null);
      } else if (def.rig === 'drac') {
        if (!clipCache.has(key)) clipCache.set(key, dragonClips(this.inner, own[0]));
        const cc = clipCache.get(key);
        this.anim = new Animator(this.inner, (name) => cc[name] || null);
        this.headBone = this.inner.getObjectByName(cc.headBone.name);
      } else {
        this.anim = new Animator(this.inner, (name) => THREE.AnimationClip.findByName(Assets.kkClips, name));
      }
    }
    this.inner.traverse((o) => { if (o.isMesh) { o.castShadow = !o.userData.isOutline; o.frustumCulled = false; } });
    if (!heroAvatar) addOutline(this.inner, def.outline || '#1b1020');
    if (this.anim) { if (info.s === 'spawn' && def.anims.spawn) this.anim.setBase(def.anims.spawn, 0, 1, false); else this.anim.setBase(def.anims.idle, 0, 1, true); }
    if (info.s === 'spawn' && def.anims.spawn && this.anim) this.anim.setBase(def.anims.spawn, 0, 1);
    this.obj.position.set(info.x, info.y, info.z);
    this.obj.rotation.y = info.ry || 0;
    this.buf = [];
    this.state = info.s; this.lastState = '';
    this.hp = info.maxHp; this.maxHp = info.maxHp;
  }

  prepareMaterials(info) {
    const v = info.v;
    const tex = v && Assets.textures[(this.def.model + '_' + v)];
    const tint = this.def.tint === 'foc' ? '#ff9a6a' : null;
    toonify(this.inner, { tint: info.boss && tint ? tint : null });
    this.mats = [];
    this.inner.traverse((o) => {
      if (!o.isMesh) return;
      o.material = o.material.clone();
      if (tex && o.material.map) { o.material.map = tex; }
      if (this.def.tint === 'magma') magmaMaterial(o.material);
      if (this.def.tint === 'foc') { o.material.emissive = new THREE.Color('#ff4a12'); o.material.emissiveIntensity = info.boss ? 0.35 : 0.18; }
      this.mats.push(o.material);
    });
    this.baseEm = this.mats.map((m) => m.emissive.clone());
    this.baseCol = this.mats.map((m) => m.color.clone());
  }

  attach(slot, wname, pose) {
    if (!wname) return;
    let bone = this.inner.getObjectByName(slot) || (typeof slot === 'string' ? this.inner.getObjectByName(THREE.PropertyBinding.sanitizeNodeName(slot)) : null);
    if (!bone && slot instanceof RegExp) this.inner.traverse((o) => { if (!bone && slot.test(o.name)) bone = o; });
    if (!bone && typeof slot === 'string' && slot.startsWith('/')) { const re = new RegExp(slot.slice(1, -1)); this.inner.traverse((o) => { if (!bone && re.test(o.name)) bone = o; }); }
    const tpl = model('a:' + wname);
    if (!bone || !tpl) return;
    const w = tpl.clone(true); toonify(w);
    if (pose) {
      // compensa l'escala del món perquè l'arma tingui la mida indicada
      bone.updateMatrixWorld(true);
      const ws = bone.getWorldScale(new THREE.Vector3()).x || 1;
      const rs = this.inner.getWorldScale(new THREE.Vector3()).x || 1;
      w.scale.setScalar((pose.s || 1) * rs / ws);
      if (pose.r) w.rotation.set(pose.r[0], pose.r[1], pose.r[2]);
      if (pose.p) w.position.set(pose.p[0] * rs / ws, pose.p[1] * rs / ws, pose.p[2] * rs / ws);
    }
    bone.add(w);
  }

  addCrown() {
    const head = this.inner.getObjectByName('head');
    if (!head) return;
    const g = new THREE.Group();
    const mat = new THREE.MeshToonMaterial({ color: '#ffcf4a', emissive: '#ff9a00', emissiveIntensity: 0.4, gradientMap: toonGradient() });
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.45, 0.18, 12, 1, true), mat); g.add(band);
    for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; const sp = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.32, 5), mat); sp.position.set(Math.cos(a) * 0.43, 0.22, Math.sin(a) * 0.43); g.add(sp); }
    g.position.set(0, 0.95, 0);
    head.add(g);
  }

  pushSnap(t, x, y, z, ry, st, hp, maxHp, frozen) {
    this.buf.push({ t, x, y, z, ry });
    if (this.buf.length > 6) this.buf.shift();
    this.hp = hp; this.maxHp = maxHp;
    this.freeze = !!frozen;
    this.serverState = st;
  }

  playAttack(animName, windup) {
    if (!this.anim) return;
    const clip = this.anim.action(animName);
    if (!clip) return;
    const dur = clip.getClip().duration;
    const frac = (this.def.hitAt && this.def.hitAt[animName]) || 0.42;
    const speed = Math.max(0.5, Math.min(2.5, (dur * frac) / Math.max(0.2, windup)));
    this.anim.play(animName, { speed });
  }

  hitFlash() { this.flash = 1; if (this.hero) this.hero.hitFlash(); }

  die() {
    this.dead = true; this.deadT = 0;
    if (this.anim) { this.anim.stopOverlay(0.05); this.anim.setBase(this.def.anims.death, 0.15, 1, false); }
  }

  update(dt, renderT, camera) {
    MAGMA_T.value = performance.now() / 1000;
    // interpolació
    if (!this.dead && this.buf.length) {
      const t = renderT;
      let a = this.buf[0], b = this.buf[this.buf.length - 1];
      for (let i = 0; i < this.buf.length - 1; i++) if (this.buf[i].t <= t && this.buf[i + 1].t >= t) { a = this.buf[i]; b = this.buf[i + 1]; break; }
      const k = b.t > a.t ? Math.max(0, Math.min(1.2, (t - a.t) / (b.t - a.t))) : 1;
      const tx = a.x + (b.x - a.x) * k, ty = a.y + (b.y - a.y) * k, tz = a.z + (b.z - a.z) * k;
      const prev = this.obj.position.clone();
      this.obj.position.set(tx, ty + (this.def.flying ? 1.2 + Math.sin(performance.now() / 600) * 0.3 : 0), tz);
      let d = b.ry - this.obj.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d));
      this.obj.rotation.y += d * Math.min(1, dt * 10);
      const sp = Math.hypot(this.obj.position.x - prev.x, this.obj.position.z - prev.z) / Math.max(dt, 1e-3);
      this.speed = this.speed === undefined ? sp : this.speed + (sp - this.speed) * Math.min(1, dt * 6);
    }
    if (this.anim) {
      const an = this.def.anims;
      if (this.dead) { /* animació de mort */ }
      else if (this.serverState === 'spawn' && an.spawn) this.anim.setBase(an.spawn, 0.1);
      else if (this.serverState === 'hit' && !this.anim.busy()) { this.anim.play(an.hit, { speed: 1.3 }); }
      else if (this.speed > 0.6 && !this.anim.busy()) this.anim.setBase(this.speed < 2.6 && an.walk ? an.walk : an.move, 0.2, this.def.rig === 'ual' ? Math.min(1.5, Math.max(0.6, this.speed / 5.5)) : Math.min(1.6, Math.max(0.7, this.speed / (this.def.speed * 0.9))), true);
      else if (this.speed <= 0.6) this.anim.setBase(an.idle, 0.25, 1, true);
      this.anim.mixer.timeScale = this.freeze ? 0 : 1;
      if (this.hero) this.hero.update(dt, camera); else this.anim.update(dt);
    }
    if (this.mats) {
      if (this.flash > 0) this.flash = Math.max(0, this.flash - dt * 6);
      const ice = this.freeze ? 1 : 0;
      this.iceK = (this.iceK || 0) + (ice - (this.iceK || 0)) * Math.min(1, dt * 8);
      this.mats.forEach((m, i) => {
        m.emissive.copy(this.baseEm[i]).lerp(WHITE, this.flash * 0.7);
        if (this.iceK > 0.01) m.color.copy(this.baseCol[i]).lerp(ICE, this.iceK * 0.7); else m.color.copy(this.baseCol[i]);
      });
    }
    if (this.dead) {
      this.deadT += dt;
      if (this.deadT > 2.2) this.obj.position.y -= dt * 1.2;
    }
    if (this.def.model === 'totem') this.inner.children.forEach((c, i) => { if (c.userData.spin) c.rotation.y += dt * c.userData.spin * (i % 2 ? 1 : -1); });
  }

  dispose() { this.obj.parent && this.obj.parent.remove(this.obj); }
}
const WHITE = new THREE.Color('#ffffff');
const ICE = new THREE.Color('#bff3ff');

function buildTotem() {
  const g = new THREE.Group();
  const stone = new THREE.MeshToonMaterial({ color: '#4a2f2a', gradientMap: toonGradient() });
  const lava = new THREE.MeshToonMaterial({ color: '#ff6a1a', emissive: '#ff4a00', emissiveIntensity: 2.2, gradientMap: toonGradient() });
  let y = 0;
  for (let i = 0; i < 4; i++) {
    const h = 0.9 - i * 0.08, r = 1.0 - i * 0.14;
    const b = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.9, r, h, 6), stone); b.position.y = y + h / 2; b.rotation.y = i * 0.4; b.castShadow = true; g.add(b);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(r * 0.95, 0.06, 6, 18), lava); ring.rotation.x = Math.PI / 2; ring.position.y = y + h * 0.5; g.add(ring);
    y += h;
  }
  const eye = new THREE.Mesh(new THREE.OctahedronGeometry(0.45, 0), lava); eye.position.y = y + 0.6; eye.userData.spin = 2; g.add(eye);
  for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; const sp = new THREE.Mesh(new THREE.ConeGeometry(0.16, 1.2, 5), stone); sp.position.set(Math.cos(a) * 1.0, 0.5, Math.sin(a) * 1.0); sp.rotation.z = Math.cos(a) * 0.4; sp.rotation.x = -Math.sin(a) * 0.4; g.add(sp); }
  return g;
}
