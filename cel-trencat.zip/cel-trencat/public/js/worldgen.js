// ============================================================
//  Generació determinista del món (compartida client/servidor)
// ============================================================

import { STRUCTURE_DEFS, STRUCTURE_CAMPS, STRUCTURE_CHESTS, STRUCTURE_FLATS, STRUCTURES, buildFortress, buildHouse, toWorld, FLOOR_H } from './structures.js';
export { STRUCTURES };
import { courseGround, inCourse, PK } from './parkour.js';

export const WORLD = { half: 320, water: 0, seed: 7331, walkRadius: 302 };

// ---------- RNG i soroll ----------
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function hash2(x, z, seed = 1) {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(z | 0, 668265263) + Math.imul(seed, 1442695040)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

const GRAD = [[1, 1], [-1, 1], [1, -1], [-1, -1], [1, 0], [-1, 0], [0, 1], [0, -1]];
function makePerm(seed) {
  const r = mulberry32(seed); const p = new Uint8Array(512); const a = [];
  for (let i = 0; i < 256; i++) a[i] = i;
  for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  for (let i = 0; i < 512; i++) p[i] = a[i & 255];
  return p;
}
const PERM = makePerm(WORLD.seed);
const F2 = 0.5 * (Math.sqrt(3) - 1), G2 = (3 - Math.sqrt(3)) / 6;
export function simplex(x, y) {
  const s = (x + y) * F2; const i = Math.floor(x + s), j = Math.floor(y + s);
  const t = (i + j) * G2; const x0 = x - (i - t), y0 = y - (j - t);
  const i1 = x0 > y0 ? 1 : 0, j1 = x0 > y0 ? 0 : 1;
  const x1 = x0 - i1 + G2, y1 = y0 - j1 + G2, x2 = x0 - 1 + 2 * G2, y2 = y0 - 1 + 2 * G2;
  const ii = i & 255, jj = j & 255;
  let n = 0;
  let t0 = 0.5 - x0 * x0 - y0 * y0;
  if (t0 > 0) { const g = GRAD[PERM[ii + PERM[jj]] & 7]; t0 *= t0; n += t0 * t0 * (g[0] * x0 + g[1] * y0); }
  let t1 = 0.5 - x1 * x1 - y1 * y1;
  if (t1 > 0) { const g = GRAD[PERM[ii + i1 + PERM[jj + j1]] & 7]; t1 *= t1; n += t1 * t1 * (g[0] * x1 + g[1] * y1); }
  let t2 = 0.5 - x2 * x2 - y2 * y2;
  if (t2 > 0) { const g = GRAD[PERM[ii + 1 + PERM[jj + 1]] & 7]; t2 *= t2; n += t2 * t2 * (g[0] * x2 + g[1] * y2); }
  return 70 * n;
}
export function fbm(x, y, oct = 4) {
  let a = 0.5, f = 1, s = 0, n = 0;
  for (let i = 0; i < oct; i++) { s += a * simplex(x * f, y * f); n += a; a *= 0.5; f *= 2.03; }
  return s / n;
}
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const lerp = (a, b, t) => a + (b - a) * t;
export { smooth, lerp };

// ---------- Zones ----------
export const ZONES = [
  { id: 'vila', name: 'Vila de l\'Alba', x: 0, z: 0, r: 58, lvl: 1, safe: true, music: 'vila', ground: [0.48, 0.72, 0.30], sky: 'dia' },
  { id: 'bosc', name: 'Bosc Encantat', x: 0, z: -170, r: 115, lvl: 2, music: 'bosc', ground: [0.30, 0.62, 0.26] },
  { id: 'ruines', name: 'Ruïnes del Sol', x: 178, z: -45, r: 100, lvl: 6, music: 'ruines', ground: [0.62, 0.62, 0.42] },
  { id: 'cremades', name: 'Terres Cremades', x: -182, z: -30, r: 105, lvl: 9, music: 'cremades', ground: [0.62, 0.36, 0.24] },
  { id: 'costa', name: 'Costa de les Gavines', x: 0, z: 150, r: 100, lvl: 3, music: 'costa', ground: [0.86, 0.80, 0.58] },
  { id: 'cel', name: 'Illes del Cel', x: 0, z: 285, r: 130, lvl: 13, music: 'cel', sky: true, ground: [0.42, 0.78, 0.36] },
  { id: 'arena', name: 'Arena d\'Aura', x: -700, z: 700, r: 60, lvl: 10, music: 'arena', pvp: true, ground: [0.5, 0.5, 0.6] },
  { id: 'niu', name: 'Niu del Drac', x: 12, z: 452, r: 40, lvl: 17, music: 'cremades', sky: true, ground: [0.3, 0.22, 0.2] },
  { id: 'parkour', name: 'Camí dels Vents', x: 700, z: 680, r: 140, lvl: 1, music: 'cel', sky: true, safe: true, ground: [0.42, 0.78, 0.36] },
];
export const ZONE = Object.fromEntries(ZONES.map((z) => [z.id, z]));

export const ISLANDS = [
  { id: 'i0', x: 0, z: 218, r: 17, top: 44 },
  { id: 'i1', x: -42, z: 246, r: 13, top: 56 },
  { id: 'i2', x: 44, z: 252, r: 13, top: 62 },
  { id: 'i3', x: 0, z: 284, r: 15, top: 70 },
  { id: 'i4', x: -36, z: 318, r: 12, top: 80 },
  { id: 'boss', x: 30, z: 342, r: 30, top: 90, flat: true },
  { id: 'i5', x: 84, z: 392, r: 16, top: 100 },
  { id: 'drac', x: 12, z: 452, r: 40, top: 112, flat: true, volcanic: true },
  { id: 'arena', x: -700, z: 700, r: 38, top: 30, flat: true },
];

export const LAUNCHPADS = [
  { id: 'pedra_vent', x: 0, z: 138, to: 'i0', quest: true },
  { id: 'v0', island: 'i0', dx: -6, dz: 9, to: 'i1' },
  { id: 'v0b', island: 'i0', dx: 7, dz: 10, to: 'i2' },
  { id: 'v1', island: 'i1', dx: 6, dz: 6, to: 'i3' },
  { id: 'v2', island: 'i2', dx: -6, dz: 6, to: 'i3' },
  { id: 'v3', island: 'i3', dx: -5, dz: 8, to: 'i4' },
  { id: 'v4', island: 'i4', dx: 7, dz: 4, to: 'boss' },
  { id: 'vb', island: 'boss', dx: -18, dz: -20, to: 'i0' },
  { id: 'vb2', island: 'boss', dx: 20, dz: 17, to: 'i5', need: 4 },
  { id: 'v5', island: 'i5', dx: -7, dz: 9, to: 'drac' },
  { id: 'vd', island: 'drac', dx: 28, dz: -24, to: 'i0' },
];
export const ISLAND = Object.fromEntries(ISLANDS.map((i) => [i.id, i]));
for (const lp of LAUNCHPADS) {
  if (lp.island) { const is = ISLAND[lp.island]; lp.x = is.x + lp.dx; lp.z = is.z + lp.dz; lp.y = is.top; }
}

export const ROADS = [
  [[0, 0], [0, -40], [8, -80], [-4, -120], [0, -160], [0, -196]],
  [[0, 0], [40, -6], [90, -20], [135, -35], [178, -45]],
  [[0, 0], [-40, 4], [-90, -6], [-140, -20], [-182, -30]],
  [[0, 0], [0, 50], [6, 95], [0, 138]],
  [[178, -45], [208, -12], [215, 2], [215, 38]],
  [[-182, -30], [-208, -70], [-226, -96]],
  [[178, -45], [194, -66], [200, -86]],
];

export const BOSS_ARENAS = [
  { id: 'rei_ossut', x: 215, z: 40, r: 26 },
  { id: 'senyor_imps', x: -228, z: -98, r: 28 },
];

function distToSeg(px, pz, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az; const l2 = dx * dx + dz * dz;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (pz - az) * dz) / l2));
  const qx = ax + dx * t, qz = az + dz * t;
  return Math.hypot(px - qx, pz - qz);
}
export function roadDist(x, z) {
  let d = 1e9;
  for (const r of ROADS) for (let i = 0; i < r.length - 1; i++) d = Math.min(d, distToSeg(x, z, r[i][0], r[i][1], r[i + 1][0], r[i + 1][1]));
  return d;
}
function zoneWeight(z, x, zz) { const d = Math.hypot(x - z.x, zz - z.z); return 1 - smooth(z.r * 0.55, z.r * 1.05, d); }

// ---------- Alçada del terreny ----------
const hCache = new Map();
export function terrainHeight(x, z) {
  let h = fbm(x * 0.0055 + 11.3, z * 0.0055 - 4.1, 4) * 9 + fbm(x * 0.021, z * 0.021, 2) * 2.0 + 3.5;
  const wCrem = zoneWeight(ZONE.cremades, x, z);
  if (wCrem > 0) h += (Math.abs(fbm(x * 0.014 + 3, z * 0.014, 3)) * 14 - 3) * wCrem;
  const wRui = zoneWeight(ZONE.ruines, x, z);
  if (wRui > 0) h = lerp(h, 7 + fbm(x * 0.03, z * 0.03, 2) * 1.5, wRui * 0.7);
  const wBosc = zoneWeight(ZONE.bosc, x, z);
  if (wBosc > 0) h += fbm(x * 0.012 - 7, z * 0.012 + 2, 3) * 5 * wBosc;
  const r = Math.hypot(x, z);
  const south = smooth(95, 150, z);
  if (r > 248) h += Math.pow((r - 248) / 42, 2) * 40 * (1 - south) * (0.75 + 0.25 * fbm(x * 0.02, z * 0.02, 2));
  // mar al sud
  h = lerp(h, -9 + fbm(x * 0.01, z * 0.01, 2) * 2, smooth(118, 172, z));
  // vila plana
  const dv = Math.hypot(x, z);
  h = lerp(h, 2.2, 1 - smooth(42, 66, dv));
  for (const a of BOSS_ARENAS) {
    const d = Math.hypot(x - a.x, z - a.z);
    const base = 5.5;
    h = lerp(h, base, 1 - smooth(a.r * 0.8, a.r * 1.25, d));
  }
  // fortaleses: terreny pla a dins i una mica al voltant
  for (const a of STRUCTURE_FLATS) {
    const d = Math.hypot(x - a.x, z - a.z);
    if (d < a.r + 12) h = lerp(h, 5.5, 1 - smooth(a.r, a.r + 12, d));
  }
  // camins: suavitzats
  const rd = roadDist(x, z);
  if (rd < 9) h = lerp(h, h * 0.85 + 0.6, (1 - rd / 9) * 0.5);
  return h;
}
export function height(x, z) {
  const k = ((Math.round(x * 4)) << 16) ^ Math.round(z * 4);
  let v = hCache.get(k);
  if (v === undefined) { v = terrainHeight(x, z); if (hCache.size > 400000) hCache.clear(); hCache.set(k, v); }
  return v;
}

export function islandTop(is, x, z) {
  const d = Math.hypot(x - is.x, z - is.z);
  if (d > is.r) return -Infinity;
  const t = d / is.r;
  return is.top + (is.flat ? 0.4 * (1 - t * t) : 1.4 * (1 - t * t)) + (is.flat ? 0 : fbm(x * 0.2, z * 0.2, 2) * 0.25);
}

// alçada del sòl sota (x,z) tenint en compte illes, a partir de l'alçada y actual
export function groundAt(x, z, y = 1e9) {
  let g = height(x, z);
  for (const is of ISLANDS) {
    const t = islandTop(is, x, z);
    if (t > g && y >= t - 2.5) g = t;
  }
  // plataformes del circuit de parkour
  if (inCourse(x, z)) { const t = courseGround(x, z, y); if (t > g) g = t; }
  return g;
}

export function zoneAt(x, z, y = 0) {
  if (inCourse(x, z) && y > PK.y - 30) return ZONE.parkour;
  for (const is of ISLANDS) if (Math.hypot(x - is.x, z - is.z) < is.r + 40 && y > 25) return is.id === 'arena' ? ZONE.arena : is.volcanic ? ZONE.niu : ZONE.cel;
  let best = ZONE.vila, bd = 1e9;
  for (const zn of ZONES) {
    if (zn.id === 'cel' || zn.id === 'arena' || zn.id === 'niu' || zn.id === 'parkour') continue;
    const d = Math.hypot(x - zn.x, z - zn.z) / zn.r;
    if (d < bd) { bd = d; best = zn; }
  }
  return best;
}

// ---------- Disposició (edificis, decorats, obstacles) ----------
// models: 'v:' = vila.glb, 'r:' = ruines.glb, 'n:' = natura.glb, 'p:' = procedural
export function buildLayout() {
  const props = [];
  const add = (model, x, z, ry = 0, s = 1, col = 0, extra) => { props.push({ model, x, z, ry, s, col, ...(extra || {}) }); };
  // col·locador de peces del MegaKit en coordenades locals d'un origen {x, z, ry, y}
  const placer = (o) => (m, lx, lz, rot = 0, ly = 0, sc = 1) => {
    const [x, z] = toWorld(o, lx, lz);
    add('k:' + m, x, z, (o.ry || 0) + rot, sc, 0, { ya: (o.y !== undefined ? o.y : height(x, z) - 0.1) + ly });
  };
  const megaHouse = (x, z, ry, opt) => {
    // base: el punt més baix de la planta, perquè no quedi penjada
    const hx = (opt.W || 3) + 0.5, hz = (opt.L || 4) + 0.5;
    let y = 1e9;
    for (const [a, b] of [[-hx, -hz], [hx, -hz], [-hx, hz], [hx, hz], [0, 0]]) { const [wx, wz] = toWorld({ x, z, ry }, a, b); y = Math.min(y, height(wx, wz)); }
    const box = buildHouse(placer({ x, z, ry, y: y - 0.08 }), { seed: Math.round(Math.abs(x * 31 + z * 17)) + 3, ...opt });
    add('x:solid', x, z, ry, 1, 0, { box: [box.hx, box.hz] });
  };
  const K = 6.2; // escala dels edificis KayKit
  // --- Vila de l'Alba ---
  add('v:building_castle_blue', 0, -38, 0, K, 9);
  add('v:building_tower_B_blue', -24, -30, 0, K, 4.5);
  add('v:building_tower_A_blue', 24, -30, 0, K, 4);
  add('v:building_church_blue', -28, -6, Math.PI / 2, K, 5.5);
  megaHouse(29, -17, -Math.PI / 2, { W: 4, L: 5, F: 2, ground: 'brick' }); // taverna
  add('v:building_market_blue', 18, 24, Math.PI, K, 6.5);
  add('v:building_blacksmith_blue', 25, 9, -Math.PI / 2, K, 5);
  megaHouse(-26, 21, Math.PI / 2, { W: 3, L: 4, F: 2, ground: 'brick' });
  megaHouse(-35, 4, Math.PI / 2, { W: 2, L: 3, F: 1, ground: 'plaster' });
  megaHouse(37, 18, -Math.PI / 2, { W: 3, L: 4, F: 2, ground: 'brick' });
  megaHouse(-16, 37, Math.PI, { W: 3, L: 3, F: 1, ground: 'brick' });
  megaHouse(7, 39, Math.PI, { W: 2, L: 4, F: 2, ground: 'plaster' });
  megaHouse(-42, -8, Math.PI / 2, { W: 2, L: 2, F: 1, ground: 'brick' });
  megaHouse(18, 42, -Math.PI / 2, { W: 2, L: 3, F: 2, ground: 'plaster' });
  megaHouse(-30, 36, Math.PI, { W: 2, L: 3, F: 1, ground: 'brick' });
  { const w = placer({ x: -6, z: -20, ry: 0.4 }); w('Prop_Wagon', 0, 0, 0, 0); add('x:solid', -6, -21, 0, 1, 1.4); }
  { const f = placer({ x: 20, z: 32, ry: 0 }); for (let i = 0; i < 5; i++) f('Prop_WoodenFence_Single', i * 2.05, 0, 0, 0); }
  add('v:building_windmill_blue', -44, -24, 0.4, K, 4.5);
  add('v:building_lumbermill_blue', 42, -16, -Math.PI / 2, K, 5.5);
  add('v:building_barracks_blue', -12, -26, 0, K, 5);
  add('v:building_archeryrange_blue', 44, 34, -2.3, K, 5);
  add('v:building_well_blue', 0, 4, 0, K, 2.4);
  add('v:tent', -9, 17, 0.3, K, 2.5);
  add('v:weaponrack', -16, 0, Math.PI / 2, K, 0);
  add('v:target', -18, 12, Math.PI / 2, K, 0.6);
  add('v:target', -21, 14, Math.PI / 2, K, 0.6);
  add('v:wheelbarrow', 12, 12, 1.2, K, 0.8);
  for (const [x, z, r] of [[14, 14, 0], [15.5, 15, 0.5], [-30, -14, 1], [30, 2, 0], [8, 26, 2], [-38, 16, 0.3]]) add('v:barrel', x, z, r, K, 0.7);
  for (const [x, z, r] of [[13, 16.5, 0.2], [-31, -12, 0.9], [9, 28, 0], [31, 4, 0.4]]) add('v:crate_A_big', x, z, r, K, 0.8);
  for (const [x, z, r] of [[16, 13, 0], [-29, -15, 1.2], [7, 25, 0.6]]) add('v:sack', x, z, r, K, 0);
  add('v:resource_lumber', 46, -6, 0.2, K, 2);
  add('v:resource_stone', 20, -18, 0.5, K, 1.5);
  // muralla al nord del castell
  for (let i = -3; i <= 3; i++) { if (i === 0) continue; add('v:wall_straight', i * 12.4, -54, 0, K, 0, { wall: [12.4, 3] }); }
  add('v:wall_straight_gate', 0, -54, 0, K, 0);
  // tanques de camps
  for (let i = 0; i < 5; i++) add('v:fence_wood_straight', -50 + i * 7.4, 30, Math.PI / 2, K, 0);
  for (let i = 0; i < 4; i++) add('v:fence_wood_straight', -54, 34 + i * 7.4, 0, K, 0);
  // banderes
  add('v:flag_blue', -24, -30, 0, K * 1.2, 0, { y: 15 });
  add('v:flag_blue', 24, -30, 0, K * 1.2, 0, { y: 13 });

  // --- Ruïnes del Sol ---
  const rr = mulberry32(991);
  const ruinPieces = ['r:pillar', 'r:pillar_decorated', 'r:column', 'r:wall_broken', 'r:wall_cracked', 'r:wall_arched', 'r:wall_half', 'r:rubble_large', 'r:rubble_half'];
  const RS = 1.6;
  for (let i = 0; i < 70; i++) {
    const a = rr() * Math.PI * 2, d = 18 + rr() * 82;
    const x = ZONE.ruines.x + Math.cos(a) * d, z = ZONE.ruines.z + Math.sin(a) * d * 0.9;
    if (Math.hypot(x - 215, z - 40) < 30) continue;
    if (roadDist(x, z) < 5) continue;
    const m = ruinPieces[Math.floor(rr() * ruinPieces.length)];
    const col = m.includes('pillar') || m.includes('column') ? 1.4 : m.includes('rubble') ? 3.5 : 0;
    add(m, x, z, Math.floor(rr() * 4) * Math.PI / 2 + (rr() - 0.5) * 0.3, RS, col, m.includes('wall') ? { wall: [4 * RS, 1 * RS] } : null);
  }
  // temple central
  const tx = 178, tz = -45;
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; add(i % 3 === 0 ? 'r:column' : 'r:pillar_decorated', tx + Math.cos(a) * 14, tz + Math.sin(a) * 14, a, 2.0, 1.6); }
  add('r:stairs_wide', tx, tz - 22, Math.PI, 1.8, 0);
  for (const [x, z] of [[tx - 4, tz], [tx + 4, tz], [tx, tz - 4], [tx, tz + 4]]) add('r:floor_tile_large', x, z, 0, 2.0, 0);
  for (const [x, z] of [[tx + 10, tz + 10], [tx - 10, tz + 10], [tx - 10, tz - 10], [tx + 10, tz - 10]]) add('r:torch_lit', x, z, 0, 2.2, 0, { light: '#ffaa55' });
  // cementiri del Rei Ossut
  const cx = 215, cz = 40;
  for (let i = 0; i < 26; i++) {
    const a = rr() * Math.PI * 2, d = 9 + rr() * 11;
    add('p:tomba', cx + Math.cos(a) * d, cz + Math.sin(a) * d, rr() * 0.5 - 0.25 + Math.PI, 1 + rr() * 0.4, 0.6);
  }
  for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2 + Math.PI / 4; add('r:pillar', cx + Math.cos(a) * 21, cz + Math.sin(a) * 21, a, 1.8, 1.4); }
  for (const [x, z] of [[cx - 4, cz - 20], [cx + 4, cz - 20]]) add('r:torch_lit', x, z, 0, 2.4, 0, { light: '#88ffcc' });

  // --- Terres Cremades: fort de Malfoc ---
  add('v:building_tower_A_red', -150, -60, 1.2, K, 4);
  add('v:building_barracks_red', -162, -72, 1.0, K, 5);
  add('v:building_tower_catapult_red', -200, 22, -0.6, K, 4);
  add('v:building_tower_A_red', -246, -56, 2.4, K, 4);
  add('v:flag_red', -150, -60, 0, K * 1.2, 0, { y: 13 });
  for (const [x, z] of [[-218, -90], [-238, -106], [-222, -108], [-234, -88]]) add('r:torch_lit', x, z, 0, 2.6, 0, { light: '#ff5a1a' });
  add('v:building_destroyed', -120, 10, 0.5, K, 4);
  add('v:building_destroyed', -195, -140, 2.1, K, 4);

  // --- Costa: Pedra de Vent ---
  add('p:pedra_vent', 0, 138, 0, 1, 0);
  add('v:building_destroyed', -40, 118, 0.8, K, 4);
  add('v:tent', 38, 122, -0.5, K, 2.5);

  // --- Fortaleses (MegaKit): murs, torres, cases i homenatge ---
  for (const d of STRUCTURE_DEFS) {
    const o = { x: d.x, z: d.z, ry: d.ry };
    const put = (m, lx, lz, rot, ly, sc) => { const [x, z] = toWorld(o, lx, lz); add('k:' + m, x, z, d.ry + rot, sc || 1, 0, { ya: height(x, z) - 0.12 + (ly || 0) }); };
    const solid = (kind, lx, lz, a, b, rot = 0) => {
      const [x, z] = toWorld(o, lx, lz);
      if (kind === 'wall') add('x:solid', x, z, d.ry + rot, 1, 0, { wall: [a, 0.75] });
      else if (kind === 'box') add('x:solid', x, z, d.ry + rot, 1, 0, { box: [a, b] });
      else add('x:solid', x, z, 0, 1, a);
    };
    buildFortress(put, solid, d);
    // torxes a la porta i dins l'homenatge
    for (const [lx, lz] of [[-2.6, d.hd + 1.4], [2.6, d.hd + 1.4], ...(d.kw ? [[-d.kw + 1.5, d.kz - 1.5], [d.kw - 1.5, d.kz - 1.5]] : [])]) {
      const [x, z] = toWorld(o, lx, lz); add('r:torch_lit', x, z, 0, 2.4, 0, { light: d.id === 'fort_malfoc' ? '#ff5a1a' : '#ffaa55' });
    }
  }
  // --- Campaments: tanques, tenda i foguera al voltant de cada grup d'enemics ---
  const cr = mulberry32(5150);
  for (const c of CAMPS) {
    if (c.island || c.boss || c.structure || c.id || c.r < 5) continue;
    const R = c.r + 2.5, n = Math.round((2 * Math.PI * R) / 2.1);
    const gap = cr() * Math.PI * 2;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a - gap), Math.cos(a - gap))) < 0.45) continue; // entrada
      if (cr() < 0.12) continue; // tanca trencada
      const x = c.x + Math.cos(a) * R, z = c.z + Math.sin(a) * R;
      if (roadDist(x, z) < 2.5) continue;
      add('k:Prop_WoodenFence_' + (cr() < 0.5 ? 'Single' : 'Extension1'), x, z, -a, 1, 0, { ya: height(x, z) - 0.05 });
    }
    const ta = gap + Math.PI + (cr() - 0.5);
    add('v:tent', c.x + Math.cos(ta) * c.r * 0.75, c.z + Math.sin(ta) * c.r * 0.75, -ta + Math.PI / 2, K * 0.8, 1.8);
    add('k:Prop_Crate', c.x + Math.cos(ta + 0.7) * c.r * 0.8, c.z + Math.sin(ta + 0.7) * c.r * 0.8, cr() * 3, 1, 0.7, { ya: height(c.x + Math.cos(ta + 0.7) * c.r * 0.8, c.z + Math.sin(ta + 0.7) * c.r * 0.8) - 0.05 });
    add('p:foguera', c.x, c.z, 0, 1, 0.6);
  }

  // --- Portals (pedres de pas) ---
  for (const w of WAYSTONES) if (!w.island) add('p:portal', w.x, w.z, 0, 1, 1.2, { waystone: w.id });

  // --- Muntanyes llunyanes ---
  const mr = mulberry32(42);
  for (let i = 0; i < 46; i++) {
    const a = i / 46 * Math.PI * 2 + mr() * 0.05;
    if (Math.sin(a) > 0.55) continue; // no al sud (mar)
    const d = 300 + mr() * 30;
    const m = ['v:mountain_A_grass', 'v:mountain_B_grass', 'v:mountain_C_grass', 'v:mountain_A'][Math.floor(mr() * 4)];
    add(m, Math.cos(a) * d, Math.sin(a) * d, mr() * 6, 26 + mr() * 18, 0, { far: true });
  }
  return props;
}

export const WAYSTONES = [
  { id: 'vila', name: 'Vila de l\'Alba', x: 0, z: 13 },
  { id: 'bosc', name: 'Bosc Encantat', x: 6, z: -112 },
  { id: 'ruines', name: 'Ruïnes del Sol', x: 136, z: -28 },
  { id: 'cremades', name: 'Terres Cremades', x: -132, z: -12 },
  { id: 'costa', name: 'Costa de les Gavines', x: 14, z: 118 },
  { id: 'cel', name: 'Illes del Cel', x: 0, z: 222, island: 'i0' },
];

export const CHESTS = [
  { id: 'ch_r1', x: 150, z: -78, quest: 'cristall' },
  { id: 'ch_r2', x: 204, z: -112, quest: 'cristall' },
  { id: 'ch_r3', x: 238, z: -30, quest: 'cristall' },
  { id: 'ch_b1', x: -60, z: -205 },
  { id: 'ch_b2', x: 70, z: -230 },
  { id: 'ch_c1', x: -255, z: 20 },
  { id: 'ch_k1', x: 68, z: 160 },
  { id: 'ch_i1', x: -44, z: 250, island: 'i1' },
  { id: 'ch_i4', x: -34, z: 322, island: 'i4' },
  ...STRUCTURE_CHESTS,
];

// camps d'enemics: [tipus, quantitat, variant]
export const CAMPS = [
  // bosc
  { x: -28, z: -118, r: 9, lvl: 1, list: [['puglin', 4]] },
  { x: 36, z: -134, r: 9, lvl: 1, list: [['puglin', 5]] },
  { x: -80, z: -132, r: 9, lvl: 2, list: [['puglin', 4]] },
  { x: 82, z: -158, r: 10, lvl: 2, list: [['puglin', 4, 'oliva']] },
  { x: -54, z: -178, r: 10, lvl: 3, list: [['puglin', 3], ['imp', 1]] },
  { x: 50, z: -196, r: 10, lvl: 3, list: [['puglin', 3], ['imp', 1]] },
  { x: -24, z: -268, r: 10, lvl: 4, list: [['imp', 2, 'verd']] },
  // costa
  { x: -62, z: 148, r: 9, lvl: 3, list: [['puglin', 3, 'blau']] },
  { x: 62, z: 156, r: 9, lvl: 3, list: [['puglin', 3, 'blau']] },
  // ruines
  { x: 140, z: -62, r: 9, lvl: 5, list: [['esquelet', 3], ['esquelet_mag', 1]] },
  { x: 160, z: -84, r: 10, lvl: 5, list: [['esquelet_minion', 5], ['esquelet_mag', 1]] },
  { x: 214, z: -52, r: 10, lvl: 6, list: [['esquelet', 2], ['esquelet_lladre', 2]] },
  { x: 160, z: -4, r: 10, lvl: 6, list: [['esquelet_mag', 2], ['esquelet_minion', 3]] },
  { x: 236, z: -12, r: 9, lvl: 7, list: [['esquelet_lladre', 3]] },
  { x: 120, z: -100, r: 10, lvl: 6, list: [['esquelet_minion', 4], ['esquelet', 1]] },
  { x: 198, z: -26, r: 9, lvl: 7, list: [['golem', 1], ['esquelet_arquer', 2]] },
  { x: 150, z: -130, r: 9, lvl: 7, list: [['golem', 2]] },
  { x: 244, z: -88, r: 9, lvl: 8, list: [['esquelet_arquer', 3], ['esquelet', 1]] },
  // cremades
  { x: -140, z: 12, r: 10, lvl: 8, list: [['imp', 2], ['puglin', 3, 'vermell']] },
  { x: -172, z: -52, r: 10, lvl: 9, list: [['imp_foc', 2], ['imp', 1]] },
  { x: -202, z: 30, r: 10, lvl: 9, list: [['puglin', 5, 'vermell']] },
  { x: -238, z: 2, r: 10, lvl: 10, list: [['imp', 3]] },
  { x: -150, z: -92, r: 10, lvl: 10, list: [['imp_foc', 2], ['puglin', 2, 'vermell']] },
  { x: -258, z: -40, r: 10, lvl: 11, list: [['imp', 2, 'verd'], ['imp_foc', 1]] },
  { x: -192, z: -72, r: 9, lvl: 11, list: [['golem_magma', 1], ['esquelet_piromant', 2]] },
  { x: -232, z: 54, r: 9, lvl: 11, list: [['golem_magma', 2]] },
  { x: -120, z: -50, r: 9, lvl: 10, list: [['esquelet_piromant', 3]] },
  // tòtems
  { x: -160, z: -26, r: 1, lvl: 9, list: [['totem', 1]], respawn: 240, id: 'totem1' },
  { x: -206, z: -6, r: 1, lvl: 10, list: [['totem', 1]], respawn: 240, id: 'totem2' },
  { x: -186, z: -112, r: 1, lvl: 10, list: [['totem', 1]], respawn: 240, id: 'totem3' },
  // cel
  { island: 'i0', x: 4, z: 222, r: 6, lvl: 12, list: [['puglin', 3, 'blau']] },
  { island: 'i1', x: -42, z: 246, r: 5, lvl: 13, list: [['imp', 2, 'blau']] },
  { island: 'i2', x: 44, z: 252, r: 5, lvl: 13, list: [['esquelet_mag', 2], ['bruixot', 1]] },
  { island: 'i3', x: 0, z: 284, r: 6, lvl: 14, list: [['imp_foc', 2], ['bruixot', 1]] },
  { island: 'i4', x: -36, z: 318, r: 5, lvl: 14, list: [['esquelet_lladre', 2], ['esquelet_arquer', 2]] },
  { island: 'i5', x: 80, z: 386, r: 7, lvl: 16, list: [['bruixot', 2], ['golem_magma', 1]] },
  { island: 'drac', x: -8, z: 438, r: 8, lvl: 17, list: [['golem_magma', 2]] },
  { island: 'drac', x: 34, z: 440, r: 8, lvl: 17, list: [['bruixot', 2], ['esquelet_piromant', 2]] },
  // caps
  { x: 215, z: 40, r: 1, lvl: 8, list: [['rei_ossut', 1]], respawn: 300, boss: true },
  { x: -228, z: -98, r: 1, lvl: 12, list: [['senyor_imps', 1]], respawn: 300, boss: true },
  { island: 'boss', x: 30, z: 346, r: 1, lvl: 16, list: [['ombra', 1]], respawn: 360, boss: true },
  { island: 'i5', x: 88, z: 396, r: 1, lvl: 17, list: [['ganfaul', 1]], respawn: 360, boss: true },
  { island: 'drac', x: 10, z: 462, r: 1, lvl: 18, list: [['drac', 1]], respawn: 420, boss: true },
  // fortaleses (onades fins al cap)
  ...STRUCTURE_CAMPS,
];
// marca els caps que viuen dins d'una fortalesa
for (const c of CAMPS) if (!c.structure) for (const st of STRUCTURES) if (Math.hypot(c.x - st.x, c.z - st.z) < st.reach - 4 && !c.island) { c.structure = st.id; if (c.boss) c.aggro = 15; }

export const ARENA_SPAWNS = [[-700 - 26, 700], [-700 + 26, 700], [-700, 700 - 26], [-700, 700 + 26]];

// Obstacles circulars per a col·lisions (edificis, troncs, roques)
export function buildObstacles(props, vegetation) {
  const obs = [];
  for (const p of props) {
    if (p.far) continue;
    if (p.wall) {
      const [len, th] = p.wall; const n = Math.max(1, Math.round(len / (th * 1.6)));
      const ca = Math.cos(p.ry), sa = Math.sin(p.ry);
      for (let i = 0; i < n; i++) { const t = (i + 0.5) / n - 0.5; obs.push({ x: p.x + ca * t * len, z: p.z - sa * t * len, r: th * 0.9 }); }
    } else if (p.box) {
      // rectangle (cases, torres): cercles petits al llarg del perímetre, per dins
      const [hx, hz] = p.box; const ca = Math.cos(p.ry), sa = Math.sin(p.ry);
      const rr = 0.7, step = rr * 1.25;
      const put = (lx, lz) => obs.push({ x: p.x + lx * ca + lz * sa, z: p.z - lx * sa + lz * ca, r: rr });
      const ix = Math.max(0, hx - rr), iz = Math.max(0, hz - rr);
      const nx = Math.max(1, Math.ceil((2 * ix) / step)), nz = Math.max(1, Math.ceil((2 * iz) / step));
      for (let i = 0; i <= nx; i++) { const lx = -ix + (2 * ix * i) / nx; put(lx, -iz); put(lx, iz); }
      for (let i = 1; i < nz; i++) { const lz = -iz + (2 * iz * i) / nz; put(-ix, lz); put(ix, lz); }
      if (Math.min(hx, hz) > 1.6) obs.push({ x: p.x, z: p.z, r: Math.min(hx, hz) - 0.6 });
    } else if (p.col > 0) obs.push({ x: p.x, z: p.z, r: p.col });
  }
  if (vegetation) for (const v of vegetation) if (v.col > 0) obs.push({ x: v.x, z: v.z, r: v.col, y: v.y });
  return obs;
}

// grid espacial per a consultes ràpides
export class SpatialGrid {
  constructor(cell = 16) { this.cell = cell; this.map = new Map(); }
  key(cx, cz) { return cx * 73856093 ^ cz * 19349663; }
  insert(o) {
    const c = this.cell; const x0 = Math.floor((o.x - o.r) / c), x1 = Math.floor((o.x + o.r) / c);
    const z0 = Math.floor((o.z - o.r) / c), z1 = Math.floor((o.z + o.r) / c);
    for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
      const k = this.key(x, z); let a = this.map.get(k); if (!a) this.map.set(k, a = []); a.push(o);
    }
  }
  query(x, z) { return this.map.get(this.key(Math.floor(x / this.cell), Math.floor(z / this.cell))) || EMPTY; }
}
const EMPTY = [];

// resol col·lisions d'un cercle contra els obstacles
export function collide(grid, x, z, r, y) {
  const list = grid.query(x, z);
  for (const o of list) {
    if (o.y !== undefined && y !== undefined && Math.abs(o.y - y) > 6) continue;
    const dx = x - o.x, dz = z - o.z; const d = Math.hypot(dx, dz); const m = o.r + r;
    if (d < m && d > 1e-4) { x = o.x + dx / d * m; z = o.z + dz / d * m; }
  }
  return [x, z];
}

// ---------- Vegetació determinista ----------
// Retorna una llista d'instàncies {m, x, z, y, s, ry, col}
export function buildVegetation(props) {
  const out = [];
  const r = mulberry32(2024);
  const blocked = (x, z, pad = 0) => {
    if (Math.hypot(x, z) < 50 + pad) return true;
    if (roadDist(x, z) < 4 + pad) return true;
    for (const a of BOSS_ARENAS) if (Math.hypot(x - a.x, z - a.z) < a.r) return true;
    for (const a of STRUCTURE_FLATS) if (Math.hypot(x - a.x, z - a.z) < a.r + 3) return true;
    for (const w of WAYSTONES) if (Math.hypot(x - w.x, z - w.z) < 6) return true;
    for (const c of CHESTS) if (Math.hypot(x - c.x, z - c.z) < 4) return true;
    for (const c of CAMPS) if (!c.island && Math.hypot(x - c.x, z - c.z) < c.r * 0.7) return true;
    if (Math.hypot(x - 0, z - 138) < 10) return true;
    if (Math.hypot(x + 18, z + 172) < 9) return true; // clariana de l'Arbre Mare
    return false;
  };
  const near = props.filter((p) => !p.far && p.col > 0);
  const onProp = (x, z) => near.some((p) => Math.hypot(x - p.x, z - p.z) < p.col + 2.5);
  const place = (m, x, z, s, col = 0, extra) => {
    const y = height(x, z);
    if (y < 0.6) return;
    out.push({ m, x, z, y, s, ry: r() * Math.PI * 2, col: col * s, ...(extra || {}) });
  };
  // arbres: mostreig per graella amb jitter
  for (let gx = -300; gx <= 300; gx += 7) {
    for (let gz = -300; gz <= 175; gz += 7) {
      const x = gx + (r() - 0.5) * 6, z = gz + (r() - 0.5) * 6;
      const d = Math.hypot(x, z);
      if (d > 292) continue;
      if (blocked(x, z, 2) || onProp(x, z)) continue;
      const zn = zoneAt(x, z);
      const n = fbm(x * 0.02 + 40, z * 0.02 - 13, 2);
      const h = height(x, z);
      if (h < 1.2) continue;
      if (zn.id === 'bosc') {
        if (n > -0.15 && r() < 0.62) {
          const k = r();
          if (k < 0.05) place('TwistedTree_' + (1 + Math.floor(r() * 5)), x, z, 0.75 + r() * 0.25, 1.2);
          else if (k < 0.3 && z < -200) place('Pine_' + (1 + Math.floor(r() * 5)), x, z, 1.0 + r() * 0.35, 0.6);
          else place('CommonTree_' + (1 + Math.floor(r() * 5)), x, z, 0.9 + r() * 0.45, 0.5);
        }
      } else if (zn.id === 'vila' || zn.id === 'costa') {
        if (n > 0.22 && r() < 0.35 && h > 1.8) place('CommonTree_' + (1 + Math.floor(r() * 5)), x, z, 0.85 + r() * 0.3, 0.5);
      } else if (zn.id === 'ruines') {
        if (n > 0.1 && r() < 0.25) place(r() < 0.6 ? 'DeadTree_' + (1 + Math.floor(r() * 5)) : 'CommonTree_' + (1 + Math.floor(r() * 5)), x, z, 0.55 + r() * 0.3, 0.5);
      } else if (zn.id === 'cremades') {
        if (n > -0.05 && r() < 0.32) {
          if (r() < 0.55) place('DeadTree_' + (1 + Math.floor(r() * 5)), x, z, 0.6 + r() * 0.35, 0.5);
          else place('TwistedTree_' + (1 + Math.floor(r() * 5)), x, z, 0.45 + r() * 0.2, 1.0, { autumn: true });
        }
      }
      if (d > 255 && z < 100 && r() < 0.5) place('Pine_' + (1 + Math.floor(r() * 5)), x, z, 1.1 + r() * 0.5, 0.6);
    }
  }
  // Arbre Mare del bosc
  out.push({ m: 'TwistedTree_2', x: -18, z: -172, y: height(-18, -172), s: 1.75, ry: 0.6, col: 3.2, mare: true });
  // detalls petits (no col·lisionen)
  const small = [
    ['Bush_Common', 0.9, ['bosc', 'vila', 'costa']], ['Bush_Common_Flowers', 0.9, ['bosc', 'vila']], ['Fern_1', 0.8, ['bosc']],
    ['Flower_3_Group', 0.5, ['bosc', 'vila', 'costa']], ['Flower_4_Group', 0.5, ['bosc', 'vila']], ['Flower_3_Single', 0.5, ['vila', 'bosc']],
    ['Mushroom_Common', 0.9, ['bosc']], ['Mushroom_Laetiporus', 0.8, ['bosc', 'ruines']], ['Clover_1', 0.7, ['bosc', 'vila']],
    ['Plant_1', 0.7, ['bosc', 'costa']], ['Plant_7_Big', 0.9, ['bosc', 'ruines']], ['Rock_Medium_1', 0.7, ['ruines', 'cremades', 'costa', 'bosc']],
    ['Rock_Medium_2', 0.8, ['cremades', 'ruines', 'costa']], ['Rock_Medium_3', 0.6, ['bosc', 'cremades']],
    ['Pebble_Round_2', 1.4, ['costa', 'ruines', 'vila']], ['Pebble_Square_3', 1.4, ['ruines', 'cremades']],
  ];
  for (let i = 0; i < 5200; i++) {
    const x = (r() - 0.5) * 580, z = -290 + r() * 460;
    if (Math.hypot(x, z) > 285) continue;
    if (Math.hypot(x, z) < 22) continue;
    if (roadDist(x, z) < 2.5) continue;
    if (onProp(x, z)) continue;
    const zn = zoneAt(x, z).id;
    const cand = small[Math.floor(r() * small.length)];
    if (!cand[2].includes(zn)) continue;
    const rock = cand[0].startsWith('Rock');
    if (rock && blocked(x, z)) continue;
    place(cand[0], x, z, cand[1] * (0.7 + r() * 0.6), rock ? 0.9 : 0, rock && cremadesTint(zn) ? { desert: true } : null);
  }
  // pedres de camí
  for (const road of ROADS) for (let i = 0; i < road.length - 1; i++) {
    const [ax, az] = road[i], [bx, bz] = road[i + 1]; const len = Math.hypot(bx - ax, bz - az);
    for (let t = 0; t < len; t += 2.6) {
      const k = t / len; const x = ax + (bx - ax) * k + (r() - 0.5) * 2.4, z = az + (bz - az) * k + (r() - 0.5) * 2.4;
      if (Math.hypot(x, z) < 10) continue;
      out.push({ m: 'RockPath_Round_' + ['Small_1', 'Small_2', 'Small_3', 'Wide', 'Thin'][Math.floor(r() * 5)], x, z, y: height(x, z), s: 0.9 + r() * 0.4, ry: r() * 6.28, col: 0, flat: true });
    }
  }
  // illes: arbres i detalls
  for (const is of ISLANDS) {
    if (is.id === 'arena') continue;
    const n = is.id === 'boss' ? 10 : Math.round(is.r * 0.45);
    for (let i = 0; i < n; i++) {
      const a = r() * 6.28, d = is.r * (0.45 + r() * 0.45);
      const x = is.x + Math.cos(a) * d, z = is.z + Math.sin(a) * d;
      if (LAUNCHPADS.some((l) => l.island === is.id && Math.hypot(x - l.x, z - l.z) < 5)) continue;
      if (is.id === 'boss' && d < is.r * 0.75) continue;
      if (is.volcanic) {
        if (d < is.r * 0.7) continue;
        out.push({ m: 'DeadTree_' + (1 + Math.floor(r() * 5)), x, z, y: islandTop(is, x, z), s: 0.6 + r() * 0.3, ry: r() * 6.28, col: 0.5, island: is.id });
        continue;
      }
      const m = r() < 0.3 ? 'TwistedTree_' + (1 + Math.floor(r() * 5)) : 'CommonTree_' + (1 + Math.floor(r() * 5));
      const s = m.startsWith('Twisted') ? 0.45 : 0.8;
      out.push({ m, x, z, y: islandTop(is, x, z), s: s * (0.8 + r() * 0.4), ry: r() * 6.28, col: (m.startsWith('Twisted') ? 1.0 : 0.5) * s, island: is.id });
    }
    for (let i = 0; i < is.r * 1.5; i++) {
      if (is.volcanic) break;
      const a = r() * 6.28, d = is.r * Math.sqrt(r()) * 0.92;
      const x = is.x + Math.cos(a) * d, z = is.z + Math.sin(a) * d;
      const m = ['Flower_3_Group', 'Flower_4_Group', 'Bush_Common_Flowers', 'Clover_2', 'Rock_Medium_2'][Math.floor(r() * 5)];
      out.push({ m, x, z, y: islandTop(is, x, z), s: 0.7 + r() * 0.3, ry: r() * 6.28, col: 0, island: is.id });
    }
  }
  return out;
}
function cremadesTint(zn) { return zn === 'cremades'; }

let _cached = null;
export function getWorld() {
  if (_cached) return _cached;
  const props = buildLayout();
  const vegetation = buildVegetation(props);
  const obstacles = buildObstacles(props, vegetation);
  const grid = new SpatialGrid(14);
  for (const o of obstacles) grid.insert(o);
  _cached = { props, vegetation, obstacles, grid };
  return _cached;
}
