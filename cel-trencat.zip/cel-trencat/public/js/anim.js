// Runtime side of the baked humanoid animation library.
// Clips are stored as world-aligned rotation deltas from a T-pose using VRM
// humanoid bone names; this module turns them into THREE.AnimationClips for a
// concrete rig (VRM heroes or Quaternius/UAL monsters).
import * as THREE from 'three';

const UPPER = new Set([
  'chest', 'upperChest', 'neck', 'head',
  'leftShoulder', 'leftUpperArm', 'leftLowerArm', 'leftHand',
  'rightShoulder', 'rightUpperArm', 'rightLowerArm', 'rightHand',
]);
function isUpper(name) {
  if (UPPER.has(name)) return true;
  return /^(left|right)(Thumb|Index|Middle|Ring|Little)/.test(name);
}

function decode(b64, scale) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const i16 = new Int16Array(bytes.buffer);
  const f = new Float32Array(i16.length);
  for (let i = 0; i < i16.length; i++) f[i] = i16[i] / scale;
  return f;
}

export class HumanoidAnimLib {
  static async load(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error('No s\'han pogut carregar les animacions');
    return new HumanoidAnimLib(await res.json());
  }

  constructor(json) {
    this.fps = json.fps;
    this.clips = {};
    for (const [name, c] of Object.entries(json.clips)) {
      const bones = {};
      for (const [bn, e] of Object.entries(c.bones)) {
        bones[bn] = { q: decode(e.q, 32767), p: e.p ? decode(e.p, 8000) : null };
      }
      this.clips[name] = { duration: c.d, frames: c.n, loop: c.loop, bones };
    }
  }

  has(name) { return !!this.clips[name]; }

  // Build a THREE.AnimationClip for a rig. mode: 'full' | 'upper' | 'lower'
  build(name, rig, mode = 'full') {
    const c = this.clips[name];
    if (!c) return null;
    const times = new Float32Array(c.frames);
    for (let i = 0; i < c.frames; i++) times[i] = Math.min(c.duration, i / this.fps);
    const tracks = [];
    const qn = new THREE.Quaternion();
    for (const [bn, data] of Object.entries(c.bones)) {
      const target = rig.bones[bn];
      if (!target) continue;
      const upper = isUpper(bn);
      if (mode === 'upper' && !upper) continue;
      if (mode === 'lower' && upper) continue;
      const vals = new Float32Array(c.frames * 4);
      const { rp, rbInv } = target;
      for (let f = 0; f < c.frames; f++) {
        qn.fromArray(data.q, f * 4);
        // local = inv(Rparent) * qnorm * Rbone
        qn.premultiply(rp).multiply(target.rb);
        qn.toArray(vals, f * 4);
      }
      tracks.push(new THREE.QuaternionKeyframeTrack(`${target.node.name}.quaternion`, times, vals));
      if (bn === 'hips' && data.p && mode !== 'upper') {
        const pv = new Float32Array(c.frames * 3);
        const v = new THREE.Vector3();
        for (let f = 0; f < c.frames; f++) {
          v.fromArray(data.p, f * 3).multiplyScalar(rig.hipsHeight).applyMatrix4(rig.hipsParentInv);
          v.toArray(pv, f * 3);
        }
        tracks.push(new THREE.VectorKeyframeTrack(`${target.node.name}.position`, times, pv));
      }
      void rbInv;
    }
    const clip = new THREE.AnimationClip(mode === 'full' ? name : `${name}:${mode}`, c.duration, tracks);
    clip.userData = { loop: c.loop };
    return clip;
  }
}

// Captures rest-pose data of a rig. `nodes` maps humanoid name -> Object3D.
function captureRig(root, nodes) {
  root.updateMatrixWorld(true);
  const rootInvQ = root.getWorldQuaternion(new THREE.Quaternion()).invert();
  const rootInv = root.matrixWorld.clone().invert();
  const bones = {};
  for (const [hn, node] of Object.entries(nodes)) {
    if (!node) continue;
    const rb = rootInvQ.clone().multiply(node.getWorldQuaternion(new THREE.Quaternion()));
    const rpWorld = rootInvQ.clone().multiply(node.parent.getWorldQuaternion(new THREE.Quaternion()));
    bones[hn] = { node, rb, rp: rpWorld.invert(), rbInv: null };
  }
  const hips = nodes.hips;
  const hipsRoot = new THREE.Vector3().setFromMatrixPosition(rootInv.clone().multiply(hips.matrixWorld));
  const hipsParentInv = rootInv.clone().multiply(hips.parent.matrixWorld).invert();
  return { bones, hipsHeight: hipsRoot.y, hipsParentInv };
}

export const VRM_BONES = [
  'hips', 'spine', 'chest', 'upperChest', 'neck', 'head',
  'leftShoulder', 'leftUpperArm', 'leftLowerArm', 'leftHand', 'rightShoulder', 'rightUpperArm', 'rightLowerArm', 'rightHand',
  'leftUpperLeg', 'leftLowerLeg', 'leftFoot', 'leftToes', 'rightUpperLeg', 'rightLowerLeg', 'rightFoot', 'rightToes',
];
for (const s of ['left', 'right']) {
  for (const f of ['Thumb']) for (const p of ['Metacarpal', 'Proximal', 'Distal']) VRM_BONES.push(s + f + p);
  for (const f of ['Index', 'Middle', 'Ring', 'Little']) for (const p of ['Proximal', 'Intermediate', 'Distal']) VRM_BONES.push(s + f + p);
}

export function rigFromVRM(vrm) {
  const nodes = {};
  for (const b of VRM_BONES) {
    const n = vrm.humanoid.getNormalizedBoneNode(b);
    if (n) nodes[b] = n;
  }
  return captureRig(vrm.scene, nodes);
}

// Quaternius Universal Animation Library rig (Bestiary monsters, mannequins)
const UAL = (() => {
  const m = { hips: 'pelvis', spine: 'spine_01', chest: 'spine_02', upperChest: 'spine_03', neck: 'neck_01', head: 'Head' };
  for (const [u, s] of [['l', 'left'], ['r', 'right']]) {
    Object.assign(m, {
      [`${s}Shoulder`]: `clavicle_${u}`, [`${s}UpperArm`]: `upperarm_${u}`, [`${s}LowerArm`]: `lowerarm_${u}`, [`${s}Hand`]: `hand_${u}`,
      [`${s}UpperLeg`]: `thigh_${u}`, [`${s}LowerLeg`]: `calf_${u}`, [`${s}Foot`]: `foot_${u}`, [`${s}Toes`]: `ball_${u}`,
      [`${s}ThumbMetacarpal`]: `thumb_01_${u}`, [`${s}ThumbProximal`]: `thumb_02_${u}`, [`${s}ThumbDistal`]: `thumb_03_${u}`,
    });
    for (const [q, v] of [['index', 'Index'], ['middle', 'Middle'], ['ring', 'Ring'], ['pinky', 'Little']]) {
      m[`${s}${v}Proximal`] = `${q}_01_${u}`; m[`${s}${v}Intermediate`] = `${q}_02_${u}`; m[`${s}${v}Distal`] = `${q}_03_${u}`;
    }
  }
  return m;
})();

export function rigFromUAL(root) {
  const nodes = {};
  for (const [hn, bn] of Object.entries(UAL)) {
    const n = root.getObjectByName(bn);
    if (n) nodes[hn] = n;
  }
  return captureRig(root, nodes);
}

// ---------------------------------------------------------------------------
// Esquelets humanoides qualssevol (Mixamo, Advanced Skeleton, etc.)
// Cada mapa associa el nom humanoide amb un patró del nom de l'os.
export const BONE_MAPS = {
  mixamo: (() => {
    const m = { hips: 'Hips', spine: 'Spine', chest: 'Spine1', upperChest: 'Spine2', neck: 'Neck', head: 'Head' };
    for (const [S, s] of [['Left', 'left'], ['Right', 'right']]) {
      Object.assign(m, { [`${s}Shoulder`]: `${S}Shoulder`, [`${s}UpperArm`]: `${S}Arm`, [`${s}LowerArm`]: `${S}ForeArm`, [`${s}Hand`]: `${S}Hand`,
        [`${s}UpperLeg`]: `${S}UpLeg`, [`${s}LowerLeg`]: `${S}Leg`, [`${s}Foot`]: `${S}Foot`, [`${s}Toes`]: `${S}ToeBase` });
    }
    for (const k in m) m[k] = new RegExp(`^mixamorig:?${m[k]}(_\\d+)?$`);
    return m;
  })(),
  // Advanced Skeleton (Maya), p. ex. el gòlem de FourthGreen
  golem: (() => {
    const m = { hips: 'Root_M', spine: 'Spine1_M', chest: 'Spine2_M', upperChest: 'Spine3_M', neck: 'Neck_M', head: 'Head_M' };
    for (const [S, s] of [['L', 'left'], ['R', 'right']]) {
      Object.assign(m, { [`${s}Shoulder`]: `Scapula_${S}`, [`${s}UpperArm`]: `Shoulder_${S}`, [`${s}LowerArm`]: `Elbow_${S}`, [`${s}Hand`]: `Wrist_${S}`,
        [`${s}UpperLeg`]: `Hip_${S}`, [`${s}LowerLeg`]: `Knee_${S}`, [`${s}Foot`]: `Ankle_${S}`, [`${s}Toes`]: `Toes_${S}` });
    }
    for (const k in m) m[k] = new RegExp(`^${m[k]}(_\\d+)?$`);
    return m;
  })(),
};

// Posa braços i cames en T (si el model no hi és) abans de capturar el repòs.
// El model ha de mirar cap a +Z: el costat esquerre és +X.
const TPOSE_DIR = {
  leftUpperArm: ['leftLowerArm', [1, 0, 0]], leftLowerArm: ['leftHand', [1, 0, 0]],
  rightUpperArm: ['rightLowerArm', [-1, 0, 0]], rightLowerArm: ['rightHand', [-1, 0, 0]],
  leftUpperLeg: ['leftLowerLeg', [0, -1, 0]], leftLowerLeg: ['leftFoot', [0, -1, 0]],
  rightUpperLeg: ['rightLowerLeg', [0, -1, 0]], rightLowerLeg: ['rightFoot', [0, -1, 0]],
};
function forceTPose(root, nodes) {
  root.updateMatrixWorld(true);
  const rootQ = root.getWorldQuaternion(new THREE.Quaternion());
  const rootQi = rootQ.clone().invert();
  const pa = new THREE.Vector3(), pb = new THREE.Vector3();
  for (const [bone, [child, dir]] of Object.entries(TPOSE_DIR)) {
    const a = nodes[bone], b = nodes[child];
    if (!a || !b) continue;
    root.updateMatrixWorld(true);
    a.getWorldPosition(pa); b.getWorldPosition(pb);
    const cur = pb.sub(pa).applyQuaternion(rootQi).normalize();
    const want = new THREE.Vector3().fromArray(dir);
    if (cur.lengthSq() < 1e-8) continue;
    // rotació en l'espai del model -> en l'espai del món -> local de l'os
    const dq = new THREE.Quaternion().setFromUnitVectors(cur, want);
    const dqWorld = rootQ.clone().multiply(dq).multiply(rootQi);
    const wq = a.getWorldQuaternion(new THREE.Quaternion());
    const pq = a.parent.getWorldQuaternion(new THREE.Quaternion());
    a.quaternion.copy(pq.invert().multiply(dqWorld.multiply(wq)));
  }
  root.updateMatrixWorld(true);
}

export function rigFromMap(root, mapName, opts = {}) {
  const map = BONE_MAPS[mapName];
  const nodes = {};
  const all = [];
  root.traverse((o) => { if (o.isBone || o.type === 'Object3D' || o.isObject3D) all.push(o); });
  for (const [hn, re] of Object.entries(map)) {
    const n = all.find((o) => re.test(o.name));
    if (n) nodes[hn] = n;
  }
  const rest = new Map();
  for (const n of Object.values(nodes)) rest.set(n, n.quaternion.clone());
  if (opts.tpose !== false) forceTPose(root, nodes);
  const rig = captureRig(root, nodes);
  // torna el model a la postura original (les animacions la sobreescriuran)
  if (opts.keepPose) for (const [n, q] of rest) n.quaternion.copy(q);
  rig.nodes = nodes;
  return rig;
}
