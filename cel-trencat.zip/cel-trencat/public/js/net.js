// Connexió amb el "servidor": local (solitari, al navegador) o remot (Socket.IO).
import { Sim } from './sim.js';

export class Emitter {
  constructor() { this.h = {}; }
  on(t, f) { (this.h[t] ||= []).push(f); return this; }
  off(t) { delete this.h[t]; return this; }
  fire(t, d) { const l = this.h[t]; if (l) for (const f of l) f(d); }
}

export class LocalServer extends Emitter {
  constructor(mode = 'coop', opts = {}) {
    super();
    this.online = false;
    this.id = 'local';
    this.mode = mode;
    this.queue = [];
    this.n = 0;
    this.sim = new Sim({ mode, level: opts.level, seed: Date.now() & 0xffffff, onEvent: (type, data, to) => this.route(type, data, to) });
  }
  route(type, data, to) { if (!to || to === this.id) this.queue.push([type, data]); }
  join(payload) {
    this.sim.addPlayer(this.id, payload);
    this.timer = setInterval(() => this.step(), 50);
    return Promise.resolve({ ok: true, code: 'SOLO', mode: this.mode, id: this.id });
  }
  step() {
    if (this.paused) return;
    this.sim.tick(0.05);
    if (this.queue.length) { const q = this.queue; this.queue = []; this.fire('ev', q); }
    if (++this.n % 2 === 0) this.fire('snap', this.sim.snapshot(this.id));
  }
  send(type, data) { this.sim.input(this.id, type, data); }
  close() { clearInterval(this.timer); }
}

export class RemoteServer extends Emitter {
  constructor(url) {
    super();
    this.online = true;
    this.url = url;
    this.id = null;
  }
  async connect() {
    if (!window.io) {
      await new Promise((ok, ko) => {
        const s = document.createElement('script');
        s.src = (this.url || '') + '/socket.io/socket.io.js';
        s.onload = ok; s.onerror = () => ko(new Error('No s\'ha pogut contactar amb el servidor'));
        document.head.appendChild(s);
      });
    }
    this.socket = window.io(this.url || undefined, { transports: ['websocket', 'polling'] });
    await new Promise((ok, ko) => {
      const t = setTimeout(() => ko(new Error('El servidor no respon (si és a Render gratuït, pot tardar fins a un minut a despertar-se)')), 60000);
      this.socket.on('connect', () => { clearTimeout(t); ok(); });
      this.socket.on('connect_error', () => {});
    });
    this.socket.on('ev', (evs) => this.fire('ev', evs));
    this.socket.on('snap', (s) => this.fire('snap', s));
    for (const t of ['room', 'roomStart', 'roomLobby', 'roomChat']) this.socket.on(t, (d) => this.fire(t, d));
    this.socket.on('disconnect', () => this.fire('disconnect'));
  }
  // amb temps límit: un servidor antic no respon a aquestes peticions
  ask(type, data, ms = 6000) {
    return new Promise((ok) => {
      const t = setTimeout(() => ok(null), ms);
      this.socket.emit(type, data, (r) => { clearTimeout(t); ok(r || {}); });
    });
  }
  async hello() { const r = await this.ask('hello', {}, 5000); this.serverVersion = r && r.version || null; return this.serverVersion; }
  check(code) { return this.ask('check', { code }); }
  create(opts) { return new Promise((ok) => this.socket.emit('create', opts, ok)); }
  join(payload) {
    return new Promise((ok) => this.socket.emit('join', payload, (r) => { if (r && r.ok) this.id = r.id; ok(r); }));
  }
  enter(payload) {
    return new Promise((ok) => this.socket.emit('enter', payload, (r) => { if (r && r.ok) this.id = r.id; ok(r); }));
  }
  roomMode(mode, level) { this.socket.emit('roomMode', { mode, level }); }
  roomStart() { return new Promise((ok) => this.socket.emit('roomStart', {}, ok)); }
  roomEnd() { this.socket.emit('roomEnd'); }
  roomBack() { this.socket.emit('roomBack'); }
  roomChat(text) { this.socket.emit('roomChat', { text }); }
  send(type, data) { if (this.socket) this.socket.emit(type, data); }
  close() { if (this.socket) { this.socket.emit('leave'); this.socket.disconnect(); } }
}

export function serverAvailable() {
  // la còpia de Claude (artifact) no té mai servidor propi
  if (typeof window !== 'undefined' && window.CT_TEXT_ASSETS) return Promise.resolve(false);
  // el servidor de joc respon /health amb {"ok":true,...}; qualsevol altra resposta vol dir que no n'hi ha
  const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const t = setTimeout(() => ctl && ctl.abort(), 4000);
  return fetch('/health', { cache: 'no-store', signal: ctl ? ctl.signal : undefined })
    .then((r) => (r.ok ? r.json() : null)).then((j) => !!(j && j.ok === true && 'rooms' in j)).catch(() => false)
    .finally(() => clearTimeout(t));
}
