// ============================================================
//  Branques d'habilitats: 3 per classe, 5 nivells (tiers) cadascuna.
//  Es guanya 1 punt d'habilitat per nivell (a partir del nivell 2).
//  Els tiers s'obren per nivell del personatge i per punts posats a la branca.
// ============================================================

export const TIER_LVL = [0, 2, 5, 8, 12, 16];   // nivell mínim de cada tier
export const TIER_PTS = [0, 0, 2, 4, 6, 8];     // punts a la branca necessaris

// Habilitats noves que s'aprenen a les branques (es poden posar a les tecles 1-4)
export const LEARN_ABILITIES = {
  // foc
  mur_flames: { name: 'Mur de Flames', el: 'foc', kind: 'field', dmg: 15, tick: 0.5, dur: 5, radius: 5.5, range: 28, cd: 12, mana: 34,
    anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'flames', status: { burn: { dur: 3, dps: 8 } }, desc: 'Un camp de flames que crema tot el que hi entra.' },
  supernova: { name: 'Supernova', el: 'foc', kind: 'nova', dmg: 95, radius: 9.5, knock: 12, cd: 16, mana: 48,
    anim: 'magic_area_b', animSpeed: 1.6, release: 0.55, fx: 'nova', status: { burn: { dur: 4, dps: 10 } }, desc: 'Una explosió immensa al teu voltant que empeny i crema.' },
  escut_flames: { name: 'Escut de Flames', el: 'foc', kind: 'buff', buff: 'shield', amount: 110, scale: 2.6, dur: 7, reflect: 0.5, cd: 16, mana: 26,
    anim: 'cast_1h', animSpeed: 2.0, release: 0.35, upper: true, fx: 'shield', desc: 'Escut que absorbeix dany i crema qui et colpeja.' },
  // gel
  preso_gel: { name: 'Presó de Gel', el: 'gel', kind: 'ground', dmg: 46, hits: 1, delay: 0.5, radius: 3.8, range: 30, cd: 10, mana: 28,
    anim: 'magic_2h_d', animSpeed: 2.0, release: 0.3, fx: 'ice', status: { freeze: { dur: 2.4 } }, desc: 'Tanca els enemics en un bloc de gel durant 2,4 s.' },
  allau: { name: 'Allau', el: 'gel', kind: 'projectile', dmg: 62, speed: 24, range: 26, radius: 2.2, pierce: true, cd: 9, mana: 30,
    anim: 'magic_2h_e', animSpeed: 1.8, release: 0.38, fx: 'wave', rad: 2.2, status: { slow: { dur: 3, amt: 0.5 } }, desc: 'Una onada de neu que travessa i alenteix tot el que troba.' },
  pas_glacat: { name: 'Pas Glaçat', el: 'gel', kind: 'blink', dist: 11, dmg: 34, radius: 4, cd: 7, mana: 16,
    anim: 'cast_1h', animSpeed: 3.0, release: 0.05, fx: 'blink', status: { slow: { dur: 2, amt: 0.45 } }, desc: 'Et teletransportes i glaces el lloc on arribes.' },
  // llamp
  bola_plasma: { name: 'Bola de Plasma', el: 'llamp', kind: 'projectile', dmg: 54, speed: 15, range: 34, radius: 1.3, pierce: true, cd: 7, mana: 24,
    anim: 'magic_1h_a', animSpeed: 1.7, release: 0.42, upper: true, fx: 'fireball', status: { shock: { dur: 1.2 } }, desc: 'Esfera lenta que travessa i electrocuta tot el que toca.' },
  tempesta_electrica: { name: 'Tempesta Elèctrica', el: 'llamp', kind: 'field', dmg: 14, tick: 0.4, dur: 5, radius: 6, range: 30, cd: 13, mana: 38,
    anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'storm', status: { shock: { dur: 0.6 } }, desc: 'Un núvol de llamps que descarrega sobre la zona.' },
  descarrega: { name: 'Descàrrega', el: 'llamp', kind: 'nova', dmg: 40, radius: 5.5, knock: 6, cd: 8, mana: 20,
    anim: 'magic_area_a', animSpeed: 2.0, release: 0.4, fx: 'nova', status: { stun: { dur: 0.9 } }, desc: 'Allibera l\'electricitat del cos i atordeix els enemics propers.' },
  // guerrer
  estocada: { name: 'Estocada', el: 'fisic', kind: 'dash', dist: 8, dmg: 110, radius: 2.4, cd: 8, mana: 14,
    anim: 'sword_dash', animSpeed: 1.6, release: 0.1, fx: 'dash', desc: 'Embat ràpid que travessa els enemics i fa molt de mal.' },
  execucio: { name: 'Execució', el: 'fisic', kind: 'melee', single: true, combo: [
    { dmg: 96, anim: 'sword_c', animSpeed: 1.7, release: 0.3, range: 3.9, arc: 130, time: 0.7, knock: 4, execute: 0.35, big: true },
  ], cd: 9, mana: 18, fx: 'slash', desc: 'Un cop precís que fa el doble de mal als enemics amb menys del 35% de vida.' },
  escomesa: { name: 'Escomesa de Terra', el: 'fisic', kind: 'nova', dmg: 58, radius: 6, knock: 8, cd: 10, mana: 18,
    anim: 'sword_heavy', animSpeed: 2.0, release: 0.35, fx: 'nova', status: { stun: { dur: 1.1 } }, desc: 'Clava l\'espasa a terra i atordeix tot el voltant.' },
};
export const LEARN_ICON = {
  mur_flames: '🧱', supernova: '🌞', escut_flames: '🔰', preso_gel: '🧊', allau: '🌊', pas_glacat: '👣',
  bola_plasma: '🔮', tempesta_electrica: '⛈️', descarrega: '💫', estocada: '🗡️', execucio: '💀', escomesa: '🪨',
  raig_solar: '☀️', orbes_flama: '🔆', raig_gelid: '❄️', vortex_gel: '🌀', escut_electric: '🔵', singularitat: '🌑',
  cop_demolidor: '🔨', rafega: '🗡️', cop_espatlla: '🛡️',
};

const N = (id, tier, name, icon, max, desc, eff) => ({ id, tier, name, icon, max, desc, eff });
const el = (e, v) => ({ el: e, dmg: v });
const st = (stat, o) => ({ stat, ...o });

export const SKILL_TREES = {
  foc: [
    { id: 'incineracio', name: 'Incineració', icon: '🔥', desc: 'Cremades que no s\'apaguen.', nodes: [
      N('f_a1', 1, 'Brases', '🔥', 3, '+7% de dany de foc per rang.', [el('foc', 0.07)]),
      N('f_a2', 2, 'Combustió', '♨️', 2, 'Les cremades fan un 30% més de mal i duren 1 s més per rang.', [{ status: 'burn', dps: 0.3, dur: 1 }]),
      N('f_a3', 3, 'Mur de Flames', '🧱', 1, 'Aprens una habilitat nova: un camp de flames que crema.', [{ unlock: 'mur_flames' }]),
      N('f_a4', 4, 'Cor de magma', '🌋', 3, '+3% de probabilitat de crític per rang.', [st('crit', { add: 3 })]),
      N('f_a5', 5, 'Cendres vives', '💀', 1, 'Els enemics que moren cremant exploten i fan mal als del voltant.', [{ special: 'ashes' }]),
    ] },
    { id: 'cataclisme', name: 'Cataclisme', icon: '☄️', desc: 'Destrucció en àrea.', nodes: [
      N('f_b1', 1, 'Ones de calor', '🌡️', 3, '+8% d\'àrea de totes les habilitats per rang.', [{ area: 0.08 }]),
      N('f_b2', 2, 'Meteorits pesants', '☄️', 2, 'Pluja de Meteorits: +1 meteorit i +12% de dany per rang.', [{ ab: 'meteorit', hits: 1, dmg: 0.12 }]),
      N('f_b3', 3, 'Supernova', '🌞', 1, 'Aprens una habilitat nova: una explosió immensa al teu voltant.', [{ unlock: 'supernova' }]),
      N('f_b4', 4, 'Fúria ígnia', '💢', 3, '+5% de poder per rang.', [st('poder', { pct: 0.05 })]),
      N('f_b5', 5, 'Apocalipsi', '🌠', 1, 'Durant l\'Avatar del Fènix cauen meteorits sobre els enemics propers.', [{ special: 'apocalypse' }]),
    ] },
    { id: 'fenix', name: 'Fènix', icon: '🦅', desc: 'Resistència i mobilitat.', nodes: [
      N('f_c1', 1, 'Plomes ardents', '🪶', 3, '+6% de vida màxima per rang.', [st('maxHp', { pct: 0.06 })]),
      N('f_c2', 2, 'Vol ardent', '💨', 2, 'Impuls Ardent: −20% de recàrrega i +25% de distància per rang.', [{ ab: 'impuls_ardent', cd: -0.2, dist: 0.25 }]),
      N('f_c3', 3, 'Escut de Flames', '🔰', 1, 'Aprens una habilitat nova: un escut que crema qui et colpeja.', [{ unlock: 'escut_flames' }]),
      N('f_c4', 4, 'Flama interior', '❤️‍🔥', 3, '+2 de regeneració de vida i +1 de manà per segon per rang.', [st('hpRegen', { add: 2 }), st('manaRegen', { add: 1 })]),
      N('f_c5', 5, 'Renéixer', '🐦‍🔥', 1, 'Un cop cada 2 minuts, en caure tornes a la vida amb el 40% de vida.', [{ special: 'rebirth' }]),
    ] },
  ],
  gel: [
    { id: 'congelacio', name: 'Congelació', icon: '❄️', desc: 'Atrapa i congela.', nodes: [
      N('g_a1', 1, 'Gebre', '❄️', 3, '+7% de dany de gel per rang.', [el('gel', 0.07)]),
      N('g_a2', 2, 'Fred intens', '🥶', 2, 'Els alentiments són un 10% més forts i les congelacions duren 0,4 s més per rang.', [{ status: 'slow', amt: 0.1, dur: 1 }, { status: 'freeze', dur: 0.4 }]),
      N('g_a3', 3, 'Presó de Gel', '🧊', 1, 'Aprens una habilitat nova: tanca els enemics dins un bloc de gel.', [{ unlock: 'preso_gel' }]),
      N('g_a4', 4, 'Cor de glaç', '💎', 3, '+3% de probabilitat de crític per rang.', [st('crit', { add: 3 })]),
      N('g_a5', 5, 'Trencaglaç', '🔨', 1, 'Els enemics alentits o congelats reben un 25% més de dany de qualsevol font.', [{ special: 'shatter' }]),
    ] },
    { id: 'tempesta', name: 'Tempesta', icon: '🌨️', desc: 'Control de zona.', nodes: [
      N('g_b1', 1, 'Vent glaçat', '🌬️', 3, '+8% d\'àrea de totes les habilitats per rang.', [{ area: 0.08 }]),
      N('g_b2', 2, 'Tempesta perpètua', '🌨️', 2, 'Tempesta de Neu: +30% de durada i +15% de dany per rang.', [{ ab: 'tempesta_neu', dur: 0.3, dmg: 0.15 }]),
      N('g_b3', 3, 'Allau', '🌊', 1, 'Aprens una habilitat nova: una onada de neu que travessa.', [{ unlock: 'allau' }]),
      N('g_b4', 4, 'Hivern profund', '💢', 3, '+5% de poder per rang.', [st('poder', { pct: 0.05 })]),
      N('g_b5', 5, 'Hivern sense fi', '🏔️', 1, 'Hivern Etern: l\'aura és un 50% més gran i congela els enemics cada 3 s.', [{ special: 'deepwinter' }]),
    ] },
    { id: 'cristall', name: 'Cristall', icon: '🛡️', desc: 'Defensa impenetrable.', nodes: [
      N('g_c1', 1, 'Cos de gel', '🧍', 3, '+6% de vida màxima per rang.', [st('maxHp', { pct: 0.06 })]),
      N('g_c2', 2, 'Cristall reforçat', '🛡️', 2, 'Escut de Cristall: +30% d\'absorció i +15% de dany retornat per rang.', [{ ab: 'escut_cristall', amount: 0.3, reflect: 0.15 }]),
      N('g_c3', 3, 'Pas Glaçat', '👣', 1, 'Aprens una habilitat nova: teletransport que glaça on arribes.', [{ unlock: 'pas_glacat' }]),
      N('g_c4', 4, 'Pell de gebre', '🧥', 3, '+8% de defensa per rang.', [st('def', { pct: 0.08 })]),
      N('g_c5', 5, 'Cos de diamant', '💠', 1, 'Mentre tens un escut, reps un 30% menys de dany i no et poden atordir.', [{ special: 'diamond' }]),
    ] },
  ],
  llamp: [
    { id: 'cadenes', name: 'Cadenes', icon: '⚡', desc: 'Llamps que salten.', nodes: [
      N('l_a1', 1, 'Alta tensió', '⚡', 3, '+7% de dany de llamp per rang.', [el('llamp', 0.07)]),
      N('l_a2', 2, 'Conductor', '🔗', 2, 'Cadena de Llamps salta a 2 enemics més i Guspira a 1 més per rang.', [{ ab: 'cadena_llamps', chain: 2 }, { ab: 'guspira', chain: 1 }]),
      N('l_a3', 3, 'Bola de Plasma', '🔮', 1, 'Aprens una habilitat nova: una esfera lenta que electrocuta tot el que travessa.', [{ unlock: 'bola_plasma' }]),
      N('l_a4', 4, 'Precisió', '🎯', 3, '+3% de probabilitat de crític per rang.', [st('crit', { add: 3 })]),
      N('l_a5', 5, 'Arc voltaic', '🌀', 1, 'Els cops crítics llancen un llamp a un altre enemic proper (50% del dany).', [{ special: 'arc' }]),
    ] },
    { id: 'cel', name: 'Cel irat', icon: '🌩️', desc: 'El cel com a arma.', nodes: [
      N('l_b1', 1, 'Camp magnètic', '🧲', 3, '+8% d\'àrea de totes les habilitats per rang.', [{ area: 0.08 }]),
      N('l_b2', 2, 'Cel irat', '🌩️', 2, 'Llamp Celestial: +1 impacte i +12% de dany per rang.', [{ ab: 'llamp_celestial', hits: 1, dmg: 0.12 }]),
      N('l_b3', 3, 'Tempesta Elèctrica', '⛈️', 1, 'Aprens una habilitat nova: un núvol de llamps sobre la zona.', [{ unlock: 'tempesta_electrica' }]),
      N('l_b4', 4, 'Sobretensió', '💢', 3, '+5% de poder per rang.', [st('poder', { pct: 0.05 })]),
      N('l_b5', 5, 'Ira del cel', '👑', 1, 'Senyor de la Tempesta: els llamps cauen el doble de sovint i fan +50% de dany.', [{ special: 'wrath' }]),
    ] },
    { id: 'velocitat', name: 'Velocitat', icon: '💨', desc: 'Moure\'s i reaccionar.', nodes: [
      N('l_c1', 1, 'Peus lleugers', '🥾', 3, '+4% de velocitat de moviment per rang.', [st('speed', { pct: 0.04 })]),
      N('l_c2', 2, 'Pas llampec', '🌀', 2, 'Pas de Tempesta: −20% de recàrrega i +20% de distància per rang.', [{ ab: 'pas_tempesta', cd: -0.2, dist: 0.2 }]),
      N('l_c3', 3, 'Descàrrega', '💫', 1, 'Aprens una habilitat nova: una descàrrega que atordeix els propers.', [{ unlock: 'descarrega' }]),
      N('l_c4', 4, 'Ment ràpida', '🧠', 3, '−3% de recàrrega de totes les habilitats per rang.', [st('cdr', { add: 3 })]),
      N('l_c5', 5, 'Esquiva elèctrica', '⚡', 1, 'Quan esquives alliberes una descàrrega que atordeix els enemics propers.', [{ special: 'dodgeshock' }]),
    ] },
  ],
  guerrer: [
    { id: 'fulla', name: 'Fulla', icon: '⚔️', desc: 'Mestre de l\'espasa.', nodes: [
      N('w_a1', 1, 'Tall afilat', '⚔️', 3, '+8% de dany físic per rang.', [el('fisic', 0.08)]),
      N('w_a2', 2, 'Combo letal', '🥷', 2, 'Tall: +12% de dany i +10% d\'abast per rang.', [{ ab: 'tall', dmg: 0.12, range: 0.1 }]),
      N('w_a3', 3, 'Estocada', '🗡️', 1, 'Aprens una habilitat nova: un embat ràpid que travessa.', [{ unlock: 'estocada' }]),
      N('w_a4', 4, 'Punt feble', '🎯', 3, '+4% de probabilitat de crític per rang.', [st('crit', { add: 4 })]),
      N('w_a5', 5, 'Set de sang', '🩸', 1, 'Et cures el 6% de tot el dany que fas.', [{ special: 'bloodlust' }]),
    ] },
    { id: 'furia', name: 'Fúria', icon: '💢', desc: 'Força bruta i cops demolidors.', nodes: [
      N('w_b1', 1, 'Força bruta', '💪', 3, '+6% de força per rang.', [st('poder', { pct: 0.06 })]),
      N('w_b2', 2, 'Demolidor', '🔨', 2, 'Cop Demolidor: +15% de dany i +15% d\'abast per rang.', [{ ab: 'cop_demolidor', dmg: 0.15, range: 0.15 }]),
      N('w_b3', 3, 'Execució', '💀', 1, 'Aprens una habilitat nova: un cop que fa el doble de mal als enemics ferits.', [{ unlock: 'execucio' }]),
      N('w_b4', 4, 'Frenesí', '🌪️', 3, 'Tall: +8% de velocitat d\'atac per rang.', [{ ab: 'tall', speed: 0.08 }]),
      N('w_b5', 5, 'Tità colèric', '🗿', 1, 'Forma Titànica: multiplica les estadístiques ×1,75 en lloc de ×1,5 i dura 5 s més.', [{ special: 'titanrage' }, { ab: 'titan', durAdd: 5 }]),
    ] },
    { id: 'baluard', name: 'Baluard', icon: '🛡️', desc: 'La primera línia.', nodes: [
      N('w_c1', 1, 'Robustesa', '💪', 3, '+7% de vida màxima per rang.', [st('maxHp', { pct: 0.07 })]),
      N('w_c2', 2, 'Mur d\'escut', '🛡️', 2, 'Crit de Guerra: redueix un 8% més de dany i cura un 5% més per rang.', [{ ab: 'crit_guerra', amountAdd: 0.08, healAdd: 0.05 }]),
      N('w_c3', 3, 'Escomesa de Terra', '🪨', 1, 'Aprens una habilitat nova: un cop a terra que atordeix.', [{ unlock: 'escomesa' }]),
      N('w_c4', 4, 'Armadura viva', '🧱', 3, '+8% de defensa per rang.', [st('def', { pct: 0.08 })]),
      N('w_c5', 5, 'Inamovible', '🏰', 1, 'Bloquejant només reps el 15% del dany i en retornes un 30% a l\'atacant.', [{ special: 'bulwark' }]),
    ] },
  ],
};

const NODE = {};
for (const [cls, trees] of Object.entries(SKILL_TREES)) for (const t of trees) for (const n of t.nodes) NODE[n.id] = { ...n, cls, branch: t.id };
export function skillNode(id) { return NODE[id] || null; }

// punts d'habilitat: 1 per nivell a partir del 2
export function skillPointsTotal(level) { return Math.max(0, (level | 0) - 1); }
export function skillSpent(skills) { let n = 0; for (const v of Object.values(skills || {})) n += v | 0; return n; }
export function branchSpent(skills, cls, branch) {
  let n = 0;
  for (const [id, r] of Object.entries(skills || {})) { const nd = NODE[id]; if (nd && nd.cls === cls && nd.branch === branch) n += r | 0; }
  return n;
}
// pot aprendre (o pujar de rang) un node?  Torna null si sí, o el motiu si no
export function canLearn(save, id) {
  const nd = NODE[id];
  if (!nd || nd.cls !== save.cls) return 'No és de la teva classe';
  const cur = (save.skills && save.skills[id]) | 0;
  if (cur >= nd.max) return 'Ja està al màxim';
  if (skillSpent(save.skills) >= skillPointsTotal(save.level)) return 'No tens punts d\'habilitat';
  if (save.level < TIER_LVL[nd.tier]) return `Cal nivell ${TIER_LVL[nd.tier]}`;
  if (branchSpent(save.skills, nd.cls, nd.branch) < TIER_PTS[nd.tier]) return `Cal tenir ${TIER_PTS[nd.tier]} punts en aquesta branca`;
  return null;
}
// neteja un conjunt de rangs: només nodes vàlids i coherents amb el nivell
export function sanitizeSkills(skills, cls, level) {
  const out = {};
  if (!skills || typeof skills !== 'object') return out;
  const trees = SKILL_TREES[cls] || [];
  let budget = skillPointsTotal(level);
  // per tier, perquè els requisits de punts a la branca es compleixin
  for (let tier = 1; tier <= 5; tier++) {
    for (const t of trees) for (const n of t.nodes) {
      if (n.tier !== tier) continue;
      const want = Math.max(0, Math.min(n.max, skills[n.id] | 0));
      if (!want || level < TIER_LVL[tier]) continue;
      if (branchSpent(out, cls, t.id) < TIER_PTS[tier]) continue;
      const r = Math.min(want, budget);
      if (r > 0) { out[n.id] = r; budget -= r; }
    }
  }
  return out;
}

export const EMPTY_EFF = { el: {}, area: 0, stats: {}, ab: {}, status: {}, unlocks: [], sp: new Set() };
// suma tots els efectes dels nodes apresos
export function skillEffects(skills, cls) {
  const E = { el: {}, area: 0, stats: {}, ab: {}, status: {}, unlocks: [], sp: new Set() };
  for (const [id, rank] of Object.entries(skills || {})) {
    const nd = NODE[id]; const r = rank | 0;
    if (!nd || !r || (cls && nd.cls !== cls)) continue;
    for (const e of nd.eff) {
      if (e.el) E.el[e.el] = (E.el[e.el] || 0) + e.dmg * r;
      else if (e.area) E.area += e.area * r;
      else if (e.stat) { const s = E.stats[e.stat] || (E.stats[e.stat] = { add: 0, pct: 0 }); s.add += (e.add || 0) * r; s.pct += (e.pct || 0) * r; }
      else if (e.ab) { const a = E.ab[e.ab] || (E.ab[e.ab] = {}); for (const [k, v] of Object.entries(e)) if (k !== 'ab') a[k] = (a[k] || 0) + v * r; }
      else if (e.status) { const s = E.status[e.status] || (E.status[e.status] = {}); for (const [k, v] of Object.entries(e)) if (k !== 'status') s[k] = (s[k] || 0) + v * r; }
      else if (e.unlock) E.unlocks.push(e.unlock);
      else if (e.special) E.sp.add(e.special);
    }
  }
  return E;
}

// aplica els efectes de les branques a una còpia d'una habilitat
export function applySkillMods(ab, key, E) {
  if (!ab || !E) return ab;
  const a = { ...ab };
  if (a.combo) a.combo = a.combo.map((c) => ({ ...c }));
  const mulDmg = (k) => { if (a.dmg) a.dmg = Math.round(a.dmg * k); if (a.combo) a.combo.forEach((c) => { c.dmg = Math.round(c.dmg * k); }); };
  // dany per element
  const eb = E.el[a.el] || 0;
  if (eb) mulDmg(1 + eb);
  // àrea
  if (E.area && a.kind !== 'buff' && a.kind !== 'transform') {
    for (const k of ['explode', 'chainRange', 'width']) if (a[k]) a[k] = +(a[k] * (1 + E.area)).toFixed(2);
    if (a.radius && a.kind !== 'projectile') a.radius = +(a.radius * (1 + E.area)).toFixed(2);
    if (a.kind === 'projectile' && a.fx === 'wave') a.radius = +(a.radius * (1 + E.area)).toFixed(2);
    if (a.combo) a.combo.forEach((c) => { c.range *= 1 + E.area * 0.5; });
  }
  // estats
  if (a.status) {
    const s = {};
    for (const [k, v] of Object.entries(a.status)) s[k] = typeof v === 'object' ? { ...v } : v;
    const m = E.status;
    if (s.burn && m.burn) { s.burn.dps = +(s.burn.dps * (1 + (m.burn.dps || 0))).toFixed(1); s.burn.dur += m.burn.dur || 0; }
    if (s.slow && m.slow) { s.slow.amt = Math.min(0.85, s.slow.amt + (m.slow.amt || 0)); s.slow.dur += m.slow.dur || 0; }
    if (s.freeze && m.freeze) s.freeze.dur += m.freeze.dur || 0;
    a.status = s;
  }
  // millores pròpies d'aquesta habilitat
  const m = E.ab[key];
  if (m) {
    if (m.dmg) mulDmg(1 + m.dmg);
    if (m.radius && a.radius) a.radius = +(a.radius * (1 + m.radius)).toFixed(2);
    if (m.cd) a.cd = +(a.cd * Math.max(0.3, 1 + m.cd)).toFixed(2);
    if (m.dur && a.dur) a.dur = +(a.dur * (1 + m.dur)).toFixed(1);
    if (m.durAdd && a.dur) a.dur = +(a.dur + m.durAdd).toFixed(1);
    if (m.dist && a.dist) a.dist = +(a.dist * (1 + m.dist)).toFixed(1);
    if (m.hits) { a.hits = (a.hits || 1) + m.hits; if (!a.interval) a.interval = 0.3; }
    if (m.chain) a.chain = (a.chain || 0) + m.chain;
    if (m.amount && a.amount) a.amount = Math.round(a.amount * (1 + m.amount));
    if (m.amountAdd && a.amount) a.amount = +(a.amount + m.amountAdd).toFixed(2);
    if (m.healAdd) a.heal = +((a.heal || 0) + m.healAdd).toFixed(2);
    if (m.reflect) a.reflect = +((a.reflect || 0) + m.reflect).toFixed(2);
    if (m.range && a.combo) a.combo.forEach((c) => { c.range *= 1 + m.range; });
    if (m.speed && a.combo) a.combo.forEach((c) => { c.time /= 1 + m.speed; c.animSpeed = (c.animSpeed || 1) * (1 + m.speed); c.release /= 1 + m.speed; });
  }
  return a;
}
