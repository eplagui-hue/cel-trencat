// ============================================================
//  Guia de l'objectiu: on s'ha d'anar per avançar en la història
//  (també funciona per a les recompenses del Capità Bru)
// ============================================================
import { CAMPS, CHESTS, LAUNCHPADS, ISLAND, ISLANDS, STRUCTURES } from './worldgen.js';
import { STORY, NPCS, BOUNTIES } from './data.js';

const npc = (id) => NPCS.find((n) => n.id === id);

// illa on és un punt (null = terra ferma)
export function islandAt(x, z, y = 999) {
  for (const is of ISLANDS) if (Math.hypot(x - is.x, z - is.z) < is.r + 3 && y > is.top - 8) return is.id;
  return null;
}

// següent plataforma de vent per anar d'un node a un altre (BFS sobre les illes)
function nextPad(from, to, storyIdx) {
  if (from === to) return null;
  const edges = (node) => LAUNCHPADS.filter((lp) => (node === null ? !lp.island : lp.island === node) && !(lp.need && storyIdx < lp.need));
  const q = [[from, null]]; const seen = new Set([String(from)]);
  while (q.length) {
    const [node, first] = q.shift();
    for (const lp of edges(node)) {
      if (seen.has(lp.to)) continue;
      seen.add(lp.to);
      const f = first || lp;
      if (lp.to === to) return f;
      q.push([lp.to, f]);
    }
  }
  return null;
}

const matches = (pattern, type) => pattern === type || (pattern.endsWith('*') && type.startsWith(pattern.slice(0, -1)));

function nearestCamp(pattern, pos, level, boss) {
  let best = null, bd = 1e9;
  for (const c of CAMPS) {
    if (!c.list.some(([t]) => (pattern === 'boss' ? c.boss : matches(pattern, t)))) continue;
    if (boss && !c.boss) continue;
    let d = Math.hypot(c.x - pos.x, c.z - pos.z);
    if (c.lvl > level + 3) d += 400; // millor un camp adequat al nivell
    if (c.island) d += 150;
    if (d < bd) { bd = d; best = c; }
  }
  return best;
}

// objectiu d'un tipus de missió
function targetFor(o, save, pos) {
  if (o.type === 'kill' || o.type === 'boss') {
    const c = nearestCamp(o.enemy, pos, save.level, o.type === 'boss');
    if (!c) return null;
    const st = c.structure && STRUCTURES.find((s) => s.id === c.structure);
    // si el cap és dins d'una fortalesa, primer la porta
    if (st && o.type === 'boss' && Math.hypot(pos.x - st.x, pos.z - st.z) > st.reach) return { x: st.gate.x, z: st.gate.z, island: null, where: st.name };
    return { x: c.x, z: c.z, island: c.island || null, where: st ? st.name : null };
  }
  if (o.type === 'collect' && o.item === 'cristall') {
    let best = null, bd = 1e9;
    for (const ch of CHESTS) {
      if (ch.quest !== 'cristall' || (save.flags && save.flags['cristall_' + ch.id])) continue;
      const d = Math.hypot(ch.x - pos.x, ch.z - pos.z); if (d < bd) { bd = d; best = ch; }
    }
    return best ? { x: best.x, z: best.z, island: best.island || null } : null;
  }
  if (o.type === 'activate') { const lp = LAUNCHPADS.find((l) => l.id === o.what); return lp ? { x: lp.x, z: lp.z, island: null } : null; }
  return null;
}

// Retorna { x, z, island, text, kind } o null
export function questTarget(save, pos) {
  if (!save) return null;
  const s = save.story; const ch = STORY[s.idx];
  let tgt = null, text = '';
  if (ch) {
    const done = ch.objectives.every((o, i) => (s.progress[i] || 0) >= o.n);
    if (!s.accepted || done) {
      const n = npc(ch.giver || 'elna');
      tgt = { x: n.x, z: n.z, island: null }; text = s.accepted ? `Torna a parlar amb ${n.name}` : `Parla amb ${n.name}`;
    } else {
      const i = ch.objectives.findIndex((o, k) => (s.progress[k] || 0) < o.n);
      const o = ch.objectives[i];
      tgt = targetFor(o, save, pos);
      text = o.text + (o.n > 1 ? ` (${s.progress[i] || 0}/${o.n})` : '');
      if (tgt && tgt.where && !o.text.includes(tgt.where)) text += ` · ${tgt.where}`;
    }
  } else if (save.bounty) {
    const b = BOUNTIES.find((x) => x.id === save.bounty.id);
    if (b) {
      if (save.bounty.progress >= b.obj.n) { const n = npc('bru'); tgt = { x: n.x, z: n.z, island: null }; text = 'Cobra la recompensa del Capità Bru'; }
      else { tgt = targetFor(b.obj, save, pos); text = b.obj.text; }
    }
  }
  if (!tgt) return null;
  // ruta per les illes del cel
  const here = islandAt(pos.x, pos.z, pos.y);
  if (tgt.island !== here) {
    if (tgt.island) {
      const pad = nextPad(here, tgt.island, s.idx);
      if (pad) return { x: pad.x, z: pad.z, island: pad.island || null, text, via: pad.id === 'pedra_vent' ? 'Pedra de Vent' : 'corrent de vent', final: tgt };
    } else if (here) {
      return { ...tgt, text, via: 'baixa de les illes', final: tgt };
    }
  }
  return { ...tgt, text, final: tgt };
}
