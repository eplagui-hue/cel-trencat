// ============================================================
//  El món 3D: terreny, aigua, cel, vegetació, edificis, illes
// ============================================================
import * as THREE from 'three';
import { mergeGeometries as mergeGeos } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  WORLD, ZONES, ZONE, ISLANDS, ISLAND, LAUNCHPADS, WAYSTONES, CHESTS, BOSS_ARENAS,
  height, groundAt, islandTop, zoneAt, getWorld, fbm, roadDist, smooth, mulberry32, hash2,
} from './worldgen.js';
import { NPCS } from './data.js';
import { getLevel, platformState } from './parkour.js';
import { STRUCTURE_DEFS } from './structures.js';
import { Assets, toonGradient, toonify, model, cloneSkinned, fitHeight, addOutline } from './assets.js';

export const UNI = { uTime: { value: 0 }, uWind: { value: 1 } };

// ---------- shaders helpers ----------
function addWind(mat, strength = 0.06, mode = 'tree') {
  const prev = mat.onBeforeCompile;
  mat.onBeforeCompile = (sh, r) => {
    if (prev) prev(sh, r);
    sh.uniforms.uTime = UNI.uTime; sh.uniforms.uWind = UNI.uWind;
    sh.vertexShader = 'uniform float uTime;\nuniform float uWind;\n' + sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      {
        vec4 wpos = vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          wpos = instanceMatrix * wpos;
        #endif
        wpos = modelMatrix * wpos;
        float hh = max(0.0, transformed.y);
        float ph = wpos.x * 0.11 + wpos.z * 0.13;
        float w = sin(uTime * 1.3 + ph) * 0.6 + sin(uTime * 2.9 + ph * 2.7) * 0.25 + sin(uTime*5.1 + wpos.y*0.8 + ph*4.0) * 0.12;
        ${mode === 'grass' ? 'float k = hh * hh;' : 'float k = hh * hh * 0.012;'}
        transformed.x += w * k * ${strength.toFixed(3)} * uWind;
        transformed.z += w * k * ${(strength * 0.7).toFixed(3)} * uWind;
      }`);
  };
  mat.customProgramCacheKey = () => 'wind' + mode + strength;
  return mat;
}

const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

// colors del terreny
const C = (r, g, b) => new THREE.Color().setRGB(r, g, b, THREE.SRGBColorSpace);
const COL = {
  grass: C(0.42, 0.70, 0.27), grassDark: C(0.26, 0.52, 0.20), forest: C(0.25, 0.53, 0.22), meadow: C(0.55, 0.76, 0.30),
  dirt: C(0.62, 0.49, 0.32), road: C(0.72, 0.60, 0.42), sand: C(0.92, 0.84, 0.62), rock: C(0.52, 0.50, 0.47), snow: C(0.95, 0.97, 1.0),
  ash: C(0.40, 0.25, 0.20), ember: C(0.70, 0.30, 0.15), ruin: C(0.70, 0.66, 0.46), seabed: C(0.36, 0.55, 0.52), cliff: C(0.46, 0.42, 0.38),
};
function terrainColor(x, z, h, slope, out) {
  const n = fbm(x * 0.05, z * 0.05, 2);
  const n2 = fbm(x * 0.013 + 9, z * 0.013, 2);
  out.copy(COL.grass).lerp(COL.meadow, smooth(-0.2, 0.5, n2));
  out.lerp(COL.grassDark, smooth(0.1, 0.6, n) * 0.5);
  const zb = ZONE.bosc, zc = ZONE.cremades, zr = ZONE.ruines;
  const wb = 1 - smooth(zb.r * 0.5, zb.r * 1.05, Math.hypot(x - zb.x, z - zb.z));
  const wc = 1 - smooth(zc.r * 0.45, zc.r * 1.0, Math.hypot(x - zc.x, z - zc.z));
  const wr = 1 - smooth(zr.r * 0.45, zr.r * 1.0, Math.hypot(x - zr.x, z - zr.z));
  if (wb > 0) out.lerp(COL.forest, wb * 0.75);
  if (wr > 0) out.lerp(COL.ruin, wr * (0.45 + 0.3 * smooth(-0.3, 0.6, n)));
  if (wc > 0) { tmpC.copy(COL.ash).lerp(COL.ember, smooth(0.2, 0.7, Math.abs(fbm(x * 0.06, z * 0.06, 2)) * 2)); out.lerp(tmpC, wc * 0.9); }
  const rd = roadDist(x, z);
  if (rd < 4.5) out.lerp(COL.road, (1 - smooth(2, 4.5, rd)) * 0.85);
  if (Math.hypot(x, z) < 26) out.lerp(COL.road, (1 - smooth(14, 26, Math.hypot(x, z))) * 0.55);
  for (const a of BOSS_ARENAS) { const d = Math.hypot(x - a.x, z - a.z); if (d < a.r) out.lerp(COL.dirt, (1 - smooth(a.r * 0.6, a.r, d)) * 0.6); }
  if (h < 2.2) out.lerp(COL.sand, 1 - smooth(0.6, 2.2, h));
  if (h < -0.4) out.lerp(COL.seabed, smooth(-0.4, -4, h));
  if (slope > 0.55) out.lerp(COL.cliff, smooth(0.55, 0.95, slope));
  if (h > 30) out.lerp(COL.rock, smooth(30, 42, h));
  if (h > 52) out.lerp(COL.snow, smooth(52, 60, h));
  out.multiplyScalar(0.92 + n * 0.12);
  return out;
}
const tmpC = new THREE.Color();

export class World {
  constructor(renderer, scene, quality) {
    this.renderer = renderer;
    this.scene = scene;
    this.quality = quality || { trees: 1, grass: 1, shadows: true, detail: 1 };
    this.root = new THREE.Group();
    scene.add(this.root);
    this.chunks = [];
    this.lods = [];
    this.interactables = [];
    this.animated = [];
    this.mixers = [];
    this.npcs = {};
    this.chests = {};
    this.flames = [];
    this.timeOfDay = 0.36;
    this.wg = getWorld();
  }

  async build(progress) {
    const step = async (label, f, p) => { progress && progress(p, label); await new Promise((r) => setTimeout(r, 0)); f(); };
    await step('Aixecant muntanyes', () => this.buildTerrain(), 0.1);
    await step('Omplint el mar', () => this.buildWater(), 0.2);
    await step('Pintant el cel', () => this.buildSky(), 0.28);
    await step('Fent surar les illes', () => this.buildIslands(), 0.36);
    await step('Plantant el bosc', () => this.buildVegetation(), 0.55);
    await step('Construint la vila', () => this.buildProps(), 0.7);
    await step('Fent créixer l\'herba', () => this.buildGrass(), 0.8);
    await step('Despertant la gent', () => this.buildNPCs(), 0.88);
    await step('Encenent la llum', () => this.buildLights(), 0.94);
    await step('Dibuixant el mapa', () => this.buildMinimap(), 1);
  }

  // ------------------------------------------------------------------ terreny
  buildTerrain() {
    const S = 680, N = this.quality.detail > 0.7 ? 230 : 170;
    const geo = new THREE.PlaneGeometry(S, S, N, N);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const cols = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    const hs = new Float32Array(pos.count);
    for (let i = 0; i < pos.count; i++) { const x = pos.getX(i), z = pos.getZ(i); hs[i] = height(x, z); pos.setY(i, hs[i]); }
    const st = S / N;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const hx = height(x + st, z) - height(x - st, z), hz = height(x, z + st) - height(x, z - st);
      const slope = Math.min(1, Math.hypot(hx, hz) / (2 * st));
      terrainColor(x, z, hs[i], slope, c);
      cols[i * 3] = c.r; cols[i * 3 + 1] = c.g; cols[i * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: toonGradient() });
    // textura de soroll subtil (pinzellada)
    mat.onBeforeCompile = (sh) => {
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWPos;').replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWPos = (modelMatrix * vec4(transformed,1.0)).xyz;');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
        varying vec3 vWPos;
        float hsh(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453); }
        float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(hsh(i),hsh(i+vec2(1,0)),f.x), mix(hsh(i+vec2(0,1)),hsh(i+vec2(1,1)),f.x), f.y); }`)
        .replace('#include <color_fragment>', `#include <color_fragment>
        float nn = vn(vWPos.xz * 0.9) * 0.5 + vn(vWPos.xz * 0.23) * 0.5;
        diffuseColor.rgb *= 0.9 + nn * 0.18;`);
    };
    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    mesh.name = 'terreny';
    this.root.add(mesh);
    this.terrain = mesh;
    // textura d'alçades per a l'aigua (vores amb escuma)
    const HN = 256, HS = 700;
    const data = new Uint8Array(HN * HN * 4);
    for (let j = 0; j < HN; j++) for (let i = 0; i < HN; i++) {
      const x = (i / (HN - 1) - 0.5) * HS, z = (j / (HN - 1) - 0.5) * HS;
      const h = height(x, z);
      const v = Math.max(0, Math.min(255, Math.round((h + 12) / 30 * 255)));
      data[(j * HN + i) * 4] = v; data[(j * HN + i) * 4 + 3] = 255;
    }
    this.heightTex = new THREE.DataTexture(data, HN, HN, THREE.RGBAFormat);
    this.heightTex.magFilter = THREE.LinearFilter; this.heightTex.minFilter = THREE.LinearFilter; this.heightTex.needsUpdate = true;
    this.heightTexSize = HS;
  }

  buildWater() {
    const geo = new THREE.PlaneGeometry(3000, 3000, 160, 160);
    geo.rotateX(-Math.PI / 2);
    this.waterUni = { uTime: UNI.uTime, uHeight: { value: this.heightTex }, uSize: { value: this.heightTexSize }, uSun: { value: new THREE.Vector3(0.4, 0.8, 0.3) },
      uDeep: { value: new THREE.Color('#1b6fa8') }, uShallow: { value: new THREE.Color('#3fd0d6') }, uFoam: { value: new THREE.Color('#ffffff') },
      uFogColor: { value: new THREE.Color() }, uFogNear: { value: 100 }, uFogFar: { value: 600 }, uSky: { value: new THREE.Color('#bfe8ff') }, uNight: { value: 0 } };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.waterUni, transparent: true, depthWrite: false,
      vertexShader: `uniform float uTime; varying vec3 vW; varying float vH;
        void main(){ vec3 p = position; vec4 w = modelMatrix * vec4(p,1.0);
          float wave = sin(w.x*0.08 + uTime*1.1)*0.25 + sin(w.z*0.11 - uTime*0.9)*0.2 + sin((w.x+w.z)*0.3 + uTime*2.0)*0.06;
          w.y += wave; vH = wave; vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: `uniform sampler2D uHeight; uniform float uSize; uniform float uTime; uniform vec3 uDeep, uShallow, uFoam, uFogColor, uSky, uSun; uniform float uFogNear, uFogFar, uNight;
        varying vec3 vW; varying float vH;
        float hsh(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453); }
        float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(hsh(i),hsh(i+vec2(1,0)),f.x), mix(hsh(i+vec2(0,1)),hsh(i+vec2(1,1)),f.x), f.y); }
        void main(){
          vec2 uv = vW.xz / uSize + 0.5;
          float th = (texture2D(uHeight, uv).r * 30.0) - 12.0;
          if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) th = -12.0;
          float depth = clamp(-th, 0.0, 12.0);
          vec3 col = mix(uShallow, uDeep, smoothstep(0.3, 7.0, depth));
          float n = vn(vW.xz*0.35 + vec2(uTime*0.25, uTime*0.1)) * 0.6 + vn(vW.xz*0.9 - vec2(uTime*0.3, 0.0))*0.4;
          float foamLine = smoothstep(1.4, 0.0, depth + n*0.6 - 0.2 + sin(uTime*1.6 + depth*3.0)*0.15);
          float caustic = smoothstep(0.62, 0.9, n) * (1.0 - smoothstep(0.0, 6.0, depth));
          col += caustic * 0.18;
          col = mix(col, uFoam, foamLine * 0.85);
          vec3 V = normalize(cameraPosition - vW);
          float fres = pow(1.0 - max(V.y, 0.0), 3.0);
          col = mix(col, uSky, fres * 0.55);
          vec3 N = normalize(vec3(-vH*0.4 + (n-0.5)*0.3, 1.0, (n-0.5)*0.3));
          vec3 H = normalize(normalize(uSun) + V);
          float spec = pow(max(dot(N, H), 0.0), 120.0) * 1.4 * (1.0 - uNight);
          col += spec;
          float alpha = mix(0.55, 0.92, smoothstep(0.0, 3.0, depth)) ;
          alpha = max(alpha, foamLine);
          float d = length(cameraPosition - vW);
          float f = smoothstep(uFogNear, uFogFar, d);
          col = mix(col, uFogColor, f);
          gl_FragColor = vec4(col, alpha);
          #include <colorspace_fragment>
        }`,
    });
    const water = new THREE.Mesh(geo, mat);
    water.position.y = WORLD.water;
    water.renderOrder = 2;
    water.name = 'aigua';
    this.root.add(water);
    this.water = water;
  }

  buildSky() {
    this.skyUni = { uTop: { value: new THREE.Color('#5fb4ff') }, uMid: { value: new THREE.Color('#bfe8ff') }, uBottom: { value: new THREE.Color('#f6f0dc') },
      uSunDir: { value: new THREE.Vector3(0.3, 0.6, -0.5) }, uSunCol: { value: new THREE.Color('#fff4d6') }, uNight: { value: 0 }, uTime: UNI.uTime };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.skyUni, side: THREE.BackSide, depthWrite: false, fog: false,
      vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }',
      fragmentShader: `uniform vec3 uTop, uMid, uBottom, uSunDir, uSunCol; uniform float uNight, uTime; varying vec3 vDir;
        float hsh(vec3 p){ return fract(sin(dot(p, vec3(127.1,311.7,74.7))) * 43758.5453); }
        void main(){
          float y = vDir.y;
          vec3 col = mix(uMid, uTop, smoothstep(0.02, 0.55, y));
          col = mix(uBottom, col, smoothstep(-0.25, 0.08, y));
          vec3 sd = normalize(uSunDir);
          float s = max(dot(normalize(vDir), sd), 0.0);
          col += uSunCol * (pow(s, 900.0) * 6.0 + pow(s, 24.0) * 0.35 + pow(s, 4.0) * 0.12) * (1.0 - uNight*0.6);
          // lluna
          float m = max(dot(normalize(vDir), -sd), 0.0);
          col += vec3(0.75,0.82,1.0) * (pow(m, 1500.0) * 3.0 + pow(m, 40.0) * 0.15) * uNight;
          // estels
          vec3 g = floor(vDir * 220.0);
          float st = step(0.9965, hsh(g)) * smoothstep(0.0, 0.25, y) * uNight;
          col += st * (0.6 + 0.4*sin(uTime*3.0 + hsh(g)*30.0));
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(1400, 32, 16), mat);
    sky.renderOrder = -10; sky.frustumCulled = false;
    this.scene.add(sky);
    this.sky = sky;
    // núvols
    this.clouds = new THREE.Group();
    const cm = new THREE.MeshToonMaterial({ color: '#ffffff', gradientMap: toonGradient(), transparent: true, opacity: 0.92 });
    const r = mulberry32(77);
    for (let i = 0; i < 42; i++) {
      const tpl = model(r() < 0.5 ? 'v:cloud_big' : 'v:cloud_small');
      if (!tpl) break;
      const c = tpl.clone();
      c.traverse((o) => { if (o.isMesh) { o.material = cm; o.castShadow = false; o.receiveShadow = false; } });
      const a = r() * Math.PI * 2, d = 80 + r() * 520;
      const low = i < 10;
      c.position.set(Math.cos(a) * d, low ? 20 + r() * 25 : 110 + r() * 80, Math.sin(a) * d + (low ? 260 : 0));
      if (low) c.position.x = (r() - 0.5) * 240;
      c.scale.setScalar(10 + r() * 14);
      c.rotation.y = r() * 6.28;
      c.userData.speed = 0.6 + r() * 1.2;
      this.clouds.add(c);
    }
    this.scene.add(this.clouds);
  }

  // ------------------------------------------------------------------ illes flotants
  buildIslands() {
    this.islandMeshes = [];
    for (const is of ISLANDS) {
      const g = new THREE.Group();
      const R = is.r;
      const rings = 10, seg = 56;
      const verts = [], cols = [], idx = [];
      const top = new THREE.Color(is.id === 'arena' ? '#8c8aa0' : is.volcanic ? '#4a3a36' : '#6fbf4a'), edge = new THREE.Color('#7a5a3a'), rock = new THREE.Color('#6d6a74'), deep = new THREE.Color('#3a3346');
      const rr = mulberry32(is.x * 13 + is.z);
      // part superior
      verts.push(is.x, islandTop(is, is.x, is.z), is.z); cols.push(top.r, top.g, top.b);
      for (let ri = 1; ri <= rings; ri++) {
        const rad = R * ri / rings;
        for (let s = 0; s < seg; s++) {
          const a = s / seg * Math.PI * 2;
          const wob = ri === rings ? 1 + fbm(Math.cos(a) * 2 + is.x, Math.sin(a) * 2, 2) * 0.12 : 1;
          const x = is.x + Math.cos(a) * rad * wob, z = is.z + Math.sin(a) * rad * wob;
          const y = ri === rings ? is.top - 0.2 : islandTop(is, x, z);
          verts.push(x, y, z);
          const cc = top.clone().lerp(edge, ri === rings ? 0.6 : 0).multiplyScalar(0.92 + rr() * 0.12);
          cols.push(cc.r, cc.g, cc.b);
        }
      }
      for (let s = 0; s < seg; s++) idx.push(0, 1 + ((s + 1) % seg), 1 + s);
      for (let ri = 1; ri < rings; ri++) for (let s = 0; s < seg; s++) {
        const a = 1 + (ri - 1) * seg + s, b = 1 + (ri - 1) * seg + (s + 1) % seg, c2 = 1 + ri * seg + s, d = 1 + ri * seg + (s + 1) % seg;
        idx.push(a, b, c2, b, d, c2);
      }
      // part inferior (con rocós)
      const lev = 9; const base0 = 1 + (rings - 1) * seg;
      const depth = R * (is.flat ? 1.1 : 1.6);
      let prevStart = base0;
      for (let l = 1; l <= lev; l++) {
        const k = l / lev; const start = verts.length / 3;
        for (let s = 0; s < seg; s++) {
          const a = s / seg * Math.PI * 2;
          const n = fbm(Math.cos(a) * 1.7 + l * 0.4 + is.z, Math.sin(a) * 1.7 + is.x, 3);
          const rad = R * (1 - Math.pow(k, 0.85) * 0.92) * (1 + n * 0.28) * (l === lev ? 0.05 : 1);
          const y = is.top - 0.6 - Math.pow(k, 1.25) * depth * (1 + n * 0.2);
          verts.push(is.x + Math.cos(a) * rad, y, is.z + Math.sin(a) * rad);
          const cc = edge.clone().lerp(rock, smooth(0, 0.3, k)).lerp(deep, smooth(0.4, 1, k)).multiplyScalar(0.85 + rr() * 0.25);
          cols.push(cc.r, cc.g, cc.b);
        }
        for (let s = 0; s < seg; s++) {
          const a = prevStart + s, b = prevStart + (s + 1) % seg, c2 = start + s, d = start + (s + 1) % seg;
          idx.push(a, c2, b, b, c2, d);
        }
        prevStart = start;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
      geo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
      geo.setIndex(idx); geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: toonGradient() }));
      mesh.receiveShadow = true; mesh.castShadow = true;
      g.add(mesh);
      // cascades
      if (!is.flat && !is.volcanic) {
        const wf = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, uniforms: { uTime: UNI.uTime },
          vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
          fragmentShader: `uniform float uTime; varying vec2 vUv;
            void main(){ float s = fract(vUv.y*3.0 + uTime*1.4 + sin(vUv.x*20.0)*0.1); float a = smoothstep(0.0,0.15,vUv.x)*smoothstep(1.0,0.85,vUv.x)*(1.0-vUv.y*0.9);
              vec3 c = mix(vec3(0.55,0.85,1.0), vec3(1.0), step(0.75, s)); gl_FragColor = vec4(c, a*0.75); }` });
        for (let i = 0; i < 2; i++) {
          const a = rr() * Math.PI * 2;
          const w = new THREE.Mesh(new THREE.PlaneGeometry(2.4, R * 2.2), wf);
          w.position.set(is.x + Math.cos(a) * (R - 0.3), is.top - R * 1.1, is.z + Math.sin(a) * (R - 0.3));
          w.lookAt(is.x, w.position.y, is.z); w.rotateY(Math.PI);
          g.add(w);
        }
      }
      if (is.id === 'arena') this.decorateArena(g, is);
      if (is.id === 'boss') this.decorateBossIsland(g, is);
      if (is.volcanic) this.decorateVolcanic(g, is);
      this.root.add(g);
      this.islandMeshes.push(g);
    }
  }

  decorateArena(g, is) {
    const mat = new THREE.MeshToonMaterial({ color: '#cfc7ff', gradientMap: toonGradient() });
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(is.r * 0.82, is.r * 0.82, 0.4, 48), new THREE.MeshToonMaterial({ color: '#9a94b8', gradientMap: toonGradient() }));
    floor.position.set(is.x, is.top + 0.05, is.z); floor.receiveShadow = true; g.add(floor);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(is.r * 0.55, 0.25, 8, 64), new THREE.MeshBasicMaterial({ color: '#7ef0ff' }));
    ring.rotation.x = Math.PI / 2; ring.position.set(is.x, is.top + 0.3, is.z); g.add(ring);
    for (let i = 0; i < 10; i++) {
      const a = i / 10 * Math.PI * 2;
      const p = model('r:pillar_decorated');
      if (p) { const c = p.clone(); toonify(c); c.scale.setScalar(2); c.position.set(is.x + Math.cos(a) * is.r * 0.88, is.top, is.z + Math.sin(a) * is.r * 0.88); c.rotation.y = -a; g.add(c); }
    }
    for (const [dx, dz] of [[0, 0], [12, 0], [-12, 0], [0, 12], [0, -12]]) {
      if (!dx && !dz) continue;
      const w = model('r:wall_half'); if (!w) continue;
      const c = w.clone(); toonify(c); c.scale.setScalar(1.4); c.position.set(is.x + dx, is.top, is.z + dz); c.rotation.y = dx ? Math.PI / 2 : 0; g.add(c);
      this.wg.grid.insert({ x: is.x + dx, z: is.z + dz, r: 1.6, y: is.top });
    }
    void mat;
  }

  // illa del drac: roca negra, esquerdes de lava, ossos i fum
  decorateVolcanic(g, is) {
    const rr = mulberry32(777);
    const lava = new THREE.MeshBasicMaterial({ color: '#ff6a1a' });
    const lavaGlow = new THREE.MeshBasicMaterial({ color: '#ffb347', transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false });
    // esquerdes de lava (cintes planes sobre el terra)
    for (let i = 0; i < 18; i++) {
      const a = rr() * Math.PI * 2, d = 6 + rr() * (is.r - 10), len = 3 + rr() * 7;
      const x = is.x + Math.cos(a) * d, z = is.z + Math.sin(a) * d;
      const crack = new THREE.Mesh(new THREE.PlaneGeometry(0.35 + rr() * 0.4, len), lava);
      crack.rotation.x = -Math.PI / 2; crack.rotation.z = rr() * Math.PI;
      crack.position.set(x, islandTop(is, x, z) + 0.06, z); g.add(crack);
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(2.2, len + 1.5), lavaGlow);
      glow.rotation.copy(crack.rotation); glow.position.copy(crack.position).y += 0.02; g.add(glow);
    }
    // pedres de basalt
    const basalt = new THREE.MeshToonMaterial({ color: '#2c2427', gradientMap: toonGradient() });
    for (let i = 0; i < 26; i++) {
      const a = rr() * Math.PI * 2, d = is.r * (0.55 + rr() * 0.4);
      const x = is.x + Math.cos(a) * d, z = is.z + Math.sin(a) * d;
      const h = 1.5 + rr() * 5;
      const rock = new THREE.Mesh(new THREE.CylinderGeometry(0.4 + rr() * 0.6, 1 + rr() * 1.2, h, 6), basalt);
      rock.position.set(x, islandTop(is, x, z) + h / 2 - 0.2, z); rock.rotation.set((rr() - 0.5) * 0.3, rr() * 3, (rr() - 0.5) * 0.3);
      rock.castShadow = true; g.add(rock);
      if (h > 3) this.wg.grid.insert({ x, z, r: 1.2, y: is.top });
    }
    // costelles d'un drac antic
    const bone = new THREE.MeshToonMaterial({ color: '#e9dcc0', gradientMap: toonGradient() });
    const bx = is.x - 18, bz = is.z + 8;
    for (let i = 0; i < 7; i++) {
      for (const sgn of [-1, 1]) {
        const rib = new THREE.Mesh(new THREE.TorusGeometry(3.2 - i * 0.25, 0.22, 6, 16, Math.PI * 0.75), bone);
        rib.position.set(bx + i * 1.6, islandTop(is, bx, bz) + 0.2, bz);
        rib.rotation.set(0, Math.PI / 2, sgn > 0 ? 0.2 : Math.PI - 0.2); rib.castShadow = true; g.add(rib);
      }
    }
    const skull = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6, 0), bone);
    skull.scale.set(1.6, 0.9, 1); skull.position.set(bx - 3, islandTop(is, bx, bz) + 0.8, bz); g.add(skull);
    // flames i llum càlida
    for (let i = 0; i < 6; i++) {
      const a = i / 6 * Math.PI * 2 + 0.3;
      const x = is.x + Math.cos(a) * is.r * 0.7, z = is.z + Math.sin(a) * is.r * 0.7;
      this.addFlame(x, islandTop(is, x, z) + 0.6, z, '#ff7a2a');
    }
    const light = new THREE.PointLight('#ff6a2a', 3, 90, 1.4); light.position.set(is.x, is.top + 14, is.z); g.add(light);
  }

  decorateBossIsland(g, is) {
    const ringMat = new THREE.MeshBasicMaterial({ color: '#b07bff', transparent: true, opacity: 0.7 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(is.r * 0.62, 0.2, 8, 72), ringMat);
    ring.rotation.x = Math.PI / 2; ring.position.set(is.x, is.top + 0.25, is.z); g.add(ring);
    for (let i = 0; i < 7; i++) {
      const a = i / 7 * Math.PI * 2;
      const cr = new THREE.Mesh(new THREE.OctahedronGeometry(1.2, 0), new THREE.MeshToonMaterial({ color: '#c9a2ff', emissive: '#7a2cff', emissiveIntensity: 1.6, gradientMap: toonGradient() }));
      cr.position.set(is.x + Math.cos(a) * is.r * 0.85, is.top + 3.5, is.z + Math.sin(a) * is.r * 0.85);
      cr.scale.set(1, 2.2, 1);
      cr.userData.spin = 0.6 + i * 0.07; cr.userData.baseY = cr.position.y;
      this.animated.push(cr); g.add(cr);
    }
  }

  // ------------------------------------------------------------------ instàncies estàtiques
  // agrupa instàncies per model -> malla -> tros del món, i crea InstancedMesh
  addInstances(list, opts = {}) {
    const byModel = new Map();
    for (const it of list) { let a = byModel.get(it.m); if (!a) byModel.set(it.m, a = []); a.push(it); }
    const chunkSize = opts.chunk || 96;
    const partsOf = (tpl) => {
      const parts = [];
      tpl.updateMatrixWorld(true);
      const inv = new THREE.Matrix4().copy(tpl.matrixWorld).invert();
      tpl.traverse((o) => { if (o.isMesh) parts.push({ geo: o.geometry, mat: o.material, local: new THREE.Matrix4().multiplyMatrices(inv, o.matrixWorld) }); });
      return parts;
    };
    for (const [mname, items] of byModel) {
      const tpl = model(mname) || model('n:' + mname);
      if (!tpl) { console.warn('model no trobat', mname); continue; }
      const lodTpl = opts.lod ? (model(mname + '_LOD') || model('n:' + mname + '_LOD')) : null;
      const parts = partsOf(tpl);
      const lparts = lodTpl ? partsOf(lodTpl) : null;
      // materials toon (cache per material original)
      for (const p of parts) p.toon = this.toonMat(p.mat, mname, opts, items[0]);
      if (lparts) for (const p of lparts) p.toon = this.toonMat(p.mat, mname, opts, items[0]);
      const byChunk = new Map();
      for (const it of items) {
        const key = Math.floor(it.x / chunkSize) + ',' + Math.floor(it.z / chunkSize) + (it.autumn ? 'A' : '') + (it.desert ? 'D' : '');
        let a = byChunk.get(key); if (!a) byChunk.set(key, a = []); a.push(it);
      }
      for (const [key, its] of byChunk) {
        // matriu base de cada instància
        const base = its.map((it) => {
          tmpQ.setFromAxisAngle(UP, it.ry || 0);
          tmpS.setScalar(it.s || 1);
          tmpP.set(it.x, (it.y !== undefined ? it.y : height(it.x, it.z)) + (it.dy || 0), it.z);
          return new THREE.Matrix4().compose(tmpP, tmpQ, tmpS);
        });
        const make = (plist, shadow) => plist.map((p) => {
          let mat = p.toon;
          if (key.endsWith('A') && /Leaves/i.test(p.mat.name || '') && Assets.textures.autumn) mat = this.variantMat(p.toon, 'autumn', Assets.textures.autumn);
          if (key.endsWith('D') && /Rock/i.test(p.mat.name || '') && Assets.textures.desert) mat = this.variantMat(p.toon, 'desert', Assets.textures.desert);
          const im = new THREE.InstancedMesh(p.geo, mat, its.length);
          base.forEach((m, i) => { tmpM.multiplyMatrices(m, p.local); im.setMatrixAt(i, tmpM); });
          im.instanceMatrix.needsUpdate = true;
          im.computeBoundingSphere();
          im.castShadow = shadow;
          im.receiveShadow = true;
          im.userData.maxDist = opts.maxDist || 400;
          im.userData.center = im.boundingSphere.center.clone();
          im.userData.radius = im.boundingSphere.radius;
          im.userData.local = p.local;
          this.root.add(im);
          this.chunks.push(im);
          return im;
        });
        const hi = make(parts, !!opts.shadow);
        if (lparts) {
          const lo = make(lparts, false);
          const c = hi[0].userData.center, r = hi[0].userData.radius;
          this.lods.push({ base, pos: its.map((it) => new THREE.Vector2(it.x, it.z)), hi, lo, center: c, radius: r, dist: opts.lod, state: -1, last: new THREE.Vector2(1e9, 1e9) });
        }
      }
    }
  }

  // nivell de detall per instància: a prop el model sencer, lluny el simplificat
  updateLOD(cam) {
    const cp = new THREE.Vector2(cam.x, cam.z);
    for (const L of this.lods) {
      const d = Math.hypot(L.center.x - cam.x, L.center.z - cam.z);
      let state;
      if (d - L.radius > L.dist) state = 0; // tot lluny
      else if (d + L.radius < L.dist) state = 1; // tot a prop
      else state = 2; // barrejat
      if (state === L.state && (state !== 2 || L.last.distanceToSquared(cp) < 16)) continue;
      L.state = state; L.last.copy(cp);
      const near = [], far = [];
      for (let i = 0; i < L.base.length; i++) {
        if (state === 1 || (state === 2 && L.pos[i].distanceTo(cp) < L.dist)) near.push(i); else far.push(i);
      }
      const fill = (meshes, idx) => {
        for (const im of meshes) {
          const loc = im.userData.local;
          for (let k = 0; k < idx.length; k++) { tmpM.multiplyMatrices(L.base[idx[k]], loc); im.setMatrixAt(k, tmpM); }
          im.count = idx.length;
          im.instanceMatrix.needsUpdate = true;
          im.userData.empty = idx.length === 0;
        }
      };
      fill(L.hi, near); fill(L.lo, far);
    }
  }

  // pedres de camí procedurals (els models originals tenen massa triangles)
  buildPathStones(paths) {
    const r = mulberry32(4242);
    const variants = [];
    const shapes = { Small: [6, 0.9, 0.9], Wide: [10, 1.7, 1.1], Thin: [7, 1.5, 0.55] };
    for (const [kind, [n, sx, sz]] of Object.entries(shapes)) {
      for (let v = 0; v < 3; v++) {
        const geos = [];
        for (let i = 0; i < n; i++) {
          const g = new THREE.CylinderGeometry(1, 1, 1, 7, 1);
          const pos = g.attributes.position;
          for (let j = 0; j < pos.count; j++) { const k = 0.82 + r() * 0.3; pos.setX(j, pos.getX(j) * k); pos.setZ(j, pos.getZ(j) * k); }
          const w = 0.13 + r() * 0.13;
          g.scale(w * (1 + r() * 0.5), 0.05 + r() * 0.035, w);
          g.rotateY(r() * 6.28);
          g.translate((r() - 0.5) * sx, 0.02, (r() - 0.5) * sz);
          const shade = 0.8 + r() * 0.3;
          const col = new Float32Array(pos.count * 3).fill(shade);
          g.setAttribute('color', new THREE.BufferAttribute(col, 3));
          geos.push(g.toNonIndexed());
        }
        const merged = mergeGeos(geos);
        merged.computeVertexNormals();
        variants.push({ kind, geo: merged });
      }
    }
    const mat = new THREE.MeshToonMaterial({ color: '#8d897f', vertexColors: true, gradientMap: toonGradient() });
    const groups = new Map();
    for (const p of paths) {
      const kind = /Wide/.test(p.m) ? 'Wide' : /Thin/.test(p.m) ? 'Thin' : 'Small';
      const vi = Object.keys(shapes).indexOf(kind) * 3 + (Math.abs(Math.round(p.x * 7 + p.z * 13)) % 3);
      const key = vi + ':' + Math.floor(p.x / 90) + ',' + Math.floor(p.z / 90);
      let a = groups.get(key); if (!a) groups.set(key, a = { vi, its: [] }); a.its.push(p);
    }
    for (const { vi, its } of groups.values()) {
      const im = new THREE.InstancedMesh(variants[vi].geo, mat, its.length);
      its.forEach((it, i) => {
        tmpQ.setFromAxisAngle(UP, it.ry || 0); tmpS.setScalar(it.s || 1);
        tmpP.set(it.x, (it.y !== undefined ? it.y : height(it.x, it.z)) + 0.02, it.z);
        tmpM.compose(tmpP, tmpQ, tmpS); im.setMatrixAt(i, tmpM);
      });
      im.computeBoundingSphere(); im.receiveShadow = true;
      im.userData.maxDist = 150; im.userData.center = im.boundingSphere.center.clone(); im.userData.radius = im.boundingSphere.radius;
      this.root.add(im); this.chunks.push(im);
    }
  }

  toonMat(m, mname, opts) {
    this._matCache ||= new Map();
    const k = m.uuid + (opts.wind ? 'w' : '');
    if (this._matCache.has(k)) return this._matCache.get(k);
    const isLeaf = /Leaves|Leaf|Grass|Flower|Petal|Clover|Fern|Plant/i.test(m.name || '') || (m.map && m.alphaTest > 0) || (m.transparent && m.map);
    const glass = /Glass/i.test(m.name || '');
    const t = new THREE.MeshToonMaterial({ color: m.color ? m.color.clone() : new THREE.Color(1, 1, 1), map: m.map || null, gradientMap: toonGradient(),
      alphaTest: isLeaf ? 0.42 : 0, side: isLeaf || (opts.kit && m.side === THREE.DoubleSide) ? THREE.DoubleSide : THREE.FrontSide, vertexColors: !!m.vertexColors,
      emissive: m.emissive ? m.emissive.clone() : new THREE.Color(0), emissiveMap: m.emissiveMap || null,
      normalMap: opts.kit && this.quality.shadows ? (m.normalMap || null) : null });
    if (t.normalMap && m.normalScale) t.normalScale.copy(m.normalScale);
    if (glass) { t.transparent = true; t.opacity = 0.45; t.depthWrite = false; t.color.set('#9fc4d8'); t.emissive.set('#2a3a48'); }
    if (isLeaf) { t.color.multiplyScalar(1.08); }
    t.name = m.name;
    if (opts.wind && isLeaf) addWind(t, opts.windStrength || 0.06, opts.windMode || 'tree');
    else if (opts.wind && opts.trunkWind) addWind(t, (opts.windStrength || 0.06) * 0.4, 'tree');
    this._matCache.set(k, t);
    return t;
  }
  variantMat(base, tag, tex) {
    this._varCache ||= new Map();
    const k = base.uuid + tag;
    if (this._varCache.has(k)) return this._varCache.get(k);
    const m = base.clone(); m.map = tex; m.onBeforeCompile = base.onBeforeCompile; m.customProgramCacheKey = base.customProgramCacheKey;
    this._varCache.set(k, m);
    return m;
  }

  buildVegetation() {
    const veg = this.wg.vegetation;
    const q = this.quality.trees;
    const trees = [], small = [], paths = [];
    for (const v of veg) {
      const big = /Tree|Pine/.test(v.m);
      if (big) { if (q < 1 && !v.mare && hash2(v.x * 3, v.z * 3) > q) continue; trees.push(v); }
      else if (v.flat) paths.push({ ...v, dy: 0.02 });
      else small.push(v);
    }
    // detalls decoratius extra només al client (herbes altes, flors, bolets)
    const r = mulberry32(555);
    const extra = [];
    const nExtra = Math.round(6500 * this.quality.detail);
    for (let i = 0; i < nExtra; i++) {
      const x = (r() - 0.5) * 560, z = -280 + r() * 440;
      if (Math.hypot(x, z) > 280) continue;
      const zn = zoneAt(x, z).id;
      if (roadDist(x, z) < 2) continue;
      if (Math.hypot(x, z) < 18) continue;
      const h = height(x, z);
      if (h < 1.0) continue;
      let m;
      const k = r();
      if (zn === 'bosc') m = k < 0.35 ? 'Grass_Common_Tall' : k < 0.55 ? 'Grass_Wispy_Tall' : k < 0.7 ? 'Flower_4_Single' : k < 0.8 ? 'Fern_1' : k < 0.88 ? 'Mushroom_Common' : 'Clover_2';
      else if (zn === 'vila' || zn === 'costa') m = k < 0.4 ? 'Grass_Common_Short' : k < 0.6 ? 'Grass_Wispy_Short' : k < 0.8 ? 'Flower_3_Single' : 'Flower_4_Single';
      else if (zn === 'ruines') m = k < 0.6 ? 'Grass_Wispy_Short' : k < 0.8 ? 'Pebble_Round_1' : 'Plant_7';
      else if (zn === 'cremades') { if (k < 0.5) continue; m = k < 0.75 ? 'Pebble_Square_2' : 'Grass_Wispy_Short'; }
      else continue;
      if (zn === 'costa' && h < 2.4) continue;
      extra.push({ m, x, z, y: h, s: (m.startsWith('Grass') ? 0.55 : m.startsWith('Flower') ? 0.42 : 0.7) * (0.75 + r() * 0.5), ry: r() * 6.28 });
    }
    this.addInstances(trees, { chunk: 110, shadow: this.quality.shadows, wind: true, windStrength: 0.05, trunkWind: true, maxDist: 420, lod: 48 + 22 * this.quality.detail });
    this.addInstances(small, { chunk: 70, shadow: false, wind: true, windStrength: 0.25, windMode: 'grass', maxDist: 150, lod: 30 });
    this.addInstances(extra, { chunk: 50, shadow: false, wind: true, windStrength: 0.35, windMode: 'grass', maxDist: 95, lod: 28 });
    this.buildPathStones(paths);
    // Arbre Mare: brillantor màgica
    const mare = veg.find((v) => v.mare);
    if (mare) {
      const glow = new THREE.PointLight('#9dffcf', 2.5, 40, 1.5);
      glow.position.set(mare.x, mare.y + 12, mare.z);
      this.root.add(glow);
    }
  }

  buildProps() {
    const props = this.wg.props;
    const inst = [], far = [];
    this.portals = [];
    const kit = [];
    for (const p of props) {
      if (p.model.startsWith('x:')) continue; // només col·lisió
      if (p.model.startsWith('p:')) { this.buildProcProp(p); continue; }
      const it = { m: p.model, x: p.x, z: p.z, y: p.ya !== undefined ? p.ya : p.y !== undefined ? height(p.x, p.z) + p.y : height(p.x, p.z) - (p.far ? 2 : 0.05), s: p.s, ry: p.ry };
      if (p.model.startsWith('k:')) { kit.push(it); continue; }
      if (p.far) far.push(it); else inst.push(it);
      if (p.light) this.addFlame(p.x, height(p.x, p.z) + 1.25 * p.s / 2.2 + 0.4, p.z, p.light);
    }
    this.addInstances(inst, { chunk: 120, shadow: this.quality.shadows, maxDist: 520 });
    // peces del MegaKit: moltes instàncies petites, agrupades per trossos
    this.addInstances(kit, { chunk: 90, shadow: this.quality.shadows, maxDist: 380, kit: true });
    this.addInstances(far, { chunk: 400, shadow: false, maxDist: 2000 });
    // cofres
    const chestTpl = model('r:chest');
    for (const c of CHESTS) {
      const y = c.island ? islandTop(ISLAND[c.island], c.x, c.z) : height(c.x, c.z);
      let obj;
      if (chestTpl) { obj = chestTpl.clone(true); toonify(obj); obj.scale.setScalar(0.9); }
      else obj = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.9, 0.8), new THREE.MeshToonMaterial({ color: '#a0703a' }));
      obj.position.set(c.x, y, c.z);
      obj.rotation.y = Math.atan2(-c.x, -c.z);
      this.root.add(obj);
      const glow = this.makeGlowSprite(c.quest ? '#7ef0ff' : '#ffd166', 1.8);
      glow.position.set(c.x, y + 1.3, c.z);
      this.root.add(glow);
      this.chests[c.id] = { obj, lid: obj.getObjectByName('chest_lid'), glow, open: 0 };
      this.interactables.push({ type: 'chest', id: c.id, x: c.x, y, z: c.z, r: 3.2, label: c.quest ? 'Obrir el cofre antic' : 'Obrir el cofre' });
    }
    // plataformes de vent
    for (const lp of LAUNCHPADS) {
      const y = lp.island ? islandTop(ISLAND[lp.island], lp.x, lp.z) : height(lp.x, lp.z);
      if (lp.id !== 'pedra_vent') this.buildWindPad(lp.x, y, lp.z);
      this.interactables.push({ type: 'launch', id: lp.id, x: lp.x, y, z: lp.z, r: 3.5, label: lp.id === 'pedra_vent' ? 'Activar la Pedra de Vent' : 'Saltar amb el vent' });
    }
    for (const w of WAYSTONES) if (w.island) this.buildProcProp({ model: 'p:portal', x: w.x, z: w.z, waystone: w.id, island: w.island });
  }

  // columna de llum que marca l'objectiu
  setBeacon(pos) {
    if (!this.beacon) {
      const g = new THREE.Group();
      const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
        uniforms: { uTime: UNI.uTime },
        vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
        fragmentShader: `uniform float uTime; varying vec2 vUv;
          void main(){ float a = (1.0 - vUv.y) * (0.55 + 0.25 * sin(uTime * 3.0 + vUv.y * 12.0)); a *= smoothstep(0.0, 0.04, vUv.y);
            gl_FragColor = vec4(vec3(1.0, 0.78, 0.35) * a, a); }`,
      });
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.6, 90, 16, 1, true), mat);
      col.position.y = 45; g.add(col);
      const ring = new THREE.Mesh(new THREE.RingGeometry(1.8, 2.4, 40), new THREE.MeshBasicMaterial({ color: '#ffd166', transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
      ring.rotation.x = -Math.PI / 2; ring.position.y = 0.2; g.add(ring); ring.userData.pulse = true;
      g.userData.ring = ring;
      g.renderOrder = 4;
      this.root.add(g);
      this.beacon = g;
    }
    this.beacon.visible = !!pos;
    if (pos) {
      this.beacon.position.set(pos.x, pos.y, pos.z);
      const k = (performance.now() / 1000) % 1.6 / 1.6;
      this.beacon.userData.ring.scale.setScalar(0.6 + k * 1.6);
      this.beacon.userData.ring.material.opacity = 0.85 * (1 - k);
    }
  }

  makeGlowSprite(color, size) {
    if (!this._glowTex) {
      const cv = document.createElement('canvas'); cv.width = cv.height = 64;
      const g = cv.getContext('2d'); const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,0.6)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
      this._glowTex = new THREE.CanvasTexture(cv);
    }
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: this._glowTex, color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    s.scale.setScalar(size);
    return s;
  }

  addFlame(x, y, z, color) {
    const s = this.makeGlowSprite(color, 2.4);
    s.position.set(x, y, z);
    s.userData.base = 2.4; s.userData.ph = Math.random() * 10;
    this.root.add(s);
    this.flames.push(s);
  }

  buildWindPad(x, y, z) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 3, 0.5, 24), new THREE.MeshToonMaterial({ color: '#b9b2c9', gradientMap: toonGradient() }));
    base.position.y = 0.2; base.receiveShadow = true; g.add(base);
    const runes = new THREE.Mesh(new THREE.RingGeometry(1.2, 2.2, 32), new THREE.MeshBasicMaterial({ color: '#8ff7ff', transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
    runes.rotation.x = -Math.PI / 2; runes.position.y = 0.47; g.add(runes);
    const swirl = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2.2, 6, 24, 1, true), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, uniforms: { uTime: UNI.uTime },
      vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform float uTime; varying vec2 vUv; void main(){ float s = sin(vUv.x*31.4 + vUv.y*8.0 - uTime*6.0)*0.5+0.5; float a = s*(1.0-vUv.y)*0.35; gl_FragColor = vec4(0.6,0.95,1.0,a); }' }));
    swirl.position.y = 3.3; g.add(swirl);
    g.position.set(x, y, z);
    this.root.add(g);
  }

  buildProcProp(p) {
    const y = p.island ? islandTop(ISLAND[p.island], p.x, p.z) : height(p.x, p.z);
    const toon = (c, e) => new THREE.MeshToonMaterial({ color: c, gradientMap: toonGradient(), emissive: e || '#000000', emissiveIntensity: e ? 1.4 : 0 });
    if (p.model === 'p:tomba') {
      this._tombGeo ||= (() => { const g = new THREE.BoxGeometry(0.9, 1.3, 0.25); g.translate(0, 0.65, 0); return g; })();
      this._tombMat ||= toon('#8d8f99');
      const m = new THREE.Mesh(this._tombGeo, this._tombMat);
      m.position.set(p.x, y - 0.1, p.z); m.rotation.set((Math.random() - 0.5) * 0.25, p.ry, (Math.random() - 0.5) * 0.2); m.scale.setScalar(p.s);
      m.castShadow = true; m.receiveShadow = true;
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.25, 12, 1, false, 0, Math.PI), this._tombMat);
      top.rotation.z = Math.PI / 2; top.rotation.y = Math.PI / 2; top.position.y = 1.3; m.add(top);
      this.root.add(m);
    } else if (p.model === 'p:foguera') {
      const g = new THREE.Group();
      this._logGeo ||= new THREE.CylinderGeometry(0.12, 0.14, 1.3, 6);
      this._logMat ||= toon('#5a3b22');
      for (let i = 0; i < 4; i++) { const l = new THREE.Mesh(this._logGeo, this._logMat); l.rotation.set(Math.PI / 2 - 0.35, i * Math.PI / 2, 0); l.position.set(Math.sin(i * Math.PI / 2) * 0.25, 0.25, Math.cos(i * Math.PI / 2) * 0.25); g.add(l); }
      this._stoneGeo ||= new THREE.DodecahedronGeometry(0.22, 0);
      this._stoneMat ||= toon('#77736d');
      for (let i = 0; i < 9; i++) { const st = new THREE.Mesh(this._stoneGeo, this._stoneMat); const a = i / 9 * Math.PI * 2; st.position.set(Math.cos(a) * 0.85, 0.08, Math.sin(a) * 0.85); g.add(st); }
      g.position.set(p.x, y, p.z);
      this.root.add(g);
      this.addFlame(p.x, y + 0.55, p.z, '#ff8a2a');
    } else if (p.model === 'p:pedra_vent') {
      const g = new THREE.Group();
      const stoneM = toon('#a8a3b5');
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * Math.PI * 2;
        const st = new THREE.Mesh(new THREE.BoxGeometry(1.1, 4 + (i % 2) * 1.2, 0.9), stoneM);
        st.position.set(Math.cos(a) * 5.2, 2, Math.sin(a) * 5.2); st.rotation.y = -a; st.castShadow = true; g.add(st);
      }
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 4, 0.5, 32), stoneM); disc.position.y = 0.2; g.add(disc);
      const rune = new THREE.Mesh(new THREE.RingGeometry(1.4, 3.2, 6), new THREE.MeshBasicMaterial({ color: '#8ff7ff', transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
      rune.rotation.x = -Math.PI / 2; rune.position.y = 0.48; g.add(rune); rune.userData.spin = 0.4; this.animated.push(rune);
      const cr = new THREE.Mesh(new THREE.OctahedronGeometry(0.9, 0), toon('#bff6ff', '#38d6ff'));
      cr.position.y = 3.2; cr.scale.set(1, 1.8, 1); cr.userData.spin = 1.2; cr.userData.baseY = 3.2; g.add(cr); this.animated.push(cr);
      g.position.set(p.x, y, p.z);
      this.root.add(g);
    } else if (p.model === 'p:portal') {
      const g = new THREE.Group();
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.3, 1.4, 8), toon('#9a95ad')); ped.position.y = 0.7; ped.castShadow = true; g.add(ped);
      const cr = new THREE.Mesh(new THREE.OctahedronGeometry(0.65, 0), toon('#ffe8a3', '#ffb703'));
      cr.position.y = 2.4; cr.scale.set(1, 1.7, 1); cr.userData.spin = 1.0; cr.userData.baseY = 2.4; g.add(cr); this.animated.push(cr);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.25, 0.08, 8, 32), new THREE.MeshBasicMaterial({ color: '#ffd166' }));
      ring.position.y = 2.4; ring.userData.spinX = 0.8; g.add(ring); this.animated.push(ring);
      const glow = this.makeGlowSprite('#ffcf5a', 3.2); glow.position.y = 2.4; g.add(glow);
      g.position.set(p.x, y, p.z);
      this.root.add(g);
      const w = WAYSTONES.find((x) => x.id === p.waystone);
      this.interactables.push({ type: 'waystone', id: p.waystone, x: p.x, y, z: p.z, r: 3.2, label: 'Pedra de portal: ' + (w ? w.name : '') });
    }
  }

  // ------------------------------------------------------------------ herba procedural
  buildGrass() {
    const q = this.quality.grass;
    if (q <= 0) return;
    const blade = new THREE.BufferGeometry();
    // fulla de 3 segments
    const W = 0.09, H = 1;
    const pos = [-W, 0, 0, W, 0, 0, -W * 0.7, H * 0.45, 0, W * 0.7, H * 0.45, 0, -W * 0.35, H * 0.8, 0, W * 0.35, H * 0.8, 0, 0, H, 0];
    const idx = [0, 1, 2, 1, 3, 2, 2, 3, 4, 3, 5, 4, 4, 5, 6];
    blade.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    blade.setIndex(idx);
    this.grassUni = { uTime: UNI.uTime, uPlayer: { value: new THREE.Vector3() }, uFogColor: { value: new THREE.Color() }, uFogNear: { value: 50 }, uFogFar: { value: 300 }, uSunCol: { value: new THREE.Color(1, 1, 1) }, uAmb: { value: 1 } };
    this.grassMat = new THREE.ShaderMaterial({
      uniforms: this.grassUni, side: THREE.DoubleSide,
      vertexShader: `uniform float uTime; uniform vec3 uPlayer; attribute vec4 aOff; attribute vec3 aCol; varying vec3 vCol; varying float vY; varying float vD;
        void main(){
          vec3 p = position; float h = aOff.w; p.y *= h;
          float ang = fract(sin(dot(aOff.xz, vec2(12.9898,78.233)))*43758.5453) * 6.2831;
          float c = cos(ang), s = sin(ang); p = vec3(p.x*c, p.y, p.x*s);
          vec3 w = aOff.xyz + p;
          float k = position.y * position.y;
          float wind = sin(uTime*1.7 + w.x*0.35 + w.z*0.27)*0.35 + sin(uTime*3.3 + w.x*1.1)*0.12;
          w.x += wind * k * h; w.z += wind * k * h * 0.6;
          vec3 dp = w - uPlayer; float dd = length(dp.xz);
          if (dd < 1.6) { w.xz += normalize(dp.xz + 0.001) * (1.6 - dd) * k * 0.9; w.y -= (1.6-dd)*k*0.35; }
          vCol = aCol; vY = position.y; vD = length(cameraPosition - w);
          gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
        }`,
      fragmentShader: `uniform vec3 uFogColor, uSunCol; uniform float uFogNear, uFogFar, uAmb; varying vec3 vCol; varying float vY; varying float vD;
        void main(){ vec3 c = vCol * mix(0.55, 1.15, vY) * uSunCol * uAmb; c += vec3(0.08,0.1,0.0)*vY*vY;
          float f = smoothstep(uFogNear, uFogFar, vD); c = mix(c, uFogColor, f);
          gl_FragColor = vec4(c, 1.0);
          #include <colorspace_fragment>
        }`,
    });
    this.grassCells = new Map();
    this.grassBlade = blade;
    this.grassCell = 14;
    this.grassRadius = 4 + Math.round(q * 1);
    this.grassPerCell = Math.round(420 * q);
  }

  grassCellMesh(cx, cz) {
    const n = this.grassPerCell, cs = this.grassCell;
    const r = mulberry32(cx * 7919 + cz * 104729);
    const off = new Float32Array(n * 4), col = new Float32Array(n * 3);
    const c = new THREE.Color();
    let k = 0;
    for (let i = 0; i < n; i++) {
      const x = (cx + r()) * cs, z = (cz + r()) * cs;
      const h = height(x, z);
      if (h < 1.3) continue;
      const zn = zoneAt(x, z).id;
      if (zn === 'cremades' && r() < 0.8) continue;
      if (zn === 'ruines' && r() < 0.5) continue;
      if (roadDist(x, z) < 2.2 && r() < 0.85) continue;
      if (Math.hypot(x, z) < 24 && r() < 0.7) continue;
      const hx = height(x + 1, z) - h, hz = height(x, z + 1) - h;
      if (Math.hypot(hx, hz) > 0.9) continue;
      terrainColor(x, z, h, 0, c);
      c.offsetHSL(0, 0.05, (r() - 0.5) * 0.08);
      off[k * 4] = x; off[k * 4 + 1] = h - 0.05; off[k * 4 + 2] = z;
      off[k * 4 + 3] = (zn === 'bosc' ? 0.95 : 0.65) * (0.6 + r() * 0.8);
      col[k * 3] = c.r; col[k * 3 + 1] = c.g; col[k * 3 + 2] = c.b;
      k++;
    }
    if (!k) return null;
    const geo = new THREE.InstancedBufferGeometry();
    geo.index = this.grassBlade.index; geo.attributes.position = this.grassBlade.attributes.position;
    geo.setAttribute('aOff', new THREE.InstancedBufferAttribute(off.slice(0, k * 4), 4));
    geo.setAttribute('aCol', new THREE.InstancedBufferAttribute(col.slice(0, k * 3), 3));
    geo.instanceCount = k;
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3((cx + 0.5) * cs, height((cx + 0.5) * cs, (cz + 0.5) * cs), (cz + 0.5) * cs), cs);
    const mesh = new THREE.Mesh(geo, this.grassMat);
    mesh.frustumCulled = true;
    return mesh;
  }

  updateGrass(p) {
    if (!this.grassMat) return;
    this.grassUni.uPlayer.value.copy(p);
    const cs = this.grassCell, R = this.grassRadius;
    const pcx = Math.floor(p.x / cs), pcz = Math.floor(p.z / cs);
    if (this._gcx === pcx && this._gcz === pcz) return;
    this._gcx = pcx; this._gcz = pcz;
    const want = new Set();
    let built = 0;
    for (let dx = -R; dx <= R; dx++) for (let dz = -R; dz <= R; dz++) {
      if (dx * dx + dz * dz > R * R + 1) continue;
      const k = (pcx + dx) + ',' + (pcz + dz);
      want.add(k);
      if (!this.grassCells.has(k)) {
        if (built > 30) continue;
        const m = this.grassCellMesh(pcx + dx, pcz + dz); built++;
        this.grassCells.set(k, m);
        if (m) this.root.add(m);
      }
    }
    for (const [k, m] of this.grassCells) {
      if (!want.has(k)) { if (m) { this.root.remove(m); m.geometry.dispose(); } this.grassCells.delete(k); }
    }
    if (built > 30) this._gcx = null; // continua el proper fotograma
  }

  // ------------------------------------------------------------------ NPCs
  buildNPCs() {
    for (const n of NPCS) {
      const obj = cloneSkinned(n.model);
      if (!obj) continue;
      toonify(obj);
      // amaga accessoris que no toquen
      obj.traverse((o) => {
        if (/Offhand|Spike_Shield|Rectangle_Shield|Badge_Shield|2H_Sword|Crossbow|Throwable|1H_Crossbow|2H_Crossbow|Knife_Offhand/.test(o.name) && o.isMesh) o.visible = false;
        if (n.model === 'knight' && /Round_Shield/.test(o.name)) o.visible = true;
      });
      fitHeight(obj, 2.0);
      addOutline(obj);
      const y = height(n.x, n.z);
      obj.position.set(n.x, y, n.z);
      obj.rotation.y = n.ry;
      this.root.add(obj);
      const mixer = new THREE.AnimationMixer(obj);
      const clip = THREE.AnimationClip.findByName(Assets.kkClips, n.anim) || THREE.AnimationClip.findByName(Assets.kkClips, 'Idle');
      if (clip) mixer.clipAction(clip).play();
      this.mixers.push(mixer);
      // cadira per a la Rina
      if (n.anim === 'Sit_Chair_Idle') {
        const chair = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 0.9), new THREE.MeshToonMaterial({ color: '#8b5a2b', gradientMap: toonGradient() }));
        chair.position.set(n.x - Math.sin(n.ry) * 0.25, y + 0.27, n.z - Math.cos(n.ry) * 0.25); this.root.add(chair);
      }
      const marker = this.makeMarker();
      marker.position.set(n.x, y + 2.75, n.z);
      this.root.add(marker);
      this.npcs[n.id] = { obj, mixer, marker, def: n };
      this.interactables.push({ type: 'npc', id: n.id, x: n.x, y, z: n.z, r: 3.6, label: `Parlar amb ${n.name}` });
      this.wg.grid.insert({ x: n.x, z: n.z, r: 0.7 });
    }
  }

  makeMarker() {
    const cv = document.createElement('canvas'); cv.width = 64; cv.height = 96;
    const tex = new THREE.CanvasTexture(cv);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
    s.scale.set(0.8, 1.2, 1);
    s.userData.cv = cv; s.userData.tex = tex; s.userData.cur = '';
    s.renderOrder = 10;
    return s;
  }
  setMarker(npcId, symbol, color = '#ffd166') {
    const n = this.npcs[npcId]; if (!n) return;
    const s = n.marker; const key = symbol + color;
    if (s.userData.cur === key) return;
    s.userData.cur = key;
    const g = s.userData.cv.getContext('2d'); g.clearRect(0, 0, 64, 96);
    s.visible = !!symbol;
    if (!symbol) return;
    g.font = 'bold 76px Georgia, serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.lineWidth = 8; g.strokeStyle = '#2a1a05'; g.strokeText(symbol, 32, 52);
    g.fillStyle = color; g.fillText(symbol, 32, 52);
    s.userData.tex.needsUpdate = true;
  }

  // ------------------------------------------------------------------ llums
  buildLights() {
    this.hemi = new THREE.HemisphereLight('#cfe9ff', '#5b6b3a', 1.15);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight('#fff1d6', 2.4);
    this.sun.castShadow = !!this.quality.shadows;
    const S = this.quality.shadows ? 60 : 30;
    this.sun.shadow.mapSize.set(this.quality.shadowRes || 2048, this.quality.shadowRes || 2048);
    Object.assign(this.sun.shadow.camera, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 400 });
    this.sun.shadow.bias = -0.0006; this.sun.shadow.normalBias = 0.6;
    this.scene.add(this.sun); this.scene.add(this.sun.target);
    this.scene.fog = new THREE.Fog('#cfe6f5', 120, 520);
  }

  // ------------------------------------------------------------------ minimapa
  buildMinimap() {
    const N = 256, S = 680;
    const cv = document.createElement('canvas'); cv.width = cv.height = N;
    const g = cv.getContext('2d'); const img = g.createImageData(N, N);
    const c = new THREE.Color();
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const x = (i / N - 0.5) * S, z = (j / N - 0.5) * S;
      const h = height(x, z);
      if (h < -0.3) c.set(h < -3 ? '#2f7fb7' : '#4fb7cf'); else terrainColor(x, z, h, 0, c);
      c.convertLinearToSRGB();
      const shade = 0.85 + Math.max(-0.15, Math.min(0.15, (height(x + 3, z - 3) - h) * 0.05));
      const o = (j * N + i) * 4;
      img.data[o] = Math.min(255, c.r * 255 * shade); img.data[o + 1] = Math.min(255, c.g * 255 * shade); img.data[o + 2] = Math.min(255, c.b * 255 * shade); img.data[o + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    // edificis i fortaleses
    const P = (x, z) => [(x / S + 0.5) * N, (z / S + 0.5) * N];
    const rect = (x, z, ry, hx, hz) => {
      const c = Math.cos(ry), s = Math.sin(ry);
      g.beginPath();
      [[-hx, -hz], [hx, -hz], [hx, hz], [-hx, hz]].forEach(([a, b], i) => { const [px, py] = P(x + a * c + b * s, z - a * s + b * c); if (i) g.lineTo(px, py); else g.moveTo(px, py); });
      g.closePath();
    };
    g.fillStyle = 'rgba(70,50,40,0.85)';
    for (const p of this.wg.props) if (p.box) { rect(p.x, p.z, p.ry, p.box[0], p.box[1]); g.fill(); }
    g.strokeStyle = 'rgba(55,40,30,0.95)'; g.lineWidth = 2.2;
    for (const d of STRUCTURE_DEFS) { rect(d.x, d.z, d.ry, d.hw, d.hd); g.stroke(); }
    // camins i vila
    g.strokeStyle = 'rgba(120,90,50,0.6)'; g.lineWidth = 2;
    this.minimap = { canvas: cv, size: S, n: N };
  }

  // ------------------------------------------------------------------ actualització
  setTime(t) { this.timeOfDay = t; }

  update(dt, time, camera, playerPos, zone) {
    UNI.uTime.value = time;
    // dia i nit
    const tod = this.timeOfDay;
    const sunA = (tod - 0.25) * Math.PI * 2;
    const sunDir = new THREE.Vector3(Math.cos(sunA) * 0.65, Math.sin(sunA), -0.45).normalize();
    const day = smooth(-0.12, 0.2, sunDir.y);
    const night = 1 - day;
    const dusk = 1 - smooth(0.0, 0.35, Math.abs(sunDir.y));
    const zoneTint = zone && (zone.id === 'cremades' || zone.id === 'niu') ? new THREE.Color('#ffb48a') : zone && zone.id === 'bosc' ? new THREE.Color('#d8ffd2') : zone && zone.sky ? new THREE.Color('#ffffff') : new THREE.Color('#ffffff');
    const top = new THREE.Color('#4a9cff').lerp(new THREE.Color('#0b1638'), night).lerp(new THREE.Color('#5a6fd1'), dusk * 0.3 * day);
    const mid = new THREE.Color('#bfe6ff').lerp(new THREE.Color('#1d2a5c'), night).lerp(new THREE.Color('#ffb38a'), dusk * 0.65);
    const bot = new THREE.Color('#f7efd9').lerp(new THREE.Color('#202a4a'), night).lerp(new THREE.Color('#ff9f7a'), dusk * 0.5);
    mid.multiply(zoneTint); bot.multiply(zoneTint);
    this.skyUni.uTop.value.copy(top); this.skyUni.uMid.value.copy(mid); this.skyUni.uBottom.value.copy(bot);
    this.skyUni.uSunDir.value.copy(sunDir); this.skyUni.uNight.value = night;
    this.skyUni.uSunCol.value.set('#fff2d6').lerp(new THREE.Color('#ff9a5a'), dusk);
    const lightDir = sunDir.y > -0.05 ? sunDir : sunDir.clone().multiplyScalar(-1); // la lluna fa llum de nit
    this.sun.position.copy(playerPos).addScaledVector(lightDir, 160);
    this.sun.target.position.copy(playerPos);
    this.sun.intensity = 0.55 + 2.0 * day;
    this.sun.color.set('#fff1d6').lerp(new THREE.Color('#ffb070'), dusk * 0.8).lerp(new THREE.Color('#9fb4ff'), night);
    this.hemi.intensity = 0.65 + 0.6 * day;
    this.hemi.color.set('#cfe9ff').lerp(new THREE.Color('#6a7cc8'), night);
    this.hemi.groundColor.set('#5b6b3a').lerp(new THREE.Color('#2a2d48'), night);
    const fogC = mid.clone().lerp(bot, 0.4);
    this.scene.fog.color.copy(fogC);
    const fogFar = zone && zone.sky ? 900 : zone && zone.id === 'cremades' ? 330 : zone && zone.id === 'bosc' ? 380 : 520;
    this.scene.fog.far += (fogFar - this.scene.fog.far) * Math.min(1, dt * 0.8);
    this.scene.fog.near = this.scene.fog.far * 0.25;
    if (this.waterUni) {
      this.waterUni.uFogColor.value.copy(fogC); this.waterUni.uFogNear.value = this.scene.fog.near; this.waterUni.uFogFar.value = this.scene.fog.far * 1.3;
      this.waterUni.uSky.value.copy(mid); this.waterUni.uSun.value.copy(sunDir); this.waterUni.uNight.value = night;
      this.waterUni.uDeep.value.set('#1b6fa8').lerp(new THREE.Color('#0b2547'), night);
      this.waterUni.uShallow.value.set('#3fd0d6').lerp(new THREE.Color('#1a4e6e'), night);
    }
    if (this.grassUni) {
      this.grassUni.uFogColor.value.copy(fogC); this.grassUni.uFogNear.value = this.scene.fog.near; this.grassUni.uFogFar.value = this.scene.fog.far;
      this.grassUni.uSunCol.value.copy(this.sun.color); this.grassUni.uAmb.value = 0.45 + 0.6 * day;
    }
    this.sky.position.copy(camera.position);
    // distància de dibuix dels trossos
    const cp = camera.position;
    this.lodT = (this.lodT || 0) - dt;
    if (this.lodT <= 0) { this.lodT = 0.25; this.updateLOD(cp); }
    for (const ch of this.chunks) {
      const d = Math.hypot(ch.userData.center.x - cp.x, ch.userData.center.z - cp.z) - ch.userData.radius;
      ch.visible = d < ch.userData.maxDist && !ch.userData.empty;
    }
    for (const c of this.clouds.children) { c.position.x += c.userData.speed * dt; if (c.position.x > 650) c.position.x = -650; }
    for (const a of this.animated) {
      if (a.userData.spin) a.rotation.y += a.userData.spin * dt;
      if (a.userData.spinX) a.rotation.x += a.userData.spinX * dt;
      if (a.userData.baseY !== undefined) a.position.y = a.userData.baseY + Math.sin(time * 1.5 + a.id) * 0.25;
    }
    for (const f of this.flames) { const k = 1 + Math.sin(time * 9 + f.userData.ph) * 0.12 + Math.sin(time * 23 + f.userData.ph) * 0.06; f.scale.setScalar(f.userData.base * k); }
    for (const m of this.mixers) m.update(dt);
    for (const id in this.chests) {
      const c = this.chests[id];
      if (c.open > 0) { c.open = Math.max(0, c.open - dt); if (c.lid) c.lid.rotation.x = -Math.min(1.6, (8 - c.open) * 3) * (c.open > 0.6 ? 1 : c.open / 0.6); }
      c.glow.material.opacity = 0.6 + Math.sin(time * 3 + c.obj.position.x) * 0.3;
    }
    this.updateGrass(playerPos);
    return { day, night };
  }

  openChest(id) { const c = this.chests[id]; if (c) c.open = 8; }

  // ------------------------------------------------------------------ circuits de parkour
  showCourse(on, level = 1) {
    this.courses = this.courses || {};
    if (on && !this.courses[level]) this.courses[level] = this.buildCourse(level);
    for (const [n, c] of Object.entries(this.courses)) c.G.visible = !!on && +n === level;
    this.course = on ? this.courses[level].G : null;
    this.courseData = on ? this.courses[level] : null;
  }
  buildCourse(level) {
    const L = getLevel(level), T = L.theme;
    const G = new THREE.Group();
    const grad = toonGradient();
    const toon = (color, extra = {}) => new THREE.MeshToonMaterial({ color, gradientMap: grad, ...extra });
    const M = {
      side: toon(T.side), top: toon(T.top), rock: toon(T.rock), tile: toon(T.tile),
      wood: toon('#9a6234'), woodTop: toon('#c58a4e'), blue: toon('#4c78c4'), blueTop: toon('#9ee0ff', { emissive: new THREE.Color('#2a6aa0'), emissiveIntensity: 0.35 }),
      pad: toon('#ff9f3a', { emissive: new THREE.Color('#ff7a1a'), emissiveIntensity: 0.6 }),
      crumble: toon('#c9a27a'), crumbleTop: toon('#e0c49a'),
      spin: toon('#7a5230'), spinTop: toon(T.accent, { emissive: new THREE.Color(T.accent), emissiveIntensity: 0.25 }),
      mushStem: toon('#f4ead8'), mushCap: toon('#ff5c8a', { emissive: new THREE.Color('#a8204a'), emissiveIntensity: 0.25 }), dot: toon('#ffffff'),
    };
    const parts = [];
    const rr = mulberry32(99 + level * 17);
    for (const p of L.platforms) {
      const g = new THREE.Group();
      const body = (mat, h, w = p.w, d = p.d) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.y = -h / 2; m.castShadow = true; m.receiveShadow = true; g.add(m); return m; };
      const slab = (mat, h = 0.24) => { const m = new THREE.Mesh(new THREE.BoxGeometry(p.w + 0.12, h, p.d + 0.12), mat); m.position.y = -h / 2 + 0.02; m.receiveShadow = true; g.add(m); return m; };
      let fade = null;
      if (p.kind === 'base') {
        body(M.side, p.h); slab(p.start || p.finish ? M.tile : M.top);
        const R = Math.max(p.w, p.d) * 0.55;
        const cone = new THREE.Mesh(new THREE.ConeGeometry(R, Math.max(p.w, p.d) * 0.9, 7), M.rock);
        cone.rotation.x = Math.PI; cone.rotation.y = rr() * 3; cone.position.y = -p.h - Math.max(p.w, p.d) * 0.45 + 0.05; g.add(cone);
      } else if (p.kind === 'beam') {
        body(M.wood, p.h); slab(M.woodTop, 0.14);
      } else if (p.kind === 'move' || p.kind === 'lift') {
        body(M.blue, p.h); slab(M.blueTop);
        const glow = this.makeGlowSprite('#8fe6ff', Math.max(p.w, p.d) * 1.6); glow.position.y = -p.h - 0.4; g.add(glow);
        if (p.kind === 'lift') for (const dx of [-1, 1]) { const a = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.6, 4), new THREE.MeshBasicMaterial({ color: '#dff8ff' })); a.position.set(dx * (p.w / 2 - 0.5), 0.35, 0); g.add(a); }
      } else if (p.kind === 'blink') {
        const col = p.glass ? '#bfe9ff' : '#b58cff', em = p.glass ? '#5ab8ff' : '#7b3dff';
        const mb = toon(col, { transparent: true, opacity: 0.9, emissive: new THREE.Color(em), emissiveIntensity: 0.5 });
        const mt = toon(p.glass ? '#ffffff' : '#e6d4ff', { transparent: true, opacity: 0.95, emissive: new THREE.Color(em), emissiveIntensity: 0.4 });
        body(mb, p.h); slab(mt);
        fade = [mb, mt];
        const ghost = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(p.w, p.h, p.d)), new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.35 }));
        ghost.position.y = -p.h / 2; g.add(ghost); g.userData.ghost = ghost;
      } else if (p.kind === 'crumble') {
        const mb = toon('#c9a27a', { transparent: true, opacity: 1 }), mt = toon('#e0c49a', { transparent: true, opacity: 1 });
        body(mb, p.h); slab(mt);
        // esquerdes
        const crack = new THREE.MeshBasicMaterial({ color: '#5a3c22' });
        for (let k = 0; k < 3; k++) { const c = new THREE.Mesh(new THREE.BoxGeometry(p.w * (0.4 + rr() * 0.5), 0.03, 0.08), crack); c.position.set((rr() - 0.5) * p.w * 0.5, 0.04, (rr() - 0.5) * p.d * 0.6); c.rotation.y = rr() * 3; g.add(c); }
        fade = [mb, mt];
      } else if (p.kind === 'spin') {
        body(M.spin, p.h); slab(M.spinTop, 0.16);
        const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.9, 6, 10), M.rock); hub.position.y = -3.4; g.add(hub);
      } else if (p.kind === 'pad') {
        if (p.mush) {
          const stem = new THREE.Mesh(new THREE.CylinderGeometry(p.w * 0.22, p.w * 0.3, 1.2, 10), M.mushStem); stem.position.y = -0.75; g.add(stem);
          const cap = new THREE.Mesh(new THREE.SphereGeometry(p.w * 0.62, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), M.mushCap); cap.scale.y = 0.45; cap.position.y = -0.25; g.add(cap);
          for (let k = 0; k < 6; k++) { const a = (k / 6) * Math.PI * 2; const d = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 4), M.dot); d.position.set(Math.cos(a) * p.w * 0.38, -0.06, Math.sin(a) * p.w * 0.38); d.scale.y = 0.4; g.add(d); }
          g.userData.cap = cap;
        } else {
          const disc = new THREE.Mesh(new THREE.CylinderGeometry(p.w * 0.5, p.w * 0.56, p.h, 24), M.pad); disc.position.y = -p.h / 2 + 0.02; g.add(disc);
        }
        const ring = new THREE.Mesh(new THREE.RingGeometry(p.w * 0.25, p.w * 0.42, 32), new THREE.MeshBasicMaterial({ color: p.mush ? '#ffd0e4' : '#fff1b0', transparent: true, opacity: 0.9, side: THREE.DoubleSide }));
        ring.rotation.x = -Math.PI / 2; ring.position.y = 0.05; g.add(ring); g.userData.ring = ring;
        for (let k = 0; k < 3; k++) { const c = new THREE.Mesh(new THREE.ConeGeometry(0.45, 0.5, 4), new THREE.MeshBasicMaterial({ color: p.mush ? '#ffb3d1' : '#ffe08a', transparent: true, opacity: 0.8 })); c.position.y = 0.6 + k * 0.7; g.add(c); (g.userData.chev ||= []).push(c); }
      }
      if (p.kind !== 'pad') addOutline(g);
      g.position.set(p.x, p.top, p.z);
      G.add(g);
      parts.push({ p, g, fade });
    }
    // portes de sortida i meta
    const CP = L.checkpoints, FIN = L.finish;
    const arch = (cp, color, wide) => {
      const g = new THREE.Group();
      const mat = toon(color, { emissive: new THREE.Color(color), emissiveIntensity: 0.25 });
      for (const dx of [-wide / 2, wide / 2]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 5.5, 10), mat); c.position.set(dx, 2.75, 0); c.castShadow = true; g.add(c); }
      const top = new THREE.Mesh(new THREE.BoxGeometry(wide + 1.6, 0.8, 0.9), mat); top.position.y = 5.7; g.add(top);
      const banner = new THREE.Mesh(new THREE.PlaneGeometry(wide - 1, 1.2), new THREE.MeshBasicMaterial({ color: '#ffffff', side: THREE.DoubleSide, transparent: true, opacity: 0.9 }));
      banner.position.y = 4.8; g.add(banner);
      addOutline(g);
      g.position.set(cp.x, cp.y, cp.z + (cp.i === 0 ? 4.5 : 0));
      G.add(g);
      return g;
    };
    arch(CP[0], T.accent, 9);
    const fin = arch(CP[FIN], '#ffd166', 8.5);
    const bigRing = new THREE.Mesh(new THREE.TorusGeometry(3.6, 0.22, 10, 48), new THREE.MeshBasicMaterial({ color: '#ffe9a0' }));
    bigRing.position.set(0, 9.5, 0); fin.add(bigRing); this.animated.push(bigRing); bigRing.userData.spin = 0.8;
    const fg = this.makeGlowSprite('#ffd166', 9); fg.position.set(0, 9.5, 0); fin.add(fg);
    // punts de control
    const cpRings = [];
    for (let i = 1; i < FIN; i++) {
      const c = CP[i];
      const g = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 3.2, 6), toon('#e8e2d0')); pole.position.set(Math.min(c.r * 0.7, 2.2), 1.6, 0); g.add(pole);
      const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.75), new THREE.MeshBasicMaterial({ color: '#7ef0ff', side: THREE.DoubleSide })); flag.position.set(Math.min(c.r * 0.7, 2.2) + 0.62, 2.8, 0); g.add(flag);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.13, 8, 36), new THREE.MeshBasicMaterial({ color: '#7ef0ff', transparent: true, opacity: 0.9 }));
      ring.position.y = 2.2; g.add(ring); this.animated.push(ring); ring.userData.spin = 1.2;
      const glow = this.makeGlowSprite('#7ef0ff', 4); glow.position.y = 2.2; g.add(glow);
      g.position.set(c.x, c.y, c.z);
      G.add(g);
      cpRings.push({ i, ring, flag, glow, done: false });
    }
    for (const r of L.rings) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(2.2, 0.16, 8, 40), new THREE.MeshBasicMaterial({ color: '#bff6ff', transparent: true, opacity: 0.75 }));
      ring.position.set(r.x, r.y, r.z); G.add(ring);
    }
    // corrents d'aire
    for (const u of L.updrafts) {
      const h = u.y1 - u.y0 + 2;
      const cyl = new THREE.Mesh(new THREE.CylinderGeometry(u.r, u.r * 1.1, h, 24, 1, true), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, uniforms: { uTime: UNI.uTime },
        vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
        fragmentShader: 'uniform float uTime; varying vec2 vUv; void main(){ float s = sin(vUv.x*37.7 + vUv.y*14.0 - uTime*7.0)*0.5+0.5; float a = s*0.32*smoothstep(0.0,0.12,vUv.y)*smoothstep(1.0,0.8,vUv.y); gl_FragColor = vec4(0.75,0.97,1.0,a); }' }));
      cyl.position.set(u.x, u.y0 + h / 2 - 1, u.z); G.add(cyl);
      for (let k = 0; k < 3; k++) { const ring = new THREE.Mesh(new THREE.TorusGeometry(u.r * 0.9, 0.06, 6, 32), new THREE.MeshBasicMaterial({ color: '#dffaff', transparent: true, opacity: 0.6 })); ring.rotation.x = Math.PI / 2; ring.position.set(u.x, u.y0, u.z); ring.userData.up = { y0: u.y0, h: u.y1 - u.y0, ph: k / 3 }; G.add(ring); (this._upRings ||= []).push(ring); }
    }
    for (const c of L.columns) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 2.2, c.top - L.killY + 26, 10), M.rock); col.position.set(c.x, (c.top + L.killY - 16) / 2, c.z); G.add(col);
    }
    const cloudMat = new THREE.MeshToonMaterial({ color: '#ffffff', gradientMap: grad, transparent: true, opacity: 0.85 });
    const zEnd = CP[FIN].z;
    for (let i = 0; i < 26; i++) {
      const c = new THREE.Mesh(new THREE.SphereGeometry(4 + rr() * 6, 10, 8), cloudMat);
      const side = rr() < 0.5 ? -1 : 1;
      c.position.set(CP[0].x + side * (22 + rr() * 40), CP[0].y - 14 - rr() * 18, CP[0].z - 20 + rr() * (zEnd - CP[0].z + 40)); c.scale.y = 0.45;
      G.add(c);
    }
    this.root.add(G);
    return { G, parts, cpRings, level };
  }
  // mou les plataformes, les fa aparèixer, desaparèixer, girar i caure
  updateCourse(t, myCp) {
    const C = this.courseData;
    if (!C || !C.G.visible) return;
    const st = {};
    for (const c of C.parts) {
      const p = c.p;
      if (p.move || p.blink || p.spin || p.crumble) {
        platformState(p, t, st);
        c.g.position.set(st.x, st.top, st.z);
        if (p.spin) c.g.rotation.y = st.a;
        if (p.blink) {
          const warn = st.on && st.k > 0.72;
          const op = st.on ? (warn ? 0.35 + 0.5 * (Math.sin(t * 30) * 0.5 + 0.5) : 0.92) : 0;
          for (const m of c.fade) { m.opacity = op; m.visible = op > 0.01; }
          c.g.children.forEach((ch) => { if (ch.userData.isOutline) ch.visible = st.on; });
          if (c.g.userData.ghost) c.g.userData.ghost.visible = !st.on;
        }
        if (p.crumble) {
          if (st.shake > 0) { c.g.position.x += (Math.random() - 0.5) * 0.12 * st.shake; c.g.position.z += (Math.random() - 0.5) * 0.12 * st.shake; }
          if (!st.on) { c.g.position.y -= Math.min(30, st.fall * st.fall * 9); }
          const op = st.on ? 1 : Math.max(0, 1 - st.fall * 1.2);
          for (const m of c.fade) { m.opacity = op; m.visible = op > 0.02; }
          c.g.children.forEach((ch) => { if (ch.userData.isOutline) ch.visible = op > 0.5; });
        }
      }
      if (p.kind === 'pad') {
        const k = (t * 1.6) % 1;
        if (c.g.userData.ring) c.g.userData.ring.scale.setScalar(1 + k * 0.6);
        if (c.g.userData.cap) c.g.userData.cap.scale.y = 0.45 + Math.sin(t * 5) * 0.03;
        (c.g.userData.chev || []).forEach((ch, i) => { ch.position.y = 0.6 + ((t * 1.4 + i / 3) % 1) * 2.4; ch.material.opacity = 0.9 * (1 - ((t * 1.4 + i / 3) % 1)); });
      }
    }
    for (const r of this._upRings || []) { if (!r.parent || !r.parent.visible) continue; const u = r.userData.up; const k = ((t * 0.5 + u.ph) % 1); r.position.y = u.y0 + k * u.h; r.material.opacity = 0.6 * (1 - k); }
    if (myCp !== undefined) for (const r of C.cpRings) {
      const done = myCp >= r.i;
      if (done !== r.done) { r.done = done; const col = done ? '#ffd166' : '#7ef0ff'; r.ring.material.color.set(col); r.flag.material.color.set(col); r.glow.material.color.set(col); }
    }
  }
}
