// ============================================================
//  Multijugador dins de Claude, sense servidor propi.
//  El navegador del líder fa de servidor (executa la simulació) i la resta
//  de jugadors s'hi connecten amb el codi de sala, a través de la capacitat
//  `room` de l'artifact (sales amb nom):
//   - líder → jugadors: paquets comprimits pel tema 'net' (10 per segon) amb
//     esdeveniments, instantànies, confirmacions i respostes.
//   - jugadors → líder: la `presence` de cada jugador (estat de moviment i una
//     cua de missatges que el líder confirma).
//  L'estat de la sala (membres, mode, xat) va a la `presence` del líder.
// ============================================================
import { Sim } from './sim.js';
import { MODES, CLASSES, MAX_PLAYERS, MAX_LEVEL, GAME_VERSION } from './data.js';
import { Emitter } from './net.js';
import { levelOk } from './parkour.js';

const CODE_CHARS = '0123456789';
const TOPIC = 'net';
const roomName = (code) => 'ct-' + String(code).toLowerCase();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const newCode = () => Array.from({ length: 4 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
const enc = new TextEncoder();
const bytes = (v) => enc.encode(JSON.stringify(v)).length;

// ---------------- compressió ----------------
const HAS_Z = typeof CompressionStream !== 'undefined' && typeof DecompressionStream !== 'undefined';
function b64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
function unb64(str) { const s = atob(str); const u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8; }
async function pack(obj) {
  const s = JSON.stringify(obj);
  if (!HAS_Z) return 'j' + s;
  const buf = await new Response(new Blob([s]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer();
  return 'z' + b64(new Uint8Array(buf));
}
async function unpack(str) {
  if (str[0] === 'j') return JSON.parse(str.slice(1));
  const txt = await new Response(new Blob([unb64(str.slice(1))]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  return JSON.parse(txt);
}
function split(str, size) { const out = []; for (let i = 0; i < str.length; i += size) out.push(str.slice(i, i + size)); return out.length ? out : ['']; }
// els fragments en base64 són ASCII; el JSON sense comprimir pot tenir accents i cometes escapades
const chunkSize = (str) => (str[0] === 'z' ? 3400 : 1100);

function roomError(e) {
  const c = e && e.code;
  if (e) console.warn('[sala]', c, e && e.message);
  if (c === 'not_permitted' || c === 'not_granted') return 'No tens permís per jugar en línia en aquest joc. Demana al propietari que te\'l comparteixi.';
  if (c === 'limit_reached') return 'Hi ha massa sales obertes en aquesta pàgina. Recarrega-la i torna-ho a provar.';
  return `No s'ha pogut connectar amb la sala. Torna-ho a provar d'aquí a un moment.${c ? ` (${c})` : ''}`;
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, ko) => setTimeout(() => ko({ code: 'timeout', message: 'sense resposta' }), ms))]);

// la capacitat `room` de l'artifact (null fora de Claude)
export async function artifactRoom() {
  try {
    if (!window.claude || typeof window.claude.use !== 'function') return null;
    return await window.claude.use('room');
  } catch { return null; }
}

// ============================================================
//  P2PNet: el mateix que RemoteServer (net.js), però per sales dins de Claude
// ============================================================
export class P2PNet extends Emitter {
  constructor(lobby) {
    super();
    this.lobby = lobby;
    this.online = true;
    this.p2p = true;
    this.id = null;
    this.nr = null; this.code = null;
    this.host = null;
    this.closed = false;
    this.disconnectMsg = 'El líder ha tancat la sala';
  }
  async connect() {}
  async hello() { this.serverVersion = GAME_VERSION; return GAME_VERSION; }

  // ---------------- sala amb nom ----------------
  async openRoom(code) {
    if (this.nr && this.code === code) return this.nr;
    await this.reset();
    this.code = code;
    this.nr = await withTimeout(this.lobby.join(roomName(code)), 15000);
    // primera llista de participants (m'hi inclou a mi)
    await new Promise((ok) => {
      let done = false;
      const fin = () => { if (!done) { done = true; ok(); } };
      const un = this.nr.onPeers(() => { setTimeout(() => { un(); fin(); }, 0); }, fin);
      setTimeout(fin, 5000);
    });
    const me = this.nr.peers().find((p) => p.sameTab);
    this.id = me ? me.peer : null;
    return this.nr;
  }
  hostPeer() {
    if (!this.nr) return null;
    return this.nr.peers().find((p) => !p.sameTab && p.kind !== 'agent' && p.presence && p.presence.role === 'host') || null;
  }
  async findHost(ms) {
    const t0 = Date.now();
    for (;;) {
      const h = this.hostPeer(); if (h) return h;
      if (Date.now() - t0 > ms) return null;
      await sleep(120);
    }
  }
  async reset() {
    if (this.host) { this.host.destroy(); this.host = null; }
    this.stopClient();
    if (this.nr) { const nr = this.nr; this.nr = null; try { await nr.leave(); } catch { /* res */ } }
    this.code = null;
  }

  async check(code) {
    try { await this.openRoom(code); } catch (e) { await this.reset(); return { ok: false, error: roomError(e) }; }
    const h = await this.findHost(4500);
    if (!h) { await this.reset(); return { ok: false, error: `No hi ha cap sala amb el codi ${code}. Revisa'l amb el teu amic: qui ha creat la sala ha de tenir el joc obert.` }; }
    const pr = h.presence;
    if (pr.v !== GAME_VERSION) { await this.reset(); return { ok: false, error: `La sala ${code} és d'una altra versió del joc (v${pr.v || '?'}). Recarregueu la pàgina tots dos.` }; }
    const R = pr.room || { members: [], max: MAX_PLAYERS };
    if (R.members.length >= R.max) { await this.reset(); return { ok: false, error: `La sala ${code} és plena (${R.members.length}/${R.max})` }; }
    return { ok: true, code, mode: R.mode, players: R.members.length, max: R.max, state: R.state };
  }

  async create(opts) {
    for (let tries = 0; tries < 4; tries++) {
      const code = newCode();
      try { await this.openRoom(code); } catch (e) { await this.reset(); return { ok: false, error: roomError(e) }; }
      if (await this.findHost(800)) { await this.reset(); continue; }
      // cal poder enviar pel tema de la partida
      try { await this.nr.emit(TOPIC, { k: -1 }); } catch (e) {
        await this.reset();
        return { ok: false, error: e && e.code === 'not_permitted'
          ? 'Amb el teu permís en aquest joc no pots crear sales. Entra a la sala d\'un amic amb el seu codi, o demana al propietari que et faci col·laborador.'
          : roomError(e) };
      }
      if (!this.id) { await this.reset(); return { ok: false, error: roomError(null) }; }
      this.host = new P2PHost(this, code, opts && opts.mode);
      return { ok: true, code, mode: this.host.mode };
    }
    return { ok: false, error: 'No s\'ha pogut crear la sala. Torna-ho a provar.' };
  }

  // ---------------- entrar a la sala ----------------
  async join(payload) {
    if (this.host) return this.host.localJoin(payload);
    const code = String(payload.code || '').toUpperCase();
    if (!this.nr || this.code !== code) { const c = await this.check(code); if (!c.ok) return c; }
    const h = this.hostPeer();
    if (!h) { await this.reset(); return { ok: false, error: 'La sala s\'ha tancat' }; }
    this.startClient(payload, h.peer);
    const t0 = Date.now();
    while (Date.now() - t0 < 9000) {
      const hp = this.hostPeer();
      if (!hp) break;
      const R = hp.presence.room;
      if (R && R.members.some((m) => m.id === this.id)) { this.onHostPresence(hp); return { ok: true, code: this.code, id: this.id, ...R }; }
      await sleep(150);
    }
    await this.reset();
    return { ok: false, error: 'No s\'ha pogut entrar: la sala és plena o el líder no respon.' };
  }
  enter(payload) {
    if (this.host) return Promise.resolve(this.host.input(this.id, 'enter', { save: payload.save, name: payload.name, cls: payload.cls, hero: payload.hero }));
    return this.request('enter', { save: payload.save, name: payload.name, cls: payload.cls, hero: payload.hero }, 15000)
      .then((r) => r || { ok: false, error: 'El líder no respon' });
  }
  roomMode(mode, level) { if (this.host) this.host.input(this.id, 'roomMode', { mode, level }); }
  roomStart() { return Promise.resolve(this.host ? this.host.input(this.id, 'roomStart', {}) : { ok: false, error: 'Només el líder pot començar la partida' }); }
  roomEnd() { if (this.host) this.host.input(this.id, 'roomEnd', {}); }
  roomBack() {
    if (this.host) { this.host.input(this.id, 'roomBack', {}); setTimeout(() => this.fire('roomLobby', {}), 0); return; }
    this.request('roomBack', {}, 8000).then(() => this.fire('roomLobby', {}));
  }
  roomChat(text) {
    if (this.host) this.host.input(this.id, 'roomChat', { text });
    else this.queueMsg('roomChat', { text });
  }
  send(type, data) {
    if (this.closed) return;
    if (this.host) { this.host.input(this.id, type, data); return; }
    if (!this.client) return;
    if (type === 'st') { this.setPresence({ st: { n: ++this.client.stN, s: data.s } }); return; }
    this.queueMsg(type, data);
  }
  close() { this.closed = true; this.reset(); }

  // ============================================================
  //  part de client
  // ============================================================
  startClient(payload, hostId) {
    this.stopClient();
    const sv = payload.save || {};
    this.client = {
      hostId, seqN: 0, outbox: [], inflight: [], reqN: 0, pending: new Map(), stN: 0,
      chain: Promise.resolve(), rx: Promise.resolve(), inbox: new Map(), nextK: null, gapT: 0, nackT: 0,
      lastRev: -1, lastState: null, lastEp: null, lastChat: 0, gone: false, missT: 0,
    };
    const C = this.client;
    this.setPresence({ role: 'client', v: GAME_VERSION, m: { name: String(sv.name || payload.name || 'Heroi').slice(0, 16), cls: sv.cls || payload.cls || 'foc', hero: sv.hero || payload.hero || 'heroi1', level: sv.level | 0 || 1 }, q: [], st: null });
    C.unNet = this.nr.on(TOPIC, (msg) => this.onNet(msg), () => this.lost());
    C.unPeers = this.nr.onPeers(() => {
      const h = this.hostPeer();
      if (!h || h.peer !== C.hostId) { if (!C.missT) C.missT = Date.now(); return; }
      C.missT = 0;
      this.onHostPresence(h);
    }, () => this.lost());
    C.timer = setInterval(() => this.clientTick(), 200);
  }
  stopClient() {
    const C = this.client; if (!C) return;
    this.client = null;
    try { C.unNet && C.unNet(); C.unPeers && C.unPeers(); } catch { /* res */ }
    clearInterval(C.timer);
    for (const ok of C.pending.values()) ok(null);
  }
  lost() {
    const C = this.client; if (!C || C.gone || this.closed) return;
    C.gone = true;
    this.fire('disconnect');
  }
  setPresence(patch) { if (this.nr) this.nr.presence(patch).catch((e) => console.warn('[sala] presence', e && (e.message || e.code))); }

  onHostPresence(h) {
    const C = this.client; if (!C) return;
    const pr = h.presence || {};
    const R = pr.room;
    if (R && R.rev !== C.lastRev) {
      C.lastRev = R.rev;
      const prev = C.lastState, prevEp = C.lastEp;
      C.lastState = R.state; C.lastEp = R.ep;
      const room = { code: R.code, mode: R.mode, level: R.level || 1, leader: R.leader, state: R.state, max: R.max, members: R.members };
      this.fire('room', room);
      if (prev === 'playing' && (R.state !== 'playing' || R.ep !== prevEp)) this.fire('roomLobby', {});
      if (prev !== null && R.state === 'playing' && (prev !== 'playing' || R.ep !== prevEp)) this.fire('roomStart', { mode: R.mode });
    }
    const chat = Array.isArray(pr.chat) ? pr.chat : [];
    for (const [n, name, text] of chat) if (n > C.lastChat) { C.lastChat = n; this.fire('roomChat', { name, text }); }
  }

  // ---- cap amunt: cua de missatges dins de la presence, fins que el líder els confirma
  request(type, data, ms) {
    const C = this.client; if (!C) return Promise.resolve(null);
    const rid = ++C.reqN;
    return new Promise((ok) => {
      C.pending.set(rid, ok);
      setTimeout(() => { if (C.pending.has(rid)) { C.pending.delete(rid); ok(null); } }, ms || 12000);
      this.queueMsg(type, data, rid);
    });
  }
  queueMsg(type, data, rid) {
    const C = this.client; if (!C) return;
    const msg = rid ? [type, data, rid] : [type, data];
    C.chain = C.chain.then(async () => {
      const s = JSON.stringify(msg);
      if (bytes(s) <= 1000) C.outbox.push(s);
      else { const p = await pack(msg); const parts = split(p, 900); parts.forEach((d, i) => C.outbox.push(`@${i}/${parts.length}:${d}`)); }
      this.flushUp();
    }).catch((e) => console.warn('[sala]', e));
  }
  flushUp() {
    const C = this.client; if (!C) return;
    let changed = false;
    while (C.outbox.length && bytes([...C.inflight, [C.seqN + 1, C.outbox[0]]]) <= 2700) { C.inflight.push([++C.seqN, C.outbox.shift()]); changed = true; }
    if (changed) this.setPresence({ q: C.inflight });
  }
  onAck(a) {
    const C = this.client; if (!C) return;
    const n = C.inflight.length;
    C.inflight = C.inflight.filter(([s]) => s > a);
    if (C.inflight.length !== n) { this.setPresence({ q: C.inflight }); this.flushUp(); }
  }

  // ---- cap avall: paquets del líder, en ordre
  onNet(msg) {
    const C = this.client; if (!C || msg.sameTab || msg.peer !== C.hostId) return;
    const d = msg.data;
    if (!d || typeof d.k !== 'number' || d.k < 0 || typeof d.d !== 'string' || !(d.n > 0) || !(d.i >= 0 && d.i < d.n)) return;
    if (C.nextK !== null && d.k < C.nextK) return;
    let e = C.inbox.get(d.k);
    if (!e) { e = { parts: new Array(d.n).fill(null), got: 0 }; C.inbox.set(d.k, e); }
    if (e.parts[d.i] === null) { e.parts[d.i] = d.d; e.got++; }
    this.pump();
  }
  complete(k) { const e = this.client.inbox.get(k); return !!e && e.got === e.parts.length; }
  pump() {
    const C = this.client; if (!C) return;
    if (C.nextK === null) {
      const ks = [...C.inbox.keys()].filter((k) => this.complete(k));
      if (!ks.length) return;
      C.nextK = Math.min(...ks);
      for (const k of [...C.inbox.keys()]) if (k < C.nextK) C.inbox.delete(k);
    }
    while (this.complete(C.nextK)) {
      const str = C.inbox.get(C.nextK).parts.join('');
      C.inbox.delete(C.nextK); C.nextK++; C.gapT = 0;
      C.rx = C.rx.then(() => unpack(str)).then((pkt) => this.onPacket(pkt)).catch((err) => console.warn('[sala] paquet', err));
    }
  }
  clientTick() {
    const C = this.client; if (!C) return;
    // el líder ha marxat (es dona un marge per si és una reconnexió)
    if (C.missT && Date.now() - C.missT > 4000) { const h = this.hostPeer(); if (h && h.peer === C.hostId) C.missT = 0; else return this.lost(); }
    // el líder no envia res (pestanya amagada o connexió aturada)
    if (C.lastPkt && Date.now() - C.lastPkt > 3500 && !C.stallWarned) { C.stallWarned = true; this.fire('warn', 'La partida s\'ha aturat: el líder té el joc amagat o s\'ha desconnectat. Espera un moment…'); }
    if (C.nextK === null) return;
    // falta algun paquet: el demana de nou i, si no arriba, el salta
    const later = [...C.inbox.keys()].filter((k) => k > C.nextK);
    if (!later.length) { C.gapT = 0; return; }
    const now = Date.now();
    if (!C.gapT) C.gapT = now;
    if (now - C.gapT > 2500) {
      const ks = later.filter((k) => this.complete(k));
      if (ks.length) { C.nextK = Math.min(...ks); for (const k of [...C.inbox.keys()]) if (k < C.nextK) C.inbox.delete(k); C.gapT = 0; this.pump(); }
      return;
    }
    if (now - C.gapT > 250 && now - C.nackT > 500) {
      C.nackT = now;
      const miss = []; const max = Math.max(...later);
      for (let k = C.nextK; k <= max && miss.length < 8; k++) if (!this.complete(k)) miss.push(k);
      if (miss.length) this.queueMsg('nack', { k: miss });
    }
  }
  onPacket(pkt) {
    const C = this.client; if (!C || !pkt) return;
    C.lastPkt = Date.now(); C.stallWarned = false;
    const me = this.id;
    if (pkt.a && pkt.a[me]) this.onAck(pkt.a[me]);
    if (pkt.r && pkt.r[me]) for (const [rid, res] of pkt.r[me]) { const ok = C.pending.get(rid); if (ok) { C.pending.delete(rid); ok(res); } }
    const inGame = Array.isArray(pkt.g) && pkt.g.includes(me);
    const evs = [];
    if (inGame && pkt.b) for (const e of pkt.b) evs.push(e);
    if (pkt.t && pkt.t[me]) for (const e of pkt.t[me]) evs.push(e);
    if (evs.length) this.fire('ev', evs);
    if (inGame && pkt.s && pkt.s[me]) this.fire('snap', pkt.s[me]);
  }
}

// ============================================================
//  P2PHost: la sala i la partida, al navegador del líder (com server.js)
// ============================================================
class P2PHost {
  constructor(net, code, mode) {
    this.net = net; this.nr = net.nr; this.code = code; this.id = net.id;
    this.mode = MODES[mode] && MODES[mode].multi ? mode : 'coop';
    this.level = 1;
    this.max = MAX_PLAYERS;
    this.members = new Map();
    this.leader = this.id;
    this.state = 'lobby'; this.ep = 0; this.rev = 0;
    this.sim = null;
    this.inGame = new Set();
    this.localQ = [];
    this.pend = { b: [], t: {} };
    this.lastSeq = new Map(); this.stN = new Map(); this.parts = new Map(); this.chains = new Map();
    this.acks = {}; this.replies = {}; this.dirty = false;
    this.chat = []; this.chatN = 0;
    this.k = 0; this.sent = []; this.sendQ = Promise.resolve();
    this.n = 0;
    this.unPeers = this.nr.onPeers((c) => this.onPeers(c), () => this.net.fire('disconnect'));
    this.timer = setInterval(() => this.tick(), 50);
    this.publish();
  }
  destroy() {
    this.dead = true;
    clearInterval(this.timer);
    try { this.unPeers(); } catch { /* res */ }
    if (this.sim) { try { this.sim.flushSaves(true); } catch { /* res */ } }
    this.sim = null;
  }

  roomState() {
    return { code: this.code, mode: this.mode, level: this.level, leader: this.leader, state: this.state, max: this.max, rev: this.rev, ep: this.ep,
      members: [...this.members.values()].map((m) => ({ id: m.id, name: m.name, cls: m.cls, hero: m.hero, level: m.level, inGame: this.inGame.has(m.id) })) };
  }
  publish() {
    this.rev++;
    const st = this.roomState();
    this.nr.presence({ role: 'host', v: GAME_VERSION, room: st, chat: this.chat.slice(-6) }).catch((e) => console.warn('[sala] presence', e && (e.message || e.code)));
    const { rev, ep, ...pub } = st;
    this.net.fire('room', pub);
  }

  // ---------------- participants ----------------
  onPeers(change) {
    for (const p of change.left) if (this.members.has(p.peer)) this.removeMember(p.peer);
    for (const p of change.peers) {
      if (p.sameTab || p.kind === 'agent') continue;
      const pr = p.presence || {};
      if (pr.role !== 'client' || pr.v !== GAME_VERSION) continue;
      if (!this.members.has(p.peer)) {
        if (this.members.size >= this.max) continue;
        const m = pr.m || {};
        this.members.set(p.peer, { id: p.peer, name: String(m.name || 'Heroi').replace(/[<>]/g, '').slice(0, 16) || 'Heroi', cls: CLASSES[m.cls] ? m.cls : 'foc', hero: /^heroi[1-3]$/.test(m.hero) ? m.hero : 'heroi1', level: Math.max(1, Math.min(MAX_LEVEL, m.level | 0 || 1)) });
        this.publish();
      }
      // missatges nous de la cua
      const last = this.lastSeq.get(p.peer) || 0;
      if (Array.isArray(pr.q)) {
        for (const ent of pr.q) {
          if (!Array.isArray(ent) || typeof ent[0] !== 'number' || ent[0] <= (this.lastSeq.get(p.peer) || 0) || typeof ent[1] !== 'string') continue;
          this.lastSeq.set(p.peer, ent[0]);
          this.entry(p.peer, ent[1]);
        }
      }
      const now = this.lastSeq.get(p.peer) || 0;
      if (now !== last) { this.acks[p.peer] = now; this.dirty = true; }
      // posició i animació
      if (pr.st && pr.st.n !== this.stN.get(p.peer)) {
        this.stN.set(p.peer, pr.st.n);
        if (this.sim && this.inGame.has(p.peer) && Array.isArray(pr.st.s)) { try { this.sim.input(p.peer, 'st', { s: pr.st.s }); } catch (e) { console.error('[input]', e); } }
      }
    }
  }
  entry(peer, str) {
    let job;
    if (str[0] === '@') {
      const m = /^@(\d+)\/(\d+):([\s\S]*)$/.exec(str); if (!m) return;
      const i = +m[1], n = +m[2];
      if (i === 0) this.parts.set(peer, []);
      const arr = this.parts.get(peer); if (!arr) return;
      arr.push(m[3]);
      if (i < n - 1) return;
      this.parts.delete(peer);
      const full = arr.join('');
      job = async () => this.handle(peer, await unpack(full));
    } else job = () => this.handle(peer, JSON.parse(str));
    const prev = this.chains.get(peer) || Promise.resolve();
    this.chains.set(peer, prev.then(job).catch((e) => console.warn('[sala] missatge', e)));
  }
  handle(peer, msg) {
    if (!Array.isArray(msg) || !this.members.has(peer)) return;
    const [type, data, rid] = msg;
    const res = this.input(peer, String(type), data && typeof data === 'object' ? data : {});
    if (rid) { (this.replies[peer] ||= []).push([rid, res || { ok: true }]); this.dirty = true; }
  }
  removeMember(id) {
    this.leaveGame(id);
    this.members.delete(id);
    this.lastSeq.delete(id); this.stN.delete(id); this.parts.delete(id); this.chains.delete(id);
    delete this.acks[id]; delete this.replies[id];
    this.publish();
  }

  // ---------------- ordres (del líder o dels jugadors) ----------------
  input(id, type, data) {
    switch (type) {
      case 'enter': return this.enter(id, data);
      case 'roomMode':
        if (id === this.leader && this.state === 'lobby' && MODES[data.mode] && MODES[data.mode].multi) { this.mode = data.mode; if (data.level) this.level = levelOk(data.level); this.publish(); }
        return null;
      case 'roomStart': return this.start(id);
      case 'roomEnd': if (id === this.leader && this.sim) this.endGame(); return null;
      case 'roomBack': this.leaveGame(id); return { ok: true };
      case 'roomChat': {
        const text = String(data.text || '').slice(0, 140).trim();
        const m = this.members.get(id);
        if (text && m) { this.chat.push([++this.chatN, m.name, text]); if (this.chat.length > 12) this.chat.shift(); this.publish(); this.net.fire('roomChat', { name: m.name, text }); }
        return null;
      }
      case 'nack': this.resend(Array.isArray(data.k) ? data.k.slice(0, 8) : []); return null;
      case 'st': case 'act': case 'chat': case 'shop': case 'npc': case 'inv': case 'respawn': case 'match':
        if (this.sim && this.inGame.has(id)) { try { this.sim.input(id, type, data); } catch (e) { console.error('[input]', e); } }
        return null;
    }
    return null;
  }
  localJoin(payload) {
    const sv = payload.save || {};
    this.members.set(this.id, { id: this.id, name: String(sv.name || payload.name || 'Heroi').slice(0, 16), cls: sv.cls || payload.cls || 'foc', hero: sv.hero || payload.hero || 'heroi1', level: sv.level | 0 || 1 });
    this.publish();
    const { rev, ep, ...st } = this.roomState();
    return Promise.resolve({ ok: true, id: this.id, ...st });
  }
  start(id) {
    if (id !== this.leader) return { ok: false, error: 'Només el líder pot començar la partida' };
    if (this.state !== 'lobby') return { ok: false, error: 'La partida ja ha començat' };
    if (MODES[this.mode].kind === 'pvp' && this.members.size < 2) return { ok: false, error: 'Per a aquest mode cal com a mínim 2 jugadors' };
    this.sim = new Sim({ mode: this.mode, seed: Math.floor(Math.random() * 1e9), expect: this.members.size, level: this.level, onEvent: (t, d, to) => this.route(t, d, to) });
    this.state = 'playing'; this.ep++;
    this.inGame.clear(); this.pend = { b: [], t: {} }; this.localQ = [];
    this.publish();
    setTimeout(() => this.net.fire('roomStart', { mode: this.mode }), 0);
    return { ok: true };
  }
  enter(id, data) {
    const m = this.members.get(id);
    if (!m) return { ok: false, error: 'No ets dins de la sala' };
    if (!this.sim) return { ok: false, error: 'La partida encara no ha començat' };
    if (this.inGame.has(id)) return { ok: false, error: 'Ja ets a la partida' };
    this.inGame.add(id);
    this.sim.addPlayer(id, { save: data.save, name: data.name, cls: data.cls, hero: data.hero });
    const p = this.sim.players.get(id);
    if (p) { m.name = p.name; m.cls = p.cls; m.level = p.save.level; }
    this.publish();
    return { ok: true, code: this.code, mode: this.mode, id };
  }
  leaveGame(id) {
    if (!this.sim || !this.inGame.has(id)) return;
    try { this.sim.flushSaves(true); } catch { /* res */ }
    this.flush();
    this.sim.removePlayer(id);
    this.inGame.delete(id);
    if (this.inGame.size === 0) this.endGame();
    else this.publish();
  }
  endGame() {
    if (this.sim) { try { this.sim.flushSaves(true); } catch { /* res */ } this.flush(); }
    const hostWasIn = this.inGame.has(this.id);
    this.sim = null; this.state = 'lobby';
    this.inGame.clear(); this.pend = { b: [], t: {} }; this.localQ = [];
    this.publish();
    if (hostWasIn) setTimeout(() => this.net.fire('roomLobby', {}), 0);
  }
  route(type, data, to) {
    if (type === 'save' && to) { const m = this.members.get(to); if (m && m.level !== data.level) { m.level = data.level; this.publish(); } }
    if (to === this.id) { if (this.inGame.has(this.id)) this.localQ.push([type, data]); return; }
    if (to) { if (this.inGame.has(to)) (this.pend.t[to] ||= []).push([type, data]); return; }
    if (this.inGame.has(this.id)) this.localQ.push([type, data]);
    this.pend.b.push([type, data]);
  }

  // ---------------- bucle ----------------
  tick() {
    this.n++;
    if (this.sim) { try { this.sim.tick(0.05); } catch (e) { console.error('[sim]', e); } }
    if (this.sim && this.inGame.has(this.id)) {
      if (this.localQ.length) { const q = this.localQ; this.localQ = []; this.net.fire('ev', q); }
      if (this.n % 2 === 0) this.net.fire('snap', this.sim.snapshot(this.id));
    }
    if (this.n % 20 === 0 && this.members.size > 1) this.dirty = true; // batec: torna a enviar les confirmacions
    if (this.n % 2 === 0) this.flush();
  }
  flush() {
    const remote = [...this.inGame].filter((id) => id !== this.id);
    if (!remote.length && !this.dirty && !Object.keys(this.replies).length) { this.pend = { b: [], t: {} }; return; }
    const pkt = { g: remote, a: { ...this.acks }, r: this.replies };
    if (remote.length && this.sim) {
      pkt.b = this.pend.b; pkt.t = this.pend.t; pkt.s = {};
      for (const id of remote) pkt.s[id] = this.sim.snapshot(id);
    }
    this.pend = { b: [], t: {} }; this.replies = {}; this.dirty = false;
    this.sendPacket(pkt);
  }
  sendPacket(pkt) {
    this.sendQ = this.sendQ.then(async () => {
      const k = ++this.k;
      const str = await pack(pkt);
      const chunks = split(str, chunkSize(str));
      this.sent.push({ k, chunks }); if (this.sent.length > 60) this.sent.shift();
      this.emitChunks(k, chunks);
    }).catch((e) => console.warn('[sala] enviar', e));
  }
  emitChunks(k, chunks) {
    if (this.dead) return;
    chunks.forEach((d, i) => { this.nr.emit(TOPIC, { k, i, n: chunks.length, d }).catch((e) => { if (e && e.code !== 'upstream_error') console.warn('[sala] emit', e.code || e); }); });
  }
  resend(ks) {
    for (const k of ks) { const s = this.sent.find((x) => x.k === k); if (s) this.emitChunks(s.k, s.chunks); }
  }
}
