// ============================================================
//  Animacions procedurals per a criatures sense animacions pròpies
//  (el drac): rotacions en l'espai del model aplicades sobre una
//  postura base. El model mira cap a +Z; X = costat esquerre; Y = amunt.
// ============================================================
import * as THREE from 'three';

const AX = { x: new THREE.Vector3(1, 0, 0), y: new THREE.Vector3(0, 1, 0), z: new THREE.Vector3(0, 0, 1) };
const D2R = Math.PI / 180;
const sm = (t) => t * t * (3 - 2 * t);

// envolupant: punts [[t, v], ...] interpolats suaument
export function env(t, pts) {
  if (t <= pts[0][0]) return pts[0][1];
  for (let i = 0; i < pts.length - 1; i++) {
    const [t0, v0] = pts[i], [t1, v1] = pts[i + 1];
    if (t <= t1) return v0 + (v1 - v0) * sm((t - t0) / Math.max(1e-6, t1 - t0));
  }
  return pts[pts.length - 1][1];
}

export class ProcRig {
  // root: arrel del model; baseClip/baseTime: postura de partida
  constructor(root, baseClip, baseTime = 0) {
    this.root = root;
    this.bones = [];
    root.traverse((o) => { if (o.isBone) this.bones.push(o); });
    const saved = this.bones.map((b) => [b.quaternion.clone(), b.position.clone(), b.scale.clone()]);
    if (baseClip) {
      const mixer = new THREE.AnimationMixer(root);
      const a = mixer.clipAction(baseClip); a.play(); mixer.setTime(baseTime);
      a.stop(); mixer.uncacheRoot(root);
    }
    root.updateMatrixWorld(true);
    const rootQi = root.getWorldQuaternion(new THREE.Quaternion()).invert();
    const rootInv = root.matrixWorld.clone().invert();
    // alçada del model en l'espai de l'arrel (per expressar desplaçaments com a fracció)
    const box = new THREE.Box3().setFromObject(root, true);
    const rs = root.getWorldScale(new THREE.Vector3());
    this.H = (box.max.y - box.min.y) / (rs.y || 1);
    this.base = new Map();
    for (const b of this.bones) {
      // matriu lineal: vector en l'espai del model -> espai local del pare
      const pm = new THREE.Matrix4().multiplyMatrices(rootInv, b.parent.matrixWorld).invert();
      this.base.set(b, {
        q: b.quaternion.clone(), p: b.position.clone(), s: b.scale.clone(),
        rs: rootQi.clone().multiply(b.getWorldQuaternion(new THREE.Quaternion())),
        lin: new THREE.Matrix3().setFromMatrix4(pm),
      });
    }
    // deixa el model en la postura base
    void saved;
  }
  find(re) { return this.bones.find((b) => re.test(b.name)); }

  // spec(t, out): out.push([bone, eix ('x'|'y'|'z'), graus]) per a cada fotograma;
  // [bone, 'px'|'py'|'pz', fracció de l'alçada] desplaça l'os en l'espai del model
  clip(name, dur, spec, { fps = 30, loop = false } = {}) {
    const n = Math.max(2, Math.round(dur * fps) + 1);
    const times = new Float32Array(n);
    for (let i = 0; i < n; i++) times[i] = (i / (n - 1)) * dur;
    const touched = new Map(); // bone -> Float32Array
    const moved = new Map();   // bone -> Float32Array (posicions)
    const out = [];
    const rot = new THREE.Quaternion(), tmp = new THREE.Quaternion(), v = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      out.length = 0;
      spec(times[i], out);
      const acc = new Map(), off = new Map();
      for (const [bone, axis, deg] of out) {
        if (!bone || !deg) continue;
        if (axis[0] === 'p') {
          let o = off.get(bone); if (!o) off.set(bone, o = new THREE.Vector3());
          o[axis[1]] += deg * this.H;
          continue;
        }
        let q = acc.get(bone); if (!q) acc.set(bone, q = new THREE.Quaternion());
        rot.setFromAxisAngle(AX[axis], deg * D2R);
        q.premultiply(rot);
      }
      for (const [bone] of off) if (!moved.has(bone)) {
        const arr = new Float32Array(n * 3), bp = this.base.get(bone).p;
        for (let j = 0; j < i; j++) bp.toArray(arr, j * 3);
        moved.set(bone, arr);
      }
      for (const [bone, arr] of moved) {
        const b = this.base.get(bone);
        const o = off.get(bone);
        v.copy(b.p);
        if (o) v.add(o.clone().applyMatrix3(b.lin));
        v.toArray(arr, i * 3);
      }
      for (const [bone] of acc) if (!touched.has(bone)) {
        const arr = new Float32Array(n * 4), bq = this.base.get(bone).q;
        for (let j = 0; j < i; j++) bq.toArray(arr, j * 4);
        touched.set(bone, arr);
      }
      for (const [bone, arr] of touched) {
        const b = this.base.get(bone);
        const q = acc.get(bone);
        if (q) {
          // rotació en l'espai del model aplicada a l'os: local * inv(rs) * R * rs
          tmp.copy(b.rs).invert().multiply(q).multiply(b.rs);
          rot.copy(b.q).multiply(tmp);
        } else rot.copy(b.q);
        rot.toArray(arr, i * 4);
      }
    }
    // els ossos tocats només en alguns fotogrames tenen la base als altres (ja inclosa)
    const tracks = [];
    for (const [bone, arr] of touched) tracks.push(new THREE.QuaternionKeyframeTrack(`${bone.name}.quaternion`, times, arr));
    // la resta d'ossos queden fixos a la postura base
    const t2 = new Float32Array([0, dur]);
    for (const [bone, arr] of moved) tracks.push(new THREE.VectorKeyframeTrack(`${bone.name}.position`, times, arr));
    for (const bone of this.bones) {
      const b = this.base.get(bone);
      if (!touched.has(bone)) tracks.push(new THREE.QuaternionKeyframeTrack(`${bone.name}.quaternion`, t2, [...b.q.toArray(), ...b.q.toArray()]));
      if (!moved.has(bone)) tracks.push(new THREE.VectorKeyframeTrack(`${bone.name}.position`, t2, [...b.p.toArray(), ...b.p.toArray()]));
    }
    const c = new THREE.AnimationClip(name, dur, tracks);
    c.userData = { loop };
    return c;
  }
}

// ---------------------------------------------------------------- drac
export function dragonClips(root, roarClip) {
  const R = new ProcRig(root, roarClip, 0.05);
  const B = (re) => R.find(re);
  const sp3 = B(/^Spine_3_/), sp2 = B(/^Spine_2_/), sp1 = B(/^Spine_1_/);
  const nk2 = B(/^Neck_2_/), nk1 = B(/^Neck_1_/), head = B(/^Head_/), jaw = B(/^Bone006_/);
  const tail = [B(/^Tail_1_/), B(/^Tail_2_/), B(/^Tail_3_/), B(/^Tail_4_/)];
  const thL = B(/^Thighs_L_/), thR = B(/^Thighs_R_/), shL = B(/^Shin_L_/), shR = B(/^Shin_R_/);
  const a1L = B(/^Arm1_L_/), a1R = B(/^Arm1_R_/), a2L = B(/^Arm2_L_/), a2R = B(/^Arm2_R_/);
  const TAU = Math.PI * 2;
  const clips = {};

  clips.idle = R.clip('idle', 3.2, (t, o) => {
    const ph = (t / 3.2) * TAU, s = Math.sin(ph);
    o.push([sp2, 'x', -1.5 * s], [nk2, 'x', 3 * s], [nk1, 'x', -2 * s], [head, 'y', 7 * Math.sin(ph * 0.5)], [jaw, 'x', 4 + 3 * s]);
    tail.forEach((b, i) => o.push([b, 'y', 7 * Math.sin(ph - i * 0.7)]));
    o.push([a1L, 'z', 3 * s], [a1R, 'z', -3 * s]);
  }, { loop: true });

  clips.walk = R.clip('walk', 1.5, (t, o) => {
    const ph = (t / 1.5) * TAU, s = Math.sin(ph), c = Math.cos(ph);
    o.push([thL, 'x', -26 * s], [thR, 'x', 26 * s], [shL, 'x', 16 * Math.max(0, -c)], [shR, 'x', 16 * Math.max(0, c)]);
    o.push([sp3, 'y', 5 * s], [sp3, 'z', 3 * s], [sp2, 'x', 2.5 * Math.sin(ph * 2)], [nk2, 'y', -5 * s], [head, 'x', 4 * Math.sin(ph * 2)]);
    tail.forEach((b, i) => o.push([b, 'y', 12 * Math.sin(ph - i * 0.8)]));
    o.push([a1L, 'z', 12 * s], [a1R, 'z', 12 * s], [a2L, 'x', 8 * c], [a2R, 'x', -8 * c]);
  }, { loop: true });

  clips.bite = R.clip('bite', 1.4, (t, o) => {
    const up = env(t, [[0, 0], [0.5, 1], [0.62, -1], [0.8, -1], [1.4, 0]]);
    const open = env(t, [[0, 0], [0.45, 1], [0.6, 1], [0.66, 0], [1.4, 0]]);
    o.push([nk2, 'x', -24 * up], [nk1, 'x', -12 * up], [head, 'x', -10 * up], [sp2, 'x', -6 * up], [jaw, 'x', 30 * open]);
    o.push([thL, 'x', 8 * up], [thR, 'x', 8 * up]);
  });

  clips.breath = R.clip('breath', 2.8, (t, o) => {
    const up = env(t, [[0, 0], [0.6, 1], [0.9, -0.6], [2.3, -0.6], [2.8, 0]]);
    const sweep = env(t, [[0, 0], [0.8, -1], [2.2, 1], [2.8, 0]]);
    const open = env(t, [[0, 0], [0.7, 1], [2.3, 1], [2.6, 0]]);
    o.push([nk2, 'x', -26 * up], [nk1, 'x', -10 * up], [head, 'x', -8 * up], [sp2, 'x', -8 * up]);
    o.push([nk2, 'y', 22 * sweep], [nk1, 'y', 14 * sweep], [head, 'y', 8 * sweep], [jaw, 'x', 32 * open]);
    o.push([a1L, 'z', -10 * open], [a1R, 'z', 10 * open]);
  });

  clips.tail = R.clip('tail', 1.6, (t, o) => {
    const body = env(t, [[0, 0], [0.45, -1], [0.75, 1.2], [1.6, 0]]);
    o.push([sp3, 'y', 28 * body], [sp2, 'y', 10 * body], [nk2, 'y', -12 * body]);
    tail.forEach((b, i) => o.push([b, 'y', -(16 + i * 6) * body]));
  });

  clips.hit = R.clip('hit', 0.6, (t, o) => {
    const k = env(t, [[0, 0], [0.12, 1], [0.6, 0]]);
    o.push([sp2, 'x', -6 * k], [nk2, 'x', -14 * k], [head, 'z', 8 * k], [jaw, 'x', 15 * k]);
  });

  clips.death = R.clip('death', 2.2, (t, o) => {
    const k = env(t, [[0, 0], [0.3, -0.15], [1.4, 1], [2.2, 1]]);
    o.push([sp3, 'z', 70 * k], [sp2, 'z', 10 * k], [nk2, 'x', 28 * k], [nk1, 'x', 20 * k], [head, 'z', 25 * k], [jaw, 'x', 20 * k]);
    tail.forEach((b, i) => o.push([b, 'z', 6 * k * (i + 1)]));
    o.push([a1L, 'z', -30 * k], [a1R, 'z', 20 * k], [thL, 'x', -20 * k], [thR, 'x', 15 * k]);
  });

  if (roarClip) { clips.roar = roarClip; }
  clips.headBone = head;
  return clips;
}

// ---------------------------------------------------------------- gòlem
// Model amb esquelet d'Advanced Skeleton (Root_M, Chest_M, Shoulder_R...). Mira cap a +Z.
// En repòs té els braços penjant amb els punys de roca a prop de terra.
export function golemClips(root, ownClips = []) {
  const R = new ProcRig(root, null);
  const B = (re) => R.find(re);
  const rootB = B(/^Root_M/), sp1 = B(/^Spine1_M/), chest = B(/^Chest_M/), neck = B(/^Neck_M/), head = B(/^Head_M/), jaw = B(/^Jaw_M/);
  // Costat esquerre del personatge = +X (mira cap a +Z).
  const shL = B(/^Shoulder_L/), shR = B(/^Shoulder_R/), elL = B(/^Elbow_L/), elR = B(/^Elbow_R/), wrL = B(/^Wrist_L/), wrR = B(/^Wrist_R/);
  const hipL = B(/^Hip_L/), hipR = B(/^Hip_R/), knL = B(/^Knee_L/), knR = B(/^Knee_R/), anL = B(/^Ankle_L/), anR = B(/^Ankle_R/);
  const TAU = Math.PI * 2;
  const clips = {};
  const ARM_FIX = 24; // el braç dret (costat -X) en repòs queda massa obert
  const _clip = R.clip.bind(R);
  R.clip = (name, dur, spec, opts) => _clip(name, dur, (t, o) => { o.push([shR, 'z', ARM_FIX]); spec(t, o); }, opts);

  clips.idle = R.clip('idle', 3.4, (t, o) => {
    const ph = (t / 3.4) * TAU, s = Math.sin(ph);
    o.push([chest, 'x', 2.5 * s], [sp1, 'x', 1.2 * s], [neck, 'x', -2 * s], [head, 'y', 6 * Math.sin(ph * 0.5)]);
    o.push([shL, 'z', 3 + 2 * s], [shR, 'z', -3 - 2 * s], [elL, 'x', -4 * s], [elR, 'x', -4 * s]);
    o.push([rootB, 'py', -0.006 * (1 - Math.cos(ph))], [knL, 'x', 2 * (1 - Math.cos(ph))], [knR, 'x', 2 * (1 - Math.cos(ph))], [hipL, 'x', -1.5 * (1 - Math.cos(ph))], [hipR, 'x', -1.5 * (1 - Math.cos(ph))]);
  }, { loop: true });

  // caminar feixuc: passes llargues, tronc que balanceja i braços que pengen i oscil·len
  clips.walk = R.clip('walk', 1.5, (t, o) => {
    const ph = (t / 1.5) * TAU, s = Math.sin(ph), c = Math.cos(ph);
    o.push([hipL, 'x', -24 * s], [hipR, 'x', 24 * s]);
    o.push([knL, 'x', 30 * Math.max(0, c)], [knR, 'x', 30 * Math.max(0, -c)]);
    o.push([anL, 'x', -8 * s], [anR, 'x', 8 * s]);
    o.push([rootB, 'py', -0.02 * Math.abs(Math.sin(ph))], [rootB, 'z', 4 * s], [rootB, 'y', -5 * s]);
    o.push([sp1, 'x', 6], [chest, 'y', 7 * s], [chest, 'z', -3 * s], [head, 'y', -5 * s], [neck, 'x', -4]);
    o.push([shL, 'x', 20 * s], [shR, 'x', -20 * s], [elL, 'x', -10 - 8 * Math.max(0, s)], [elR, 'x', -10 - 8 * Math.max(0, -s)]);
    o.push([shL, 'z', 6], [shR, 'z', -6]);
  }, { loop: true });

  // cop de puny doble: aixeca els braços per sobre del cap i els estavella a terra
  clips.slam = R.clip('slam', 1.7, (t, o) => {
    const up = env(t, [[0, 0], [0.55, 1], [0.7, 1.05], [0.82, -0.55], [1.15, -0.5], [1.7, 0]]);
    const crouch = env(t, [[0, 0], [0.5, -0.3], [0.85, 1], [1.2, 0.9], [1.7, 0]]);
    o.push([shL, 'x', -150 * Math.max(0, up) + 40 * Math.min(0, up)], [shR, 'x', -150 * Math.max(0, up) + 40 * Math.min(0, up)]);
    o.push([shL, 'z', 12 * Math.max(0, up)], [shR, 'z', -12 * Math.max(0, up)], [elL, 'x', -40 * Math.max(0, up)], [elR, 'x', -40 * Math.max(0, up)]);
    o.push([chest, 'x', -18 * Math.max(0, up) + 30 * Math.max(0, crouch)], [sp1, 'x', 14 * Math.max(0, crouch)], [neck, 'x', -10 * Math.max(0, crouch)]);
    o.push([rootB, 'py', -0.07 * Math.max(0, crouch)], [hipL, 'x', -22 * Math.max(0, crouch)], [hipR, 'x', -22 * Math.max(0, crouch)], [knL, 'x', 34 * Math.max(0, crouch)], [knR, 'x', 34 * Math.max(0, crouch)], [anL, 'x', -12 * Math.max(0, crouch)], [anR, 'x', -12 * Math.max(0, crouch)]);
    o.push([jaw, 'x', 18 * Math.max(0, crouch)]);
  });

  // cop de revés amb el puny dret
  clips.swipe = R.clip('swipe', 1.3, (t, o) => {
    const k = env(t, [[0, 0], [0.45, -1], [0.62, 1], [0.85, 1], [1.3, 0]]);
    o.push([chest, 'y', 32 * k], [sp1, 'y', 10 * k], [rootB, 'y', 8 * k]);
    o.push([shR, 'z', -60 * Math.max(0, -k) - 70 * Math.max(0, k)], [shR, 'x', -30 * Math.max(0, k)], [elR, 'x', -30 * Math.max(0, -k)]);
    o.push([shL, 'z', 10 * Math.max(0, k)], [hipL, 'x', -10 * Math.abs(k)], [knL, 'x', 10 * Math.abs(k)]);
  });

  clips.roar = R.clip('roar', 1.8, (t, o) => {
    const k = env(t, [[0, 0], [0.4, 1], [1.4, 1], [1.8, 0]]);
    const sh = Math.sin(t * 40) * 1.5 * k;
    o.push([chest, 'x', -16 * k], [neck, 'x', -14 * k], [head, 'x', -10 * k + sh], [jaw, 'x', 25 * k]);
    o.push([shL, 'z', 55 * k], [shR, 'z', -55 * k], [elL, 'x', -50 * k], [elR, 'x', -50 * k]);
  });

  clips.hit = R.clip('hit', 0.6, (t, o) => {
    const k = env(t, [[0, 0], [0.12, 1], [0.6, 0]]);
    o.push([chest, 'x', -10 * k], [head, 'x', -12 * k], [shL, 'z', 12 * k], [shR, 'z', -12 * k], [rootB, 'x', -4 * k]);
  });

  // cau de genolls i s'esfondra endavant
  clips.death = R.clip('death', 2.4, (t, o) => {
    const k1 = env(t, [[0, 0], [0.8, 1], [2.4, 1]]);
    const k2 = env(t, [[0, 0], [0.7, 0], [1.6, 1], [2.4, 1]]);
    o.push([rootB, 'py', -0.24 * k1 - 0.12 * k2], [hipL, 'x', -55 * k1], [hipR, 'x', -50 * k1], [knL, 'x', 100 * k1], [knR, 'x', 95 * k1], [anL, 'x', -30 * k1], [anR, 'x', -30 * k1]);
    o.push([rootB, 'x', 55 * k2], [chest, 'x', 25 * k1], [neck, 'x', 15 * k2], [head, 'z', 12 * k2]);
    o.push([shL, 'z', 25 * k1], [shR, 'z', -15 * k1], [shL, 'x', -30 * k2], [shR, 'x', -40 * k2]);
  });

  clips.spawn = R.clip('spawn', 1.6, (t, o) => {
    const k = env(t, [[0, 1], [1.2, 0], [1.6, 0]]);
    o.push([rootB, 'py', -0.3 * k], [hipL, 'x', -55 * k], [hipR, 'x', -55 * k], [knL, 'x', 100 * k], [knR, 'x', 100 * k], [chest, 'x', 30 * k]);
  });

  for (const c of ownClips) clips['own:' + c.name] = c;
  return clips;
}
