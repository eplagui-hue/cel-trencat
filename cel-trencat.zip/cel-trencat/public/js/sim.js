// ============================================================
//  Simulació del joc (servidor autoritatiu). S'executa al
//  servidor Node (multijugador) o al navegador (solitari).
// ============================================================
import {
  ABILITIES, CLASSES, ENEMIES, VARIANTS, computeStats, buildCustomAbility, makeItem, XP_TABLE, MAX_LEVEL,
  MODES, BOSS_ORDER, RUNES, validRunes, applyRunes, MAX_LOADOUTS, MAX_GRIMORI, abilityFor, slotChoices, activeSlots, effectsOf, powerMult,
  STORY, BOUNTIES, SHOP, SKINS, NPCS, newCharacter,
} from './data.js';
import { canLearn, sanitizeSkills, skillNode } from './skills.js';
import { getLevel, levelOk, LEVELS, RACE_LIMIT } from './parkour.js';
import {
  getWorld, groundAt, height, CAMPS, ISLAND, ISLANDS, CHESTS, WAYSTONES, LAUNCHPADS, ARENA_SPAWNS, collide,
  mulberry32, zoneAt, WORLD, islandTop, STRUCTURES,
} from './worldgen.js';

const TAU = Math.PI * 2;
// enemics normals (no caps): més ràpids, més forts i més agressius
const HILL_R = 8;
const FIERCE = { hp: 1.25, dmg: 1.25, speed: 1.22, windup: 0.9, recover: 0.85, aggro: 1.2 };
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const dist2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const dist3 = (a, b) => Math.hypot(a.x - b.x, (a.y - b.y) * 0.7, a.z - b.z);
const r2 = (v) => Math.round(v * 100) / 100;
const angleTo = (a, b) => Math.atan2(b.x - a.x, b.z - a.z);
const angDiff = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };

export const ANIM_CODES = ['idle', 'move', 'windup', 'recover', 'hit', 'dead', 'spawn', 'stun', 'return', 'cast'];

export class Sim {
  constructor(opts = {}) {
    this.mode = MODES[opts.mode] ? opts.mode : 'coop';
    const M = MODES[this.mode];
    this.isPvp = M.kind === 'pvp'; this.isPve = M.kind === 'pve'; this.isStory = M.kind === 'story'; this.isRace = M.kind === 'race';
    this.hasEnemies = !this.isPvp && !this.isRace;
    this.level = levelOk(opts.level); // nivell de parkour
    this.emitFn = opts.onEvent || (() => {});
    this.expect = Math.max(1, opts.expect | 0 || 1); // jugadors que s'esperen (sala multijugador)
    this.rng = mulberry32((opts.seed || Date.now()) & 0xffffffff);
    this.t = 0;
    this.players = new Map();
    this.enemies = new Map();
    this.projs = new Map();
    this.fields = [];
    this.pending = [];
    this.loot = new Map();
    this.nextId = 1;
    this.world = getWorld();
    this.camps = [];
    this.chestOpened = new Map(); // playerId -> {chestId: time}
    this.pvp = { scores: {}, target: M.target || 5, roundEnd: 0, teams: {}, zone: 0, nextTeam: 1 };
    this.match = this.isPve || this.isRace ? { state: 'wait' } : null;
    if (this.isStory) this.initCamps();
    this.saveDirty = new Set();
    this.lastSaveFlush = 0;
  }

  id() { return this.nextId++; }
  emit(type, data, to = null) { this.emitFn(type, data, to); }

  // ------------------------------------------------------------------ camps
  initCamps() {
    CAMPS.forEach((c, ci) => {
      const camp = { idx: ci, def: c, members: [], respawn: c.respawn || 45 };
      this.camps.push(camp);
      for (const [type, n, variant] of c.list) for (let i = 0; i < n; i++) this.spawnEnemy(type, camp, variant, i, n);
    });
  }

  spawnEnemy(type, camp, variant, i = 0, n = 1, at = null, opts = {}) {
    const def = ENEMIES[type];
    const c = camp ? camp.def : null;
    let x, z;
    if (at) { x = at.x; z = at.z; } else {
      const a = (i / Math.max(1, n)) * TAU + this.rng() * 0.8;
      const d = n > 1 ? c.r * (0.35 + this.rng() * 0.6) : 0;
      x = c.x + Math.cos(a) * d; z = c.z + Math.sin(a) * d;
    }
    const island = at ? at.island : c && c.island;
    const y = island ? islandTop(ISLAND[island], x, z) : height(x, z);
    const lvl = (opts.lvl || (c ? c.lvl : 1));
    const vdef = (VARIANTS[def.model] && variant && VARIANTS[def.model][variant]) || { mult: 1, name: '' };
    const party = Math.max(1, this.players.size);
    const pm = def.boss ? 1 + 0.75 * (party - 1) : 1 + 0.3 * (party - 1);
    const fm = def.boss ? 1 : FIERCE.hp;
    const maxHp = Math.round(def.hp * (1 + 0.17 * (lvl - 1)) * vdef.mult * pm * fm * (opts.hpMult || 1));
    const e = {
      id: this.id(), type, def, variant: variant || null, vname: vdef.name, el: vdef.el || def.el || (def.ranged && def.ranged.el) || null,
      lvl, x, y, z, ry: this.rng() * TAU, hp: maxHp, maxHp, dmg: def.dmg * (1 + 0.12 * (lvl - 1)) * Math.sqrt(vdef.mult) * (def.boss ? 1 : FIERCE.dmg),
      state: def.anims && def.anims.spawn && !def.boss ? 'spawn' : 'idle', stateT: this.t + (def.anims && def.anims.spawn && !def.boss ? 1.6 : 0),
      target: null, home: { x, z }, camp, island, alive: true, statuses: {}, poise: 0, atk: null, atkCd: this.t + 1 + this.rng(),
      aggroR: opts.aggro || (c && c.aggro) || def.aggro, hpMult: opts.hpMult || 1, boss: !!def.boss, phase: 1, pattern: 0, summoned: !!opts.summoned, owner: opts.owner || null, wanderT: this.t + this.rng() * 4,
      dmgBy: new Map(), lastHit: 0, anim: 0, engaged: false,
    };
    this.enemies.set(e.id, e);
    if (camp) camp.members.push(e);
    this.emit('espawn', this.enemyInfo(e));
    return e;
  }

  enemyInfo(e) {
    return { id: e.id, type: e.type, v: e.variant, lvl: e.lvl, boss: e.boss, name: e.def.name + (e.vname ? ' ' + e.vname : ''), maxHp: e.maxHp, s: e.state, x: r2(e.x), y: r2(e.y), z: r2(e.z), ry: r2(e.ry) };
  }

  // ------------------------------------------------------------------ players
  addPlayer(id, join) {
    let save = sanitizeSave(join && join.save, join && join.cls, join && join.hero, join && join.name);
    const p = {
      id, name: save.name, cls: save.cls, hero: save.hero, save, team: 0,
      x: 0, y: 2.5, z: 12, ry: Math.PI, anim: 'idle', flags: 0, hp: 1, mana: 1, stats: null,
      dead: false, respawnT: 0, statuses: {}, buffs: {}, transform: null, aura: 0, cds: {}, combo: 0, comboT: 0,
      poise: 0, invuln: 0, lastSt: this.t, allowJump: 0, potionCd: 0, lastDmgT: -99, kills: 0, deaths: 0,
      blocking: false, lastSave: 0, inArena: false,
    };
    this.players.set(id, p);
    this.recalc(p, true);
    if (this.isPvp) {
      if (this.mode === 'ffa') p.team = this.pvp.nextTeam++;
      else { const counts = [0, 0]; for (const q of this.players.values()) if (q !== p && q.team) counts[q.team - 1]++; p.team = counts[0] <= counts[1] ? 1 : 2; }
      this.pvp.scores[p.team] = this.pvp.scores[p.team] || 0;
      this.placeAtArena(p);
    } else if (this.isPve) {
      this.placeInArena(p);
      if (this.match.state === 'wait') this.startCountdown(this.expect > 1 ? 10 : 4);
    } else if (this.isRace) {
      p.cp = 0; p.finishT = null; p.place = 0;
      this.placeAtCheckpoint(p, 0);
      if (this.match.state === 'wait') this.startCountdown(this.expect > 1 ? 10 : 3);
    } else {
      const w = WAYSTONES[0];
      p.x = w.x + (this.rng() - 0.5) * 6; p.z = w.z + 4 + (this.rng() - 0.5) * 4; p.y = height(p.x, p.z);
      // reescalar enemics per al nombre de jugadors
      this.rescaleEnemies();
    }
    this.emit('pjoin', this.playerInfo(p));
    this.emit('welcome', { id, mode: this.mode, t: this.t, save: p.save, x: p.x, y: p.y, z: p.z, team: p.team,
      players: [...this.players.values()].map((q) => this.playerInfo(q)),
      enemies: [...this.enemies.values()].filter((e) => e.alive).map((e) => this.enemyInfo(e)),
      loot: [...this.loot.values()].map((l) => this.lootInfo(l)), fields: this.fields.map((f) => this.fieldInfo(f)),
      pvp: this.isPvp ? this.pvpInfo() : null, match: this.isPve || this.isRace ? this.matchInfo() : null,
    }, id);
    return p;
  }

  playerInfo(p) {
    return { id: p.id, name: p.name, cls: p.cls, hero: p.hero, level: p.save.level, team: p.team, skins: p.save.skins, x: r2(p.x), y: r2(p.y), z: r2(p.z), maxHp: p.stats.maxHp, hp: Math.round(p.hp) };
  }

  removePlayer(id) {
    const p = this.players.get(id);
    if (!p) return;
    this.players.delete(id);
    this.emit('pleave', { id });
    if (this.hasEnemies) this.rescaleEnemies();
    if (this.isPve && this.match && this.match.state !== 'over' && this.players.size && [...this.players.values()].every((q) => q.dead)) this.endMatch(false);
    if (this.isRace && this.match && this.match.state === 'running' && this.players.size && [...this.players.values()].every((q) => q.finishT !== null)) this.endMatch(true);
  }

  rescaleEnemies() {
    const party = Math.max(1, this.players.size);
    for (const e of this.enemies.values()) {
      if (!e.alive || e.engaged) continue;
      const vdef = (VARIANTS[e.def.model] && e.variant && VARIANTS[e.def.model][e.variant]) || { mult: 1 };
      const pm = e.boss ? 1 + 0.75 * (party - 1) : 1 + 0.3 * (party - 1);
      const maxHp = Math.round(e.def.hp * (1 + 0.17 * (e.lvl - 1)) * vdef.mult * pm * (e.boss ? 1 : FIERCE.hp) * (e.hpMult || 1));
      const f = e.hp / e.maxHp; e.maxHp = maxHp; e.hp = maxHp * f;
    }
  }

  recalc(p, full = false) {
    const pvp = this.isPvp;
    const st = computeStats(p.cls, pvp ? 10 : p.save.level, p.save.talents, pvp ? {} : p.save.equip, { pvp, skills: p.save.skills });
    p.eff = effectsOf(p.save, pvp);
    // Forma Titànica: multiplica totes les estadístiques (el dany es multiplica a part)
    const tr = p.transform && p.transform.until > this.t ? p.transform : null;
    if (tr && tr.statMult) {
      const m = tr.statMult;
      st.maxHp = Math.round(st.maxHp * m); st.def = Math.round(st.def * m); st.crit = Math.min(75, st.crit * m);
      st.speed *= m; st.hpRegen *= m; st.manaRegen *= m; st.maxMana = Math.round(st.maxMana * m);
      st.poderShown = Math.round(st.poder * m);
    }
    const oldMax = p.stats ? p.stats.maxHp : st.maxHp;
    p.stats = st;
    if (full) { p.hp = st.maxHp; p.mana = st.maxMana; } else { p.hp = Math.min(st.maxHp, p.hp * st.maxHp / oldMax); p.mana = Math.min(p.mana, st.maxMana); }
  }

  slotAbilities(p) {
    const c = CLASSES[p.cls];
    void c;
    return activeSlots(p.save, this.isPvp);
  }

  abilityDef(p, key) {
    return abilityFor(p.save, key, { noSkills: this.isPvp });
  }

  // ------------------------------------------------------------------ input
  input(id, type, m) {
    const p = this.players.get(id);
    if (!p || !m) return;
    switch (type) {
      case 'st': return this.onState(p, m);
      case 'act': return this.onAction(p, m);
      case 'chat': {
        const text = String(m.text || '').slice(0, 160).trim();
        if (text) this.emit('chat', { id: p.id, name: p.name, text });
        return;
      }
      case 'shop': return this.onShop(p, m);
      case 'npc': return this.onNpc(p, m);
      case 'inv': return this.onInventory(p, m);
      case 'respawn': return this.onRespawn(p);
      case 'match': {
        // tornar a jugar una partida acabada
        if (this.isRace && this.match && this.match.state === 'over' && m.a === 'restart') {
          // es pot tornar a jugar el mateix nivell o passar a un altre
          if (m.level && levelOk(m.level) !== this.level) { this.level = levelOk(m.level); this.emit('pkLevel', { level: this.level }); }
          for (const q of this.players.values()) { q.cp = 0; q.finishT = null; q.place = 0; this.placeAtCheckpoint(q, 0); }
          this.startCountdown(5);
          return;
        }
        if (this.isPve && this.match && this.match.state === 'over' && m.a === 'restart') {
          for (const id of [...this.loot.keys()]) { this.loot.delete(id); this.emit('unloot', { id }); }
          for (const q of this.players.values()) { if (q.dead) { q.dead = false; this.emit('prespawn', { id: q.id, hp: 1 }); } this.recalc(q, true); q.statuses = {}; q.buffs = {}; q.transform = null; q.aura = 0; this.placeInArena(q); this.sendMe(q); }
          this.startCountdown(5);
        }
        return;
      }
      default:
    }
  }

  onState(p, m) {
    if (!Array.isArray(m.s)) return;
    const [x, y, z, ry, anim, flags] = m.s;
    if (![x, y, z, ry].every(Number.isFinite)) return;
    if (p.dead) return;
    const dt = Math.max(0.03, this.t - p.lastSt);
    const d = Math.hypot(x - p.x, z - p.z);
    const maxD = (p.stats.speed * 2.2 + 6) * dt + 3;
    if (d > maxD && this.t > p.allowJump) {
      // moviment impossible: corregeix
      this.emit('tp', { x: p.x, y: p.y, z: p.z }, p.id);
    } else {
      p.x = x; p.y = y; p.z = z;
    }
    p.ry = ry; p.anim = String(anim || 'idle').slice(0, 16); p.flags = flags | 0; p.lastSt = this.t;
    p.blocking = !!(p.flags & 4);
    if (p.flags & 8) p.invuln = Math.max(p.invuln, this.t + 0.12);
    // parkour: si caus, tornes a l'últim punt de control
    if (this.isRace) { if (p.y < this.course.killY - 3 && this.t > p.allowJump) this.placeAtCheckpoint(p, p.cp || 0); return; }
    // caure al mar o fora del món
    if (p.y < -6 && this.t > p.allowJump) this.fallReset(p);
  }

  fallReset(p) {
    let best = null, bd = 1e9;
    for (const w of WAYSTONES) {
      if (!p.save.waystones.includes(w.id) && w.id !== 'vila') continue;
      const d = Math.hypot(p.x - w.x, p.z - w.z); if (d < bd) { bd = d; best = w; }
    }
    if (this.isPvp) return this.placeAtArena(p);
    if (this.isPve) { this.placeInArena(p); return this.damagePlayer(p, p.stats.maxHp * 0.1, null, 'fisic', { noPoise: true, fall: true }); }
    const w = best || WAYSTONES[0];
    const y = w.island ? ISLAND[w.island].top : height(w.x, w.z);
    this.teleport(p, w.x + 2, y + 0.5, w.z + 2);
    this.damagePlayer(p, p.stats.maxHp * 0.1, null, 'fisic', { noPoise: true, fall: true });
  }

  teleport(p, x, y, z) {
    p.x = x; p.y = y; p.z = z; p.allowJump = this.t + 1.5;
    this.emit('tp', { x, y, z }, p.id);
  }

  onAction(p, m) {
    if (p.dead) return;
    const k = m.k;
    if (k === 'pkReset') { if (this.isRace && this.t > p.allowJump - 1.2) this.placeAtCheckpoint(p, p.cp || 0); return; }
    if (k === 'potion') return this.usePotion(p, m.kind);
    if (k === 'interact') return this.interact(p, m);
    if (k === 'revive') return this.revive(p, m.target);
    if (k === 'dodge') {
      p.invuln = this.t + 0.55;
      if (p.eff && p.eff.sp.has('dodgeshock') && this.t > (p.dodgeShockT || 0)) {
        p.dodgeShockT = this.t + 2.5;
        this.later(0.2, () => { if (p.dead) return; this.emit('nova', { p: p.id, key: 'dodge', el: 'llamp', fx: 'nova', r: 4.5, x: r2(p.x), y: r2(p.y), z: r2(p.z) }); this.aoe(p, p, 4.5, 30 * powerMult(p.stats.poder), 'llamp', { stun: { dur: 0.8 } }, {}); });
      }
      return;
    }
    const stunned = p.statuses.stun > this.t || p.statuses.freeze > this.t;
    if (stunned) return this.emit('deny', { msg: 'Estàs atordit!' }, p.id);
    let key;
    if (k === 'basic') key = CLASSES[p.cls].basic;
    else if (k === 'ab') { const slots = this.slotAbilities(p); key = slots[clamp(m.slot | 0, 0, 3)]; }
    else if (k === 'ult') key = CLASSES[p.cls].ult;
    else return;
    const ab = this.abilityDef(p, key);
    if (!ab) return;
    const now = this.t;
    if ((p.cds[key] || 0) > now + 0.08) return this.emit('deny', { msg: 'Encara no està llest', key }, p.id);
    if (ab.kind === 'transform') {
      if (p.aura < 100) return this.emit('deny', { msg: 'L\'aura encara no està carregada' }, p.id);
      if (p.transform && p.transform.until > now) return;
    }
    const cost = ab.mana || 0;
    if (p.mana < cost) return this.emit('deny', { msg: CLASSES[p.cls].melee ? 'No tens prou energia' : 'No tens prou manà', key }, p.id);
    p.mana -= cost;
    const haste = p.buffs.haste && p.buffs.haste.until > now ? p.buffs.haste.amt : 0;
    let cd = ab.cd * (1 - p.stats.cdr / 100);
    if (k === 'basic') cd *= (1 - haste);
    p.cds[key] = now + cd;
    // direcció d'apuntat
    let aim = Array.isArray(m.aim) && m.aim.length === 3 ? m.aim.map(Number) : [Math.sin(p.ry), 0, Math.cos(p.ry)];
    const al = Math.hypot(aim[0], aim[1], aim[2]) || 1; aim = aim.map((v) => v / al);
    let tgt = Array.isArray(m.tgt) && m.tgt.length === 3 ? m.tgt.map(Number) : [p.x + aim[0] * 10, p.y, p.z + aim[2] * 10];
    if (Array.isArray(m.pos) && m.pos.length === 3 && m.pos.every(Number.isFinite) && Math.hypot(m.pos[0] - p.x, m.pos[2] - p.z) < 4) {
      p.x = m.pos[0]; p.y = m.pos[1]; p.z = m.pos[2];
    }
    let comboStep = null;
    if (ab.kind === 'melee') {
      const trs = p.transform && p.transform.until > now && p.transform.statMult ? 1 / (1 + (p.transform.statMult - 1) * 0.5) : 1;
      if (ab.single) {
        comboStep = ab.combo[0];
        p.cds[key] = now + Math.max(cd, comboStep.time * trs);
      } else {
        if (now - p.comboT > 1.15) p.combo = 0;
        comboStep = ab.combo[p.combo % ab.combo.length];
        p.cds[key] = now + comboStep.time * (1 - haste * 0.6) * trs;
        p.combo = (p.combo + 1) % ab.combo.length; p.comboT = now;
      }
    }
    this.emit('cast', { p: p.id, key, ab: ab.custom ? ab : undefined, step: comboStep ? ab.combo.indexOf(comboStep) : undefined, aim: aim.map(r2), tgt: tgt.map(r2), x: r2(p.x), y: r2(p.y), z: r2(p.z) });
    const rel = (comboStep ? comboStep.release : ab.release) || 0;
    this.later(rel, () => this.release(p, key, ab, aim, tgt, comboStep));
  }

  later(dt, fn) { this.pending.push({ t: this.t + dt, fn }); }

  // ------------------------------------------------------------------ release
  release(p, key, ab, aim, tgt, step) {
    if (!this.players.has(p.id) || p.dead) return;
    const tr = p.transform && p.transform.until > this.t ? p.transform : null;
    const mult = (tr ? tr.dmgMult : 1);
    const origin = { x: p.x + aim[0] * 0.6, y: p.y + 1.35, z: p.z + aim[2] * 0.6 };
    const pw = p.stats.poder;
    const hb = p.buffs.haste && p.buffs.haste.until > this.t ? (p.buffs.haste.dmg || 0) : 0;
    const scale = (base) => base * powerMult(pw) * mult * (1 + hb);
    const flatAim = (() => { const l = Math.hypot(aim[0], aim[2]) || 1; return [aim[0] / l, 0, aim[2] / l]; })();
    switch (ab.kind) {
      case 'projectile': {
        const fen = (tr && tr.ab === 'fenix' && key === CLASSES[p.cls].basic) ? 3 : 1;
        const n = Math.max(fen, ab.multi || 1);
        const pd = ab.multi ? ab.multiDmg || 0.55 : 1;
        for (let i = 0; i < n; i++) {
          const spread = (i - (n - 1) / 2) * (ab.multi ? 0.2 : 0.12);
          const ca = Math.cos(spread), sa = Math.sin(spread);
          const d = [aim[0] * ca - aim[2] * sa, aim[1], aim[0] * sa + aim[2] * ca];
          this.spawnProj({ owner: p, team: p.team, x: origin.x, y: origin.y, z: origin.z, dir: d, speed: ab.speed, range: ab.range, radius: ab.radius,
            dmg: scale(ab.dmg) * pd, el: ab.el, status: ab.status, pierce: ab.pierce, explode: ab.explode, fx: ab.fx, key, leech: ab.leech,
            groundFire: ab.groundFire ? { ...ab.groundFire, dmg: scale(ab.groundFire.dmg) } : null, shards: ab.shards || 0 });
        }
        break;
      }
      case 'hitscan': this.hitscan(p, origin, aim, ab, scale(ab.dmg)); break;
      // (les runes vampíriques es passen a cada impacte amb o.leech)
      case 'ground': {
        let tx = tgt[0], tz = tgt[2];
        const d = Math.hypot(tx - p.x, tz - p.z);
        if (d > ab.range) { tx = p.x + (tx - p.x) / d * ab.range; tz = p.z + (tz - p.z) / d * ab.range; }
        const ty = groundAt(tx, tz, p.y + 4);
        const hits = ab.hits || 1;
        const pts = [];
        for (let i = 0; i < hits; i++) {
          const ox = i === 0 ? 0 : (this.rng() - 0.5) * ab.radius * 1.2, oz = i === 0 ? 0 : (this.rng() - 0.5) * ab.radius * 1.2;
          pts.push([r2(tx + ox), r2(ty), r2(tz + oz)]);
        }
        this.emit('ground', { p: p.id, key, el: ab.el, fx: ab.fx, r: ab.radius, delay: ab.delay, interval: ab.interval || 0, pts });
        pts.forEach((pt, i) => this.later(ab.delay + i * (ab.interval || 0), () => {
          this.aoe(p, { x: pt[0], y: pt[1], z: pt[2] }, ab.radius, scale(ab.dmg), ab.el, ab.status, { knock: 4, leech: ab.leech });
          if (ab.aftershock) {
            const c = { x: pt[0], y: pt[1], z: pt[2] };
            const near = this.targetsNear(p, c, 12).filter((t) => Math.hypot(t.x - c.x, t.z - c.z) > ab.radius * 0.6).slice(0, 3);
            for (const t of near) {
              this.emit('zap', { p: p.id, el: 'llamp', fx: 'chain', pts: [[pt[0], r2(pt[1] + 1), pt[2]], [r2(t.x), r2(t.y + (t.def ? t.def.height * 0.55 : 1)), r2(t.z)]] });
              this.damage(p, t, scale(ab.dmg) * 0.4, 'llamp', { shock: { dur: 0.8 } }, { leech: ab.leech });
            }
          }
        }));
        break;
      }
      case 'nova': {
        const hits = ab.hits || 1;
        for (let i = 0; i < hits; i++) this.later(i * (ab.interval || 0), () => {
          if (p.dead) return;
          this.emit('nova', { p: p.id, key, el: ab.el, fx: ab.fx, r: ab.radius, x: r2(p.x), y: r2(p.y), z: r2(p.z) });
          this.aoe(p, p, ab.radius, scale(ab.dmg), ab.el, ab.status, { knock: ab.knock || 0, from: p, leech: ab.leech });
        });
        if (ab.selfShield) { p.buffs.shield = { amt: ab.selfShield + pw * 1.5, until: this.t + 5, reflect: 0, el: ab.el }; this.emit('buff', { p: p.id, key, buff: 'shield', dur: 5, el: ab.el }); this.sendMe(p); }
        break;
      }
      case 'field': {
        let tx = tgt[0], tz = tgt[2];
        const d = Math.hypot(tx - p.x, tz - p.z);
        if (d > ab.range) { tx = p.x + (tx - p.x) / d * ab.range; tz = p.z + (tz - p.z) / d * ab.range; }
        if (ab.follow) { tx = p.x; tz = p.z; }
        this.addField(p, tx, ab.follow ? p.y : groundAt(tx, tz, p.y + 4), tz, { r: ab.radius, dur: ab.dur, tick: ab.tick, dmg: scale(ab.dmg), el: ab.el, status: ab.status, fx: ab.fx, leech: ab.leech,
          follow: !!ab.follow, pull: ab.pull || 0, endDmg: ab.explodeEnd ? scale(ab.explodeEnd.dmg) : 0, endR: ab.explodeEnd ? ab.explodeEnd.r : 0 });
        break;
      }
      case 'beam': {
        const L = ab.range, W = ab.width || 1.4;
        const ox = p.x, oz = p.z;
        const mid = { x: ox + flatAim[0] * L / 2, y: p.y, z: oz + flatAim[2] * L / 2 };
        for (const t of this.targetsNear(p, mid, L / 2 + 3)) {
          const rx = t.x - ox, rz = t.z - oz;
          const along = rx * flatAim[0] + rz * flatAim[2];
          if (along < 0 || along > L) continue;
          const perp = Math.abs(rx * flatAim[2] - rz * flatAim[0]);
          if (perp > W + (t.def ? t.def.radius : 0.4) || Math.abs(t.y - p.y) > 6) continue;
          this.damage(p, t, scale(ab.dmg), ab.el, ab.status, { knock: 2, from: p, leech: ab.leech });
        }
        this.emit('beam', { p: p.id, el: ab.el, w: W, from: [r2(origin.x), r2(origin.y), r2(origin.z)], to: [r2(ox + flatAim[0] * L), r2(origin.y), r2(oz + flatAim[2] * L)] });
        break;
      }
      case 'dash':
      case 'blink': {
        const start = { x: p.x, y: p.y, z: p.z };
        const end = { x: p.x + flatAim[0] * ab.dist, z: p.z + flatAim[2] * ab.dist };
        p.allowJump = this.t + 1.2;
        this.emit('dash', { p: p.id, key, el: ab.el, fx: ab.fx, kind: ab.kind, from: [r2(start.x), r2(start.y), r2(start.z)], to: [r2(end.x), r2(end.z)] });
        if (ab.kind === 'blink') {
          this.later(0.08, () => this.aoe(p, { x: end.x, y: groundAt(end.x, end.z, p.y + 3), z: end.z }, ab.radius, scale(ab.dmg), ab.el, ab.status, { leech: ab.leech }));
          if (ab.startBurst) {
            this.emit('nova', { p: p.id, key, el: ab.el, fx: 'nova', r: ab.radius, x: r2(start.x), y: r2(start.y), z: r2(start.z) });
            this.aoe(p, start, ab.radius, scale(ab.dmg) * 0.7, ab.el, ab.status, { leech: ab.leech });
          }
        } else {
          if (ab.fireTrail) {
            const ft = ab.fireTrail;
            for (let i = 0; i < 3; i++) {
              const k = (i + 0.5) / 3; const x = start.x + (end.x - start.x) * k, z = start.z + (end.z - start.z) * k;
              this.later(0.1 + i * 0.05, () => this.addField(p, x, groundAt(x, z, p.y + 3), z, { r: ft.r, dur: ft.dur, tick: ft.tick, dmg: scale(ft.dmg), el: ab.el, status: { burn: { dur: 2, dps: 6 } }, fx: 'flames', leech: ab.leech }));
            }
          }
          // dany al llarg del recorregut
          const steps = 6;
          for (let i = 1; i <= steps; i++) this.later(i * 0.05, () => {
            const t = i / steps; const pt = { x: start.x + (end.x - start.x) * t, y: p.y, z: start.z + (end.z - start.z) * t };
            this.aoe(p, pt, ab.radius, scale(ab.dmg) / 2.2, ab.el, ab.status, { once: `dash${key}${Math.floor(this.t)}`, leech: ab.leech });
          });
        }
        p.invuln = this.t + 0.35;
        break;
      }
      case 'buff': {
        const until = this.t + ab.dur;
        if (ab.buff === 'shield') p.buffs.shield = { amt: ab.amount + pw * ab.scale, until, reflect: ab.reflect, el: ab.el };
        if (ab.buff === 'haste') p.buffs.haste = { amt: ab.amount, until, dmg: ab.dmgBoost || 0 };
        if (ab.buff === 'guard') { p.buffs.guard = { amt: ab.amount, until }; this.healPlayer(p, p.stats.maxHp * (ab.heal || 0)); this.taunt(p, 14); }
        this.emit('buff', { p: p.id, key, buff: ab.buff, dur: ab.dur, el: ab.el });
        this.sendMe(p);
        break;
      }
      case 'transform': {
        p.aura = 0;
        const sm = ab.statMult ? (p.eff && p.eff.sp.has('titanrage') ? 1.75 : ab.statMult) : 0;
        p.transform = { until: this.t + ab.dur, ab: key, def: ab, dmgMult: sm || ab.dmgMult || 1, defMult: sm ? 1 : (ab.defMult || 1), speedMult: ab.speedMult || 1, statMult: sm, nextStrike: this.t + 0.5, nextAura: this.t, nextFreeze: this.t + 3, nextMeteor: this.t + 1 };
        if (sm) this.recalc(p);
        this.emit('transform', { p: p.id, key, dur: ab.dur, el: ab.el });
        this.healPlayer(p, p.stats.maxHp * 0.25);
        this.sendMe(p);
        break;
      }
      case 'melee': {
        const s = step || ab.combo[0];
        const fwd = Math.atan2(flatAim[0], flatAim[2]);
        const hits = s.hits || 1;
        const stepIdx = ab.combo.indexOf(s);
        const strike = (hi) => {
          if (p.dead) return;
          let hitAny = false;
          for (const t of this.targetsNear(p, p, s.range + 1.6)) {
            const d = dist2(p, t); const rad = (t.def ? t.def.radius : 0.5);
            if (d > s.range + rad) continue;
            if (Math.abs(angDiff(fwd, angleTo(p, t))) > (s.arc / 2) * Math.PI / 180 && d > 1.2 + rad) continue;
            let dmg = scale(s.dmg);
            if (s.execute && t.maxHp && t.hp / t.maxHp < s.execute) dmg *= 2;
            this.damage(p, t, dmg, ab.meleeEl || 'fisic', ab.status || null, { knock: (hi === hits - 1 ? s.knock : 0) || 1.2, heavy: !!s.knock, leech: ab.leech });
            hitAny = true;
          }
          this.emit('slash', { p: p.id, step: hits > 1 ? hi % 2 : stepIdx, big: s.big ? 1 : 0, hit: hitAny, x: r2(p.x), y: r2(p.y), z: r2(p.z), ry: r2(fwd), el: tr && tr.statMult ? 'titan' : (ab.meleeEl || 'fisic') });
        };
        for (let hi = 0; hi < hits; hi++) { if (hi === 0) strike(0); else this.later(hi * (s.interval || 0.15), () => strike(hi)); }
        break;
      }
      default:
    }
  }

  taunt(p, r) {
    for (const e of this.enemies.values()) if (e.alive && !e.boss && dist2(e, p) < r) { e.target = p.id; e.tauntUntil = this.t + 4; }
  }

  // ------------------------------------------------------------------ projectiles
  spawnProj(o) {
    const pr = { id: this.id(), ...o, ox: o.x, oy: o.y, oz: o.z, travelled: 0, hit: new Set(), born: this.t };
    this.projs.set(pr.id, pr);
    this.emit('proj', { id: pr.id, o: pr.owner.id, oe: pr.owner.def ? 1 : 0, x: r2(pr.x), y: r2(pr.y), z: r2(pr.z), d: pr.dir.map((v) => r2(v)), s: pr.speed, r: pr.range, el: pr.el, fx: pr.fx, rad: pr.radius });
    return pr;
  }

  updateProjs(dt) {
    for (const pr of this.projs.values()) {
      const step = pr.speed * dt;
      const sub = Math.max(1, Math.ceil(step / 0.8));
      let ended = false;
      for (let s = 0; s < sub && !ended; s++) {
        pr.x += pr.dir[0] * step / sub; pr.y += pr.dir[1] * step / sub; pr.z += pr.dir[2] * step / sub;
        pr.travelled += step / sub;
        // impacte amb terra
        const g = groundAt(pr.x, pr.z, pr.y + 1);
        if (pr.y < g + 0.15 && pr.travelled > 1) { ended = true; break; }
        const targets = this.targetsNear(pr.owner, pr, pr.radius + 2.5, pr.team);
        for (const t of targets) {
          if (pr.hit.has(t)) continue;
          const tr = t.def ? t.def.radius : 0.45;
          const th = t.def ? t.def.height * 0.5 : 0.9;
          const dy = pr.y - (t.y + th);
          if (Math.hypot(pr.x - t.x, pr.z - t.z) < pr.radius + tr && Math.abs(dy) < th + pr.radius + 0.4) {
            pr.hit.add(t);
            if (!pr.explode) this.damage(pr.owner, t, pr.dmg, pr.el, pr.status, { knock: 1.5, leech: pr.leech });
            else if (pr.pierce) { this.aoe(pr.owner, pr, pr.explode, pr.dmg * 0.8, pr.el, pr.status, { knock: 3, team: pr.team, leech: pr.leech }); this.emit('impact', { x: r2(pr.x), y: r2(pr.y), z: r2(pr.z), r: pr.explode, el: pr.el }); }
            if (!pr.pierce) { ended = true; break; }
          }
        }
        if (pr.travelled > pr.range) ended = true;
      }
      if (ended) {
        this.projs.delete(pr.id);
        if (pr.explode) this.aoe(pr.owner, pr, pr.explode, pr.dmg, pr.el, pr.status, { knock: 5, team: pr.team, leech: pr.leech });
        if (pr.groundFire && !pr.owner.def) { const g = pr.groundFire; this.addField(pr.owner, pr.x, groundAt(pr.x, pr.z, pr.y + 2), pr.z, { r: g.r, dur: g.dur, tick: g.tick, dmg: g.dmg, el: pr.el, status: { burn: { dur: 2, dps: 6 } }, fx: 'flames', leech: pr.leech }); }
        if (pr.shards && !pr.owner.def) {
          for (let i = 0; i < pr.shards; i++) {
            const a = Math.atan2(pr.dir[0], pr.dir[2]) + (i - (pr.shards - 1) / 2) * 0.5;
            this.spawnProj({ owner: pr.owner, team: pr.team, x: pr.x - pr.dir[0] * 0.5, y: pr.y, z: pr.z - pr.dir[2] * 0.5, dir: [Math.sin(a), 0, Math.cos(a)], speed: 30, range: 9, radius: 0.5, dmg: pr.dmg * 0.35, el: pr.el, status: pr.status, fx: 'bolt', leech: pr.leech });
          }
        }
        this.emit('projEnd', { id: pr.id, x: r2(pr.x), y: r2(pr.y), z: r2(pr.z), ex: pr.explode || 0, el: pr.el });
      }
    }
  }

  hitscan(p, origin, aim, ab, dmg) {
    // primer objectiu: el més proper al raig
    let best = null, bt = 1e9;
    for (const t of this.targetsNear(p, p, ab.range + 3)) {
      const tx = t.x - origin.x, ty = (t.y + (t.def ? t.def.height * 0.5 : 0.9)) - origin.y, tz = t.z - origin.z;
      const along = tx * aim[0] + ty * aim[1] + tz * aim[2];
      if (along < 0 || along > ab.range) continue;
      const px = origin.x + aim[0] * along, py = origin.y + aim[1] * along, pz = origin.z + aim[2] * along;
      const off = Math.hypot(t.x - px, (t.y + (t.def ? t.def.height * 0.5 : 0.9)) - py, t.z - pz);
      const tol = 1.3 + (t.def ? t.def.radius : 0.4) + along * 0.03;
      if (off < tol && along < bt) { bt = along; best = t; }
    }
    const pts = [[r2(origin.x), r2(origin.y), r2(origin.z)]];
    if (!best) {
      const end = [origin.x + aim[0] * ab.range * 0.6, origin.y + aim[1] * ab.range * 0.6, origin.z + aim[2] * ab.range * 0.6];
      pts.push(end.map(r2));
      this.emit('zap', { p: p.id, el: ab.el, fx: ab.fx, pts });
      return;
    }
    const hit = new Set();
    let cur = best, d = dmg;
    for (let i = 0; i <= (ab.chain || 0) && cur; i++) {
      hit.add(cur);
      pts.push([r2(cur.x), r2(cur.y + (cur.def ? cur.def.height * 0.55 : 1)), r2(cur.z)]);
      this.damage(p, cur, d, ab.el, ab.status, { knock: 0.5, leech: ab.leech });
      d *= ab.falloff || 0.85;
      let nxt = null, nd = ab.chainRange || 8;
      for (const t of this.targetsNear(p, cur, nd + 1)) {
        if (hit.has(t)) continue; const dd = dist3(t, cur); if (dd < nd) { nd = dd; nxt = t; }
      }
      cur = nxt;
    }
    this.emit('zap', { p: p.id, el: ab.el, fx: ab.fx, pts });
  }

  // objectius hostils per a l'atacant (enemics per a jugadors; jugadors per a enemics; jugadors d'altre equip en PvP)
  targetsNear(src, pos, r, team) {
    const out = [];
    const isPlayer = src && !src.def;
    if (isPlayer || src === null) {
      for (const e of this.enemies.values()) if (e.alive && e.state !== 'spawn' && Math.abs(e.y - pos.y) < 14 + r && Math.hypot(e.x - pos.x, e.z - pos.z) < r + e.def.radius) out.push(e);
      if (this.isPvp && src) {
        const tm = team !== undefined ? team : src.team;
        for (const q of this.players.values()) if (q !== src && !q.dead && q.team !== tm && Math.hypot(q.x - pos.x, q.z - pos.z) < r && Math.abs(q.y - pos.y) < 10) out.push(q);
      }
    } else {
      for (const q of this.players.values()) if (!q.dead && Math.hypot(q.x - pos.x, q.z - pos.z) < r && Math.abs(q.y - pos.y) < 10) out.push(q);
    }
    return out;
  }

  aoe(src, c, r, dmg, el, status, o = {}) {
    for (const t of this.targetsNear(src, c, r + 1, o.team)) {
      const d = Math.hypot(t.x - c.x, t.z - c.z) - (t.def ? t.def.radius : 0.4);
      if (d > r) continue;
      if (o.once) { t._once = t._once || new Set(); if (t._once.has(o.once)) continue; t._once.add(o.once); }
      const fall = 1 - clamp(d / r, 0, 1) * 0.35;
      this.damage(src, t, dmg * fall, el, status, { knock: o.knock || 0, from: o.from || c, heavy: (o.knock || 0) > 3, leech: o.leech });
    }
  }

  // ------------------------------------------------------------------ dany
  damage(src, t, amount, el, status, o = {}) {
    if (!t) return;
    if (t.def) this.damageEnemy(src, t, amount, el, status, o);
    else this.damagePlayer(t, amount, src, el, { ...o, status });
  }

  damageEnemy(src, e, amount, el, status, o = {}) {
    if (!e.alive) return;
    let dmg = amount * (0.92 + this.rng() * 0.16);
    let crit = false;
    if (src && src.stats && this.rng() * 100 < src.stats.crit) { dmg *= 1.65; crit = true; }
    let combo = null;
    const st = e.statuses;
    if (st.vuln > this.t) dmg *= 1 + (st.vulnAmt || 0.15);
    if (el === 'gel' && st.burn > this.t) { dmg *= 1.5; st.burn = 0; combo = 'Vapor!'; }
    else if (el === 'llamp' && (st.freeze > this.t || st.slow > this.t)) { dmg *= 1.8; st.freeze = 0; combo = 'Trencament!'; }
    else if (el === 'llamp' && st.burn > this.t && !o.plasma) { combo = 'Plasma!'; this.later(0.05, () => this.aoe(src, e, 3.5, amount * 0.6, 'foc', null, { plasma: true })); }
    else if (el === 'foc' && st.freeze > this.t) { dmg *= 1.4; st.freeze = 0; combo = 'Desglaç!'; }
    if (e.variant && VARIANTS[e.def.model] && VARIANTS[e.def.model][e.variant] && VARIANTS[e.def.model][e.variant].el === el) dmg *= 0.6; // resistència
    if (e.blocking > this.t && src && Math.abs(angDiff(e.ry, angleTo(e, src))) < 1.2) { dmg *= 0.3; }
    const ssp = src && !src.def && src.eff ? src.eff.sp : null;
    if (ssp && ssp.has('shatter') && (st.freeze > this.t || st.slow > this.t)) dmg *= 1.25;
    dmg = Math.max(1, Math.round(dmg));
    e.hp -= dmg;
    e.lastHit = this.t;
    const leech = (o.leech || 0) + (ssp && ssp.has('bloodlust') ? 0.06 : 0);
    if (leech && src && !src.def && !src.dead) this.healPlayer(src, dmg * leech, true);
    if (crit && ssp && ssp.has('arc') && !o.arc) {
      let nxt = null, nd = 9;
      for (const t of this.targetsNear(src, e, 10)) { if (t === e || !t.def) continue; const dd = dist3(t, e); if (dd < nd) { nd = dd; nxt = t; } }
      if (nxt) {
        this.emit('zap', { p: src.id, el: 'llamp', fx: 'zap', pts: [[r2(e.x), r2(e.y + e.def.height * 0.55), r2(e.z)], [r2(nxt.x), r2(nxt.y + nxt.def.height * 0.55), r2(nxt.z)]] });
        this.later(0.05, () => this.damageEnemy(src, nxt, dmg * 0.5, 'llamp', { shock: { dur: 0.6 } }, { arc: true }));
      }
    }
    if (!e.engaged) { e.engaged = true; }
    if (src && !src.def) {
      e.dmgBy.set(src.id, (e.dmgBy.get(src.id) || 0) + dmg);
      if (!e.target || this.rng() < 0.15 || !(e.tauntUntil > this.t)) if (!e.target) e.target = src.id;
      src.aura = Math.min(100, src.aura + dmg * (e.boss ? 0.05 : 0.07));
      src.lastHitT = this.t;
    }
    if (status) this.applyStatus(e, status);
    this.emit('hit', { t: e.id, e: 1, d: dmg, c: crit ? 1 : 0, el, cb: combo, by: src ? src.id : 0, x: r2(e.x), y: r2(e.y + e.def.height * 0.75), z: r2(e.z), hp: Math.max(0, Math.round(e.hp)) });
    if (e.hp <= 0) return this.killEnemy(e, src);
    // equilibri / tambaleig
    if (!e.boss) {
      e.poise += o.heavy ? 3 : 1;
      if (e.poise >= e.def.poise && e.state !== 'spawn') {
        e.poise = 0;
        e.state = 'hit'; e.stateT = this.t + 0.45; e.atk = null;
        if (o.knock && src) {
          const from = o.from || src; const a = Math.atan2(e.x - from.x, e.z - from.z);
          e.kx = Math.sin(a) * o.knock; e.kz = Math.cos(a) * o.knock;
        }
      }
    }
  }

  applyStatus(e, status) {
    if (!status) return;
    if (status.chance && this.rng() > status.chance) return;
    const st = e.statuses;
    const res = e.boss ? 0.4 : 1;
    if (status.burn) { st.burn = this.t + status.burn.dur; st.burnDps = Math.max(st.burnDps || 0, status.burn.dps); }
    if (status.slow) { st.slow = this.t + status.slow.dur; st.slowAmt = Math.max(status.slow.amt, st.slow > this.t ? st.slowAmt || 0 : 0); }
    if (status.freeze) st.freeze = this.t + status.freeze.dur * res;
    if (status.stun) st.stun = this.t + status.stun.dur * res;
    if (status.shock) st.shock = this.t + status.shock.dur;
    if (status.vuln) { st.vuln = this.t + status.vuln.dur; st.vulnAmt = status.vuln.amt; }
    if (status.poison) { st.poison = this.t + status.poison.dur; st.poisonDps = status.poison.dps; }
    if ((status.freeze || status.stun) && !e.boss && e.def) { e.atk = null; if (e.state === 'windup') e.state = 'idle'; }
    this.emit('status', { t: e.id, e: e.def ? 1 : 0, s: Object.fromEntries(Object.entries(st).filter(([k, v]) => !k.endsWith('Dps') && !k.endsWith('Amt') && v > this.t).map(([k, v]) => [k, r2(v - this.t)])) });
  }

  damagePlayer(p, amount, src, el, o = {}) {
    if (p.dead) return;
    if (this.t < p.invuln && !o.fall) { this.emit('miss', { t: p.id, x: r2(p.x), y: r2(p.y + 1.8), z: r2(p.z) }); return; }
    let dmg = amount;
    const isPvp = src && !src.def && src !== p;
    if (isPvp) {
      dmg *= 0.55;
      if (src.stats && this.rng() * 100 < src.stats.crit) dmg *= 1.5;
      const tr = src.transform && src.transform.until > this.t ? src.transform : null; void tr;
    }
    const tr = p.transform && p.transform.until > this.t ? p.transform : null;
    const def = p.stats.def * (tr ? tr.defMult : 1);
    if (!o.fall) dmg *= 60 / (60 + def);
    let blocked = false;
    const psp = p.eff ? p.eff.sp : null;
    if (p.blocking && src && Math.abs(angDiff(p.ry, angleTo(p, src))) < 1.3) {
      const bul = psp && psp.has('bulwark');
      if (bul && src.def && !o.reflected) this.later(0.01, () => this.damageEnemy(p, src, amount * 0.3, 'fisic', null, {}));
      dmg *= bul ? 0.15 : 0.3; blocked = true;
    }
    const shielded = p.buffs.shield && p.buffs.shield.until > this.t && p.buffs.shield.amt > 0;
    if (psp && psp.has('diamond') && shielded) dmg *= 0.7;
    if (p.buffs.guard && p.buffs.guard.until > this.t) dmg *= 1 - p.buffs.guard.amt;
    if (p.buffs.shield && p.buffs.shield.until > this.t && p.buffs.shield.amt > 0) {
      const ab = Math.min(p.buffs.shield.amt, dmg); p.buffs.shield.amt -= ab; dmg -= ab;
      if (src && p.buffs.shield.reflect && src.def) this.damageEnemy(p, src, ab * p.buffs.shield.reflect, p.buffs.shield.el || 'gel', p.buffs.shield.el === 'foc' ? { burn: { dur: 3, dps: 8 } } : null, {});
    }
    dmg = Math.max(0, Math.round(dmg));
    p.hp -= dmg; p.lastDmgT = this.t;
    p.aura = Math.min(100, p.aura + dmg * 0.08);
    // només 1 de cada 5 cops atura el jugador
    let stagger = false;
    if (!o.noPoise && dmg > 0) { p.poise++; if (p.poise >= 5) { p.poise = 0; stagger = true; } }
    if (o.status) {
      const s = o.status;
      if (s.burn) p.statuses.burn = this.t + s.burn.dur, p.statuses.burnDps = s.burn.dps;
      if (s.slow) p.statuses.slow = this.t + s.slow.dur, p.statuses.slowAmt = s.slow.amt;
      const immune = psp && psp.has('diamond') && shielded;
      if (s.stun && !blocked && !immune) p.statuses.stun = this.t + s.stun.dur * (isPvp ? 0.5 : 1);
      if (s.freeze && !blocked) p.statuses.freeze = this.t + s.freeze.dur * (isPvp ? 0.5 : 1);
      if (s.poison) p.statuses.poison = this.t + s.poison.dur, p.statuses.poisonDps = s.poison.dps;
    }
    let kx = 0, kz = 0;
    if (o.knock && src && !blocked) { const a = angleTo(src, p); kx = Math.sin(a) * o.knock; kz = Math.cos(a) * o.knock; }
    this.emit('hit', { t: p.id, e: 0, d: dmg, el, b: blocked ? 1 : 0, st: stagger ? 1 : 0, kx: r2(kx), kz: r2(kz), x: r2(p.x), y: r2(p.y + 1.9), z: r2(p.z), hp: Math.max(0, Math.round(p.hp)), by: src ? (src.def ? -src.id : src.id) : 0 });
    if (p.hp <= 0 && psp && psp.has('rebirth') && !(this.t < p.rebirthT) && !this.isPvp) {
      p.rebirthT = this.t + 120; p.hp = p.stats.maxHp * 0.4; p.invuln = this.t + 1.5; p.statuses = {};
      this.emit('nova', { p: p.id, key: 'fenix', el: 'foc', fx: 'nova', r: 6, x: r2(p.x), y: r2(p.y), z: r2(p.z) });
      this.emit('note', { msg: '🐦‍🔥 Renéixes de les cendres!' }, p.id);
      this.aoe(p, p, 6, 50 * powerMult(p.stats.poder), 'foc', { burn: { dur: 3, dps: 8 } }, { knock: 8 });
      return;
    }
    if (p.hp <= 0) this.killPlayer(p, src);
  }

  healPlayer(p, amt, quiet = false) {
    if (p.dead) return;
    const h = Math.min(p.stats.maxHp - p.hp, amt);
    if (h <= 0) return;
    p.hp += h;
    if (quiet) { p._leechAcc = (p._leechAcc || 0) + h; if (p._leechAcc < 25) return; p._leechAcc = 0; }
    this.emit('heal', { t: p.id, d: Math.round(quiet ? 25 : h), x: r2(p.x), y: r2(p.y + 1.9), z: r2(p.z) });
  }

  killPlayer(p, src) {
    p.dead = true; p.hp = 0; p.deaths++;
    p.respawnT = this.t + (this.isPvp ? 3 : this.mode === 'crono' ? 3 : this.isPve ? 12 : 6);
    p.transform = null; p.buffs = {}; p.statuses = {};
    this.emit('pdie', { id: p.id, by: src ? (src.def ? src.def.name : src.name) : null, rt: p.respawnT - this.t, final: this.isPve && this.mode !== 'crono' && this.players.size === 1 ? 1 : 0 });
    if (this.isPvp && src && !src.def && src !== p) {
      src.kills++;
      if (this.mode !== 'turo') this.pvp.scores[src.team] = (this.pvp.scores[src.team] || 0) + 1;
      else this.pvp.scores[src.team] = Math.min(this.pvp.target, (this.pvp.scores[src.team] || 0) + 3);
      src.save.pvp.kills++;
      this.emit('pvp', this.pvpInfo());
      if (this.pvp.scores[src.team] >= this.pvp.target && !this.pvp.roundEnd) this.endPvpRound(src.team);
    }
    // Hordes i Cacera de caps: si cauen tots els jugadors, s'acaba la partida
    if (this.isPve && this.mode !== 'crono' && this.match.state !== 'over' && [...this.players.values()].every((q) => q.dead)) this.later(1.5, () => { if (this.match.state !== 'over' && [...this.players.values()].every((q) => q.dead)) this.endMatch(false); });
    for (const e of this.enemies.values()) if (e.target === p.id) e.target = null;
  }

  onRespawn(p) {
    if (!p.dead || this.t < p.respawnT) return;
    p.dead = false;
    this.recalc(p, true);
    if (this.isPvp) this.placeAtArena(p);
    else if (this.isPve) { if (this.match.state === 'over') return; this.placeInArena(p); }
    else {
      let best = WAYSTONES[0], bd = 1e9;
      for (const w of WAYSTONES) {
        if (!p.save.waystones.includes(w.id)) continue;
        const d = Math.hypot(p.x - w.x, p.z - w.z); if (d < bd) { bd = d; best = w; }
      }
      const y = best.island ? ISLAND[best.island].top + 0.5 : height(best.x, best.z) + 0.3;
      this.teleport(p, best.x + 2.5, y, best.z + 2.5);
    }
    p.invuln = this.t + 2;
    this.emit('prespawn', { id: p.id, hp: p.hp });
    this.sendMe(p);
  }

  revive(p, targetId) {
    const t = this.players.get(targetId);
    if (!t || !t.dead || t === p || this.isPvp) return;
    if (dist2(p, t) > 3.5) return;
    t.dead = false; t.hp = t.stats.maxHp * 0.4; t.mana = t.stats.maxMana * 0.4; t.invuln = this.t + 2;
    this.emit('prespawn', { id: t.id, hp: t.hp, revivedBy: p.name });
    this.sendMe(t);
  }

  placeAtArena(p) {
    const is = ISLAND.arena;
    let sp;
    if (this.mode === 'ffa') {
      // el punt més lluny dels altres jugadors vius
      let best = -1;
      for (const c of ARENA_SPAWNS) {
        let dmin = 1e9; for (const q of this.players.values()) if (q !== p && !q.dead) dmin = Math.min(dmin, Math.hypot(q.x - c[0], q.z - c[1]));
        if (dmin > best) { best = dmin; sp = c; }
      }
    } else {
      const idx = (p.team - 1) * 2 + ([...this.players.values()].filter((q) => q.team === p.team).indexOf(p) % 2);
      sp = ARENA_SPAWNS[idx % 4];
    }
    this.teleport(p, sp[0], is.top + 0.5, sp[1]);
  }
  // modes contra monstres: els jugadors apareixen al voltant del centre de l'arena
  placeInArena(p) {
    const is = ISLAND.arena; const i = [...this.players.keys()].indexOf(p.id);
    const a = i * 1.57 + 0.4;
    this.teleport(p, is.x + Math.cos(a) * 4, is.top + 0.5, is.z + Math.sin(a) * 4);
  }
  get isSolo() { return this.players.size <= 1; }

  pvpInfo() {
    return { mode: this.mode, scores: this.pvp.scores, target: this.pvp.target, zone: this.pvp.zone, players: [...this.players.values()].map((q) => ({ id: q.id, name: q.name, team: q.team, k: q.kills, d: q.deaths })) };
  }

  // Rei del turó: l'equip que té el cercle del centre suma punts
  updateHill(dt) {
    const is = ISLAND.arena;
    const inside = new Set();
    for (const p of this.players.values()) if (!p.dead && Math.hypot(p.x - is.x, p.z - is.z) < HILL_R && Math.abs(p.y - is.top) < 4) inside.add(p.team);
    const zone = inside.size === 1 ? [...inside][0] : inside.size > 1 ? -1 : 0;
    this.pvp.hillAcc = (this.pvp.hillAcc || 0) + dt;
    if (zone !== this.pvp.zone) { this.pvp.zone = zone; this.emit('pvp', this.pvpInfo()); }
    if (this.pvp.hillAcc >= 1) {
      this.pvp.hillAcc -= 1;
      if (zone > 0) {
        this.pvp.scores[zone] = Math.min(this.pvp.target, (this.pvp.scores[zone] || 0) + 2);
        this.emit('pvp', this.pvpInfo());
        if (this.pvp.scores[zone] >= this.pvp.target) this.endPvpRound(zone);
      }
    }
  }

  // ------------------------------------------------------------------ partides contra monstres (Hordes, Caps, Contrarellotge)
  avgLevel() { let n = 0, s = 0; for (const p of this.players.values()) { s += p.save.level; n++; } return n ? Math.max(1, Math.round(s / n)) : 1; }
  startCountdown(sec) {
    this.match = { state: 'countdown', at: this.t + sec, wave: 0, score: 0, kills: 0, t0: 0, combo: 0, comboT: 0, bossesDone: 0, nextSpawn: 0, minis: 0 };
    this.emitMatch(`La partida comença en ${Math.round(sec)} s`);
  }
  matchInfo() {
    const m = this.match; if (!m) return null;
    if (this.isRace) {
      const time = m.state === 'countdown' ? Math.max(0, m.at - this.t) : m.t0 ? (m.state === 'over' ? m.end - m.t0 : this.t - m.t0) : 0;
      return { mode: this.mode, level: this.level, state: m.state, time: r2(time), total: this.course.finish, left: m.endAt ? r2(Math.max(0, m.endAt - this.t)) : 0,
        racers: [...this.players.values()].map((p) => [p.id, p.cp || 0, p.finishT === null || p.finishT === undefined ? -1 : r2(p.finishT), p.name]) };
    }
    const alive = [...this.enemies.values()].filter((e) => e.alive && !e.def.static).length;
    const M = MODES[this.mode];
    const time = m.state === 'countdown' ? Math.max(0, m.at - this.t) : this.mode === 'crono' ? Math.max(0, M.time - (this.t - m.t0)) : m.t0 ? (m.state === 'over' ? m.end - m.t0 : this.t - m.t0) : 0;
    return { mode: this.mode, state: m.state, wave: m.wave, left: alive, score: Math.round(m.score), kills: m.kills, combo: m.combo, time: r2(time), bosses: m.bossesDone, total: this.mode === 'caps' ? BOSS_ORDER.length : 0, boss: m.bossName || '' };
  }
  emitMatch(msg) { this.emit('match', { ...this.matchInfo(), msg: msg || '' }); this.lastMatchEmit = this.t; }
  arenaSpawnPoint(minFromPlayers = 10) {
    const is = ISLAND.arena;
    for (let k = 0; k < 12; k++) {
      const a = this.rng() * TAU, d = is.r * (0.45 + this.rng() * 0.38);
      const x = is.x + Math.cos(a) * d, z = is.z + Math.sin(a) * d;
      if ([...this.players.values()].every((p) => p.dead || Math.hypot(p.x - x, p.z - z) > minFromPlayers)) return { x, z };
    }
    const a = this.rng() * TAU; return { x: is.x + Math.cos(a) * is.r * 0.7, z: is.z + Math.sin(a) * is.r * 0.7 };
  }
  spawnArena(type, lvl, opts = {}) {
    const pt = opts.at || this.arenaSpawnPoint(opts.boss ? 14 : 9);
    const e = this.spawnEnemy(type, null, opts.variant || null, 0, 1, { x: pt.x, z: pt.z, island: 'arena' }, { lvl, aggro: 90, hpMult: opts.hpMult || 1 });
    e.home = { x: ISLAND.arena.x, z: ISLAND.arena.z };
    return e;
  }
  wavePool(n) {
    const pool = [['puglin'], ['puglin', 'oliva']];
    if (n >= 3) pool.push(['imp'], ['esquelet_minion']);
    if (n >= 5) pool.push(['esquelet'], ['esquelet_arquer'], ['imp_foc'], ['puglin', 'vermell']);
    if (n >= 8) pool.push(['golem'], ['esquelet_mag'], ['bruixot'], ['esquelet_lladre']);
    if (n >= 12) pool.push(['golem_magma'], ['esquelet_piromant'], ['imp', 'blau'], ['puglin', 'blau']);
    if (n >= 8) pool.splice(0, 2); // ja no surten puglins normals
    return pool;
  }
  spawnWave(n) {
    const m = this.match; m.wave = n;
    const party = Math.max(1, this.players.size);
    const lvl = this.avgLevel() + Math.floor((n - 1) / 3);
    const boss = n % 5 === 0;
    const count = Math.min(26, Math.round((3 + n * 1.5) * (1 + 0.45 * (party - 1)) * (boss ? 0.4 : 1)));
    const pool = this.wavePool(n);
    let msg = `Onada ${n}`;
    if (boss) {
      const type = BOSS_ORDER[(n / 5 - 1) % BOSS_ORDER.length];
      const e = this.spawnArena(type, lvl, { boss: true, hpMult: 0.55 + 0.05 * Math.floor(n / 5) });
      m.bossName = e.def.name;
      msg = `Onada ${n} — ${e.def.name}${e.def.title ? ', ' + e.def.title : ''}!`;
    } else m.bossName = '';
    for (let i = 0; i < count; i++) {
      const [type, variant] = pool[Math.floor(this.rng() * pool.length)];
      this.later(0.6 + i * 0.25, () => { if (m.state === 'running' && this.match === m) this.spawnArena(type, lvl, { variant }); });
    }
    m.waveReadyT = this.t + 0.8 + count * 0.25;
    this.emitMatch(msg);
  }
  spawnNextBoss() {
    const m = this.match;
    const i = m.bossesDone;
    const type = BOSS_ORDER[i];
    const hm = (0.45 + 0.03 * i) * (type === 'drac' || type === 'ombra' || type === 'ganfaul' ? 0.7 : 1);
    const e = this.spawnArena(type, Math.max(this.avgLevel(), 3) + Math.floor(i / 2), { boss: true, hpMult: hm, at: { x: ISLAND.arena.x, z: ISLAND.arena.z - 16 } });
    m.bossName = e.def.name; m.waveReadyT = this.t + 1;
    this.emitMatch(`Cap ${i + 1} de ${BOSS_ORDER.length}: ${e.def.name}${e.def.title ? ', ' + e.def.title : ''}!`);
  }
  restorePlayers(frac) {
    for (const p of this.players.values()) {
      if (p.dead) { p.dead = false; this.recalc(p, true); p.hp = p.stats.maxHp * Math.max(frac, 0.5); this.placeInArena(p); this.emit('prespawn', { id: p.id, hp: p.hp }); }
      else { this.healPlayer(p, p.stats.maxHp * frac); p.mana = Math.min(p.stats.maxMana, p.mana + p.stats.maxMana * frac); }
      this.sendMe(p);
    }
  }
  updateMatch(dt) {
    const m = this.match;
    if (!m || m.state === 'wait' || m.state === 'over') return;
    const M = MODES[this.mode];
    if (m.state === 'countdown') {
      const left = Math.ceil(m.at - this.t);
      if (left !== m.lastCount && left <= 3 && left > 0) { m.lastCount = left; this.emitMatch(String(left)); }
      if (this.t >= m.at) {
        m.state = 'running'; m.t0 = this.t;
        if (this.mode === 'hordes') this.spawnWave(1);
        else if (this.mode === 'caps') this.spawnNextBoss();
        else this.emitMatch('Som-hi! Derrota tants enemics com puguis!');
      }
      return;
    }
    const alive = [...this.enemies.values()].filter((e) => e.alive && !e.def.static);
    if (this.mode === 'hordes') {
      if (m.state === 'running' && this.t > m.waveReadyT && !alive.length) {
        m.state = 'break'; m.breakEnd = this.t + 6; m.score = m.wave;
        this.restorePlayers(0.3);
        for (const p of this.players.values()) { p.save.gold += 10 + m.wave * 4; this.markSave(p); }
        this.emitMatch(`Onada ${m.wave} superada! Descans (+${10 + m.wave * 4} 🪙)`);
      } else if (m.state === 'break' && this.t > m.breakEnd) { m.state = 'running'; this.spawnWave(m.wave + 1); }
    } else if (this.mode === 'caps') {
      if (m.state === 'running' && this.t > m.waveReadyT && !alive.length) {
        m.bossesDone++; m.score = m.bossesDone;
        for (const p of this.players.values()) { p.save.gold += 40 + m.bossesDone * 20; this.markSave(p); }
        if (m.bossesDone >= BOSS_ORDER.length) return this.endMatch(true);
        m.state = 'break'; m.breakEnd = this.t + 7;
        this.restorePlayers(0.5);
        this.emitMatch(`${m.bossName} derrotat! Següent cap en 7 s`);
      } else if (m.state === 'break' && this.t > m.breakEnd) { m.state = 'running'; this.spawnNextBoss(); }
    } else if (this.mode === 'crono') {
      const el = this.t - m.t0;
      if (el >= M.time) return this.endMatch(true);
      const party = Math.max(1, this.players.size);
      const want = 6 + 3 * party + Math.floor(el / 40);
      if (alive.length < want && this.t > m.nextSpawn) {
        m.nextSpawn = this.t + 0.35;
        const n = 1 + Math.floor(el / 20);
        const pool = this.wavePool(n);
        const [type, variant] = pool[Math.floor(this.rng() * pool.length)];
        this.spawnArena(type, this.avgLevel() + Math.floor(el / 60), { variant });
      }
      // un gòlem cada minut
      if (el > 60 * (m.minis + 1) && m.minis < 2) { m.minis++; this.spawnArena(m.minis === 1 ? 'golem' : 'golem_magma', this.avgLevel() + 1); this.emitMatch('Ha aparegut un gòlem: val molts punts!'); }
      if (m.combo && this.t - m.comboT > 4) { m.combo = 0; }
    }
    if (this.t - (this.lastMatchEmit || 0) > 1) this.emitMatch();
  }
  // ------------------------------------------------------------------ parkour (cursa)
  get course() { return getLevel(this.level); }
  placeAtCheckpoint(p, i = 0) {
    const CP = this.course.checkpoints;
    const c = CP[i] || CP[0];
    let x = c.x, z = c.z;
    if (i === 0) { const k = [...this.players.keys()].indexOf(p.id); x += ((Math.max(0, k) % 4) - 1.5) * 2.4; z -= 2; }
    this.teleport(p, x, c.y + 0.4, z);
  }
  updateRace() {
    const m = this.match;
    if (!m || m.state === 'wait' || m.state === 'over') return;
    if (m.state === 'countdown') {
      const left = Math.ceil(m.at - this.t);
      if (left !== m.lastCount && left <= 3 && left > 0) { m.lastCount = left; this.emitMatch(String(left)); }
      // ningú surt abans d'hora
      const st = this.course.checkpoints[0];
      for (const p of this.players.values()) if (this.t > p.allowJump && (Math.hypot(p.x - st.x, p.z - st.z) > 9 || p.y < st.y - 3)) this.placeAtCheckpoint(p, 0);
      if (this.t >= m.at) { m.state = 'running'; m.t0 = this.t; this.emitMatch('Som-hi! Corre fins a la meta!'); }
      return;
    }
    const el = this.t - m.t0;
    for (const p of this.players.values()) {
      if (p.finishT !== null && p.finishT !== undefined) continue;
      const next = this.course.checkpoints[(p.cp || 0) + 1]; if (!next) continue;
      if (Math.hypot(p.x - next.x, p.z - next.z) < next.r && Math.abs(p.y - next.y) < 3.5) {
        p.cp = (p.cp || 0) + 1;
        if (p.cp >= this.course.finish) {
          p.finishT = el; m.finished = (m.finished || 0) + 1; p.place = m.finished;
          this.emit('pk', { id: p.id, cp: p.cp, t: r2(el), fin: 1, place: p.place, name: p.name });
          if (!m.endAt && this.players.size > 1 && [...this.players.values()].some((q) => q.finishT === null)) { m.endAt = this.t + 30; this.emitMatch(`${p.name} ha arribat a la meta! Queden 30 s`); }
        } else this.emit('pk', { id: p.id, cp: p.cp, t: r2(el), name: p.name });
        this.emitMatch();
      }
    }
    const all = [...this.players.values()];
    if (all.length && all.every((p) => p.finishT !== null && p.finishT !== undefined)) return this.endMatch(true);
    if (m.endAt && this.t >= m.endAt) return this.endMatch(true);
    if (el >= RACE_LIMIT) return this.endMatch(false);
    if (this.t - (this.lastMatchEmit || 0) > 1) this.emitMatch();
  }

  onMatchKill(e) {
    const m = this.match;
    if (!m || m.state === 'over' || m.state === 'countdown') return;
    m.kills++;
    if (this.mode === 'crono') {
      m.combo = this.t - m.comboT < 4 ? m.combo + 1 : 1; m.comboT = this.t;
      const mult = Math.min(3, 1 + (m.combo - 1) * 0.1);
      m.score += Math.round(e.def.xp * (e.boss ? 3 : 1) * mult);
    }
  }
  endMatch(win) {
    const m = this.match;
    if (!m || m.state === 'over') return;
    m.state = 'over'; m.end = this.t;
    for (const e of this.enemies.values()) if (e.alive) { e.alive = false; e.state = 'dead'; e.deadT = this.t; this.emit('edie', { id: e.id, by: 0, quiet: 1 }); }
    const info = this.matchInfo();
    const results = [];
    for (const p of this.players.values()) {
      const s = p.save; s.records = s.records || {};
      const R = s.records[this.mode] || {};
      let best = false, gold = 0, xp = 0;
      if (this.mode === 'hordes') { gold = m.wave * 15; xp = m.wave * 60; if ((m.score || 0) > (R.wave || 0)) { R.wave = m.score; best = true; } }
      if (this.mode === 'caps') {
        gold = m.bossesDone * 50; xp = m.bossesDone * 200;
        const tm = Math.round(info.time);
        if (m.bossesDone > (R.bosses || 0) || (m.bossesDone === (R.bosses || 0) && m.bossesDone && tm < (R.time || 1e9))) { R.bosses = m.bossesDone; R.time = tm; best = true; }
      }
      if (this.mode === 'crono') { gold = Math.round(m.score / 12); xp = Math.round(m.score * 0.5); if (m.score > (R.score || 0)) { R.score = Math.round(m.score); best = true; } }
      let extra = {};
      if (this.isRace) {
        const fin = p.finishT !== null && p.finishT !== undefined;
        const many = this.players.size > 1;
        gold = fin ? 60 + (many ? [0, 40, 20, 10][p.place] || 0 : 0) : (p.cp || 0) * 8;
        xp = fin ? 300 + Math.max(0, Math.round((180 - p.finishT) * 2)) : (p.cp || 0) * 40;
        // millor temps de cada nivell
        R.times = Array.isArray(R.times) ? R.times : [];
        const li = this.level - 1, tm = Math.round(p.finishT * 10) / 10;
        if (fin && (!R.times[li] || tm < R.times[li])) { R.times[li] = tm; best = true; }
        for (let k = 0; k < LEVELS.length; k++) R.times[k] = R.times[k] || 0;
        R.time = R.times[0] || 0;
        gold = Math.round(gold * (1 + 0.25 * (this.level - 1))); xp = Math.round(xp * (1 + 0.25 * (this.level - 1)));
        extra = { time: fin ? r2(p.finishT) : null, place: fin ? p.place : 0, cp: p.cp || 0, level: this.level };
      }
      R.played = (R.played || 0) + 1;
      s.records[this.mode] = R;
      s.gold += gold; this.giveXp(p, xp);
      this.markSave(p, true);
      results.push({ id: p.id, name: p.name, gold, xp, best, ...extra });
    }
    if (this.isRace) results.sort((a, b) => (a.time === null) - (b.time === null) || (a.time || 0) - (b.time || 0) || b.cp - a.cp);
    this.emit('matchEnd', { ...info, win: !!win, results });
  }

  endPvpRound(team) {
    this.pvp.roundEnd = this.t + 8;
    for (const q of this.players.values()) {
      if (q.team === team) q.save.pvp.wins++; else q.save.pvp.losses++;
      this.markSave(q);
    }
    this.emit('pvpEnd', { winner: team, info: this.pvpInfo() });
  }

  // ------------------------------------------------------------------ morts i botí
  killEnemy(e, src) {
    e.alive = false; e.state = 'dead'; e.hp = 0;
    e.deadT = this.t;
    if (src && !src.def && src.eff && src.eff.sp.has('ashes') && e.statuses.burn > this.t) {
      const c = { x: e.x, y: e.y, z: e.z };
      this.later(0.15, () => { this.emit('impact', { x: r2(c.x), y: r2(c.y), z: r2(c.z), r: 4.5, el: 'foc' }); this.aoe(src, c, 4.5, 40 * powerMult(src.stats.poder), 'foc', { burn: { dur: 3, dps: 8 } }, { knock: 4 }); });
    }
    this.emit('edie', { id: e.id, by: src && !src.def ? src.id : 0 });
    // crèdit: tots els jugadors propers o que han fet mal
    const credited = [];
    for (const p of this.players.values()) {
      if (e.dmgBy.has(p.id) || dist2(p, e) < 70) credited.push(p);
    }
    const lootPos = { x: e.x, y: e.y, z: e.z };
    for (const p of credited) {
      const diff = e.lvl - p.save.level;
      const xpMult = diff < -5 ? 0.2 : diff < -2 ? 0.6 : diff > 3 ? 1.4 : 1;
      this.giveXp(p, Math.round(e.def.xp * (1 + 0.12 * (e.lvl - 1)) * xpMult));
      if (this.isStory) this.questProgress(p, 'kill', e);
    }
    if (this.isPve) this.onMatchKill(e);
    // or
    const [g0, g1] = e.def.gold || [1, 3];
    const gold = Math.round((g0 + this.rng() * (g1 - g0)) * (1 + 0.1 * e.lvl));
    if (gold > 0) this.dropLoot({ kind: 'gold', amount: gold }, lootPos);
    const itemChance = e.boss ? 1 : e.variant && e.vname ? 0.18 : 0.07;
    const nItems = e.boss ? 2 : 1;
    for (let i = 0; i < nItems; i++) if (this.rng() < itemChance) this.dropLoot({ kind: 'item', lvl: e.lvl, luck: e.boss ? 2 : e.vname ? 0.5 : 0 }, lootPos);
    if (this.rng() < 0.08) this.dropLoot({ kind: 'potion', potion: this.rng() < 0.6 ? 'vida' : 'mana' }, lootPos);
    // mort del cap: elimina invocats
    if (e.boss) {
      for (const m of this.enemies.values()) if (m.owner === e.id && m.alive) this.killEnemy(m, null);
      this.emit('bossDown', { id: e.id, name: e.def.name });
    }
    if (e.camp) e.respawnAt = this.t + (e.camp.respawn || 45) + this.rng() * 10;
  }

  dropLoot(l, pos) {
    const a = this.rng() * TAU, d = 0.5 + this.rng() * 1.5;
    const lo = { id: this.id(), ...l, x: pos.x + Math.cos(a) * d, z: pos.z + Math.sin(a) * d, born: this.t };
    lo.y = groundAt(lo.x, lo.z, pos.y + 2);
    this.loot.set(lo.id, lo);
    this.emit('loot', this.lootInfo(lo));
  }
  lootInfo(l) { return { id: l.id, kind: l.kind, x: r2(l.x), y: r2(l.y), z: r2(l.z), potion: l.potion, amount: l.amount }; }

  updateLoot() {
    for (const l of this.loot.values()) {
      if (this.t - l.born > 120) { this.loot.delete(l.id); this.emit('unloot', { id: l.id }); continue; }
      if (this.t - l.born < 0.6) continue;
      for (const p of this.players.values()) {
        if (p.dead) continue;
        const d = Math.hypot(p.x - l.x, p.z - l.z);
        if (d < 2.2 && Math.abs(p.y - l.y) < 3) {
          this.pickLoot(p, l); this.loot.delete(l.id);
          this.emit('unloot', { id: l.id, by: p.id });
          break;
        }
      }
    }
  }

  pickLoot(p, l) {
    const s = p.save;
    if (l.kind === 'gold') {
      // l'or es reparteix entre tot el grup proper
      const near = [...this.players.values()].filter((q) => !q.dead && dist2(q, p) < 60);
      const each = Math.max(1, Math.round(l.amount / near.length));
      for (const q of near) { q.save.gold += each; this.emit('pick', { kind: 'gold', amount: each }, q.id); this.markSave(q); }
      return;
    }
    if (l.kind === 'potion') { s.potions[l.potion] = Math.min(9, (s.potions[l.potion] || 0) + 1); this.emit('pick', { kind: 'potion', potion: l.potion }, p.id); }
    if (l.kind === 'item') {
      const it = makeItem(this.rng, Math.max(1, Math.min(l.lvl, s.level + 1)), p.cls, null, l.luck || 0);
      if (s.inv.length >= 24) { s.gold += Math.round(it.price * 0.4); this.emit('pick', { kind: 'gold', amount: Math.round(it.price * 0.4), full: true }, p.id); }
      else { s.inv.push(it); this.emit('pick', { kind: 'item', item: it }, p.id); }
    }
    this.markSave(p);
  }

  giveXp(p, xp) {
    const s = p.save;
    if (s.level >= MAX_LEVEL) return;
    s.xp += xp;
    this.emit('xp', { xp, total: s.xp }, p.id);
    while (s.level < MAX_LEVEL && s.xp >= XP_TABLE(s.level)) {
      s.xp -= XP_TABLE(s.level); s.level++; s.talentPts++;
      this.recalc(p, true);
      this.emit('lvl', { id: p.id, level: s.level });
    }
    this.markSave(p);
  }

  // ------------------------------------------------------------------ missions
  questProgress(p, type, data) {
    const s = p.save;
    const ch = STORY[s.story.idx];
    let changed = false;
    const matches = (obj) => {
      if (obj.type === 'kill' && type === 'kill') {
        const t = data.type;
        if (obj.enemy === 'boss') return data.boss;
        if (obj.enemy.endsWith('*')) return t.startsWith(obj.enemy.slice(0, -1));
        return t === obj.enemy;
      }
      if (obj.type === 'boss' && type === 'kill') return data.type === obj.enemy;
      if (obj.type === 'collect' && type === 'collect') return data === obj.item;
      if (obj.type === 'activate' && type === 'activate') return data === obj.what;
      return false;
    };
    if (ch && s.story.accepted) {
      ch.objectives.forEach((obj, i) => {
        const cur = s.story.progress[i] || 0;
        if (cur < obj.n && matches(obj)) { s.story.progress[i] = cur + 1; changed = true; }
      });
    }
    if (s.bounty) {
      const b = BOUNTIES.find((x) => x.id === s.bounty.id);
      if (b && s.bounty.progress < b.obj.n && matches(b.obj)) { s.bounty.progress++; changed = true; }
    }
    if (changed) { this.emit('quest', { story: s.story, bounty: s.bounty }, p.id); this.markSave(p); }
  }

  onNpc(p, m) {
    const npc = NPCS.find((n) => n.id === m.npc);
    if (!npc || Math.hypot(p.x - npc.x, p.z - npc.z) > 7) return;
    const s = p.save;
    if (m.a === 'accept' && npc.id === 'elna') {
      const ch = STORY[s.story.idx];
      if (ch && !s.story.accepted) { s.story.accepted = true; s.story.progress = ch.objectives.map(() => 0); }
    } else if (m.a === 'turnin' && npc.id === 'elna') {
      const ch = STORY[s.story.idx];
      if (ch && s.story.accepted && ch.objectives.every((o, i) => (s.story.progress[i] || 0) >= o.n)) {
        this.reward(p, ch.reward);
        s.story.idx++; s.story.accepted = false; s.story.progress = [];
        this.emit('chapter', { done: ch.id, idx: s.story.idx }, p.id);
      }
    } else if (m.a === 'bounty' && npc.id === 'bru') {
      const b = BOUNTIES.find((x) => x.id === m.id);
      if (b && !s.bounty) s.bounty = { id: b.id, progress: 0 };
    } else if (m.a === 'bountyDone' && npc.id === 'bru' && s.bounty) {
      const b = BOUNTIES.find((x) => x.id === s.bounty.id);
      if (b && s.bounty.progress >= b.obj.n) { this.reward(p, b.reward); s.bountiesDone.push(b.id); s.bounty = null; }
    } else if (m.a === 'abandon' && npc.id === 'bru') {
      s.bounty = null;
    } else if (m.a === 'custom' && npc.id === 'elna') {
      if (m.spec) s.custom = { form: String(m.spec.form), el: String(m.spec.el), pow: m.spec.pow | 0, name: String(m.spec.name || '').slice(0, 24) };
      if (Array.isArray(m.slots) && m.slots.length === 4) s.slots = m.slots.map(String);
    }
    this.emit('quest', { story: s.story, bounty: s.bounty }, p.id);
    this.markSave(p, true);
  }

  reward(p, r) {
    if (!r) return;
    p.save.gold += r.gold || 0;
    if (r.item) { const it = makeItem(this.rng, p.save.level + 1, p.cls, null, 2); if (p.save.inv.length < 24) p.save.inv.push(it); this.emit('pick', { kind: 'item', item: it }, p.id); }
    this.emit('reward', r, p.id);
    if (r.xp) this.giveXp(p, r.xp);
  }

  onShop(p, m) {
    const s = p.save;
    const near = (id) => { const n = NPCS.find((x) => x.id === id); return n && Math.hypot(p.x - n.x, p.z - n.z) < 8; };
    if (m.a === 'buy' && near('oleguer')) {
      const it = SHOP.find((x) => x.id === m.id);
      if (!it || s.gold < it.price) return this.emit('deny', { msg: 'No tens prou or' }, p.id);
      s.gold -= it.price;
      if (it.kind === 'potion') s.potions[it.potion] = Math.min(9, (s.potions[it.potion] || 0) + 1);
      if (it.kind === 'chest') {
        const item = makeItem(this.rng, s.level, p.cls, null, it.luck || 0.6);
        if (it.luck >= 3 && item.rar === 'comu') item.rar = 'rar';
        s.inv.push(item); this.emit('pick', { kind: 'item', item }, p.id);
      }
    } else if (m.a === 'sell' && near('oleguer')) {
      const i = s.inv.findIndex((x) => x.id === m.id);
      if (i >= 0) { s.gold += Math.round(s.inv[i].price * 0.4); s.inv.splice(i, 1); }
    } else if (m.a === 'skin' && near('rina')) {
      const list = SKINS[m.cat]; const sk = list && list.find((x) => x.id === m.id);
      if (!sk) return;
      s.owned[m.cat] = s.owned[m.cat] || [];
      if (!s.owned[m.cat].includes(sk.id)) {
        if (s.gold < sk.price) return this.emit('deny', { msg: 'No tens prou or' }, p.id);
        s.gold -= sk.price; s.owned[m.cat].push(sk.id);
      }
      s.skins[m.cat] = sk.id;
      this.emit('skin', { id: p.id, skins: s.skins });
    } else if (m.a === 'teleport') {
      const w = WAYSTONES.find((x) => x.id === m.id);
      const nearW = WAYSTONES.some((x) => Math.hypot(p.x - x.x, p.z - x.z) < 8 && Math.abs((x.island ? ISLAND[x.island].top : height(x.x, x.z)) - p.y) < 8) || near('rina');
      if (!w || !s.waystones.includes(w.id) || !nearW) return;
      const y = w.island ? ISLAND[w.island].top + 0.5 : height(w.x, w.z) + 0.3;
      this.teleport(p, w.x + 2, y, w.z + 3);
    }
    this.markSave(p, true);
  }

  onInventory(p, m) {
    const s = p.save;
    if (m.a === 'equip') {
      const i = s.inv.findIndex((x) => x.id === m.id);
      if (i < 0) return;
      const it = s.inv[i];
      const old = s.equip[it.slot];
      s.inv.splice(i, 1);
      if (old) s.inv.push(old);
      s.equip[it.slot] = it;
      this.recalc(p);
      this.emit('equip', { id: p.id, weapon: s.equip.arma ? s.equip.arma.model : null, rar: s.equip.arma ? s.equip.arma.rar : null });
    } else if (m.a === 'unequip') {
      const it = s.equip[m.slot];
      if (it && s.inv.length < 24) { s.inv.push(it); delete s.equip[m.slot]; this.recalc(p); }
      this.emit('equip', { id: p.id, weapon: s.equip.arma ? s.equip.arma.model : null });
    } else if (m.a === 'talent') {
      if (s.talentPts > 0 && ['poder', 'vitalitat', 'agilitat', 'saviesa'].includes(m.stat)) { s.talents[m.stat]++; s.talentPts--; this.recalc(p); }
    } else if (m.a === 'drop') {
      const i = s.inv.findIndex((x) => x.id === m.id); if (i >= 0) s.inv.splice(i, 1);
    } else if (m.a === 'runes') {
      // runes d'una habilitat
      const key = String(m.key || '');
      const c = CLASSES[p.cls];
      if (![c.basic, c.ult, ...slotChoices(s)].includes(key)) return;
      const base = key === 'custom' ? (s.custom ? buildCustomAbility(s.custom) : null) : ABILITIES[key];
      s.runes = { ...(s.runes || {}) };
      s.runes[key] = validRunes(base, Array.isArray(m.runes) ? m.runes.map(String) : [], s.level);
    } else if (m.a === 'slots') {
      const c = CLASSES[p.cls];
      const ok = slotChoices(s);
      if (Array.isArray(m.slots) && m.slots.length === 4) s.slots = m.slots.map((k, i) => (ok.includes(k) ? k : c.abilities[i]));
    } else if (m.a === 'grimori') {
      // llibre d'encanteris propis
      s.grimori = Array.isArray(s.grimori) ? s.grimori : [];
      const idx = m.idx | 0;
      if (m.op === 'save' && m.spec) {
        const spec = { form: String(m.spec.form), el: String(m.spec.el), pow: clamp(m.spec.pow | 0, 0, 2), name: String(m.spec.name || 'Encanteri').replace(/[<>]/g, '').slice(0, 24) };
        if (idx >= 0 && idx < s.grimori.length) s.grimori[idx] = spec; else if (s.grimori.length < MAX_GRIMORI) s.grimori.push(spec);
      } else if (m.op === 'del' && idx >= 0 && idx < s.grimori.length) s.grimori.splice(idx, 1);
      else if (m.op === 'use' && s.grimori[idx]) {
        s.custom = { ...s.grimori[idx] };
        if (Array.isArray(m.slots) && m.slots.length === 4) { const c = CLASSES[p.cls]; const ok = slotChoices(s); s.slots = m.slots.map((k, i) => (ok.includes(k) ? k : c.abilities[i])); }
      }
    } else if (m.a === 'skill') {
      // aprendre o pujar de rang un node d'una branca
      s.skills = s.skills || {};
      const why = canLearn(s, String(m.id));
      if (why) return this.emit('deny', { msg: why }, p.id);
      s.skills[m.id] = (s.skills[m.id] | 0) + 1;
      const nd = skillNode(m.id);
      this.recalc(p);
      if (nd && nd.eff.some((e) => e.unlock)) this.emit('note', { msg: `Has après ${nd.name}! Posa-la a una tecla des del Grimori (K).` }, p.id);
    } else if (m.a === 'skillReset') {
      s.skills = {};
      const c = CLASSES[p.cls];
      if (s.slots) s.slots = s.slots.map((k, i) => (slotChoices(s).includes(k) ? k : c.abilities[i]));
      this.recalc(p);
      this.emit('note', { msg: 'Has reiniciat les branques: tens tots els punts per tornar-los a repartir.' }, p.id);
    } else if (m.a === 'talentReset') {
      s.talents = { poder: 0, vitalitat: 0, agilitat: 0, saviesa: 0 }; s.talentPts = Math.max(0, s.level - 1);
      this.recalc(p);
      this.emit('note', { msg: 'Has reiniciat les estadístiques.' }, p.id);
    } else if (m.a === 'loadout') {
      // conjunts guardats: habilitats a les ranures + runes + encanteri propi
      s.loadouts = Array.isArray(s.loadouts) ? s.loadouts : [];
      const idx = m.idx | 0;
      if (m.op === 'save') {
        const L = { name: String(m.name || `Conjunt ${idx + 1}`).replace(/[<>]/g, '').slice(0, 20), slots: s.slots ? [...s.slots] : null, runes: JSON.parse(JSON.stringify(s.runes || {})), custom: s.custom ? { ...s.custom } : null };
        if (idx >= 0 && idx < s.loadouts.length) s.loadouts[idx] = L; else if (s.loadouts.length < MAX_LOADOUTS) s.loadouts.push(L);
      } else if (m.op === 'del' && idx >= 0 && idx < s.loadouts.length) s.loadouts.splice(idx, 1);
      else if (m.op === 'load' && s.loadouts[idx]) {
        const L = s.loadouts[idx];
        s.custom = L.custom ? { ...L.custom } : s.custom;
        s.slots = L.slots ? [...L.slots] : null;
        s.runes = JSON.parse(JSON.stringify(L.runes || {}));
        this.emit('note', { msg: `Conjunt «${L.name}» equipat` }, p.id);
      }
    }
    this.markSave(p, true);
  }

  usePotion(p, kind) {
    const s = p.save;
    if (this.t < p.potionCd) return this.emit('deny', { msg: 'Espera abans de beure una altra poció' }, p.id);
    if (!s.potions[kind]) return this.emit('deny', { msg: 'No et queden pocions' }, p.id);
    s.potions[kind]--; p.potionCd = this.t + 6;
    if (kind === 'vida') this.healPlayer(p, p.stats.maxHp * 0.45);
    else { p.mana = Math.min(p.stats.maxMana, p.mana + p.stats.maxMana * 0.5); }
    this.emit('potion', { id: p.id, kind });
    this.markSave(p);
  }

  interact(p, m) {
    const s = p.save;
    if (m.what === 'chest') {
      const c = CHESTS.find((x) => x.id === m.id);
      if (!c || Math.hypot(p.x - c.x, p.z - c.z) > 4) return;
      let opened = this.chestOpened.get(p.id); if (!opened) this.chestOpened.set(p.id, opened = {});
      const needCrystal = c.quest === 'cristall' && STORY[s.story.idx] && STORY[s.story.idx].id === 'c2' && s.story.accepted && (s.story.progress[0] || 0) < 3 && !(s.flags['cristall_' + c.id]);
      if (opened[c.id] && opened[c.id] > this.t && !needCrystal) return this.emit('deny', { msg: 'El cofre és buit. Torna més tard.' }, p.id);
      opened[c.id] = this.t + 300;
      this.emit('chest', { id: c.id, p: p.id });
      if (needCrystal) { s.flags['cristall_' + c.id] = 1; this.questProgress(p, 'collect', 'cristall'); this.emit('pick', { kind: 'cristall' }, p.id); }
      const zl = c.structure ? (STRUCTURES.find((x) => x.id === c.structure) || {}).lvl || zoneAt(c.x, c.z, p.y).lvl : zoneAt(c.x, c.z, p.y).lvl;
      // els cofres del fons de les fortaleses donen més or i sempre un objecte bo
      this.dropLoot({ kind: 'gold', amount: (20 + zl * 8) * (c.structure ? 3 : 1) }, c);
      if (c.structure) { this.dropLoot({ kind: 'item', lvl: zl + 1, luck: 2.2 }, c); this.dropLoot({ kind: 'potion', potion: 'mana' }, c); }
      else if (this.rng() < 0.65) this.dropLoot({ kind: 'item', lvl: Math.max(zl, 1), luck: 0.8 }, c);
      if (this.rng() < 0.5) this.dropLoot({ kind: 'potion', potion: 'vida' }, c);
      this.markSave(p);
    } else if (m.what === 'waystone') {
      const w = WAYSTONES.find((x) => x.id === m.id);
      if (!w || Math.hypot(p.x - w.x, p.z - w.z) > 6) return;
      if (!s.waystones.includes(w.id)) { s.waystones.push(w.id); this.emit('waystone', { id: w.id, name: w.name }, p.id); this.markSave(p, true); }
    } else if (m.what === 'launch') {
      const lp = LAUNCHPADS.find((x) => x.id === m.id);
      if (!lp || Math.hypot(p.x - lp.x, p.z - lp.z) > 5) return;
      if (lp.need && s.story.idx < lp.need) return this.emit('deny', { msg: 'El corrent de vent encara és massa feble. Parla amb la Sàvia Elna.' }, p.id);
      if (lp.quest && !s.flags.pedraVent) {
        const ch = STORY[s.story.idx];
        const can = (ch && ch.id === 'c4' && s.story.accepted) || s.story.idx > 3;
        if (!can) return this.emit('deny', { msg: 'La Pedra de Vent dorm. Encara no és el moment.' }, p.id);
        s.flags.pedraVent = 1; this.questProgress(p, 'activate', 'pedra_vent');
        if (!s.waystones.includes('cel')) s.waystones.push('cel');
        this.markSave(p, true);
      }
      p.allowJump = this.t + 8;
      this.emit('launch', { id: lp.id, p: p.id });
    }
  }

  markSave(p, now = false) { this.saveDirty.add(p.id); if (now) this.flushSaves(true); }
  flushSaves(force = false) {
    if (!force && this.t - this.lastSaveFlush < 1.5) return;
    this.lastSaveFlush = this.t;
    for (const id of this.saveDirty) {
      const p = this.players.get(id); if (!p) continue;
      this.emit('save', p.save, id);
      this.sendMe(p);
    }
    this.saveDirty.clear();
  }

  sendMe(p) {
    const b = {};
    for (const [k, v] of Object.entries(p.buffs)) if (v.until > this.t) b[k] = { t: r2(v.until - this.t), a: v.amt ? Math.round(v.amt) : 0 };
    this.emit('me', { hp: Math.round(p.hp), mhp: p.stats.maxHp, mana: Math.round(p.mana), mmana: p.stats.maxMana, aura: Math.round(p.aura), stats: p.stats,
      tr: p.transform && p.transform.until > this.t ? { key: p.transform.ab, t: r2(p.transform.until - this.t), sm: p.transform.statMult || 0 } : null, buffs: b,
      st: Object.fromEntries(Object.entries(p.statuses).filter(([k, v]) => !k.endsWith('Dps') && !k.endsWith('Amt') && v > this.t).map(([k, v]) => [k, r2(v - this.t)])) }, p.id);
  }

  // ------------------------------------------------------------------ tick
  tick(dt) {
    this.t += dt;
    // accions programades
    if (this.pending.length) {
      const due = this.pending.filter((a) => a.t <= this.t);
      this.pending = this.pending.filter((a) => a.t > this.t);
      for (const a of due) { try { a.fn(); } catch (e) { console.error(e); } }
    }
    this.updatePlayers(dt);
    if (this.hasEnemies) this.updateEnemies(dt);
    if (this.isPve) this.updateMatch(dt);
    if (this.isRace) this.updateRace();
    if (this.mode === 'turo' && !this.pvp.roundEnd) this.updateHill(dt);
    this.updateProjs(dt);
    this.updateFields(dt);
    this.updateLoot();
    if (this.isPvp && this.pvp.roundEnd && this.t > this.pvp.roundEnd) {
      this.pvp.roundEnd = 0; this.pvp.scores = {}; for (const q of this.players.values()) this.pvp.scores[q.team] = 0;
      for (const q of this.players.values()) { q.kills = 0; q.deaths = 0; q.dead = false; this.recalc(q, true); this.placeAtArena(q); }
      this.emit('pvp', this.pvpInfo());
    }
    this.flushSaves();
  }

  updatePlayers(dt) {
    for (const p of this.players.values()) {
      if (p.dead) continue;
      const st = p.statuses;
      if ((st.burn > this.t || st.poison > this.t) && this.t > (p.dotT || 0)) {
        p.dotT = this.t + 0.5;
        if (st.burn > this.t) this.damagePlayer(p, (st.burnDps || 5) * 0.5, null, 'foc', { noPoise: true, fall: true });
        if (st.poison > this.t) this.damagePlayer(p, (st.poisonDps || 5) * 0.5, null, 'poison', { noPoise: true, fall: true });
      }
      if (p.dead) continue;
      const inCombat = this.t - Math.max(p.lastDmgT, p.lastHitT || -99) < 5;
      p.hp = Math.min(p.stats.maxHp, p.hp + p.stats.hpRegen * (inCombat ? 0.3 : 2.5) * dt);
      p.mana = Math.min(p.stats.maxMana, p.mana + p.stats.manaRegen * dt);
      if (!inCombat && p.aura < 100) p.aura = Math.max(0, p.aura - 0.6 * dt); // plena, es guarda
      const tr = p.transform;
      if (tr && tr.until > this.t) {
        const ab = tr.def || ABILITIES[tr.ab];
        const sp = p.eff ? p.eff.sp : null;
        if (ab.autoStrike && this.t > tr.nextStrike) {
          const wrath = sp && sp.has('wrath');
          tr.nextStrike = this.t + ab.autoStrike.every * (wrath ? 0.5 : 1);
          const near = this.targetsNear(p, p, ab.autoStrike.range);
          if (near.length) {
            const t = near[Math.floor(this.rng() * near.length)];
            this.emit('zap', { p: p.id, el: 'llamp', fx: 'strike', pts: [[r2(t.x), r2(t.y + 14), r2(t.z)], [r2(t.x), r2(t.y + 1), r2(t.z)]] });
            this.damage(p, t, ab.autoStrike.dmg * powerMult(p.stats.poder) * (wrath ? 1.5 : 1), 'llamp', { shock: { dur: 0.6 } }, {});
          }
        }
        if (ab.aura && this.t > tr.nextAura) {
          tr.nextAura = this.t + 0.5;
          const deep = sp && sp.has('deepwinter');
          const R = ab.aura.radius * (deep ? 1.5 : 1);
          const freeze = deep && this.t > tr.nextFreeze;
          if (freeze) { tr.nextFreeze = this.t + 3; this.emit('nova', { p: p.id, key: 'hivern', el: 'gel', fx: 'nova', r: R, x: r2(p.x), y: r2(p.y), z: r2(p.z) }); }
          for (const t of this.targetsNear(p, p, R)) this.damage(p, t, ab.aura.dps * 0.5 * (1 + p.stats.poder / 60), 'gel', freeze ? { freeze: { dur: 1.3 } } : { slow: { dur: 1, amt: ab.aura.slow } }, {});
        }
        // Apocalipsi: meteorits durant l'Avatar del Fènix
        if (tr.ab === 'fenix' && sp && sp.has('apocalypse') && this.t > tr.nextMeteor) {
          tr.nextMeteor = this.t + 1.3;
          const near = this.targetsNear(p, p, 20);
          if (near.length) {
            const t = near[Math.floor(this.rng() * near.length)];
            const pt = [r2(t.x), r2(groundAt(t.x, t.z, t.y + 3)), r2(t.z)];
            this.emit('ground', { p: p.id, key: 'meteorit', el: 'foc', fx: 'meteor', r: 3.6, delay: 0.7, interval: 0, pts: [pt] });
            this.later(0.7, () => this.aoe(p, { x: pt[0], y: pt[1], z: pt[2] }, 3.6, 46 * powerMult(p.stats.poder), 'foc', { burn: { dur: 3, dps: 9 } }, { knock: 4 }));
          }
        }
      } else if (tr) { const had = tr.statMult; p.transform = null; if (had) this.recalc(p); this.emit('untransform', { p: p.id }); }
      // envia estat propi de tant en tant
      if (!p._meT || this.t - p._meT > 0.25) { p._meT = this.t; this.sendMe(p); }
    }
  }

  addField(owner, x, y, z, o) {
    const f = { id: this.id(), owner, team: owner.team, x, y, z, r: o.r, until: this.t + o.dur, tick: o.tick, next: this.t, dmg: o.dmg, el: o.el, status: o.status, fx: o.fx, leech: o.leech,
      follow: o.follow, pull: o.pull || 0, endDmg: o.endDmg || 0, endR: o.endR || 0 };
    this.fields.push(f);
    this.emit('field', this.fieldInfo(f));
    return f;
  }
  updateFields(dt = 0) {
    if (!this.fields.length) return;
    for (const f of this.fields) {
      if (f.follow) { if (f.owner.dead || !this.players.has(f.owner.id)) { f.until = this.t; continue; } f.x = f.owner.x; f.y = f.owner.y; f.z = f.owner.z; }
      if (f.pull && dt) {
        for (const t of this.targetsNear(f.owner, f, f.r + 1)) {
          if (!t.def || t.boss || t.def.static || !t.alive) continue;
          const dx = f.x - t.x, dz = f.z - t.z, d = Math.hypot(dx, dz);
          if (d < 1) continue;
          const step = Math.min(d - 0.8, f.pull * dt);
          t.x += dx / d * step; t.z += dz / d * step;
          if (!t.island) t.y = height(t.x, t.z);
        }
      }
      if (this.t >= f.next && this.t < f.until) {
        f.next = this.t + f.tick;
        this.aoe(f.owner, f, f.r, f.dmg, f.el, f.status, { team: f.team, leech: f.leech });
      }
      if (f.endDmg && this.t >= f.until && !f.ended) {
        f.ended = true;
        this.emit('impact', { x: r2(f.x), y: r2(f.y), z: r2(f.z), r: f.endR, el: f.el });
        this.aoe(f.owner, f, f.endR, f.endDmg, f.el, f.status, { team: f.team, knock: 6, leech: f.leech });
      }
    }
    this.fields = this.fields.filter((f) => f.until > this.t);
  }
  fieldInfo(f) { return { id: f.id, x: r2(f.x), y: r2(f.y), z: r2(f.z), r: f.r, el: f.el, fx: f.fx, t: r2(f.until - this.t), follow: f.follow ? f.owner.id : undefined }; }

  // ------------------------------------------------------------------ IA d'enemics
  updateEnemies(dt) {
    const grid = this.world.grid;
    const list = [...this.enemies.values()];
    for (const e of list) {
      if (!e.alive) {
        if (e.camp && e.respawnAt && this.t > e.respawnAt) {
          // reapareix si no hi ha jugadors massa a prop
          const near = [...this.players.values()].some((p) => dist2(p, e.home) < 30);
          if (!near) {
            this.enemies.delete(e.id);
            const i = e.camp.members.indexOf(e); if (i >= 0) e.camp.members.splice(i, 1);
            const idx = e.camp.def.list.findIndex((x) => x[0] === e.type);
            this.spawnEnemy(e.type, e.camp, e.variant, Math.floor(this.rng() * 5), Math.max(2, e.camp.def.list.reduce((a, b) => a + b[1], 0)), null);
            void idx;
          } else e.respawnAt = this.t + 8;
        } else if (!e.camp && this.t - e.deadT > 6) this.enemies.delete(e.id);
        continue;
      }
      const d = e.def;
      const st = e.statuses;
      // efectes
      if ((st.burn > this.t || st.poison > this.t) && this.t > (e.dotT || 0)) {
        e.dotT = this.t + 0.5;
        const dot = Math.max(1, Math.round(((st.burn > this.t ? st.burnDps || 4 : 0) + (st.poison > this.t ? st.poisonDps || 4 : 0)) * 0.5));
        e.hp -= dot;
        this.emit('hit', { t: e.id, e: 1, d: dot, el: st.burn > this.t ? 'foc' : 'poison', dot: 1, x: r2(e.x), y: r2(e.y + d.height * 0.8), z: r2(e.z), hp: Math.max(0, Math.round(e.hp)) });
        if (e.hp <= 0) { this.killEnemy(e, this.players.get(e.target) || null); continue; }
      }
      if (d.static) { this.updateTotem(e); continue; }
      const frozen = st.freeze > this.t || st.stun > this.t;
      // selecció d'objectiu
      let tgt = e.target != null ? this.players.get(e.target) : null;
      if (tgt && (tgt.dead || Math.abs(tgt.y - e.y) > 15)) { tgt = null; e.target = null; }
      if (!tgt && e.state !== 'spawn') {
        let best = null, bd = (e.aggroR || d.aggro) * (d.boss ? 1 : FIERCE.aggro);
        for (const p of this.players.values()) {
          if (p.dead || Math.abs(p.y - e.y) > 10) continue;
          const dd = dist2(p, e); if (dd < bd) { bd = dd; best = p; }
        }
        if (best) { tgt = best; e.target = best.id; if (!e.engaged) { e.engaged = true; this.emit('aggro', { id: e.id }); } }
      }
      const homeD = dist2(e, e.home);
      const leash = e.boss ? 46 : Math.max(38, d.aggro * 2.4);
      if (tgt && homeD > leash && dist2(tgt, e.home) > leash) { e.target = null; tgt = null; e.state = 'return'; }
      if (e.boss && !tgt && e.engaged && !this.anyPlayerNear(e, 60)) { e.engaged = false; e.hp = e.maxHp; e.phase = 1; e.dmgBy.clear(); this.emit('bossReset', { id: e.id }); }
      let moveX = 0, moveZ = 0, speed = d.speed * (d.boss ? 1 : FIERCE.speed) * (st.slow > this.t ? 1 - (st.slowAmt || 0.3) : 1) * (e.phase >= 3 ? 1.2 : 1);
      if (frozen) {
        e.state = e.state === 'dead' ? 'dead' : 'stun';
      } else switch (e.state) {
        case 'spawn':
          if (this.t > e.stateT) e.state = 'idle';
          break;
        case 'stun':
          e.state = 'idle';
          break;
        case 'hit':
          if (e.kx) { moveX = e.kx; moveZ = e.kz; e.kx *= 0.8; e.kz *= 0.8; speed = 1; }
          if (this.t > e.stateT) { e.state = tgt ? 'move' : 'idle'; e.kx = 0; e.kz = 0; }
          break;
        case 'windup':
          if (tgt && e.atk && e.atk.track) e.ry = turn(e.ry, angleTo(e, tgt), dt * 3);
          if (this.t > e.stateT) this.resolveAttack(e, tgt);
          break;
        case 'recover':
          if (e.atk && e.atk.move) { moveX = Math.sin(e.ry); moveZ = Math.cos(e.ry); speed = e.atk.move; }
          if (this.t > e.stateT) { e.state = tgt ? 'move' : 'idle'; e.atk = null; }
          break;
        case 'return':
          if (homeD < 3) { e.state = 'idle'; e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.5); break; }
          moveX = (e.home.x - e.x) / homeD; moveZ = (e.home.z - e.z) / homeD; speed *= 1.3;
          e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.15 * dt);
          break;
        default: {
          if (tgt) {
            const dd = dist2(e, tgt);
            const want = angleTo(e, tgt);
            e.ry = turn(e.ry, want, dt * 7);
            const range = (d.boss ? d.range : d.range) + (tgt.def ? 0 : 0.2);
            if (d.keep && dd < d.keep * 0.6) { moveX = -Math.sin(want); moveZ = -Math.cos(want); speed *= 0.7; e.state = 'move'; }
            else if (dd > range * 0.9) { moveX = Math.sin(want); moveZ = Math.cos(want); e.state = 'move'; }
            else e.state = 'idle';
            if (dd < range + 0.4 && this.t > e.atkCd) this.startAttack(e, tgt, dd);
            else if (d.ranged && dd < d.range && this.t > e.atkCd) this.startAttack(e, tgt, dd);
          } else {
            // passejar a prop de casa
            if (this.t > e.wanderT) {
              e.wanderT = this.t + 3 + this.rng() * 5;
              const a = this.rng() * TAU, r = (e.camp && e.camp.def.r) || 4;
              e.wander = { x: e.home.x + Math.cos(a) * r * 0.8, z: e.home.z + Math.sin(a) * r * 0.8 };
            }
            if (e.wander && !e.boss) {
              const wd = Math.hypot(e.wander.x - e.x, e.wander.z - e.z);
              if (wd > 1) { moveX = (e.wander.x - e.x) / wd; moveZ = (e.wander.z - e.z) / wd; speed *= 0.4; e.ry = turn(e.ry, Math.atan2(moveX, moveZ), dt * 4); e.state = 'move'; }
              else e.state = 'idle';
            }
          }
        }
      }
      if (moveX || moveZ) {
        let nx = e.x + moveX * speed * dt, nz = e.z + moveZ * speed * dt;
        // separació
        for (const o of list) {
          if (o === e || !o.alive) continue;
          const dx = nx - o.x, dz = nz - o.z; const dd = Math.hypot(dx, dz); const m = (d.radius + o.def.radius) * 0.9;
          if (dd < m && dd > 0.001) { nx += dx / dd * (m - dd) * 0.5; nz += dz / dd * (m - dd) * 0.5; }
        }
        if (!e.island) [nx, nz] = collide(grid, nx, nz, d.radius, e.y);
        if (e.island) {
          const is = ISLAND[e.island]; const id = Math.hypot(nx - is.x, nz - is.z);
          if (id > is.r - 1.5) { nx = is.x + (nx - is.x) / id * (is.r - 1.5); nz = is.z + (nz - is.z) / id * (is.r - 1.5); }
          e.y = islandTop(is, nx, nz);
        } else {
          const h = height(nx, nz);
          if (h < -0.5) { nx = e.x; nz = e.z; } else e.y = h;
        }
        if (Math.hypot(nx, nz) > WORLD.walkRadius && !e.island) { nx = e.x; nz = e.z; }
        e.x = nx; e.z = nz;
      }
      // fases de cap
      if (e.boss) {
        const f = e.hp / e.maxHp;
        const ph = f < 0.3 ? 3 : f < 0.62 ? 2 : 1;
        if (ph > e.phase) { e.phase = ph; this.emit('bossPhase', { id: e.id, phase: ph }); if (e.type === 'rei_ossut' || e.type === 'ombra' || e.type === 'ganfaul') this.bossSummon(e, ph === 3 ? 5 : 3); }
      }
    }
  }

  anyPlayerNear(e, r) { for (const p of this.players.values()) if (!p.dead && dist2(p, e) < r) return true; return false; }

  updateTotem(e) {
    const s = e.def.summon;
    if (!e.nextSummon) e.nextSummon = this.t + s.every;
    const near = this.anyPlayerNear(e, 32);
    if (near && this.t > e.nextSummon) {
      e.nextSummon = this.t + s.every;
      const alive = [...this.enemies.values()].filter((m) => m.owner === e.id && m.alive).length;
      if (alive < s.max) {
        const a = this.rng() * TAU;
        const m = this.spawnEnemy(s.type, null, s.variant, 0, 1, { x: e.x + Math.cos(a) * 4, z: e.z + Math.sin(a) * 4 }, { lvl: e.lvl, summoned: true, owner: e.id });
        this.emit('summon', { id: e.id, m: m.id });
      }
    }
  }

  startAttack(e, tgt, dd) {
    const d = e.def;
    let name = 'attack', anim, windup = d.windup * (e.phase >= 2 ? 0.8 : 1) * (d.boss ? 1 : FIERCE.windup), kind = d.ranged ? 'ranged' : 'melee';
    if (d.boss && d.attacks) {
      name = d.attacks[e.pattern % d.attacks.length]; e.pattern++;
      if (name === 'summon' || name === 'clones') { if ([...this.enemies.values()].filter((m) => m.owner === e.id && m.alive).length >= 4) name = 'slam'; }
      if (name === 'blink' && dd < 6) name = 'nova';
      anim = d.anims[name] || d.anims.attack[0];
      kind = (d.kinds && d.kinds[name]) || name;
      windup = (d.windups && d.windups[name]) || { slam: 0.95, spin: 0.85, summon: 1.1, charge: 0.75, meteors: 1.0, nova: 1.05, barrage: 0.7, blink: 0.4, clones: 1.0 }[name] || windup;
      if (e.phase >= 2) windup *= 0.85;
      if (name === 'slam' && dd > d.range + 1.5 && e.type !== 'ombra') { name = 'charge'; kind = 'charge'; anim = d.anims.charge || anim; windup = 0.7; }
    } else {
      const list = d.anims.attack; anim = list[Math.floor(this.rng() * list.length)];
    }
    const atk = { name, kind, anim, tx: tgt.x, tz: tgt.z, track: kind === 'melee' || kind === 'ranged' || kind === 'barrage' };
    const radii = d.radii || {};
    // telegrafies
    let tele = null;
    if (kind === 'slam') { const a = angleTo(e, tgt); atk.cx = e.x + Math.sin(a) * d.range * 0.7; atk.cz = e.z + Math.cos(a) * d.range * 0.7; atk.r = radii.slam || 5.5; tele = { x: atk.cx, z: atk.cz, r: atk.r }; e.ry = a; }
    if (kind === 'spin' || kind === 'nova') { atk.cx = e.x; atk.cz = e.z; atk.r = kind === 'nova' ? (radii.nova || 9) : (radii.spin || 6.5); tele = { x: atk.cx, z: atk.cz, r: atk.r }; }
    if (kind === 'breath') { const a = angleTo(e, tgt); e.ry = a; atk.dir = a; atk.len = 19; atk.ang = 0.62; tele = { x: e.x, z: e.z, cone: [r2(a), atk.len, atk.ang] }; }
    if (kind === 'charge') { const a = angleTo(e, tgt); e.ry = a; atk.dir = a; atk.len = Math.min(18, dd + 3); tele = { x: e.x, z: e.z, line: [r2(Math.sin(a) * atk.len), r2(Math.cos(a) * atk.len)], r: 2.6 }; }
    if (kind === 'meteors') {
      atk.pts = [...this.players.values()].filter((p) => !p.dead && dist2(p, e) < 40).slice(0, 4).map((p) => ({ x: p.x + (this.rng() - 0.5) * 2, z: p.z + (this.rng() - 0.5) * 2 }));
      for (let i = atk.pts.length; i < 4; i++) { const a = this.rng() * TAU, r = 4 + this.rng() * 12; atk.pts.push({ x: e.x + Math.cos(a) * r, z: e.z + Math.sin(a) * r }); }
      tele = { pts: atk.pts.map((p) => [r2(p.x), r2(p.z)]), r: 4.2 };
      windup = 1.25;
    }
    e.atk = atk; e.state = 'windup'; e.stateT = this.t + windup;
    this.emit('eatk', { id: e.id, a: anim, w: r2(windup), k: kind, tele, y: r2(e.y) });
  }

  resolveAttack(e, tgt) {
    const d = e.def; const atk = e.atk || {};
    const dmg = e.dmg * (e.phase >= 3 ? 1.25 : 1);
    const recover = d.recover * (e.phase >= 2 ? 0.8 : 1) * (d.boss ? 1 : FIERCE.recover);
    e.state = 'recover'; e.stateT = this.t + recover;
    e.atkCd = this.t + recover + (d.boss ? 0.6 : 0.35 + this.rng() * 0.9);
    switch (atk.kind) {
      case 'melee': {
        for (const p of this.players.values()) {
          if (p.dead) continue;
          const dd = dist2(e, p);
          if (dd < d.range + 0.8 && Math.abs(angDiff(e.ry, angleTo(e, p))) < 1.0 && Math.abs(p.y - e.y) < 3) {
            const st = e.el === 'foc' ? { burn: { dur: 3, dps: 6 } } : e.el === 'gel' ? { slow: { dur: 2, amt: 0.35 } } : e.el === 'poison' ? { poison: { dur: 4, dps: 6 } } : null;
            this.damagePlayer(p, dmg, e, e.el || 'fisic', { knock: 2, status: st });
          }
        }
        break;
      }
      case 'ranged': {
        const t = tgt || this.players.get(e.target);
        if (!t) break;
        const r = d.ranged;
        const ox = e.x + Math.sin(e.ry) * 0.8, oz = e.z + Math.cos(e.ry) * 0.8, oy = e.y + d.height * 0.65;
        const tt = dist2(e, t) / r.speed;
        const tx = t.x, tz = t.z, ty = t.y + 1;
        void tt;
        let dx = tx - ox, dy = ty - oy, dz = tz - oz; const l = Math.hypot(dx, dy, dz) || 1;
        this.spawnProj({ owner: e, team: -1, x: ox, y: oy, z: oz, dir: [dx / l, dy / l, dz / l], speed: r.speed, range: d.range + 6, radius: r.radius, dmg, el: r.el, fx: r.fx, status: r.el === 'foc' ? { burn: { dur: 3, dps: 6 } } : null });
        break;
      }
      case 'slam': case 'spin': case 'nova': {
        this.emit('impact', { x: r2(atk.cx), y: r2(e.y), z: r2(atk.cz), r: atk.r, el: e.el || (e.type === 'ombra' ? 'ombra' : 'fisic'), k: atk.kind });
        for (const p of this.players.values()) {
          if (p.dead) continue;
          if (Math.hypot(p.x - atk.cx, p.z - atk.cz) < atk.r && Math.abs(p.y - e.y) < 4) this.damagePlayer(p, dmg * (atk.kind === 'nova' ? 1.1 : 1.3), e, e.el || 'fisic', { knock: 7, status: atk.kind === 'nova' && e.type === 'ombra' ? { slow: { dur: 2, amt: 0.4 } } : null });
        }
        break;
      }
      case 'charge': {
        const a = atk.dir; const len = atk.len;
        const sx = e.x, sz = e.z;
        let ex = e.x + Math.sin(a) * len, ez = e.z + Math.cos(a) * len;
        if (!e.island) [ex, ez] = collide(this.world.grid, ex, ez, d.radius, e.y);
        for (const p of this.players.values()) {
          if (p.dead) continue;
          const dd = segDist(p.x, p.z, sx, sz, ex, ez);
          if (dd < 2.8 && Math.abs(p.y - e.y) < 4) this.damagePlayer(p, dmg * 1.2, e, 'fisic', { knock: 9 });
        }
        e.x = ex; e.z = ez; e.y = e.island ? islandTop(ISLAND[e.island], ex, ez) : height(ex, ez);
        this.emit('impact', { x: r2(ex), y: r2(e.y), z: r2(ez), r: 4, el: 'fisic', k: 'charge' });
        break;
      }
      case 'meteors': {
        this.emit('ground', { p: -e.id, key: 'meteor_boss', el: e.el || 'foc', fx: 'meteor', r: 4.2, delay: 0.05, interval: 0.12, pts: atk.pts.map((pt) => [r2(pt.x), r2(e.y), r2(pt.z)]) });
        atk.pts.forEach((pt, i) => this.later(0.1 + i * 0.12, () => {
          for (const p of this.players.values()) if (!p.dead && Math.hypot(p.x - pt.x, p.z - pt.z) < 4.2) this.damagePlayer(p, dmg * 1.1, e, e.el || 'foc', { knock: 5, status: { burn: { dur: 3, dps: 8 } } });
        }));
        break;
      }
      case 'summon': case 'clones': this.bossSummon(e, e.phase >= 3 ? 4 : 3); break;
      case 'breath': {
        // alè de foc: escombrada d'esquerra a dreta dins d'un con
        const steps = 10, len = atk.len, half = atk.ang;
        const ox = e.x + Math.sin(atk.dir) * d.radius * 0.8, oz = e.z + Math.cos(atk.dir) * d.radius * 0.8;
        for (let i = 0; i < steps; i++) {
          this.later(i * 0.14, () => {
            if (!e.alive) return;
            const cur = atk.dir - half + (2 * half * i) / (steps - 1);
            for (const p of this.players.values()) {
              if (p.dead || Math.abs(p.y - e.y) > 5) continue;
              const dd = Math.hypot(p.x - ox, p.z - oz);
              if (dd > len) continue;
              const ang = Math.abs(angDiff(cur, Math.atan2(p.x - ox, p.z - oz)));
              if (ang < 0.32 || dd < 3) this.damagePlayer(p, dmg * 0.32, e, 'foc', { knock: 1.5, noPoise: i % 3 !== 0, status: { burn: { dur: 3, dps: 10 } } });
            }
          });
        }
        break;
      }
      case 'barrage': {
        const t = tgt || this.players.get(e.target); if (!t) break;
        for (let i = 0; i < 5; i++) {
          const spread = (i - 2) * 0.16; const a = angleTo(e, t) + spread;
          const oy = e.y + d.height * 0.6;
          const dy = (t.y + 1 - oy) / Math.max(4, dist2(e, t));
          const l = Math.hypot(1, dy);
          this.later(i * 0.09, () => this.spawnProj({ owner: e, team: -1, x: e.x, y: oy, z: e.z, dir: [Math.sin(a) / l, dy / l, Math.cos(a) / l], speed: d.ranged.speed, range: 40, radius: d.ranged.radius, dmg: dmg * 0.55, el: 'ombra', fx: 'darkbolt' }));
        }
        break;
      }
      case 'blink': {
        const t = tgt || this.players.get(e.target); if (!t) break;
        const a = t.ry + Math.PI + (this.rng() - 0.5);
        let nx = t.x + Math.sin(a) * 6, nz = t.z + Math.cos(a) * 6;
        if (e.island) { const is = ISLAND[e.island]; const id = Math.hypot(nx - is.x, nz - is.z); if (id > is.r - 2) { nx = is.x + (nx - is.x) / id * (is.r - 2); nz = is.z + (nz - is.z) / id * (is.r - 2); } }
        this.emit('eblink', { id: e.id, from: [r2(e.x), r2(e.y), r2(e.z)], to: [r2(nx), r2(nz)] });
        e.x = nx; e.z = nz; e.y = e.island ? islandTop(ISLAND[e.island], nx, nz) : height(nx, nz);
        e.ry = angleTo(e, t); e.atkCd = this.t + 0.4;
        break;
      }
      default:
    }
  }

  bossSummon(e, n) {
    const type = e.def.summonType || (e.type === 'ombra' ? 'puglin' : 'esquelet_minion');
    const variant = type === 'puglin' ? 'blau' : null;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + this.rng();
      let x = e.x + Math.cos(a) * 6, z = e.z + Math.sin(a) * 6;
      if (e.island) { const is = ISLAND[e.island]; const id = Math.hypot(x - is.x, z - is.z); if (id > is.r - 2) { x = is.x + (x - is.x) / id * (is.r - 2); z = is.z + (z - is.z) / id * (is.r - 2); } }
      this.spawnEnemy(type, null, variant, 0, 1, { x, z, island: e.island }, { lvl: e.lvl - 2, summoned: true, owner: e.id });
    }
    this.emit('summon', { id: e.id });
  }

  // ------------------------------------------------------------------ snapshot
  snapshot(forId) {
    const me = this.players.get(forId);
    const P = [];
    for (const p of this.players.values()) {
      if (p.id === forId) continue;
      P.push([p.id, r2(p.x), r2(p.y), r2(p.z), r2(p.ry), p.anim, Math.round(p.hp), p.stats.maxHp, (p.dead ? 1 : 0) | (p.blocking ? 4 : 0) | (p.transform && p.transform.until > this.t ? 2 : 0) | (p.flags & ~7)]);
    }
    const E = [];
    if (this.hasEnemies) {
      for (const e of this.enemies.values()) {
        if (!e.alive) continue;
        if (me && dist2(me, e) > (e.boss ? 260 : 150)) continue;
        E.push([e.id, r2(e.x), r2(e.y), r2(e.z), r2(e.ry), ANIM_CODES.indexOf(e.state), Math.max(0, Math.round(e.hp)), e.maxHp, e.statuses.freeze > this.t ? 1 : 0]);
      }
    }
    return { t: r2(this.t), P, E };
  }
}

function turn(a, b, max) { const d = angDiff(a, b); return a + clamp(d, -max, max); }
function segDist(px, pz, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az; const l2 = dx * dx + dz * dz || 1;
  const t = clamp(((px - ax) * dx + (pz - az) * dz) / l2, 0, 1);
  return Math.hypot(px - (ax + dx * t), pz - (az + dz * t));
}

export function sanitizeSave(s, cls, hero, name) {
  if (!s || typeof s !== 'object') s = newCharacter(name, cls || 'foc', hero || 'heroi1');
  const base = newCharacter(s.name || name, CLASSES[s.cls] ? s.cls : (cls || 'foc'), s.hero || hero || 'heroi1');
  const out = { ...base, ...s };
  out.name = String(out.name || 'Heroi').replace(/[<>]/g, '').slice(0, 16) || 'Heroi';
  out.cls = CLASSES[out.cls] ? out.cls : 'foc';
  out.hero = /^heroi[1-3]$/.test(out.hero) ? out.hero : 'heroi1';
  out.level = clamp(out.level | 0, 1, MAX_LEVEL);
  out.xp = Math.max(0, +out.xp || 0); out.gold = Math.max(0, Math.min(999999, +out.gold || 0));
  out.talents = { ...base.talents, ...(out.talents || {}) };
  const spent = Object.values(out.talents).reduce((a, b) => a + (b | 0), 0);
  if (spent > out.level - 1) out.talents = { ...base.talents }, out.talentPts = out.level - 1;
  out.talentPts = clamp(out.talentPts | 0, 0, out.level - 1);
  out.inv = Array.isArray(out.inv) ? out.inv.filter((i) => i && i.stats && i.slot).slice(0, 24) : [];
  out.equip = out.equip && typeof out.equip === 'object' ? out.equip : {};
  out.potions = { vida: clamp((out.potions && out.potions.vida) | 0, 0, 9), mana: clamp((out.potions && out.potions.mana) | 0, 0, 9) };
  out.story = out.story && typeof out.story.idx === 'number' ? { idx: clamp(out.story.idx | 0, 0, STORY.length), accepted: !!out.story.accepted, progress: Array.isArray(out.story.progress) ? out.story.progress.map((v) => v | 0) : [] } : base.story;
  out.waystones = Array.isArray(out.waystones) ? out.waystones.filter((w) => WAYSTONES.some((x) => x.id === w)) : ['vila'];
  if (!out.waystones.includes('vila')) out.waystones.unshift('vila');
  out.flags = out.flags && typeof out.flags === 'object' ? out.flags : {};
  out.skins = { ...base.skins, ...(out.skins || {}) }; out.owned = { ...base.owned, ...(out.owned || {}) };
  out.pvp = { ...base.pvp, ...(out.pvp || {}) };
  out.bountiesDone = Array.isArray(out.bountiesDone) ? out.bountiesDone : [];
  out.skills = sanitizeSkills(out.skills, out.cls, out.level);
  out.records = out.records && typeof out.records === 'object' && !Array.isArray(out.records) ? Object.fromEntries(Object.entries(out.records).filter(([k, v]) => MODES[k] && v && typeof v === 'object').map(([k, v]) => [k, { wave: v.wave | 0, bosses: v.bosses | 0, time: Math.max(0, Math.round((+v.time || 0) * 10) / 10), score: v.score | 0, played: v.played | 0, ...(k === 'parkour' ? { times: Array.from({ length: LEVELS.length }, (_, i) => Math.max(0, Math.round((+(Array.isArray(v.times) ? v.times[i] : i === 0 ? v.time : 0) || 0) * 10) / 10)) } : {}) }])) : {};
  out.runes = out.runes && typeof out.runes === 'object' && !Array.isArray(out.runes) ? Object.fromEntries(Object.entries(out.runes).filter(([k, v]) => typeof k === 'string' && Array.isArray(v)).map(([k, v]) => [k.slice(0, 24), v.filter((r) => RUNES[r]).slice(0, 2)])) : {};
  const okSpec = (c) => c && typeof c === 'object' && typeof c.form === 'string';
  out.grimori = Array.isArray(out.grimori) ? out.grimori.filter(okSpec).slice(0, MAX_GRIMORI) : [];
  out.loadouts = Array.isArray(out.loadouts) ? out.loadouts.filter((l) => l && typeof l === 'object').slice(0, MAX_LOADOUTS).map((l) => ({ name: String(l.name || 'Conjunt').slice(0, 20), slots: Array.isArray(l.slots) && l.slots.length === 4 ? l.slots.map(String) : null, runes: l.runes && typeof l.runes === 'object' ? l.runes : {}, custom: okSpec(l.custom) ? l.custom : null })) : [];
  return out;
}
