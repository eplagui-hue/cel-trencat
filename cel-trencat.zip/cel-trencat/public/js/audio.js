// ============================================================
//  So: efectes sintetitzats i música generativa (Web Audio)
// ============================================================
export class Audio {
  constructor() {
    this.ctx = null; this.sfxVol = 0.6; this.musicVol = 0.35; this.enabled = true;
    this.zone = null; this.mode = 'calm'; this.nextNote = 0; this.step = 0;
  }
  init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain(); this.master.gain.value = 1; this.master.connect(this.ctx.destination);
      this.sfx = this.ctx.createGain(); this.sfx.gain.value = this.sfxVol; this.sfx.connect(this.master);
      this.music = this.ctx.createGain(); this.music.gain.value = this.musicVol; this.music.connect(this.master);
      // reverb senzilla
      this.verb = this.ctx.createConvolver(); this.verb.buffer = this.impulse(2.4); const vg = this.ctx.createGain(); vg.gain.value = 0.35;
      this.verb.connect(vg); vg.connect(this.master);
      this.noiseBuf = this.makeNoise();
    } catch (e) { this.enabled = false; }
  }
  setVolumes(sfx, music) { this.sfxVol = sfx; this.musicVol = music; if (this.ctx) { this.sfx.gain.value = sfx; this.music.gain.value = music; } }
  impulse(sec) {
    const r = this.ctx.sampleRate, n = r * sec, b = this.ctx.createBuffer(2, n, r);
    for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.5); }
    return b;
  }
  makeNoise() { const n = this.ctx.sampleRate; const b = this.ctx.createBuffer(1, n, n); const d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; return b; }

  env(g, t, a, peak, d) { g.gain.cancelScheduledValues(t); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d); }
  osc(type, f, t, dur, vol, dest, f2) {
    const o = this.ctx.createOscillator(); const g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    this.env(g, t, 0.005, vol, dur); o.connect(g); g.connect(dest || this.sfx); o.start(t); o.stop(t + dur + 0.05);
    return g;
  }
  noise(t, dur, vol, filter = 'lowpass', f = 1200, f2, q = 1, dest) {
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const fl = this.ctx.createBiquadFilter(); fl.type = filter; fl.frequency.setValueAtTime(f, t); if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + dur); fl.Q.value = q;
    const g = this.ctx.createGain(); this.env(g, t, 0.01, vol, dur);
    s.connect(fl); fl.connect(g); g.connect(dest || this.sfx); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.1);
    return g;
  }

  play(name, vol = 1) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime; const v = vol;
    switch (name) {
      case 'cast_foc': this.noise(t, 0.45, 0.5 * v, 'bandpass', 600, 2400, 1.5); this.osc('sawtooth', 160, t, 0.3, 0.08 * v, null, 90); break;
      case 'cast_gel': this.osc('sine', 1800, t, 0.4, 0.12 * v, this.verb, 2600); this.osc('triangle', 2400, t + 0.05, 0.3, 0.08 * v, this.verb, 1500); this.noise(t, 0.25, 0.2 * v, 'highpass', 4000); break;
      case 'cast_llamp': this.noise(t, 0.18, 0.55 * v, 'highpass', 2000, 6000); this.osc('square', 90, t, 0.12, 0.08 * v, null, 40); break;
      case 'cast_arca': case 'cast_ombra': this.osc('sine', 520, t, 0.35, 0.12 * v, this.verb, 880); this.osc('sine', 780, t + 0.04, 0.3, 0.07 * v, this.verb, 1320); break;
      case 'slash': this.noise(t, 0.18, 0.5 * v, 'bandpass', 3000, 900, 2); break;
      case 'whoosh': this.noise(t, 0.3, 0.35 * v, 'bandpass', 400, 1600, 1); break;
      case 'hit': this.noise(t, 0.12, 0.6 * v, 'lowpass', 1800, 300); this.osc('sine', 140, t, 0.12, 0.25 * v, null, 60); break;
      case 'crit': this.noise(t, 0.16, 0.7 * v, 'lowpass', 3000, 400); this.osc('triangle', 880, t, 0.18, 0.12 * v, this.verb, 1760); break;
      case 'hurt': this.osc('sawtooth', 220, t, 0.18, 0.12 * v, null, 110); this.noise(t, 0.1, 0.3 * v, 'lowpass', 900); break;
      case 'block': this.osc('square', 1200, t, 0.08, 0.1 * v, this.verb, 900); this.noise(t, 0.08, 0.3 * v, 'highpass', 2500); break;
      case 'explosion': this.noise(t, 0.9, 0.9 * v, 'lowpass', 1400, 80); this.osc('sine', 80, t, 0.6, 0.4 * v, null, 30); break;
      case 'zap': this.noise(t, 0.25, 0.5 * v, 'bandpass', 3500, 1500, 3); break;
      case 'jump': this.osc('sine', 300, t, 0.12, 0.08 * v, null, 520); break;
      case 'land': this.noise(t, 0.12, 0.25 * v, 'lowpass', 500); break;
      case 'coin': this.osc('triangle', 1320, t, 0.08, 0.12 * v); this.osc('triangle', 1760, t + 0.07, 0.15, 0.12 * v, this.verb); break;
      case 'item': [660, 880, 1100].forEach((f, i) => this.osc('triangle', f, t + i * 0.07, 0.25, 0.1 * v, this.verb)); break;
      case 'levelup': [523, 659, 784, 1047, 1319].forEach((f, i) => this.osc('triangle', f, t + i * 0.09, 0.5, 0.12 * v, this.verb)); break;
      case 'quest': [784, 988, 1175].forEach((f, i) => this.osc('sine', f, t + i * 0.12, 0.6, 0.12 * v, this.verb)); break;
      case 'ui': this.osc('sine', 900, t, 0.05, 0.06 * v); break;
      case 'deny': this.osc('square', 180, t, 0.12, 0.06 * v); break;
      case 'heal': [660, 990].forEach((f, i) => this.osc('sine', f, t + i * 0.08, 0.4, 0.08 * v, this.verb)); break;
      case 'transform': this.noise(t, 1.4, 0.5 * v, 'bandpass', 200, 3000, 1); [262, 392, 523, 784].forEach((f, i) => this.osc('sawtooth', f, t + i * 0.1, 1.0, 0.05 * v, this.verb)); break;
      case 'death': this.osc('sawtooth', 300, t, 1.2, 0.12 * v, this.verb, 60); break;
      case 'boss': this.osc('sawtooth', 55, t, 2.0, 0.25 * v, this.verb, 50); this.noise(t, 1.5, 0.4 * v, 'lowpass', 300); break;
      case 'roar': this.noise(t, 0.8, 0.5 * v, 'bandpass', 200, 120, 2); this.osc('sawtooth', 90, t, 0.8, 0.12 * v, null, 60); break;
      case 'chest': this.osc('triangle', 440, t, 0.2, 0.1 * v, this.verb, 660); [880, 1320].forEach((f, i) => this.osc('sine', f, t + 0.15 + i * 0.1, 0.4, 0.1 * v, this.verb)); break;
      case 'launch': this.noise(t, 1.2, 0.6 * v, 'bandpass', 300, 2500, 1); break;
      default:
    }
  }

  // ---------------- música ----------------
  setZone(id, combat = false, boss = false) { this.zone = id; this.mode = boss ? 'boss' : combat ? 'combat' : 'calm'; }
  update() {
    if (!this.ctx || !this.enabled || this.musicVol <= 0.001) return;
    const t = this.ctx.currentTime;
    if (this.nextNote > t + 0.3) return;
    if (this.nextNote < t) this.nextNote = t + 0.05;
    const SCALES = {
      vila: [0, 2, 4, 7, 9], bosc: [0, 2, 3, 7, 9], ruines: [0, 3, 5, 7, 10], cremades: [0, 1, 4, 5, 7], costa: [0, 2, 4, 7, 11], cel: [0, 2, 4, 6, 9], arena: [0, 3, 5, 6, 7],
    };
    const ROOT = { vila: 57, bosc: 55, ruines: 52, cremades: 50, costa: 60, cel: 62, arena: 53 };
    const sc = SCALES[this.zone] || SCALES.vila; const root = ROOT[this.zone] || 57;
    const boss = this.mode === 'boss', combat = this.mode === 'combat' || boss;
    const beat = boss ? 0.2 : combat ? 0.26 : 0.42;
    const s = this.step++;
    const f = (n) => 440 * Math.pow(2, (n - 69) / 12);
    const tt = this.nextNote;
    // pad cada 16 passos
    if (s % 16 === 0) {
      const chordRoot = root - 12 + [0, 5, 7, 3][(s / 16) % 4 | 0];
      for (const iv of [0, 7, 12, 16]) {
        const o = this.ctx.createOscillator(); const g = this.ctx.createGain(); const fl = this.ctx.createBiquadFilter();
        o.type = 'sawtooth'; o.frequency.value = f(chordRoot + iv) * (1 + (Math.random() - 0.5) * 0.004);
        fl.type = 'lowpass'; fl.frequency.value = boss ? 900 : 650;
        g.gain.setValueAtTime(0.0001, tt); g.gain.linearRampToValueAtTime(0.022, tt + 1.2); g.gain.linearRampToValueAtTime(0.0001, tt + beat * 16 + 0.5);
        o.connect(fl); fl.connect(g); g.connect(this.music); g.connect(this.verb); o.start(tt); o.stop(tt + beat * 16 + 0.6);
      }
    }
    // arpegi
    if (s % (combat ? 1 : 2) === 0 && Math.random() < (combat ? 0.9 : 0.7)) {
      const deg = sc[Math.floor(Math.random() * sc.length)] + (Math.random() < 0.3 ? 12 : 0);
      const o = this.ctx.createOscillator(); const g = this.ctx.createGain();
      o.type = 'triangle'; o.frequency.value = f(root + deg);
      g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(0.05, tt + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, tt + beat * 3);
      o.connect(g); g.connect(this.music); g.connect(this.verb); o.start(tt); o.stop(tt + beat * 3 + 0.05);
    }
    // percussió en combat
    if (combat) {
      if (s % 4 === 0) { const g = this.osc('sine', 110, tt, 0.25, boss ? 0.35 : 0.22, this.music, 40); void g; }
      if (s % 4 === 2) this.noise(tt, 0.08, boss ? 0.18 : 0.1, 'highpass', 5000, null, 1, this.music);
      if (boss && s % 8 === 6) this.noise(tt, 0.2, 0.25, 'bandpass', 1200, 800, 1, this.music);
    }
    this.nextNote += beat;
  }
}
