// ============================================================
//  Efectes visuals: partícules, projectils, raigs, telegrafies
// ============================================================
import * as THREE from 'three';
import { ELEMENTS } from './data.js';
import { groundAt } from './worldgen.js';
import { UNI } from './world.js';

const ELC = (el) => new THREE.Color((ELEMENTS[el] || ELEMENTS.arca).color);
const ELG = (el) => new THREE.Color((ELEMENTS[el] || ELEMENTS.arca).glow);

function glowTexture() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 64;
  const g = cv.getContext('2d'); const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.2, 'rgba(255,255,255,0.85)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.25)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(cv); return t;
}

// ---------------- sistema de partícules ----------------
class Particles {
  constructor(scene, max = 6000) {
    this.max = max;
    this.pos = new Float32Array(max * 3); this.col = new Float32Array(max * 3); this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max); this.size0 = new Float32Array(max); this.grow = new Float32Array(max);
    this.count = 0; this.cursor = 0;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uTex: { value: glowTexture() }, uScale: { value: 450 }, uMax: { value: 140 } },
      vertexShader: `attribute float size; attribute float alpha; attribute vec3 color; varying vec3 vC; varying float vA; uniform float uScale, uMax;
        void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0); float z = -mv.z;
          vA = alpha * smoothstep(0.8, 3.2, z);
          gl_PointSize = min(size * uScale / max(z, 0.1), uMax); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform sampler2D uTex; varying vec3 vC; varying float vA; void main(){ vec4 t = texture2D(uTex, gl_PointCoord); gl_FragColor = vec4(vC * t.rgb * 0.8, t.a * vA); if (gl_FragColor.a < 0.01) discard; }`,
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    });
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
    scene.add(this.points);
    this.geo = geo;
    for (let i = 0; i < max; i++) this.alpha[i] = 0;
  }
  emit(x, y, z, vx, vy, vz, color, size, life, grav = 0, drag = 0, grow = 0) {
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.col[i * 3] = color.r; this.col[i * 3 + 1] = color.g; this.col[i * 3 + 2] = color.b;
    this.size0[i] = size; this.size[i] = size; this.life[i] = life; this.maxLife[i] = life; this.grav[i] = grav; this.drag[i] = drag; this.grow[i] = grow; this.alpha[i] = 1;
  }
  burst(p, n, color, opts = {}) {
    const sp = opts.speed ?? 6, up = opts.up ?? 2, size = opts.size ?? 0.6, life = opts.life ?? 0.8;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, b = Math.random() * 2 - 1, s = sp * (0.3 + Math.random() * 0.7);
      const r = Math.sqrt(1 - b * b);
      this.emit(p.x + (Math.random() - 0.5) * (opts.spread || 0), p.y + (Math.random() - 0.5) * (opts.spread || 0), p.z + (Math.random() - 0.5) * (opts.spread || 0),
        Math.cos(a) * r * s, b * s * 0.6 + up, Math.sin(a) * r * s, opts.col2 && Math.random() < 0.5 ? opts.col2 : color, size * (0.6 + Math.random() * 0.8), life * (0.6 + Math.random() * 0.8), opts.grav ?? -4, opts.drag ?? 1.8, opts.grow || 0);
    }
  }
  update(dt) {
    const n = this.max;
    for (let i = 0; i < n; i++) {
      if (this.alpha[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) { this.alpha[i] = 0; continue; }
      const d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i * 3] *= d; this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * d + this.grav[i] * dt; this.vel[i * 3 + 2] *= d;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      const k = this.life[i] / this.maxLife[i];
      this.alpha[i] = Math.min(1, k * 2.2);
      this.size[i] = this.size0[i] * (this.grow[i] ? 1 + (1 - k) * this.grow[i] : 0.4 + k * 0.6);
    }
    this.geo.attributes.position.needsUpdate = true; this.geo.attributes.alpha.needsUpdate = true; this.geo.attributes.size.needsUpdate = true; this.geo.attributes.color.needsUpdate = true;
  }
}

// ---------------- números de dany (DOM) ----------------
class DamageNumbers {
  constructor(container) {
    this.el = container; this.list = [];
  }
  add(pos, text, cls, scale = 1) {
    const d = document.createElement('div');
    d.className = 'dmg ' + (cls || '');
    d.textContent = text;
    d.style.setProperty('--s', scale);
    this.el.appendChild(d);
    this.list.push({ d, pos: pos.clone(), t: 0, life: cls && cls.includes('combo') ? 1.6 : 1.1, vx: (Math.random() - 0.5) * 30 });
  }
  update(dt, camera, w, h) {
    const v = new THREE.Vector3();
    for (let i = this.list.length - 1; i >= 0; i--) {
      const n = this.list[i]; n.t += dt;
      if (n.t > n.life) { n.d.remove(); this.list.splice(i, 1); continue; }
      v.copy(n.pos); v.y += n.t * 1.4;
      v.project(camera);
      if (v.z > 1) { n.d.style.display = 'none'; continue; }
      n.d.style.display = '';
      const x = (v.x * 0.5 + 0.5) * w + n.vx * n.t, y = (-v.y * 0.5 + 0.5) * h;
      const k = n.t / n.life;
      n.d.style.transform = `translate(${x}px, ${y}px) translate(-50%,-50%) scale(${(k < 0.15 ? 0.6 + k * 4 : 1.2 - k * 0.3) * (parseFloat(n.d.style.getPropertyValue('--s')) || 1)})`;
      n.d.style.opacity = k > 0.7 ? (1 - k) / 0.3 : 1;
    }
  }
}

export class FX {
  constructor(scene, dmgContainer) {
    this.scene = scene;
    this.parts = new Particles(scene);
    this.nums = new DamageNumbers(dmgContainer);
    this.projs = new Map();
    this.temp = [];   // objectes amb vida limitada {obj, t, life, update}
    this.glowTex = glowTexture();
    this.ringGeo = new THREE.RingGeometry(0.9, 1, 64);
    this.discGeo = new THREE.CircleGeometry(1, 48);
    this.sphereGeo = new THREE.SphereGeometry(1, 16, 12);
    this.ambientT = 0;
  }

  sprite(color, size, add = true) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glowTex, color, transparent: true, blending: add ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: false }));
    s.scale.setScalar(size);
    return s;
  }

  addTemp(obj, life, update) { this.scene.add(obj); this.temp.push({ obj, t: 0, life, update }); return obj; }

  // ---------------- projectils ----------------
  projectile(m) {
    const el = m.el || 'arca';
    const c = ELC(el), g = ELG(el);
    const grp = new THREE.Group();
    const big = m.fx === 'fireball' || m.fx === 'darkbolt' || m.fx === 'wave';
    let core;
    if (m.fx === 'arrow') {
      core = new THREE.Group();
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.1, 4), new THREE.MeshBasicMaterial({ color: '#6b4a2f' }));
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.18, 4), new THREE.MeshBasicMaterial({ color: '#d9e2ea' }));
      tip.position.y = 0.62;
      const fl = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.24), new THREE.MeshBasicMaterial({ color: '#e8e0d0', side: THREE.DoubleSide }));
      fl.position.y = -0.45;
      core.add(shaft, tip, fl);
      core.rotation.x = Math.PI / 2;
    } else if (m.fx === 'spear') {
      core = new THREE.Mesh(new THREE.ConeGeometry(0.22, 2.2, 6), new THREE.MeshBasicMaterial({ color: g }));
      core.rotation.x = Math.PI / 2;
    } else if (m.fx === 'wave') {
      core = new THREE.Mesh(new THREE.TorusGeometry(m.rad || 1.6, 0.18, 6, 24, Math.PI), new THREE.MeshBasicMaterial({ color: g, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending }));
      core.rotation.z = Math.PI / 2;
    } else {
      core = new THREE.Mesh(this.sphereGeo, new THREE.MeshBasicMaterial({ color: g }));
      core.scale.setScalar(big ? 0.42 : 0.2);
    }
    grp.add(core);
    if (m.fx !== 'arrow') { const halo = this.sprite(c, big ? 3.2 : 1.6); grp.add(halo); }
    const dir = new THREE.Vector3(m.d[0], m.d[1], m.d[2]);
    grp.position.set(m.x, m.y, m.z);
    grp.lookAt(grp.position.clone().add(dir));
    this.scene.add(grp);
    this.projs.set(m.id, { grp, dir, speed: m.s, range: m.r, travelled: 0, el, c, g, fx: m.fx, big });
  }
  projectileEnd(m) {
    const p = this.projs.get(m.id);
    const pos = new THREE.Vector3(m.x, m.y, m.z);
    if (p) { this.scene.remove(p.grp); this.projs.delete(m.id); }
    const el = m.el || 'arca';
    if (m.ex) this.explosion(pos, m.ex, el);
    else if (p && p.fx === 'arrow') this.parts.burst(pos, 6, new THREE.Color('#cfc6b4'), { speed: 3, size: 0.3, life: 0.3 });
    else this.parts.burst(pos, 14, ELC(el), { speed: 5, size: 0.5, life: 0.4, col2: ELG(el) });
  }
  updateProjs(dt) {
    for (const [id, p] of this.projs) {
      const step = p.speed * dt;
      p.grp.position.addScaledVector(p.dir, step);
      p.travelled += step;
      if (p.fx === 'wave') p.grp.children[0].rotation.y += dt * 2;
      const pp = p.grp.position;
      const n = p.fx === 'arrow' ? 0 : p.big ? 3 : 1;
      for (let i = 0; i < n; i++) this.parts.emit(pp.x + (Math.random() - 0.5) * 0.3, pp.y + (Math.random() - 0.5) * 0.3, pp.z + (Math.random() - 0.5) * 0.3, (Math.random() - 0.5), Math.random() * 0.8, (Math.random() - 0.5), Math.random() < 0.5 ? p.c : p.g, p.big ? 0.9 : 0.45, 0.35, p.el === 'foc' ? 2 : 0, 2);
      if (p.travelled > p.range + 4) { this.scene.remove(p.grp); this.projs.delete(id); }
    }
  }

  explosion(pos, r, el) {
    const c = ELC(el), g = ELG(el);
    this.parts.burst(pos, Math.min(70, 20 + r * 8), c, { speed: r * 3.2, up: 3, size: 0.9, life: 0.6, col2: g, grav: -3 });
    const flash = this.sprite(g, r * 1.8); flash.position.copy(pos).y += 0.6;
    this.addTemp(flash, 0.3, (o, k) => { o.material.opacity = 0.75 * (1 - k) * (1 - k); o.scale.setScalar(r * (1.8 + k * 1.6)); });
    this.ring(pos, r, c, 0.5);
    if (this.onShake) this.onShake(Math.min(0.5, r * 0.07), pos);
  }

  ring(pos, r, color, life = 0.6, y = 0.15) {
    const m = new THREE.Mesh(this.ringGeo, new THREE.MeshBasicMaterial({ color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    m.rotation.x = -Math.PI / 2;
    m.position.set(pos.x, groundAt(pos.x, pos.z, pos.y + 2) + y, pos.z);
    this.addTemp(m, life, (o, k) => { o.scale.setScalar(Math.max(0.01, r * (0.2 + k * 0.9))); o.material.opacity = 0.75 * (1 - k); });
  }

  // ---------------- raigs ----------------
  zap(pts, el, strike = false) {
    const c = ELG(el), c2 = ELC(el);
    for (let i = 0; i < pts.length - 1; i++) {
      const a = new THREE.Vector3(...pts[i]), b = new THREE.Vector3(...pts[i + 1]);
      const path = [];
      const segs = Math.max(4, Math.round(a.distanceTo(b) / 1.2));
      for (let s = 0; s <= segs; s++) {
        const p = a.clone().lerp(b, s / segs);
        if (s > 0 && s < segs) p.add(new THREE.Vector3((Math.random() - 0.5) * 0.9, (Math.random() - 0.5) * 0.9, (Math.random() - 0.5) * 0.9));
        path.push(p);
      }
      const curve = new THREE.CatmullRomCurve3(path, false, 'catmullrom', 0.1);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, segs * 3, strike ? 0.16 : 0.07, 5, false), new THREE.MeshBasicMaterial({ color: c, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      const glow = new THREE.Mesh(new THREE.TubeGeometry(curve, segs * 2, strike ? 0.45 : 0.22, 6, false), new THREE.MeshBasicMaterial({ color: c2, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false }));
      const g = new THREE.Group(); g.add(tube); g.add(glow);
      this.addTemp(g, 0.28, (o, k) => { o.children.forEach((m) => { m.material.opacity = (1 - k) * (m === glow ? 0.35 : 1); }); });
      this.parts.burst(b, 10, c2, { speed: 6, size: 0.45, life: 0.35, col2: c });
    }
    if (strike && pts.length > 1) { const b = new THREE.Vector3(...pts[pts.length - 1]); this.explosion(b, 3, el); }
  }

  // ---------------- zona (telegrafia / impacte retardat) ----------------
  groundCast(m) {
    const el = m.el;
    for (let i = 0; i < m.pts.length; i++) {
      const [x, y, z] = m.pts[i];
      const delay = m.delay + i * (m.interval || 0);
      const pos = new THREE.Vector3(x, y, z);
      const enemy = m.p < 0;
      this.telegraph(pos, m.r, enemy ? '#ff3b3b' : ELC(el), delay, enemy);
      if (m.fx === 'meteor') {
        const met = new THREE.Group();
        const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9, 0), new THREE.MeshBasicMaterial({ color: ELG(el) }));
        met.add(core); met.add(this.sprite(ELC(el), 5));
        const start = pos.clone().add(new THREE.Vector3(-8, 34, -6));
        met.position.copy(start);
        this.addTemp(met, Math.max(0.2, delay), (o, k) => {
          o.position.lerpVectors(start, pos, k * k);
          core.rotation.x += 0.2; core.rotation.y += 0.13;
          if (Math.random() < 0.9) this.parts.emit(o.position.x, o.position.y, o.position.z, (Math.random() - 0.5) * 2, 2, (Math.random() - 0.5) * 2, ELC(el), 1.6, 0.6, 0, 1, 1.2);
        });
        setTimeout(() => this.explosion(pos, m.r, el), delay * 1000);
      } else if (m.fx === 'strike') {
        setTimeout(() => { this.zap([[x, y + 24, z], [x, y + 0.2, z]], el, true); }, delay * 1000);
      } else setTimeout(() => this.explosion(pos, m.r, el), delay * 1000);
    }
  }

  telegraph(pos, r, color, life, danger = false) {
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      uniforms: { uCol: { value: new THREE.Color(color) }, uK: { value: 0 }, uTime: UNI.uTime },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `uniform vec3 uCol; uniform float uK, uTime; varying vec2 vUv;
        void main(){ float d = length(vUv-0.5)*2.0; if (d>1.0) discard; float edge = smoothstep(0.86,0.98,d)*(1.0-smoothstep(0.98,1.0,d));
          float fill = step(d, uK) * 0.32; float pulse = 0.15 + 0.1*sin(uTime*12.0);
          gl_FragColor = vec4(uCol, edge*0.95 + fill + pulse*(1.0-d)); }`,
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), mat);
    m.rotation.x = -Math.PI / 2;
    m.position.set(pos.x, groundAt(pos.x, pos.z, pos.y + 3) + 0.12, pos.z);
    m.scale.setScalar(r);
    m.renderOrder = 3;
    this.addTemp(m, Math.max(0.15, life), (o, k) => { mat.uniforms.uK.value = k; });
    return m;
  }

  // con d'avís (alè del drac): angle a (sin→x, cos→z), llargada len, mig angle half
  coneTelegraph(x, y, z, a, len, half, life) {
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      uniforms: { uK: { value: 0 }, uTime: UNI.uTime },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `uniform float uK, uTime; varying vec2 vUv;
        void main(){ float d = vUv.y; float edge = smoothstep(0.9,1.0,vUv.x) + smoothstep(0.1,0.0,vUv.x) + smoothstep(0.96,1.0,d);
          float fill = step(d, uK) * 0.3; float pulse = 0.12 + 0.08*sin(uTime*12.0);
          gl_FragColor = vec4(1.0, 0.32, 0.12, min(1.0, edge*0.9 + fill + pulse*(1.0-d))); }`,
    });
    // ventall de triangles al pla XZ
    const segs = 24, pos = [0, 0, 0], uv = [0.5, 0], idx = [];
    for (let i = 0; i <= segs; i++) {
      const t = i / segs, aa = a - half + 2 * half * t;
      pos.push(Math.sin(aa) * len, 0, Math.cos(aa) * len); uv.push(t, 1);
      if (i > 0) idx.push(0, i, i + 1);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, groundAt(x, z, y + 3) + 0.15, z);
    m.renderOrder = 3;
    this.addTemp(m, Math.max(0.15, life), () => { mat.uniforms.uK.value = Math.min(1, mat.uniforms.uK.value + 0.016 / Math.max(0.15, life)); });
    return m;
  }

  // alè de foc: escombrada des de la boca (origin: funció que torna la posició del cap)
  fireBreath(origin, a, half, len, delay, dur) {
    const tmp = new THREE.Vector3();
    const c1 = new THREE.Color('#ffd27a'), c2 = new THREE.Color('#ff5a1a'), c3 = new THREE.Color('#5a2a20');
    const holder = new THREE.Object3D();
    let t = 0;
    this.addTemp(holder, delay + dur + 0.2, (o, k, dt) => {
      t += dt;
      const u = (t - delay) / dur;
      if (u < 0 || u > 1) return;
      const cur = a - half + 2 * half * u;
      origin(tmp);
      const n = Math.min(40, Math.max(4, Math.round(dt * 240)));
      for (let i = 0; i < n; i++) {
        const sp = len * (1.0 + Math.random() * 0.5), da = (Math.random() - 0.5) * 0.36;
        const vx = Math.sin(cur + da) * sp, vz = Math.cos(cur + da) * sp, vy = -3.5 - Math.random() * 3;
        const r = Math.random(), j = Math.random() * dt; // repartits dins del fotograma
        this.parts.emit(tmp.x + vx * j, tmp.y + vy * j, tmp.z + vz * j, vx, vy, vz, r < 0.4 ? c1 : r < 0.92 ? c2 : c3, 1.6 + Math.random() * 1.8, 0.75 + Math.random() * 0.35, 3, 0.45, 3.2);
      }
      if (this.onShake && Math.random() < 0.2) this.onShake(0.08, tmp);
    });
  }

  lineTelegraph(x, y, z, dx, dz, w, life) {
    const len = Math.hypot(dx, dz);
    const mat = new THREE.MeshBasicMaterial({ color: '#ff3b3b', transparent: true, opacity: 0.4, depthWrite: false, side: THREE.DoubleSide });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w * 2, len), mat);
    m.rotation.x = -Math.PI / 2; m.rotation.z = -Math.atan2(dx, dz) + Math.PI;
    m.position.set(x + dx / 2, groundAt(x + dx / 2, z + dz / 2, y + 3) + 0.15, z + dz / 2);
    this.addTemp(m, life, (o, k) => { mat.opacity = 0.25 + k * 0.4; });
  }

  nova(m) {
    const pos = new THREE.Vector3(m.x, m.y, m.z);
    const el = m.el; const c = ELC(el), g = ELG(el);
    // els cops repetits (remolí, etc.) fan un efecte més lleuger
    const key = m.p + ':' + m.key, now = performance.now();
    this._novaT ||= {};
    const repeat = now - (this._novaT[key] || 0) < 700; this._novaT[key] = now;
    if (!repeat) { this.ring(pos, m.r, c, 0.55, 0.3); this.ring(pos, m.r * 0.8, g, 0.4, 0.5); }
    const n = repeat ? 10 : 36;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2; const s = m.r * 2.4;
      this.parts.emit(pos.x + Math.cos(a) * 0.8, pos.y + 0.5, pos.z + Math.sin(a) * 0.8, Math.cos(a) * s, 1 + Math.random() * 2, Math.sin(a) * s, Math.random() < 0.5 ? c : g, 0.8, 0.45, -2, 3);
    }
    if (m.fx === 'spin') {
      const arc = new THREE.Mesh(new THREE.RingGeometry(m.r * 0.6, m.r, 48, 1, 0, Math.PI * 1.4), new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
      arc.rotation.x = -Math.PI / 2; arc.position.copy(pos).y += 1.1;
      this.addTemp(arc, 0.3, (o, k) => { o.rotation.z += 0.5; o.material.opacity = 0.35 * (1 - k); });
    }
    if (this.onShake) this.onShake(0.15, pos);
  }

  // raig recte i gruixut (Raig Solar, Raig Gèlid)
  beam(m) {
    const a = new THREE.Vector3(...m.from), b = new THREE.Vector3(...m.to);
    const c = ELC(m.el), g = ELG(m.el);
    const len = a.distanceTo(b);
    const grp = new THREE.Group();
    const core = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, len, 10, 1, true), new THREE.MeshBasicMaterial({ color: g, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    const glow = new THREE.Mesh(new THREE.CylinderGeometry(m.w * 0.55, m.w * 0.55, len, 14, 1, true), new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    grp.add(core, glow);
    grp.position.copy(a).lerp(b, 0.5);
    grp.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize());
    this.addTemp(grp, 0.45, (o, k) => { core.material.opacity = 1 - k; glow.material.opacity = 0.35 * (1 - k); o.scale.set(1 + k * 0.6, 1, 1 + k * 0.6); });
    for (let i = 0; i < 40; i++) {
      const p = a.clone().lerp(b, Math.random());
      this.parts.emit(p.x, p.y, p.z, (Math.random() - 0.5) * 3, Math.random() * 2, (Math.random() - 0.5) * 3, Math.random() < 0.5 ? c : g, 0.9, 0.5, m.el === 'gel' ? -2 : 1.5, 1.5);
    }
    this.parts.burst(b, 18, c, { speed: 5, size: 0.7, life: 0.5, col2: g });
    if (this.onShake) this.onShake(0.12, a);
  }

  field(m) {
    const pos = new THREE.Vector3(m.x, m.y, m.z);
    const c = ELC(m.el), g = ELG(m.el);
    if (m.fx === 'orbs') return this.orbField(m, c, g);
    if (m.fx === 'vortex') return this.vortexField(m, c, g);
    const disc = new THREE.Mesh(this.discGeo, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false }));
    disc.rotation.x = -Math.PI / 2; disc.position.set(m.x, groundAt(m.x, m.z, m.y + 2) + 0.1, m.z); disc.scale.setScalar(m.r);
    this.addTemp(disc, m.t, (o, k) => {
      o.material.opacity = 0.22 * (k > 0.9 ? (1 - k) * 10 : 1);
      const up = m.fx === 'flames' || m.fx === 'runes';
      for (let i = 0; i < (up ? 6 : 4); i++) {
        const a = Math.random() * Math.PI * 2, d = Math.sqrt(Math.random()) * m.r;
        if (up) this.parts.emit(pos.x + Math.cos(a) * d, pos.y + 0.2, pos.z + Math.sin(a) * d, 0, 2 + Math.random() * 3, 0, Math.random() < 0.5 ? g : c, m.fx === 'flames' ? 1.1 : 0.6, 0.8, 1.5, 0.5, m.fx === 'flames' ? 1.5 : 0);
        else this.parts.emit(pos.x + Math.cos(a) * d, pos.y + 5 + Math.random() * 3, pos.z + Math.sin(a) * d, 2.5, -7, 1, Math.random() < 0.5 ? g : c, 0.55, 0.9, 0, 0);
      }
      if (m.fx === 'storm' && Math.random() < 0.08) { const a = Math.random() * 6.28, d = Math.random() * m.r; const x = pos.x + Math.cos(a) * d, z = pos.z + Math.sin(a) * d; this.zap([[x, pos.y + 12, z], [x, groundAt(x, z, pos.y + 2) + 0.2, z]], 'llamp', false); }
    });
    this.ring(pos, m.r, g, 0.6);
  }

  // orbes que giren al voltant d'un jugador
  orbField(m, c, g) {
    const grp = new THREE.Group();
    const orbs = [];
    for (let i = 0; i < 3; i++) {
      const o = new THREE.Group();
      o.add(new THREE.Mesh(this.sphereGeo, new THREE.MeshBasicMaterial({ color: g })));
      o.children[0].scale.setScalar(0.32);
      o.add(this.sprite(c, 2.2));
      grp.add(o); orbs.push(o);
    }
    let t = 0;
    const base = new THREE.Vector3(m.x, m.y, m.z);
    this.addTemp(grp, m.t, (o, k, dt) => {
      t += dt;
      const fp = m.follow && this.followPos ? this.followPos(m.follow) : null;
      o.position.copy(fp || base);
      orbs.forEach((q, i) => {
        const a = t * 3.2 + (i / orbs.length) * Math.PI * 2;
        q.position.set(Math.cos(a) * m.r * 0.75, 1.2 + Math.sin(t * 4 + i) * 0.25, Math.sin(a) * m.r * 0.75);
        if (Math.random() < 0.6) { const w = o.position.clone().add(q.position); this.parts.emit(w.x, w.y, w.z, 0, 0.4, 0, Math.random() < 0.5 ? c : g, 0.5, 0.35, 0, 1); }
      });
      const fade = k > 0.92 ? (1 - k) / 0.08 : 1;
      orbs.forEach((q) => q.scale.setScalar(fade));
    });
  }

  // remolí que xucla cap al centre
  vortexField(m, c, g) {
    const pos = new THREE.Vector3(m.x, m.y, m.z);
    const disc = new THREE.Mesh(this.discGeo, new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.25, blending: THREE.AdditiveBlending, depthWrite: false }));
    disc.rotation.x = -Math.PI / 2; disc.position.set(m.x, groundAt(m.x, m.z, m.y + 2) + 0.1, m.z); disc.scale.setScalar(m.r);
    const core = this.sprite(g, 3); core.position.copy(disc.position).y += 1.2;
    const grp = new THREE.Group(); grp.add(disc); grp.add(core);
    let t = 0;
    this.addTemp(grp, m.t, (o, k, dt) => {
      t += dt;
      disc.material.opacity = 0.25 * (k > 0.9 ? (1 - k) * 10 : 1);
      core.scale.setScalar(2.5 + Math.sin(t * 8) * 0.6);
      for (let i = 0; i < 6; i++) {
        const a = Math.random() * Math.PI * 2, d = m.r * (0.6 + Math.random() * 0.4);
        const x = pos.x + Math.cos(a) * d, z = pos.z + Math.sin(a) * d;
        // velocitat tangencial + cap al centre
        const vx = -Math.cos(a) * d * 1.4 - Math.sin(a) * 6, vz = -Math.sin(a) * d * 1.4 + Math.cos(a) * 6;
        this.parts.emit(x, disc.position.y + 0.3 + Math.random() * 1.5, z, vx, 0.6, vz, Math.random() < 0.5 ? c : g, 0.6, 0.6, 0.5, 0.2);
      }
    });
    this.ring(pos, m.r, g, 0.6);
  }

  slash(pos, ry, step, el, big) {
    const c = el === 'titan' ? new THREE.Color('#ffc75a') : el === 'fisic' || !ELEMENTS[el] ? new THREE.Color('#ffffff') : ELG(el);
    const r = big ? 4.4 : step === 2 ? 3.6 : 2.8;
    const arc = new THREE.Mesh(new THREE.RingGeometry(r * 0.55, r, 32, 1, -Math.PI * 0.45, Math.PI * 0.9), new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
    arc.position.copy(pos).y += 1.1 + (step === 1 ? 0.3 : 0);
    arc.rotation.order = 'YXZ';
    arc.rotation.y = ry + Math.PI / 2;
    arc.rotation.x = -Math.PI / 2 + (step === 0 ? 0.35 : step === 1 ? -0.35 : 0);
    this.addTemp(arc, 0.22, (o, k) => { o.material.opacity = 0.9 * (1 - k); o.scale.setScalar(1 + k * 0.25); });
  }

  dash(from, to, el) {
    const a = new THREE.Vector3(...from), b = new THREE.Vector3(to[0], from[1], to[1]);
    const c = ELC(el), g = ELG(el);
    for (let i = 0; i < 40; i++) {
      const p = a.clone().lerp(b, i / 40);
      this.parts.emit(p.x, p.y + 0.3 + Math.random() * 1.5, p.z, (Math.random() - 0.5) * 2, 1 + Math.random(), (Math.random() - 0.5) * 2, Math.random() < 0.5 ? c : g, 0.9, 0.5 + Math.random() * 0.4, 1, 1.5);
    }
  }

  levelUp(pos) {
    const col = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 14, 24, 1, true), new THREE.MeshBasicMaterial({ color: '#ffc94a', transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
    col.position.copy(pos).y += 7;
    this.addTemp(col, 1.4, (o, k) => { o.material.opacity = 0.3 * (1 - k); o.scale.set(1 + k, 1, 1 + k); });
    this.parts.burst(pos.clone().setY(pos.y + 1), 50, new THREE.Color('#ffd166'), { speed: 5, up: 6, size: 0.55, life: 1.3, grav: -2, col2: new THREE.Color('#fff2b8') });
  }

  heal(pos) { this.parts.burst(pos, 18, new THREE.Color('#7dff9a'), { speed: 1.5, up: 3, size: 0.5, life: 1.0, grav: 1.5, spread: 1.2 }); }

  update(dt, camera, w, h) {
    this.parts.mat.uniforms.uScale.value = h / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2)) * 0.5;
    this.parts.mat.uniforms.uMax.value = h * 0.18;
    this.parts.update(dt);
    this.updateProjs(dt);
    for (let i = this.temp.length - 1; i >= 0; i--) {
      const t = this.temp[i]; t.t += dt;
      const k = Math.min(1, t.t / t.life);
      if (t.update) t.update(t.obj, k, dt);
      if (t.t >= t.life) {
        this.scene.remove(t.obj);
        t.obj.traverse && t.obj.traverse((o) => { if (o.geometry && o.geometry !== this.ringGeo && o.geometry !== this.discGeo && o.geometry !== this.sphereGeo) o.geometry.dispose(); if (o.material) o.material.dispose(); });
        this.temp.splice(i, 1);
      }
    }
    this.nums.update(dt, camera, w, h);
  }

  // partícules ambientals al voltant del jugador
  ambient(dt, pos, zone, night) {
    this.ambientT += dt;
    if (this.ambientT < 0.05) return;
    this.ambientT = 0;
    const z = zone ? zone.id : 'vila';
    const r = () => (Math.random() - 0.5);
    if (z === 'cremades') for (let i = 0; i < 3; i++) this.parts.emit(pos.x + r() * 40, pos.y + Math.random() * 3, pos.z + r() * 40, r() * 0.5, 1.2 + Math.random(), r() * 0.5, new THREE.Color('#ff7a2a'), 0.35, 3, 0.2, 0.1);
    if (z === 'bosc' || night > 0.5) for (let i = 0; i < (night > 0.5 ? 2 : 1); i++) this.parts.emit(pos.x + r() * 34, pos.y + 0.5 + Math.random() * 3, pos.z + r() * 34, r() * 0.6, r() * 0.4, r() * 0.6, new THREE.Color(z === 'bosc' ? '#c8ff7a' : '#fff1a8'), 0.28, 3.5, 0, 0.05);
    if (z === 'cel') this.parts.emit(pos.x + r() * 40, pos.y - 2 + Math.random() * 8, pos.z + r() * 40, 2, 0.2, 0, new THREE.Color('#dff6ff'), 0.25, 3, 0, 0);
    if (z === 'ruines' && Math.random() < 0.3) this.parts.emit(pos.x + r() * 30, pos.y + 0.3, pos.z + r() * 30, 1.2, 0.3, 0.4, new THREE.Color('#f5e1a8'), 0.25, 3, 0, 0);
  }
}
