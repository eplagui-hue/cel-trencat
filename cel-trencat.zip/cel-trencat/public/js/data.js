// ============================================================
//  CEL TRENCAT — dades compartides (client i servidor)
// ============================================================

import { LEARN_ABILITIES, SKILL_TREES, skillEffects, applySkillMods, EMPTY_EFF, sanitizeSkills } from './skills.js';
export { SKILL_TREES };

export const GAME_NAME = 'Cel Trencat';

// ---------------- MODES DE JOC ----------------
// kind: story (món obert) | pve (arena contra monstres) | race (parkour) | pvp (jugadors contra jugadors)
export const MODES = {
  coop: { name: 'Mode història', icon: '📜', kind: 'story', solo: true, multi: true, desc: 'El món obert: missions, fortaleses, caps i les illes del cel.' },
  hordes: { name: 'Hordes', icon: '🌊', kind: 'pve', solo: true, multi: true, desc: 'Sobreviu onades d\'enemics cada cop més forts a l\'Arena d\'Aura. Cada 5 onades arriba un cap.' },
  caps: { name: 'Cacera de caps', icon: '👑', kind: 'pve', solo: true, multi: true, desc: 'Els 7 caps del regne, l\'un rere l\'altre. Derrota\'ls tots tan ràpid com puguis.' },
  crono: { name: 'Contrarellotge', icon: '⏱️', kind: 'pve', solo: true, multi: true, time: 180, desc: '3 minuts per derrotar tants enemics com puguis. Encadena morts seguides per multiplicar els punts.' },
  parkour: { name: 'Parkour', icon: '🏃', kind: 'race', solo: true, multi: true, desc: '5 nivells de plataformes flotants, de fàcil a expert: bolets saltadors, pedres que cauen, corrents d\'aire, bigues que giren i molt més. Supera\'n un per obrir el següent. En multijugador, és una cursa!' },
  pvp: { name: 'Arena per equips', icon: '⚔️', kind: 'pvp', solo: false, multi: true, target: 5, desc: 'Dos equips. El primer a fer 5 eliminacions guanya.' },
  ffa: { name: 'Tots contra tots', icon: '💥', kind: 'pvp', solo: false, multi: true, target: 7, desc: 'Cadascú per la seva. El primer a fer 7 eliminacions guanya.' },
  turo: { name: 'Rei del turó', icon: '🚩', kind: 'pvp', solo: false, multi: true, target: 100, desc: 'Dos equips es disputen el cercle del centre. El primer equip a 100 punts guanya.' },
};
// ordre dels caps a la Cacera de caps i a les Hordes
export const BOSS_ORDER = ['cap_puglin', 'golem_antic', 'rei_ossut', 'senyor_imps', 'ganfaul', 'ombra', 'drac'];
export const MAX_LEVEL = 20;
// versió del joc: el client i el servidor l'han de tenir igual
export const GAME_VERSION = '1.8';
export const MAX_PLAYERS = 4;

export const ELEMENTS = {
  foc: { name: 'Foc', color: '#ff6a2a', glow: '#ffb35c', icon: '🔥' },
  gel: { name: 'Gel', color: '#63d4ff', glow: '#c8f4ff', icon: '❄️' },
  llamp: { name: 'Llamp', color: '#b48cff', glow: '#f0e2ff', icon: '⚡' },
  arca: { name: 'Arcà', color: '#46f0c0', glow: '#c9fff0', icon: '✦' },
  ombra: { name: 'Ombra', color: '#9b3dff', glow: '#e3b8ff', icon: '☾' },
  fisic: { name: 'Físic', color: '#9fb6d6', glow: '#e4ecf7', icon: '⚔️' },
};

export const STATUS = {
  burn: { name: 'Cremat', color: '#ff7a2a' },
  slow: { name: 'Alentit', color: '#63d4ff' },
  freeze: { name: 'Congelat', color: '#bff0ff' },
  stun: { name: 'Atordit', color: '#ffe066' },
  shock: { name: 'Electrocutat', color: '#c9a2ff' },
  vuln: { name: 'Vulnerable', color: '#46f0c0' },
  poison: { name: 'Enverinat', color: '#7ddc4a' },
};

// ---------------- CLASSES ----------------
// anims: noms de clips de l'arxiu humanoid.json
export const CLASSES = {
  foc: {
    name: 'Mag de Foc', short: 'Piromant', element: 'foc', color: '#ff6a2a',
    desc: 'Destrucció pura. Boles de foc, meteorits i un fènix interior.',
    weapon: 'staff', stats: { hp: 520, mana: 260, poder: 32, def: 10, crit: 7, speed: 7.2 },
    basic: 'espurna', abilities: ['bola_foc', 'meteorit', 'anell_flames', 'impuls_ardent'], extra: ['raig_solar', 'orbes_flama'], ult: 'fenix',
    idle: 'idle', block: 'block_idle',
  },
  gel: {
    name: 'Mag de Gel', short: 'Criomant', element: 'gel', color: '#63d4ff',
    desc: 'Control del camp de batalla: alenteix, congela i protegeix.',
    weapon: 'staff', stats: { hp: 560, mana: 280, poder: 28, def: 14, crit: 6, speed: 7.0 },
    basic: 'fragment', abilities: ['llanca_gel', 'tempesta_neu', 'nova_glacada', 'escut_cristall'], extra: ['raig_gelid', 'vortex_gel'], ult: 'hivern',
    idle: 'idle', block: 'block_idle',
  },
  llamp: {
    name: 'Mag del Llamp', short: 'Fulminant', element: 'llamp', color: '#b48cff',
    desc: 'Velocitat i cadenes elèctriques que salten entre enemics.',
    weapon: 'wand', stats: { hp: 500, mana: 250, poder: 30, def: 9, crit: 12, speed: 7.6 },
    basic: 'guspira', abilities: ['cadena_llamps', 'llamp_celestial', 'pas_tempesta', 'sobrecarrega'], extra: ['escut_electric', 'singularitat'], ult: 'senyor_tempesta',
    idle: 'idle', block: 'block_idle',
  },
  guerrer: {
    name: 'Guerrer', short: 'Espasa', element: 'fisic', color: '#f0b450', melee: true,
    desc: 'Pura força cos a cos: combos d\'espasa, cops demolidors i una forma titànica que multiplica totes les estadístiques.',
    weapon: 'sword_2handed', stats: { hp: 920, mana: 180, poder: 31, def: 27, crit: 11, speed: 7.6 },
    basic: 'tall', abilities: ['cop_demolidor', 'remoli', 'embestida', 'crit_guerra'], extra: ['rafega', 'cop_espatlla'], ult: 'titan',
    idle: 'idle_sword', block: 'sword_block',
  },
};

// ---------------- HABILITATS ----------------
// kind: projectile | hitscan | ground | nova | dash | blink | buff | melee | transform | wave | field
export const ABILITIES = {
  // ---- foc ----
  espurna: { name: 'Espurna', el: 'foc', kind: 'projectile', dmg: 21, speed: 40, range: 40, radius: 0.55, cd: 0.42, mana: 0,
    anim: 'spell_shoot', animSpeed: 1.25, release: 0.16, upper: true, fx: 'bolt', status: { burn: { dur: 2, dps: 4 }, chance: 0.25 }, desc: 'Dard de foc ràpid.' },
  bola_foc: { name: 'Bola de Foc', el: 'foc', kind: 'projectile', dmg: 74, speed: 28, range: 45, radius: 0.9, explode: 4.2, cd: 5, mana: 22,
    anim: 'magic_1h_a', animSpeed: 1.7, release: 0.42, upper: true, fx: 'fireball', status: { burn: { dur: 4, dps: 10 } },
    groundFire: { r: 3, dur: 3, dmg: 9, tick: 0.5 }, desc: 'Explota en impactar, crema els enemics i deixa el terra en flames.' },
  meteorit: { name: 'Pluja de Meteorits', el: 'foc', kind: 'ground', dmg: 56, hits: 4, interval: 0.28, delay: 0.85, radius: 5.6, range: 32, cd: 12, mana: 42,
    anim: 'magic_2h_a', animSpeed: 1.7, release: 0.36, fx: 'meteor', status: { burn: { dur: 3, dps: 8 } }, desc: 'Quatre meteorits cauen sobre la zona marcada.' },
  anell_flames: { name: 'Anell de Flames', el: 'foc', kind: 'nova', dmg: 60, radius: 7, knock: 11, cd: 9, mana: 30,
    anim: 'magic_area_a', animSpeed: 2.0, release: 0.4, fx: 'nova', status: { burn: { dur: 3, dps: 7 } }, desc: 'Ona de foc que empeny i crema.' },
  impuls_ardent: { name: 'Impuls Ardent', el: 'foc', kind: 'dash', dist: 13, dmg: 42, fireTrail: { r: 2.2, dur: 3, dmg: 8, tick: 0.5 }, radius: 2.6, cd: 7, mana: 16,
    anim: 'roll', animSpeed: 1.3, release: 0.05, fx: 'dash', trail: true, status: { burn: { dur: 3, dps: 6 } }, desc: 'Esquiva endavant deixant un rastre de foc que crema.' },
  fenix: { name: 'Avatar del Fènix', el: 'foc', kind: 'transform', dur: 15, dmgMult: 1.6, speedMult: 1.15, cd: 0, mana: 0,
    anim: 'power_up', animSpeed: 1.4, release: 0.5, fx: 'transform', wings: true, desc: 'Et transformes en fènix: +60% dany, ales de foc i dards triples.' },

  // ---- gel ----
  fragment: { name: 'Fragment de Gel', el: 'gel', kind: 'projectile', dmg: 19, speed: 42, range: 40, radius: 0.5, cd: 0.42, mana: 0,
    anim: 'spell_shoot', animSpeed: 1.25, release: 0.16, upper: true, fx: 'bolt', status: { slow: { dur: 1.6, amt: 0.2 } }, desc: 'Fragment que alenteix.' },
  llanca_gel: { name: 'Llança de Gel', el: 'gel', kind: 'projectile', dmg: 66, shards: 5, speed: 48, range: 48, radius: 0.8, pierce: true, cd: 4.5, mana: 18,
    anim: 'magic_1h_b', animSpeed: 1.8, release: 0.4, upper: true, fx: 'spear', status: { slow: { dur: 3, amt: 0.35 } }, desc: 'Travessa tots els enemics en línia i al final es trenca en esquerdes de gel.' },
  tempesta_neu: { name: 'Tempesta de Neu', el: 'gel', kind: 'field', dmg: 15, tick: 0.5, dur: 5, radius: 6.2, range: 30, cd: 13, mana: 40,
    anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'blizzard', status: { slow: { dur: 1, amt: 0.5 } }, desc: 'Zona glaçada que fa mal i alenteix un 50%.' },
  nova_glacada: { name: 'Nova Glaçada', el: 'gel', kind: 'nova', dmg: 46, radius: 7.6, cd: 11, mana: 32, selfShield: 60,
    anim: 'magic_area_b', animSpeed: 2.0, release: 0.42, fx: 'nova', status: { freeze: { dur: 2 } }, desc: 'Congela tots els enemics del voltant i et cobreix amb una capa de gel que absorbeix dany.' },
  escut_cristall: { name: 'Escut de Cristall', el: 'gel', kind: 'buff', buff: 'shield', amount: 180, scale: 3.6, dur: 7, reflect: 0.3, cd: 15, mana: 30,
    anim: 'cast_1h', animSpeed: 2.0, release: 0.35, upper: true, fx: 'shield', desc: 'Escut que absorbeix dany i en retorna part.' },
  hivern: { name: 'Hivern Etern', el: 'gel', kind: 'transform', dur: 15, dmgMult: 1.45, aura: { radius: 9, dps: 24, slow: 0.45 }, cd: 0, mana: 0,
    anim: 'power_up', animSpeed: 1.4, release: 0.5, fx: 'transform', desc: 'Una aura de gel et rodeja: fa mal i alenteix tot el que s\'apropa.' },

  // ---- llamp ----
  guspira: { name: 'Guspira', el: 'llamp', kind: 'hitscan', dmg: 18, range: 32, chain: 1, chainRange: 7, cd: 0.36, mana: 0,
    anim: 'spell_shoot', animSpeed: 1.4, release: 0.12, upper: true, fx: 'zap', desc: 'Raig instantani que salta a un enemic més.' },
  cadena_llamps: { name: 'Cadena de Llamps', el: 'llamp', kind: 'hitscan', dmg: 56, range: 34, chain: 5, chainRange: 10, falloff: 0.86, cd: 6, mana: 22,
    anim: 'magic_2h_b', animSpeed: 1.9, release: 0.38, upper: true, fx: 'chain', status: { shock: { dur: 1.2 } }, desc: 'Salta entre fins a 6 enemics.' },
  llamp_celestial: { name: 'Llamp Celestial', el: 'llamp', kind: 'ground', dmg: 112, aftershock: true, hits: 1, delay: 0.45, radius: 3.8, range: 34, cd: 9, mana: 30,
    anim: 'magic_2h_d', animSpeed: 2.0, release: 0.3, fx: 'strike', status: { stun: { dur: 1.3 } }, desc: 'Un llamp del cel atordeix la zona i en salten llamps als enemics propers.' },
  pas_tempesta: { name: 'Pas de Tempesta', el: 'llamp', kind: 'blink', dist: 12, dmg: 46, startBurst: true, radius: 4.2, cd: 6, mana: 18,
    anim: 'cast_1h', animSpeed: 3.0, release: 0.05, fx: 'blink', desc: 'Teletransport amb una descàrrega on marxes i una altra on arribes.' },
  sobrecarrega: { name: 'Sobrecàrrega', el: 'llamp', kind: 'buff', buff: 'haste', dur: 7, amount: 0.5, dmgBoost: 0.2, cd: 16, mana: 24,
    anim: 'cast_2h', animSpeed: 2.2, release: 0.3, upper: true, fx: 'buff', desc: 'Més velocitat d\'atac i de moviment i +20% de dany durant 7 s.' },
  senyor_tempesta: { name: 'Senyor de la Tempesta', el: 'llamp', kind: 'transform', dur: 15, dmgMult: 1.5, speedMult: 1.2, autoStrike: { every: 0.6, dmg: 46, range: 16 }, cd: 0, mana: 0,
    anim: 'power_up', animSpeed: 1.4, release: 0.5, fx: 'transform', desc: 'Llamps automàtics colpegen els enemics propers.' },

  // ---- guerrer ----
  tall: { name: 'Tall', el: 'fisic', kind: 'melee', combo: [
    { dmg: 33, anim: 'sword_a', animSpeed: 1.3, release: 0.4, range: 3.6, arc: 130, time: 0.4 },
    { dmg: 36, anim: 'sword_b', animSpeed: 1.3, release: 0.38, range: 3.6, arc: 130, time: 0.44 },
    { dmg: 60, anim: 'sword_c', animSpeed: 2.0, release: 0.30, range: 4.0, arc: 170, time: 0.72, knock: 7 },
  ], cd: 0.1, mana: 0, upper: false, fx: 'slash', desc: 'Combo de tres cops d\'espasa; el tercer empeny.' },
  cop_demolidor: { name: 'Cop Demolidor', el: 'fisic', kind: 'melee', single: true, combo: [
    { dmg: 112, anim: 'sword_mx', animSpeed: 1.45, release: 0.4, range: 4.6, arc: 150, time: 0.8, knock: 9, big: true },
  ], status: { stun: { dur: 1.1 } }, cd: 6, mana: 15, fx: 'slash', desc: 'Un cop brutal per sobre del cap que atordeix i empeny.' },
  remoli: { name: 'Remolí d\'Acer', el: 'fisic', kind: 'nova', dmg: 31, radius: 5, hits: 4, interval: 0.26, cd: 8, mana: 18,
    anim: 'sword_heavy', animSpeed: 2.4, release: 0.15, fx: 'spin', desc: 'Gires l\'espasa i colpeges quatre cops al voltant.' },
  embestida: { name: 'Embestida', el: 'fisic', kind: 'dash', dist: 11, dmg: 64, radius: 2.9, cd: 7, mana: 12,
    anim: 'sword_dash', animSpeed: 1.6, release: 0.1, fx: 'dash', status: { stun: { dur: 1.0 } }, desc: 'Carrega endavant i atordeix tot el que trobes.' },
  crit_guerra: { name: 'Crit de Guerra', el: 'fisic', kind: 'buff', buff: 'guard', dur: 8, amount: 0.4, heal: 0.15, cd: 16, mana: 20,
    anim: 'power_up', animSpeed: 1.8, release: 0.45, fx: 'buff', desc: 'Redueix el dany rebut un 40%, et cura un 15% i atrau els enemics.' },
  rafega: { name: 'Ràfega de Talls', el: 'fisic', kind: 'melee', single: true, combo: [
    { dmg: 26, anim: 'sword_b', animSpeed: 2.4, release: 0.12, range: 3.9, arc: 140, time: 0.95, hits: 5, interval: 0.14 },
  ], cd: 7, mana: 16, fx: 'slash', desc: 'Cinc talls molt ràpids seguits davant teu.' },
  cop_espatlla: { name: 'Cop d\'Espatlla', el: 'fisic', kind: 'melee', single: true, combo: [
    { dmg: 50, anim: 'shield_dash', animSpeed: 1.6, release: 0.18, range: 3.4, arc: 130, time: 0.6, knock: 16 },
  ], status: { stun: { dur: 0.7 } }, cd: 6, mana: 10, fx: 'slash', desc: 'Envesteixes amb l\'espatlla i llances els enemics lluny.' },
  titan: { name: 'Forma Titànica', el: 'fisic', kind: 'transform', dur: 15, statMult: 1.5, scale: 1.25, cd: 0, mana: 0,
    anim: 'power_up', animSpeed: 1.4, release: 0.5, fx: 'transform', desc: 'Creixes i totes les teves estadístiques (vida, força, defensa, crític, velocitat, regeneració i velocitat d\'atac) es multipliquen ×1,5.' },
};

// habilitats extra dels mags (es poden posar a les tecles des del primer nivell)
Object.assign(ABILITIES, {
  raig_solar: { name: 'Raig Solar', el: 'foc', kind: 'beam', dmg: 72, range: 26, width: 1.5, cd: 7, mana: 26,
    anim: 'magic_2h_b', animSpeed: 1.8, release: 0.38, fx: 'beam', status: { burn: { dur: 3, dps: 9 } }, desc: 'Un raig de foc que travessa tots els enemics en línia recta.' },
  orbes_flama: { name: 'Orbes Flamejants', el: 'foc', kind: 'field', follow: true, dmg: 17, tick: 0.35, dur: 7, radius: 3.8, range: 0, cd: 14, mana: 30,
    anim: 'cast_2h', animSpeed: 2.2, release: 0.3, upper: true, fx: 'orbs', status: { burn: { dur: 2, dps: 6 } }, desc: 'Orbes de foc giren al teu voltant i cremen tot el que toquen.' },
  raig_gelid: { name: 'Raig Gèlid', el: 'gel', kind: 'beam', dmg: 60, range: 26, width: 1.5, cd: 8, mana: 26,
    anim: 'magic_2h_b', animSpeed: 1.8, release: 0.38, fx: 'beam', status: { freeze: { dur: 1.3 } }, desc: 'Un raig de gel que congela tot el que travessa.' },
  vortex_gel: { name: 'Vòrtex Glaçat', el: 'gel', kind: 'field', pull: 7, dmg: 11, tick: 0.5, dur: 4.5, radius: 7, range: 28, cd: 15, mana: 40,
    anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'vortex', status: { slow: { dur: 1, amt: 0.5 } }, desc: 'Un remolí de gel que xucla els enemics cap al centre i els alenteix.' },
  escut_electric: { name: 'Escut Elèctric', el: 'llamp', kind: 'field', follow: true, dmg: 15, tick: 0.4, dur: 7, radius: 4, range: 0, cd: 14, mana: 28,
    anim: 'cast_2h', animSpeed: 2.2, release: 0.3, upper: true, fx: 'orbs', status: { shock: { dur: 0.5 } }, desc: 'Esferes de llamp giren al teu voltant i electrocuten qui s\'acosta.' },
  singularitat: { name: 'Singularitat', el: 'llamp', kind: 'field', pull: 9, dmg: 12, tick: 0.4, dur: 4, radius: 7.5, range: 28, cd: 16, mana: 42,
    anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'vortex', status: { shock: { dur: 0.6 } }, explodeEnd: { dmg: 80, r: 5.5 }, desc: 'Un punt de tempesta que atrau els enemics i esclata en acabar.' },
});

// habilitats que s'aprenen a les branques
Object.assign(ABILITIES, LEARN_ABILITIES);

// Editor d'encanteris: el jugador combina forma + element + potència.
export const CUSTOM_FORMS = {
  projectil: { name: 'Projectil', kind: 'projectile', base: { dmg: 56, speed: 32, range: 40, radius: 0.85, cd: 5, mana: 20 }, anim: 'magic_1h_a', animSpeed: 1.7, release: 0.42, upper: true, fx: 'fireball' },
  explosio: { name: 'Explosió a distància', kind: 'ground', base: { dmg: 76, hits: 1, delay: 0.6, radius: 4.5, range: 30, cd: 8, mana: 30 }, anim: 'magic_2h_d', animSpeed: 2.0, release: 0.3, fx: 'strike' },
  nova: { name: 'Nova', kind: 'nova', base: { dmg: 50, radius: 6, cd: 8, mana: 26 }, anim: 'magic_area_a', animSpeed: 2.0, release: 0.4, fx: 'nova' },
  cadena: { name: 'Cadena', kind: 'hitscan', base: { dmg: 44, range: 30, chain: 3, chainRange: 9, falloff: 0.85, cd: 6, mana: 22 }, anim: 'magic_2h_b', animSpeed: 1.9, release: 0.38, upper: true, fx: 'chain' },
  camp: { name: 'Camp persistent', kind: 'field', base: { dmg: 13, tick: 0.5, dur: 5, radius: 5.5, range: 28, cd: 12, mana: 34 }, anim: 'magic_2h_c', animSpeed: 2.2, release: 0.3, fx: 'blizzard' },
};
export const CUSTOM_ELEMENTS = {
  foc: { status: { burn: { dur: 4, dps: 9 } } },
  gel: { status: { slow: { dur: 2.5, amt: 0.4 } } },
  llamp: { status: { shock: { dur: 1.0 } } },
  arca: { status: { vuln: { dur: 4, amt: 0.15 } } },
};
export const CUSTOM_POWER = [
  { name: 'Lleuger', dmg: 0.7, cd: 0.6, mana: 0.6 },
  { name: 'Equilibrat', dmg: 1.0, cd: 1.0, mana: 1.0 },
  { name: 'Devastador', dmg: 1.45, cd: 1.65, mana: 1.5 },
];
export function buildCustomAbility(spec) {
  const form = CUSTOM_FORMS[spec && spec.form] || CUSTOM_FORMS.projectil;
  const el = CUSTOM_ELEMENTS[spec && spec.el] ? spec.el : 'arca';
  const pw = CUSTOM_POWER[Math.max(0, Math.min(2, spec && spec.pow | 0))];
  const b = form.base;
  const name = String((spec && spec.name) || 'Encanteri propi').slice(0, 24);
  const a = { ...b, name, el, kind: form.kind, anim: form.anim, animSpeed: form.animSpeed, release: form.release, upper: !!form.upper, fx: form.fx,
    custom: true, dmg: Math.round(b.dmg * pw.dmg), cd: +(b.cd * pw.cd).toFixed(1), mana: Math.round(b.mana * pw.mana),
    status: CUSTOM_ELEMENTS[el].status, desc: `${form.name} de ${ELEMENTS[el].name.toLowerCase()} (${pw.name.toLowerCase()})` };
  if (form.kind === 'projectile' && pw.dmg > 1.2) a.explode = 3.2;
  if (form.kind === 'nova' && el === 'gel') a.status = { freeze: { dur: 1.2 } };
  return a;
}

// ---------------- RUNES D'HABILITAT ----------------
// Cada habilitat pot portar fins a 2 runes (la segona ranura s'obre al nivell 8).
const DMG_KINDS = ['projectile', 'hitscan', 'ground', 'nova', 'field', 'dash', 'blink', 'melee', 'beam'];
export const RUNES = {
  poder: { name: 'Poder', icon: '🔥', desc: '+30% de dany, però +20% de recàrrega.', kinds: DMG_KINDS, lvl: 2 },
  celeritat: { name: 'Celeritat', icon: '⚡', desc: '−30% de recàrrega i −12% de dany.', kinds: [...DMG_KINDS, 'buff'], lvl: 2 },
  eficiencia: { name: 'Eficiència', icon: '💧', desc: '−45% de cost de manà.', kinds: [...DMG_KINDS, 'buff'], lvl: 3 },
  amplitud: { name: 'Amplitud', icon: '⭕', desc: '+35% d\'àrea, abast i distància.', kinds: ['projectile', 'hitscan', 'ground', 'nova', 'field', 'dash', 'blink', 'melee', 'beam'], lvl: 4 },
  multiple: { name: 'Multiplicació', icon: '✳️', desc: 'Projectils: 3 en ventall (55% de dany cadascun). Àrees: +1 impacte. Cadenes: +2 salts.', kinds: ['projectile', 'ground', 'nova', 'hitscan'], lvl: 5 },
  vampir: { name: 'Vampirisme', icon: '🩸', desc: 'Et cures el 12% del dany que fa l\'habilitat.', kinds: DMG_KINDS, lvl: 6 },
  perforant: { name: 'Perforació', icon: '🗡️', desc: 'Els projectils travessen enemics i volen un 25% més ràpid.', kinds: ['projectile'], lvl: 4 },
  persistent: { name: 'Persistència', icon: '⏳', desc: '+50% de durada (camps, escuts, millores i transformació).', kinds: ['field', 'buff', 'transform'], lvl: 5 },
  af_foc: { name: 'Afinitat de Foc', icon: '🟠', desc: 'L\'habilitat passa a ser de foc i crema.', kinds: DMG_KINDS, lvl: 7, el: 'foc' },
  af_gel: { name: 'Afinitat de Gel', icon: '🔵', desc: 'L\'habilitat passa a ser de gel i alenteix.', kinds: DMG_KINDS, lvl: 7, el: 'gel' },
  af_llamp: { name: 'Afinitat de Llamp', icon: '🟣', desc: 'L\'habilitat passa a ser de llamp i electrocuta.', kinds: DMG_KINDS, lvl: 7, el: 'llamp' },
  af_arca: { name: 'Afinitat Arcana', icon: '🟢', desc: 'L\'habilitat passa a ser arcana i fa vulnerables.', kinds: DMG_KINDS, lvl: 7, el: 'arca' },
};
export const RUNE_SLOT2_LVL = 8;
export const MAX_LOADOUTS = 4;
export const MAX_GRIMORI = 6;
// runes vàlides per a una habilitat i un nivell
export function validRunes(ab, list, level) {
  if (!ab || !Array.isArray(list)) return [];
  const max = level >= RUNE_SLOT2_LVL ? 2 : 1;
  const out = [];
  for (const r of list) {
    const R = RUNES[r];
    if (!R || out.includes(r) || !R.kinds.includes(ab.kind) || level < R.lvl) continue;
    if (R.el && out.some((x) => RUNES[x].el)) continue; // una sola afinitat
    out.push(r);
    if (out.length >= max) break;
  }
  return out;
}
// aplica les runes a una còpia de l'habilitat
export function applyRunes(ab, runes) {
  if (!ab || !runes || !runes.length) return ab;
  const a = { ...ab, runes: [...runes] };
  if (a.combo) a.combo = a.combo.map((c) => ({ ...c }));
  const mulDmg = (k) => { if (a.dmg) a.dmg = Math.round(a.dmg * k); if (a.combo) a.combo.forEach((c) => { c.dmg = Math.round(c.dmg * k); }); if (a.autoStrike) a.autoStrike = { ...a.autoStrike, dmg: Math.round(a.autoStrike.dmg * k) }; };
  for (const r of runes) {
    const R = RUNES[r]; if (!R) continue;
    if (r === 'poder') { mulDmg(1.3); a.cd = +(a.cd * 1.2).toFixed(2); }
    if (r === 'celeritat') { mulDmg(0.88); a.cd = +(a.cd * 0.7).toFixed(2); if (a.combo) a.combo.forEach((c) => { c.time *= 0.82; c.animSpeed = (c.animSpeed || 1) * 1.15; }); }
    if (r === 'eficiencia') a.mana = Math.round((a.mana || 0) * 0.55);
    if (r === 'amplitud') {
      for (const k of ['radius', 'explode', 'chainRange', 'dist', 'width']) if (a[k]) a[k] = +(a[k] * 1.35).toFixed(2);
      if (a.range) a.range = Math.round(a.range * 1.2);
      if (a.combo) a.combo.forEach((c) => { c.range *= 1.25; c.arc = Math.min(220, c.arc * 1.2); });
    }
    if (r === 'multiple') {
      if (a.kind === 'projectile') { a.multi = 3; a.multiDmg = 0.55; }
      else if (a.kind === 'hitscan') a.chain = (a.chain || 0) + 2;
      else { a.hits = (a.hits || 1) + 1; if (!a.interval) a.interval = 0.3; }
    }
    if (r === 'vampir') a.leech = 0.12;
    if (r === 'perforant') { a.pierce = true; if (a.speed) a.speed = Math.round(a.speed * 1.25); }
    if (r === 'persistent') { if (a.dur) a.dur = +(a.dur * 1.5).toFixed(1); }
    if (R.el) { a.el = R.el; a.status = CUSTOM_ELEMENTS[R.el].status; if (a.kind === 'melee') a.meleeEl = R.el; }
  }
  return a;
}

// habilitat d'un personatge amb les seves runes aplicades
// efectes de branques d'un personatge (null si és PvP)
export function effectsOf(save, noSkills = false) {
  if (!save || noSkills) return EMPTY_EFF;
  return skillEffects(save.skills, save.cls);
}
// habilitats que pot posar a les tecles 1-4
export function slotChoices(save, noSkills = false) {
  const c = CLASSES[save.cls] || CLASSES.foc;
  return [...c.abilities, ...(c.extra || []), ...effectsOf(save, noSkills).unlocks.filter((k) => ABILITIES[k]), ...(save.custom && !c.melee ? ['custom'] : [])];
}
// habilitats actives a les tecles 1-4 (les no vàlides tornen a la de classe)
export function activeSlots(save, noSkills = false) {
  const c = CLASSES[save.cls] || CLASSES.foc;
  const slots = (save.slots && save.slots.length === 4) ? save.slots : c.abilities;
  const ok = slotChoices(save, noSkills);
  return slots.map((k, i) => (ok.includes(k) ? k : c.abilities[i]));
}
// multiplicador de dany pel poder (les habilitats es fan més fortes amb les estadístiques)
export const powerMult = (poder) => 1 + (poder || 0) / 45;

// habilitat d'un personatge: base → branques → estadístiques → runes
export function abilityFor(save, key, opts = {}) {
  const base = key === 'custom' ? (save && save.custom ? buildCustomAbility(save.custom) : null) : ABILITIES[key];
  if (!base) return null;
  let a = applySkillMods(base, key, effectsOf(save, opts.noSkills));
  // estadístiques: la saviesa amplia l'àrea, l'agilitat accelera l'atac bàsic, la vitalitat reforça escuts i cures
  const t = (save && save.talents) || {};
  const cls = save && CLASSES[save.cls];
  const sav = Math.min(25, (t.saviesa || 0) * 1.2) / 100;
  if (sav > 0 && a.kind !== 'buff' && a.kind !== 'transform' && a.kind !== 'melee') {
    a = { ...a };
    if (a.radius && a.kind !== 'projectile') a.radius = +(a.radius * (1 + sav)).toFixed(2);
    if (a.explode) a.explode = +(a.explode * (1 + sav)).toFixed(2);
  }
  if (cls && key === cls.basic && t.agilitat) {
    a = { ...a }; const k = 1 - Math.min(0.25, t.agilitat * 0.012);
    a.cd = +(a.cd * k).toFixed(3);
    if (a.combo) a.combo = a.combo.map((c) => ({ ...c, time: c.time * k, animSpeed: (c.animSpeed || 1) / k }));
  }
  if (a.buff === 'shield' && t.vitalitat) { a = { ...a, amount: Math.round(a.amount * (1 + t.vitalitat * 0.03)) }; }
  if (a.heal && t.vitalitat) { a = { ...a, heal: +(a.heal * (1 + t.vitalitat * 0.03)).toFixed(3) }; }
  const r = validRunes(base, save && save.runes && save.runes[key], (save && save.level) || 1);
  return r.length ? applyRunes(a, r) : a;
}

// ---------------- ENEMICS ----------------
// rig: 'ual' (Quaternius Bestiary, animacions humanoides) | 'kk' (KayKit) | 'vrm'
export const ENEMIES = {
  puglin: { name: 'Puglin', model: 'puglin', rig: 'ual', height: 1.25, hp: 120, dmg: 10, speed: 5.4, range: 1.7, windup: 0.32, recover: 0.6, xp: 14, gold: [2, 6],
    aggro: 17, poise: 2, radius: 0.55, anims: { idle: 'zombie_idle', move: 'jog', attack: ['punch_jab', 'melee_hook'], hit: 'hit_front', death: 'death_ual', taunt: 'yes' } },
  imp: { name: 'Imp', model: 'imp', rig: 'ual', height: 2.15, hp: 320, dmg: 24, speed: 4.4, range: 2.5, windup: 0.55, recover: 0.9, xp: 38, gold: [6, 14],
    aggro: 19, poise: 5, radius: 0.8, anims: { idle: 'idle_sword', move: 'run', attack: ['sword_mx', 'zombie_attack'], hit: 'hit_large', death: 'death_fwd', taunt: 'power_up' } },
  imp_foc: { name: 'Imp Piròman', model: 'imp', rig: 'ual', height: 2.0, hp: 240, dmg: 20, speed: 4.0, range: 15, ranged: { speed: 20, radius: 0.8, el: 'foc', fx: 'fireball' }, windup: 0.7, recover: 1.4, xp: 42, gold: [6, 16],
    aggro: 22, poise: 3, radius: 0.8, keep: 9, anims: { idle: 'idle_ual', move: 'jog', attack: ['throw'], hit: 'hit_large', death: 'death_back', taunt: 'power_up' }, tint: 'foc' },
  esquelet: { name: 'Esquelet Guerrer', model: 'esquelet_dd', rig: 'own', height: 1.95, hp: 230, dmg: 18, speed: 4.0, range: 2.3, windup: 0.5, recover: 0.8, xp: 30, gold: [4, 10],
    aggro: 18, poise: 4, radius: 0.6, weapon: 'Skeleton_Blade', weaponBone: '/^Bip01_R_Hand/', weaponPose: { s: 1.25, r: [1.5708, 0, 0] },
    anims: { idle: 'skeleton1_patrol', move: 'skeleton1_walk', attack: ['skeleton1_slash', 'skeleton1_slash2', 'skeleton1_chop'], hit: 'skeleton1_reacttohit', death: 'skeleton1_dieback', spawn: 'skeleton1_standup2', taunt: 'skeleton1_claw' },
    hitAt: { skeleton1_slash: 0.45, skeleton1_slash2: 0.45, skeleton1_chop: 0.5 } },
  esquelet_mag: { name: 'Esquelet Nigromant', model: 'skeleton_mage', rig: 'kk', height: 1.95, hp: 170, dmg: 19, speed: 3.6, range: 16, ranged: { speed: 18, radius: 0.7, el: 'ombra', fx: 'darkbolt' }, windup: 0.6, recover: 1.3, xp: 34, gold: [5, 12],
    aggro: 22, poise: 2, radius: 0.6, keep: 10, weapon: 'Skeleton_Staff',
    anims: { idle: 'Idle', move: 'Running_A', attack: ['Spellcast_Shoot'], hit: 'Hit_B', death: 'Death_C_Skeletons', spawn: 'Skeletons_Awaken_Floor', taunt: 'Spellcast_Long' } },
  esquelet_lladre: { name: 'Esquelet Saquejador', model: 'skeleton_rogue', rig: 'kk', height: 1.85, hp: 160, dmg: 14, speed: 6.0, range: 2.0, windup: 0.25, recover: 0.45, xp: 28, gold: [5, 12],
    aggro: 20, poise: 2, radius: 0.55, weapon: 'Skeleton_Axe',
    anims: { idle: 'Idle_Combat', move: 'Running_A', attack: ['1H_Melee_Attack_Stab', '1H_Melee_Attack_Slice_Diagonal'], hit: 'Hit_A', death: 'Death_C_Skeletons', spawn: 'Skeletons_Awaken_Standing', taunt: 'Taunt' } },
  esquelet_minion: { name: 'Esquelet Menor', model: 'skeleton_minion', rig: 'kk', height: 1.6, hp: 80, dmg: 9, speed: 4.6, range: 1.9, windup: 0.35, recover: 0.6, xp: 9, gold: [1, 3],
    aggro: 16, poise: 1, radius: 0.5, weapon: 'Skeleton_Blade',
    anims: { idle: 'Idle', move: 'Walking_D_Skeletons', attack: ['1H_Melee_Attack_Chop'], hit: 'Hit_B', death: 'Death_C_Skeletons', spawn: 'Skeletons_Awaken_Floor' } },
  golem: { name: 'Gòlem de Runa', model: 'golem', rig: 'golem', height: 3.1, hp: 820, dmg: 36, speed: 3.4, range: 3.3, windup: 0.85, recover: 1.2, xp: 95, gold: [10, 22],
    aggro: 18, poise: 14, radius: 1.3,
    anims: { idle: 'idle', move: 'walk', attack: ['slam', 'swipe', 'own:Take 001'], hit: 'hit', death: 'death', spawn: 'spawn', taunt: 'roar' },
    hitAt: { slam: 0.48, swipe: 0.48, 'own:Take 001': 0.74 } },
  golem_magma: { name: 'Gòlem de Magma', model: 'golem', rig: 'golem', height: 3.4, hp: 1050, dmg: 40, speed: 3.6, range: 3.5, windup: 0.85, recover: 1.1, xp: 130, gold: [14, 28],
    aggro: 19, poise: 16, radius: 1.4, el: 'foc', tint: 'magma', outline: '#2a0a02',
    anims: { idle: 'idle', move: 'walk', attack: ['slam', 'swipe', 'own:Take 001'], hit: 'hit', death: 'death', spawn: 'spawn', taunt: 'roar' },
    hitAt: { slam: 0.48, swipe: 0.48, 'own:Take 001': 0.74 } },
  bruixot: { name: 'Bruixot de l\'Esquerda', model: 'ganfaul', rig: 'map', bonemap: 'mixamo', height: 2.15, hp: 420, dmg: 27, speed: 4.6, range: 18, ranged: { speed: 22, radius: 0.8, el: 'ombra', fx: 'darkbolt' },
    windup: 0.6, recover: 1.1, xp: 78, gold: [10, 22], aggro: 23, poise: 4, radius: 0.6, keep: 10,
    anims: { idle: 'spell_idle', move: 'run', attack: ['magic_1h_a', 'cast_1h'], hit: 'hit_front', death: 'death_back', taunt: 'magic_user' } },
  esquelet_arquer: { name: 'Esquelet Arquer', model: 'skeleton_warrior', rig: 'kk', height: 1.95, hp: 150, dmg: 16, speed: 3.8, range: 21, ranged: { speed: 36, radius: 0.5, el: 'fisic', fx: 'arrow' },
    windup: 0.55, recover: 1.1, xp: 32, gold: [4, 11], aggro: 24, poise: 2, radius: 0.55, keep: 12, weapon: 'Skeleton_Crossbow',
    anims: { idle: 'Idle_Combat', move: 'Running_C', attack: ['1H_Ranged_Shoot', '2H_Ranged_Shoot'], hit: 'Hit_A', death: 'Death_C_Skeletons', spawn: 'Skeletons_Awaken_Floor', taunt: 'Taunt' } },
  esquelet_piromant: { name: 'Esquelet Piromant', model: 'esquelet_dd', rig: 'own', height: 1.95, hp: 140, dmg: 21, speed: 3.6, range: 17, ranged: { speed: 20, radius: 0.8, el: 'foc', fx: 'fireball' },
    windup: 0.7, recover: 1.3, xp: 38, gold: [5, 12], aggro: 22, poise: 2, radius: 0.55, keep: 10, tint: 'foc',
    anims: { idle: 'skeleton1_patrol', move: 'skeleton1_walk', attack: ['skeleton1_firesphereshot', 'skeleton1_firesphere'], hit: 'skeleton1_reacttohit', death: 'skeleton1_diebasic', spawn: 'skeleton1_standup2', taunt: 'skeleton1_claw' },
    hitAt: { skeleton1_firesphereshot: 0.5, skeleton1_firesphere: 0.6 } },
  totem: { name: 'Tòtem de Foc', model: 'totem', rig: 'none', height: 4, hp: 900, dmg: 0, speed: 0, range: 0, xp: 60, gold: [10, 20], aggro: 25, poise: 999, radius: 1.4,
    static: true, summon: { type: 'puglin', variant: 'vermell', every: 9, max: 3 } },

  // ---- caps ----
  rei_ossut: { name: 'Rei Ossut', title: 'Senyor del Cementiri', model: 'skeleton_warrior', rig: 'kk', height: 6.2, hp: 5200, dmg: 46, speed: 4.6, range: 5.2, windup: 0.9, recover: 1.0, xp: 900, gold: [150, 220],
    aggro: 30, poise: 9999, radius: 2.2, boss: true, weapon: 'Skeleton_Axe', crown: true,
    attacks: ['slam', 'spin', 'summon', 'slam', 'charge'],
    anims: { idle: 'Idle_Combat', move: 'Running_C', attack: ['1H_Melee_Attack_Chop'], slam: '2H_Melee_Attack_Chop', spin: '2H_Melee_Attack_Spin', summon: 'Spellcast_Summon', charge: 'Running_C', hit: 'Hit_A', death: 'Death_C_Skeletons', taunt: 'Taunt' } },
  cap_puglin: { name: 'Gruny', title: 'Cap dels Puglins', model: 'puglin', rig: 'ual', height: 3.4, hp: 2600, dmg: 30, speed: 5.0, range: 3.2, windup: 0.8, recover: 1.0, xp: 520, gold: [80, 130],
    aggro: 24, poise: 9999, radius: 1.5, boss: true, summonType: 'puglin', radii: { slam: 4.6, spin: 5.4, nova: 7 },
    attacks: ['slam', 'spin', 'summon', 'charge', 'slam', 'nova'],
    anims: { idle: 'zombie_idle', move: 'jog', attack: ['punch_jab'], slam: 'zombie_attack', spin: 'melee_hook', summon: 'power_up', charge: 'sprint', nova: 'punch_cross', hit: 'hit_large', death: 'death_ual', taunt: 'yes' } },
  golem_antic: { name: 'Gòlem Antic', title: 'Guardià de la Ciutadella', model: 'golem', rig: 'golem', height: 6.2, hp: 5200, dmg: 54, speed: 3.9, range: 5.4, windup: 0.95, recover: 1.1, xp: 1100, gold: [160, 240],
    aggro: 28, poise: 9999, radius: 2.6, boss: true, outline: '#1d140c', radii: { slam: 6.5, spin: 7.5, nova: 11 },
    attacks: ['slam', 'spin', 'charge', 'nova', 'slam', 'spin'], kinds: {},
    anims: { idle: 'idle', move: 'walk', attack: ['slam'], slam: 'slam', spin: 'swipe', charge: 'walk', nova: 'roar', hit: 'hit', death: 'death', taunt: 'roar' },
    hitAt: { slam: 0.48, swipe: 0.48, roar: 0.4 } },
  senyor_imps: { name: 'Malfoc', title: 'Senyor dels Imps', model: 'imp', rig: 'ual', height: 6.4, hp: 6400, dmg: 52, speed: 4.8, range: 5.6, windup: 0.85, recover: 1.0, xp: 1300, gold: [200, 300],
    aggro: 30, poise: 9999, radius: 2.4, boss: true, tint: 'foc',
    attacks: ['slam', 'meteors', 'charge', 'nova', 'slam'],
    anims: { idle: 'idle_sword', move: 'run', attack: ['sword_mx'], slam: 'zombie_attack', meteors: 'magic_2h_a', charge: 'sprint', nova: 'magic_area_a', hit: 'hit_large', death: 'death_fwd', taunt: 'power_up' } },
  ombra: { name: 'L\'Ombra', title: 'Cor del Cel Trencat', model: 'vrm:heroi3', rig: 'vrm', height: 3.4, hp: 9800, dmg: 58, speed: 5.4, range: 18, windup: 0.75, recover: 0.8, xp: 2500, gold: [400, 600],
    aggro: 34, poise: 9999, radius: 1.3, boss: true, tint: 'ombra', flying: true,
    ranged: { speed: 24, radius: 1.0, el: 'ombra', fx: 'darkbolt' },
    attacks: ['barrage', 'meteors', 'blink', 'nova', 'clones', 'barrage'],
    anims: { idle: 'spell_idle', move: 'glide', attack: ['magic_1h_a'], barrage: 'magic_2h_e', meteors: 'magic_2h_a', blink: 'cast_1h', nova: 'magic_area_b', clones: 'cast_2h', hit: 'hit_front', death: 'death_back', taunt: 'magic_user' } },
  ganfaul: { name: 'Ganfaul', title: 'Bruixot de l\'Esquerda', model: 'ganfaul', rig: 'map', bonemap: 'mixamo', height: 3.7, hp: 12500, dmg: 56, speed: 5.2, range: 18, windup: 0.75, recover: 0.8, xp: 3200, gold: [450, 650],
    aggro: 32, poise: 9999, radius: 1.3, boss: true, el: 'ombra', outline: '#12051f',
    ranged: { speed: 24, radius: 1.0, el: 'ombra', fx: 'darkbolt' }, summonType: 'esquelet_arquer',
    attacks: ['barrage', 'blink', 'meteors', 'nova', 'summon', 'barrage', 'blink'],
    anims: { idle: 'spell_idle', move: 'run', attack: ['magic_1h_a'], barrage: 'magic_2h_e', meteors: 'magic_2h_a', blink: 'cast_1h', nova: 'magic_area_b', summon: 'cast_2h', hit: 'hit_front', death: 'death_back', taunt: 'magic_user' } },
  drac: { name: 'Ignàrion', title: 'Drac Ancestral', model: 'drac', rig: 'drac', height: 7, hp: 24000, dmg: 66, speed: 5.4, range: 8, windup: 0.9, recover: 1.0, xp: 6000, gold: [900, 1300],
    aggro: 42, poise: 9999, radius: 4.4, boss: true, el: 'foc', outline: '#1a0c04',
    attacks: ['bite', 'breath', 'tail', 'roar', 'bite', 'meteors', 'breath', 'tail', 'bite'],
    kinds: { bite: 'slam', tail: 'spin', roar: 'nova' }, radii: { slam: 6.5, spin: 11, nova: 14 },
    windups: { bite: 0.8, breath: 0.95, tail: 0.75, roar: 1.1, meteors: 1.2 },
    anims: { idle: 'idle', move: 'walk', attack: ['bite'], bite: 'bite', breath: 'breath', tail: 'tail', roar: 'roar', meteors: 'roar', hit: 'hit', death: 'death', taunt: 'roar' },
    hitAt: { bite: 0.47, breath: 0.27, tail: 0.45, roar: 0.5 } },
};

// variants de color (textures alternatives del Bestiary)
export const VARIANTS = {
  puglin: { verd: { name: '', mult: 1 }, vermell: { name: 'de Foc', tex: 'puglin_vermell', mult: 1.25, el: 'foc' }, blau: { name: 'Glaçat', tex: 'puglin_blau', mult: 1.35, el: 'gel' }, oliva: { name: 'Pantaner', tex: 'puglin_oliva', mult: 1.15, el: 'poison' } },
  imp: { vermell: { name: '', mult: 1 }, verd: { name: 'Verinós', tex: 'imp_verd', mult: 1.3, el: 'poison' }, blau: { name: 'del Buit', tex: 'imp_blau', mult: 1.45, el: 'gel' } },
};

// ---------------- OBJECTES ----------------
export const RARITIES = [
  { id: 'comu', name: 'Comú', color: '#d6d6d6', mult: 1.0, weight: 60 },
  { id: 'rar', name: 'Rar', color: '#4aa3ff', mult: 1.4, weight: 28 },
  { id: 'epic', name: 'Èpic', color: '#b36bff', mult: 1.9, weight: 10 },
  { id: 'llegendari', name: 'Llegendari', color: '#ffb02e', mult: 2.6, weight: 2 },
];
export const ITEM_BASES = {
  arma: {
    foc: [['Bàcul de brasa', 'staff'], ['Vareta volcànica', 'wand'], ['Grimori ardent', 'spellbook_open']],
    gel: [['Bàcul de gebre', 'staff'], ['Vareta boreal', 'wand'], ['Grimori glaçat', 'spellbook_open']],
    llamp: [['Vareta tronadora', 'wand'], ['Bàcul de tempesta', 'staff'], ['Grimori del tro', 'spellbook_open']],
    guerrer: [['Mandoble rúnic', 'sword_2handed'], ['Espasa arcana', 'sword_1handed'], ['Destral de runes', 'axe_1handed']],
  },
  armadura: [['Túnica de viatger', 0], ['Cota d\'escates', 1], ['Mantell encantat', 2], ['Armadura de l\'alba', 3]],
  amulet: [['Amulet d\'ambre', 0], ['Penjoll lunar', 1], ['Anell d\'èter', 2], ['Talismà estel·lar', 3]],
};
export const PREFIXES = ['Antic', 'Brillant', 'Salvatge', 'Sagrat', 'Ombrívol', 'Ferotge', 'Etern', 'Celestial'];
export const SUFFIXES = ['de l\'Alba', 'del Drac', 'de les Cendres', 'del Gel Perpetu', 'de la Tempesta', 'dels Antics', 'del Cel Trencat', 'de l\'Aura'];

export function rollRarity(rng, luck = 0) {
  let total = 0; for (const r of RARITIES) total += r.weight * (r.id === 'comu' ? 1 : 1 + luck);
  let x = rng() * total;
  for (const r of RARITIES) { x -= r.weight * (r.id === 'comu' ? 1 : 1 + luck); if (x <= 0) return r; }
  return RARITIES[0];
}

export function makeItem(rng, level, cls, slot, luck = 0) {
  const rar = rollRarity(rng, luck);
  slot = slot || ['arma', 'armadura', 'amulet'][Math.floor(rng() * 3)];
  const lv = Math.max(1, level);
  const m = rar.mult * (1 + (lv - 1) * 0.12);
  const it = { id: Math.floor(rng() * 1e9).toString(36), slot, rar: rar.id, lvl: lv, stats: {} };
  let base;
  if (slot === 'arma') {
    const list = ITEM_BASES.arma[cls] || ITEM_BASES.arma.foc;
    base = list[Math.floor(rng() * list.length)];
    it.model = base[1];
    it.stats.poder = Math.round(5 * m + rng() * 3 * m);
    if (rng() < 0.5) it.stats.crit = Math.round(1 + rng() * 2 * rar.mult);
  } else if (slot === 'armadura') {
    base = ITEM_BASES.armadura[Math.floor(rng() * ITEM_BASES.armadura.length)];
    it.stats.vida = Math.round(45 * m + rng() * 20 * m);
    it.stats.def = Math.round(3 * m + rng() * 2 * m);
  } else {
    base = ITEM_BASES.amulet[Math.floor(rng() * ITEM_BASES.amulet.length)];
    it.stats.mana = Math.round(18 * m + rng() * 10 * m);
    if (rng() < 0.6) it.stats.cdr = Math.min(20, Math.round(2 + rng() * 3 * rar.mult));
    if (rng() < 0.5) it.stats.poder = Math.round(2 * m);
  }
  let name = base[0];
  if (rar.id !== 'comu') name = PREFIXES[Math.floor(rng() * PREFIXES.length)] + ' ' + name.charAt(0).toLowerCase() + name.slice(1);
  if (rar.id === 'epic' || rar.id === 'llegendari') name += ' ' + SUFFIXES[Math.floor(rng() * SUFFIXES.length)];
  it.name = name;
  it.price = Math.round(15 * m * (1 + Object.keys(it.stats).length * 0.3));
  return it;
}

// ---------------- BOTIGUES I SKINS ----------------
export const SHOP = [
  { id: 'pocio_vida', name: 'Poció de vida', desc: 'Recupera el 45% de la vida.', price: 25, kind: 'potion', potion: 'vida' },
  { id: 'pocio_mana', name: 'Poció de manà', desc: 'Recupera el 50% del manà.', price: 20, kind: 'potion', potion: 'mana' },
  { id: 'cofre', name: 'Cofre de l\'aventurer', desc: 'Un objecte a l\'atzar (més sort de raresa).', price: 140, kind: 'chest' },
  { id: 'cofre_gran', name: 'Cofre llegendari', desc: 'Garanteix un objecte rar o millor.', price: 420, kind: 'chest', luck: 3 },
];
export const SKINS = {
  aura: [
    { id: 'classe', name: 'Color de classe', price: 0 },
    { id: 'or', name: 'Aura daurada', color: '#ffd166', price: 250 },
    { id: 'rosa', name: 'Aura de sakura', color: '#ff7eb6', price: 250 },
    { id: 'verd', name: 'Aura de jade', color: '#3cff8f', price: 250 },
    { id: 'ombra', name: 'Aura d\'ombra', color: '#8a2bff', price: 450 },
    { id: 'blanc', name: 'Aura celestial', color: '#ffffff', price: 600 },
  ],
  arma: [
    { id: 'base', name: 'Arma d\'inici', price: 0 },
    { id: 'or', name: 'Arma daurada', color: '#ffcf4a', price: 300 },
    { id: 'cristall', name: 'Arma de cristall', color: '#8fe7ff', price: 350 },
    { id: 'obsidiana', name: 'Arma d\'obsidiana', color: '#2b1840', price: 400 },
  ],
  ales: [
    { id: 'cap', name: 'Sense ales', price: 0 },
    { id: 'aura', name: 'Ales d\'aura', price: 380 },
    { id: 'fenix', name: 'Ales de fènix', color: '#ff7a2a', price: 520 },
    { id: 'gel', name: 'Ales de gebre', color: '#9be9ff', price: 520 },
  ],
};

// ---------------- HISTÒRIA ----------------
export const STORY = [
  { id: 'c1', title: 'Capítol 1 — L\'Aura Trencada', giver: 'elna',
    intro: ['Ets aquí, per fi. La meva visió no s\'equivocava.', 'Fa tres nits, el cel es va esquerdar damunt la vila. Des de llavors, l\'aura que protegia aquestes terres s\'escola com aigua.', 'Els Puglins del Bosc Encantat s\'han tornat bojos amb l\'aura vessada. Comença per allà: atura\'ls abans que arribin als camps.', 'S\'han fet forts en un fortí al nord del bosc. El seu cap, en Gruny, s\'amaga al fons, darrere del segon mur.'],
    done: ['Ho has fet bé. Però els Puglins no eren la causa, només el símptoma.', 'Al nord-est, a les Ruïnes del Sol, els morts s\'han aixecat. Algú està xuclant l\'aura dels cristalls antics.'],
    objectives: [{ type: 'kill', enemy: 'puglin', n: 8, text: 'Derrota Puglins al Bosc Encantat' }, { type: 'boss', enemy: 'cap_puglin', n: 1, text: 'Derrota en Gruny al Fortí dels Puglins' }],
    reward: { xp: 420, gold: 90, item: true } },
  { id: 'c2', title: 'Capítol 2 — Els Ossos del Sol', giver: 'elna',
    intro: ['Als cofres de les Ruïnes del Sol hi ha tres cristalls d\'aura. Recupera\'ls. Un és dins la Ciutadella del Sol, que guarda un gòlem antic.', 'I vés amb compte amb el Rei Ossut. Dorm al fons de la cripta emmurallada, però els morts no dormen mai del tot.'],
    done: ['Els cristalls encara bateguen... Però estan contaminats amb foc.', 'Això només pot venir de les Terres Cremades, a l\'oest. Malfoc, el senyor dels Imps, hi ha alçat tòtems.'],
    objectives: [{ type: 'collect', item: 'cristall', n: 3, text: 'Recupera cristalls d\'aura dels cofres de les Ruïnes' }, { type: 'boss', enemy: 'rei_ossut', n: 1, text: 'Derrota el Rei Ossut a la Cripta' }],
    reward: { xp: 900, gold: 220, item: true } },
  { id: 'c3', title: 'Capítol 3 — Les Terres Cremades', giver: 'elna',
    intro: ['Els tòtems de foc de Malfoc estan bombant aura cap al cel.', 'Destrueix-los i enfronta\'t a ell. Si cau, potser podrem veure què hi ha darrere l\'esquerda.'],
    done: ['Malfoc ha caigut... i l\'esquerda del cel s\'ha obert del tot. Hi ha illes surant sobre el mar!', 'A la Costa de les Gavines hi ha una Pedra de Vent antiga. Activa-la i et portarà fins al cel.'],
    objectives: [{ type: 'kill', enemy: 'totem', n: 3, text: 'Destrueix els tòtems de foc' }, { type: 'boss', enemy: 'senyor_imps', n: 1, text: 'Derrota Malfoc al seu fort' }],
    reward: { xp: 1500, gold: 320, item: true } },
  { id: 'c4', title: 'Capítol 4 — El Cel Trencat', giver: 'elna',
    intro: ['Totes les pistes porten a les Illes del Cel. Allà hi ha el cor de l\'esquerda.', 'Sento una presència... té la teva forma, però està buida. Una ombra de tu mateix.'],
    done: ['L\'Ombra s\'ha dissolt... però l\'esquerda encara batega. Era només un titella.', 'Algú la movia des de més amunt. Descansa una mica i torna a parlar amb mi.'],
    objectives: [{ type: 'activate', what: 'pedra_vent', n: 1, text: 'Activa la Pedra de Vent a la Costa' }, { type: 'boss', enemy: 'ombra', n: 1, text: 'Derrota l\'Ombra a les Illes del Cel' }],
    reward: { xp: 3000, gold: 600, item: true } },
  { id: 'c5', title: 'Capítol 5 — El Drac Ancestral', giver: 'elna',
    intro: ['Ara ho veig clar. Ganfaul, un bruixot que tothom creia mort, movia l\'Ombra com un titella.', 'Amb l\'aura robada ha despertat Ignàrion, el drac ancestral que dormia dins l\'esquerda.', 'A l\'illa del cap s\'ha obert un nou corrent de vent. Segueix-lo, venç Ganfaul i després el drac. Que l\'aura t\'acompanyi.'],
    done: ['Ignàrion ha caigut i l\'esquerda s\'ha segellat per sempre. Ara sí: has salvat l\'Alba.', 'Les cançons de les tavernes ja parlen de tu. Torna quan vulguis: sempre hi haurà monstres a caçar i tresors a trobar.'],
    objectives: [{ type: 'boss', enemy: 'ganfaul', n: 1, text: 'Derrota Ganfaul a l\'Illa del Bruixot' }, { type: 'boss', enemy: 'drac', n: 1, text: 'Derrota Ignàrion, el Drac Ancestral' }],
    reward: { xp: 6000, gold: 1200, item: true } },
];

export const BOUNTIES = [
  { id: 'b_puglin', title: 'Plaga de Puglins', obj: { type: 'kill', enemy: 'puglin', n: 15, text: 'Derrota 15 Puglins' }, reward: { xp: 300, gold: 90 } },
  { id: 'b_ossos', title: 'Ossos inquiets', obj: { type: 'kill', enemy: 'esquelet*', n: 14, text: 'Derrota 14 esquelets' }, reward: { xp: 520, gold: 140 } },
  { id: 'b_imps', title: 'Banyes i foc', obj: { type: 'kill', enemy: 'imp*', n: 10, text: 'Derrota 10 Imps' }, reward: { xp: 760, gold: 200 } },
  { id: 'b_golems', title: 'Pedra que camina', obj: { type: 'kill', enemy: 'golem*', n: 6, text: 'Derrota 6 gòlems' }, reward: { xp: 900, gold: 240 } },
  { id: 'b_bruixots', title: 'Aprenents de l\'esquerda', obj: { type: 'kill', enemy: 'bruixot', n: 6, text: 'Derrota 6 Bruixots de l\'Esquerda' }, reward: { xp: 1300, gold: 320 } },
  { id: 'b_guardia', title: 'El guardià de pedra', obj: { type: 'boss', enemy: 'golem_antic', n: 1, text: 'Derrota el Gòlem Antic a la Ciutadella del Sol' }, reward: { xp: 1200, gold: 300, item: true } },
  { id: 'b_caps', title: 'Caçador de llegendes', obj: { type: 'kill', enemy: 'boss', n: 2, text: 'Derrota 2 caps' }, reward: { xp: 1400, gold: 400, item: true } },
];

export const NPCS = [
  { id: 'elna', name: 'Sàvia Elna', role: 'Història · Grimori', model: 'mage', x: 6, z: -9, ry: Math.PI, anim: 'Idle' },
  { id: 'bru', name: 'Capità Bru', role: 'Recompenses', model: 'knight', x: -14, z: 4, ry: Math.PI / 2, anim: 'Idle' },
  { id: 'oleguer', name: 'Ferrer Oleguer', role: 'Botiga', model: 'barbarian', x: 15, z: 8, ry: -Math.PI / 2, anim: 'Idle' },
  { id: 'rina', name: 'Rina la Viatgera', role: 'Skins · Portals', model: 'rogue_hooded', x: -6, z: 14, ry: 0, anim: 'Sit_Chair_Idle' },
];

export const XP_TABLE = (lv) => Math.round(120 * Math.pow(lv, 1.55));

// què dona cada punt d'estadística
export const TALENT_INFO = {
  poder: { name: 'Poder', poder: 4, desc: '+4 de poder: totes les habilitats fan més dany' },
  vitalitat: { name: 'Vitalitat', hp: 55, def: 1.5, desc: '+55 de vida, +1,5 de defensa, +3% d\'escuts i cures' },
  agilitat: { name: 'Agilitat', crit: 1, speed: 1, desc: '+1% de crític, +1% de velocitat i atac bàsic més ràpid' },
  saviesa: { name: 'Saviesa', mana: 20, cdr: 1, regen: 0.5, desc: '+20 de manà, −1% de recàrrega i +1,2% d\'àrea' },
};

// el guerrer no fa servir màgia: el poder és força i el manà, energia
export function statLabel(cls, key) {
  const melee = CLASSES[cls] && CLASSES[cls].melee;
  if (!melee) return { poder: 'Poder', saviesa: 'Saviesa', mana: 'Manà' }[key] || key;
  return { poder: 'Força', saviesa: 'Disciplina', mana: 'Energia' }[key] || key;
}

export function computeStats(cls, level, talents = {}, equip = {}, extras = {}) {
  const c = CLASSES[cls] || CLASSES.foc;
  const L = Math.max(1, Math.min(MAX_LEVEL, level | 0));
  const s = {
    maxHp: Math.round(c.stats.hp * (1 + 0.1 * (L - 1)) + (talents.vitalitat || 0) * TALENT_INFO.vitalitat.hp),
    maxMana: Math.round(c.stats.mana * (1 + 0.05 * (L - 1)) + (talents.saviesa || 0) * TALENT_INFO.saviesa.mana),
    poder: c.stats.poder * (1 + 0.08 * (L - 1)) + (talents.poder || 0) * TALENT_INFO.poder.poder,
    def: c.stats.def * (1 + 0.07 * (L - 1)) + (talents.vitalitat || 0) * TALENT_INFO.vitalitat.def,
    crit: c.stats.crit + (talents.agilitat || 0) * TALENT_INFO.agilitat.crit,
    cdr: (talents.saviesa || 0) * TALENT_INFO.saviesa.cdr,
    speed: c.stats.speed * (1 + (talents.agilitat || 0) * TALENT_INFO.agilitat.speed / 100),
    manaRegen: 4 + L * 0.35 + (talents.saviesa || 0) * TALENT_INFO.saviesa.regen,
    hpRegen: 1.5 + L * 0.25 + (talents.vitalitat || 0) * 0.3,
  };
  for (const it of Object.values(equip || {})) {
    if (!it || !it.stats) continue;
    s.maxHp += it.stats.vida || 0; s.maxMana += it.stats.mana || 0; s.poder += it.stats.poder || 0;
    s.def += it.stats.def || 0; s.crit += it.stats.crit || 0; s.cdr += it.stats.cdr || 0;
  }
  // branques d'habilitats
  if (!extras.pvp && extras.skills) {
    const E = skillEffects(extras.skills, cls);
    for (const [k, m] of Object.entries(E.stats)) if (s[k] !== undefined) s[k] = (s[k] + m.add) * (1 + m.pct);
    s.maxHp = Math.round(s.maxHp); s.maxMana = Math.round(s.maxMana);
  }
  if (extras.pvp) { s.maxHp = Math.round(s.maxHp * 1.6); }
  s.cdr = Math.min(35, s.cdr); s.crit = Math.min(60, s.crit);
  s.poder = Math.round(s.poder); s.def = Math.round(s.def);
  return s;
}

export function newCharacter(name, cls, hero) {
  return {
    v: 1, name: String(name || 'Heroi').slice(0, 16), cls, hero, level: 1, xp: 0, gold: 30,
    talents: { poder: 0, vitalitat: 0, agilitat: 0, saviesa: 0 }, talentPts: 0,
    inv: [], equip: {}, potions: { vida: 3, mana: 2 },
    story: { idx: 0, accepted: false, progress: [] }, bounty: null, bountiesDone: [],
    custom: null, slots: null, runes: {}, loadouts: [], grimori: [], skills: {}, records: {}, skins: { aura: 'classe', arma: 'base', ales: 'cap' }, owned: { aura: ['classe'], arma: ['base'], ales: ['cap'] },
    waystones: ['vila'], flags: {}, pvp: { wins: 0, losses: 0, kills: 0 },
    created: Date.now(),
  };
}
