// ============================================================
//  Estructures modulars amb el Medieval Village MegaKit (Quaternius, CC0)
//  i fortaleses amb enemics que cal travessar fins arribar al cap.
//  Funcions pures: no depenen del terreny (worldgen els passa un col·locador).
// ============================================================

export const FLOOR_H = 3.12;   // alçada d'un pis del MegaKit
const PI = Math.PI;

// rotació local -> món (mateixa convenció que three.js: rotation.y)
export function toWorld(o, lx, lz) {
  const c = Math.cos(o.ry || 0), s = Math.sin(o.ry || 0);
  return [o.x + lx * c + lz * s, o.z - lx * s + lz * c];
}

function rngOf(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// sostres disponibles (amplada x llargada en metres)
const ROOFS = { 2: [2, 3, 4], 3: [3, 4, 5, 7], 4: [4, 5, 6, 7] };
export function fitRoofL(W, L) { const opts = ROOFS[W] || ROOFS[3]; return opts.reduce((a, b) => (Math.abs(b - L) < Math.abs(a - L) ? b : a)); }

const WALLS = {
  brick: { straight: 'Wall_UnevenBrick_Straight', door: 'Wall_UnevenBrick_Door_Round', doorFlat: 'Wall_UnevenBrick_Door_Flat',
    win: ['Wall_UnevenBrick_Window_Wide_Round', 'Wall_UnevenBrick_Window_Thin_Round', 'Wall_UnevenBrick_Window_Wide_Flat'] },
  plaster: { straight: 'Wall_Plaster_Straight', door: 'Wall_Plaster_Door_Round', doorFlat: 'Wall_Plaster_Door_Flat', grid: 'Wall_Plaster_WoodGrid',
    win: ['Wall_Plaster_Window_Wide_Round', 'Wall_Plaster_Window_Thin_Round', 'Wall_Plaster_Window_Wide_Flat'] },
};
const WIN_INSERT = {
  Wide_Round: ['Window_Wide_Round1', 'WindowShutters_Wide_Round_Open', 'WindowShutters_Wide_Round_Closed'],
  Thin_Round: ['Window_Thin_Round1', 'WindowShutters_Thin_Round_Open', 'WindowShutters_Thin_Round_Closed'],
  Wide_Flat: ['Window_Wide_Flat1', 'WindowShutters_Wide_Flat_Open', 'WindowShutters_Wide_Flat_Closed'],
};

// ------------------------------------------------------------------ casa
// put(model, lx, lz, lrot, ly, scale) col·loca una peça en coordenades locals de la casa.
// opt: { W, L (cel·les de 2 m), F (pisos), ground: 'brick'|'plaster', seed, chimney, door: 'front' }
export function buildHouse(put, opt) {
  const r = rngOf(opt.seed || 1);
  const W = opt.W || 3, L = fitRoofL(W, opt.L || 4), F = Math.max(1, Math.min(3, opt.F || 1));
  const hx = W, hz = L;
  const sides = [
    { n: W, pos: (i) => [-hx + 1 + 2 * i, hz], rot: 0, front: true },
    { n: W, pos: (i) => [hx - 1 - 2 * i, -hz], rot: PI },
    { n: L, pos: (i) => [hx, hz - 1 - 2 * i], rot: PI / 2 },
    { n: L, pos: (i) => [-hx, -hz + 1 + 2 * i], rot: -PI / 2 },
  ];
  const doorI = Math.floor((W - 1) / 2 + (W % 2 === 0 && r() < 0.5 ? 1 : 0));
  for (let f = 0; f < F; f++) {
    const y = f * FLOOR_H;
    const mat = f === 0 ? (opt.ground || 'brick') : 'plaster';
    const set = WALLS[mat];
    for (const sd of sides) {
      for (let i = 0; i < sd.n; i++) {
        const [lx, lz] = sd.pos(i);
        if (f === 0 && sd.front && i === doorI) {
          put(set.door, lx, lz, sd.rot, y);
          put('Door_1_Round', lx - 0.51, lz - 0.08, sd.rot, y);
          continue;
        }
        const k = r();
        if (k < (f === 0 ? 0.45 : 0.55)) {
          const wm = set.win[Math.floor(r() * set.win.length)];
          put(wm, lx, lz, sd.rot, y);
          const ins = WIN_INSERT[wm.replace(/^Wall_\w+?_Window_/, '')];
          if (ins) { put(ins[0], lx, lz, sd.rot, y); if (r() < 0.75) put(ins[r() < 0.6 ? 1 : 2], lx, lz, sd.rot, y); }
        } else put(mat === 'plaster' && set.grid && r() < 0.5 ? set.grid : set.straight, lx, lz, sd.rot, y);
        if (f > 0) put('Wall_BottomCover', lx, lz, sd.rot, y);
      }
    }
    for (const [cx, cz] of [[hx, hz], [-hx, hz], [hx, -hz], [-hx, -hz]]) put('Corner_Exterior_Wood', cx, cz, 0, y);
  }
  const top = F * FLOOR_H;
  put(`Roof_RoundTiles_${2 * W}x${2 * L}`, 0, 0, 0, top);
  put(`Roof_Front_Brick${2 * W}`, 0, hz, 0, top);
  put(`Roof_Front_Brick${2 * W}`, 0, -hz, PI, top);
  if (opt.chimney !== false && r() < 0.8) put(r() < 0.5 ? 'Prop_Chimney' : 'Prop_Chimney2', (hx - 1.1) * (r() < 0.5 ? 1 : -1), -hz + 1.6 + r() * (2 * hz - 3.2), 0, top + 0.1);
  // detalls
  if (r() < 0.6) put('Prop_Vine' + ['1', '2', '4', '5'][Math.floor(r() * 4)], -hx + 1 + 2 * Math.floor(r() * W), hz + 0.12, 0, 2.6);
  if (r() < 0.55) put('Prop_Crate', hx + 0.9, hz - 0.6, r() * PI, 0);
  return { hx: hx + 0.25, hz: hz + 0.25, height: top + 5 };
}

// ------------------------------------------------------------------ torre quadrada
export function buildTower(put, opt) {
  const F = opt.F || 3, mat = opt.mat || 'brick';
  const set = WALLS[mat];
  const sides = [[0, 1, 0], [0, -1, PI], [1, 0, PI / 2], [-1, 0, -PI / 2]];
  for (let f = 0; f < F; f++) {
    const y = f * FLOOR_H;
    for (const [sx, sz, rot] of sides) {
      for (const o of [-1, 1]) {
        const lx = sx ? sx * 2 : o, lz = sz ? sz * 2 : o;
        const win = f === F - 1 && o === 1;
        if (win) { put(set.win[1], lx, lz, rot, y); put('Window_Thin_Round1', lx, lz, rot, y); }
        else put(set.straight, lx, lz, rot, y);
      }
    }
    for (const [cx, cz] of [[2, 2], [-2, 2], [2, -2], [-2, -2]]) put('Corner_Exterior_Wood', cx, cz, 0, y);
  }
  put('Roof_Tower_RoundTiles', 0, 0, 0, F * FLOOR_H);
  return { r: 2.9 };
}

// ------------------------------------------------------------------ mur recte
// tram de mur entre (x0,z0) i (x1,z1) (local), amb la cara exterior cap a la normal (nx,nz)
export function buildWall(put, x0, z0, x1, z1, opt = {}) {
  const len = Math.hypot(x1 - x0, z1 - z0);
  const n = Math.max(1, Math.round(len / 2));
  const dx = (x1 - x0) / n, dz = (z1 - z0) / n;
  const rot = Math.atan2(opt.nx || 0, opt.nz || 1);
  const H = opt.H || 2;
  for (let i = 0; i < n; i++) {
    const cx = x0 + dx * (i + 0.5), cz = z0 + dz * (i + 0.5);
    for (let f = 0; f < H; f++) put(opt.model || 'Wall_UnevenBrick_Straight', cx, cz, rot, f * FLOOR_H);
    put('Wall_BottomCover', cx, cz, rot, H * FLOOR_H);
    if (opt.inner) for (let f = 0; f < H; f++) put(opt.model || 'Wall_UnevenBrick_Straight', cx - (opt.nx || 0) * 0.42, cz - (opt.nz || 1) * 0.42, rot + PI, f * FLOOR_H);
  }
  return { len, rot };
}

// ============================================================
//  FORTALESES: murs, torres, porta, pati amb onades d'enemics i
//  una torre de l'homenatge (recinte interior) amb el cap al final.
//  Coordenades locals: la porta mira cap a +z.
// ============================================================
export const STRUCTURE_DEFS = [
  {
    id: 'forti_bosc', name: 'Fortí dels Puglins', x: 0, z: -222, ry: 0, hw: 18, hd: 24, kw: 10, kz: -8, lvl: 4,
    boss: { type: 'cap_puglin', lvl: 5, respawn: 300 },
    waves: [
      { lx: 0, lz: 31, r: 5, list: [['puglin', 3]], lvl: 3 },
      { lx: -8, lz: 16, r: 4, list: [['puglin', 3, 'oliva']], lvl: 4 },
      { lx: 8, lz: 6, r: 4, list: [['puglin', 2], ['imp', 1]], lvl: 4 },
      { lx: 0, lz: -2, r: 3, list: [['imp', 2, 'verd']], lvl: 5 },
    ],
    houses: [{ lx: -11, lz: 11, ry: PI / 2, W: 2, L: 3, F: 1 }, { lx: 11, lz: 14, ry: -PI / 2, W: 2, L: 4, F: 2 }],
    style: 'brick',
  },
  {
    id: 'ciutadella', name: 'Ciutadella del Sol', x: 200, z: -116, ry: 0, hw: 20, hd: 24, kw: 12, kz: -6, lvl: 8,
    boss: { type: 'golem_antic', lvl: 9, respawn: 300 },
    waves: [
      { lx: 0, lz: 31, r: 5, list: [['esquelet', 2], ['esquelet_arquer', 2]], lvl: 7 },
      { lx: -9, lz: 15, r: 4, list: [['esquelet_minion', 4], ['esquelet_mag', 1]], lvl: 7 },
      { lx: 9, lz: 8, r: 4, list: [['golem', 1], ['esquelet_arquer', 2]], lvl: 8 },
      { lx: 0, lz: 0, r: 3, list: [['esquelet_lladre', 2], ['esquelet', 1]], lvl: 8 },
    ],
    houses: [{ lx: -13, lz: 10, ry: PI / 2, W: 2, L: 4, F: 2 }, { lx: 13, lz: 16, ry: -PI / 2, W: 2, L: 3, F: 1 }],
    style: 'brick',
  },
  {
    id: 'cripta', name: 'Cripta del Rei Ossut', x: 215, z: 40, ry: PI, hw: 24, hd: 24, kw: 0, kz: 0, lvl: 8,
    boss: null, // el Rei Ossut ja té el seu camp (al centre)
    waves: [
      { lx: 0, lz: 31, r: 5, list: [['esquelet', 3]], lvl: 7 },
      { lx: -11, lz: 17, r: 4, list: [['esquelet_arquer', 2], ['esquelet_mag', 1]], lvl: 7 },
      { lx: 11, lz: 17, r: 4, list: [['esquelet_lladre', 2], ['esquelet_minion', 2]], lvl: 8 },
    ],
    houses: [],
    style: 'brick', openKeep: true,
  },
  {
    id: 'fort_malfoc', name: 'Fort de Malfoc', x: -228, z: -98, ry: 0.62, hw: 26, hd: 26, kw: 0, kz: 0, lvl: 11,
    boss: null, // Malfoc ja té el seu camp (al centre)
    waves: [
      { lx: 0, lz: 33, r: 5, list: [['puglin', 3, 'vermell'], ['imp_foc', 1]], lvl: 10 },
      { lx: -12, lz: 19, r: 4, list: [['golem_magma', 1], ['esquelet_piromant', 1]], lvl: 11 },
      { lx: 12, lz: 19, r: 4, list: [['imp_foc', 2], ['esquelet_piromant', 1]], lvl: 11 },
    ],
    houses: [{ lx: -18, lz: -13, ry: PI / 2, W: 2, L: 3, F: 1 }, { lx: 18, lz: -11, ry: -PI / 2, W: 2, L: 4, F: 1 }],
    style: 'brick', openKeep: true,
  },
];

// porta, abast i camps de cada fortalesa (sense dependre del terreny)
export const STRUCTURES = STRUCTURE_DEFS.map((d) => {
  const [gx, gz] = toWorld(d, 0, d.hd + 4);
  return { id: d.id, name: d.name, x: d.x, z: d.z, reach: Math.max(d.hw, d.hd) + 2, gate: { x: gx, z: gz }, lvl: d.lvl };
});

export const STRUCTURE_CAMPS = [];
for (const d of STRUCTURE_DEFS) {
  for (const w of d.waves) {
    const [x, z] = toWorld(d, w.lx, w.lz);
    STRUCTURE_CAMPS.push({ x, z, r: w.r, lvl: w.lvl || d.lvl, list: w.list, structure: d.id, respawn: 90 });
  }
  if (d.boss) {
    const [x, z] = toWorld(d, 0, (-d.hd + d.kz) / 2);
    STRUCTURE_CAMPS.push({ x, z, r: 1, lvl: d.boss.lvl, list: [[d.boss.type, 1]], respawn: d.boss.respawn, boss: true, structure: d.id });
  }
}
export const STRUCTURE_CHESTS = STRUCTURE_DEFS.map((d) => {
  const [x, z] = toWorld(d, 0, -d.hd + 3);
  return { id: 'ch_' + d.id, x, z, structure: d.id };
});
// zones aplanades per al terreny
export const STRUCTURE_FLATS = STRUCTURE_DEFS.map((d) => ({ id: d.id, x: d.x, z: d.z, r: Math.hypot(d.hw, d.hd) + 4 }));

// Genera totes les peces d'una fortalesa. put(model, lx, lz, lrot, ly, s) en coordenades locals.
// solid(kind, lx, lz, a, b, lrot): col·lisions locals ('wall' de llargada a; 'circle' de radi a; 'box' a×b)
export function buildFortress(put, solid, d) {
  const r = rngOf(d.id.length * 977 + d.hw * 13);
  const { hw, hd } = d;
  const H = 2;
  const opt = (nx, nz) => ({ H, nx, nz, inner: true });
  // mur del darrere i laterals (deixant lloc a les torres de les cantonades)
  buildWall(put, -hw + 2, -hd, hw - 2, -hd, opt(0, -1)); solid('wall', 0, -hd, 2 * hw, 0, 0);
  buildWall(put, -hw, -hd + 2, -hw, hd - 2, opt(-1, 0)); solid('wall', -hw, 0, 2 * hd, 0, PI / 2);
  buildWall(put, hw, -hd + 2, hw, hd - 2, opt(1, 0)); solid('wall', hw, 0, 2 * hd, 0, PI / 2);
  // façana amb la porta (forat de 4 m flanquejat per dues torres)
  buildWall(put, -hw + 2, hd, -6, hd, opt(0, 1)); solid('wall', (-hw + 2 - 6) / 2, hd, hw - 8, 0, 0);
  buildWall(put, 6, hd, hw - 2, hd, opt(0, 1)); solid('wall', (hw - 2 + 6) / 2, hd, hw - 8, 0, 0);
  // torres
  for (const [tx, tz] of [[-hw, -hd], [hw, -hd], [-hw, hd], [hw, hd], [-4, hd], [4, hd]]) {
    const F = Math.abs(tx) === 4 ? 3 : 3;
    buildTower((m, lx, lz, rot, ly, s) => put(m, tx + lx, tz + lz, rot, ly, s), { F, mat: 'brick' });
    solid('box', tx, tz, 2.3, 2.3, 0);
  }
  // arc de la porta
  put('Wall_Arch', 0, hd + 0.2, 0, 0, 2);
  put('Wall_Arch', 0, hd - 0.2, PI, 0, 2);
  // recinte interior (homenatge) amb porta pròpia
  if (d.kw > 0) {
    const kz = d.kz, kw = d.kw;
    buildWall(put, -kw, kz, -2, kz, { H: 1, nx: 0, nz: 1, inner: true }); solid('wall', (-kw - 2) / 2, kz, kw - 2, 0, 0);
    buildWall(put, 2, kz, kw, kz, { H: 1, nx: 0, nz: 1, inner: true }); solid('wall', (kw + 2) / 2, kz, kw - 2, 0, 0);
    buildWall(put, -kw, -hd, -kw, kz, { H: 1, nx: 1, nz: 0, inner: true }); solid('wall', -kw, (kz - hd) / 2, kz + hd, 0, PI / 2);
    buildWall(put, kw, -hd, kw, kz, { H: 1, nx: -1, nz: 0, inner: true }); solid('wall', kw, (kz - hd) / 2, kz + hd, 0, PI / 2);
    for (const sx of [-1, 1]) put('Prop_Chimney2', sx * 2.6, kz + 0.4, 0, 0, 0.9); // pilars de la porta interior
    put('Wall_Arch', 0, kz + 0.2, 0, 0, 1.6);
    // terra de pedra dins l'homenatge
    for (let x = -kw + 1; x < kw; x += 2) for (let z = -hd + 1; z < kz; z += 2) put('Floor_UnevenBrick', x, z, 0, 0.04);
  }
  // cases i decorat del pati
  for (const h of d.houses || []) {
    const o = { x: h.lx, z: h.lz, ry: h.ry };
    const box = buildHouse((m, lx, lz, rot, ly, s) => { const [x, z] = toWorld(o, lx, lz); put(m, x, z, rot + h.ry, ly, s); }, { W: h.W, L: h.L, F: h.F, ground: 'brick', seed: Math.round(h.lx * 7 + h.lz * 13 + 5) });
    solid('box', h.lx, h.lz, box.hx, box.hz, h.ry);
  }
  for (let i = 0; i < 6; i++) {
    const x = (r() - 0.5) * (hw * 2 - 8), z = d.kz + 4 + r() * (hd - d.kz - 10);
    if (Math.abs(x) < 4) continue;
    put('Prop_Crate', x, z, r() * PI, 0); solid('circle', x, z, 0.7);
  }
  put('Prop_Wagon', hw - 4, d.kz + 6, 0.3, 0); solid('circle', hw - 4, d.kz + 4.6, 1.4);
}
