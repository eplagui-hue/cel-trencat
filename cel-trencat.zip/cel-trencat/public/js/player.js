// ============================================================
//  Jugador local: controls, física, càmera i apuntat
// ============================================================
import * as THREE from 'three';
import { groundAt, height, collide, getWorld, WORLD, ISLAND, ISLANDS, LAUNCHPADS, islandTop } from './worldgen.js';
import { ABILITIES, CLASSES } from './data.js';
import { activeLevel, platformAt, platformState, courseTime, updraftAt, touchCrumble } from './parkour.js';
const PA = {}, PB = {};

export const KEYS = {
  forward: ['KeyW', 'ArrowUp'], back: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  jump: ['Space'], sprint: ['ShiftLeft', 'ShiftRight'], dodge: ['KeyQ', 'ControlLeft'], interact: ['KeyF'],
  ab1: ['Digit1'], ab2: ['Digit2'], ab3: ['Digit3'], ab4: ['Digit4'], ult: ['KeyR'],
  potionHp: ['KeyG'], potionMana: ['KeyH'], lock: ['Tab'], map: ['KeyM'], inv: ['KeyI'], char: ['KeyC'], grim: ['KeyK'], chat: ['Enter'], emote: ['KeyT'],
};

export class Input {
  constructor(dom) {
    this.dom = dom;
    this.down = new Set();
    this.pressed = new Set();
    this.released = new Set();
    this.mouse = { dx: 0, dy: 0, left: false, right: false, leftPressed: false, rightPressed: false, wheel: 0 };
    this.locked = false;
    this.enabled = true;
    this.touch = { move: new THREE.Vector2(), active: false };
    this.sens = 1;
    addEventListener('keydown', (e) => {
      if (!this.enabled || isTyping(e)) return;
      if (e.code === 'Tab') e.preventDefault();
      if (!this.down.has(e.code)) this.pressed.add(e.code);
      this.down.add(e.code);
    });
    addEventListener('keyup', (e) => { this.down.delete(e.code); this.released.add(e.code); });
    addEventListener('blur', () => { this.down.clear(); this.mouse.left = this.mouse.right = false; });
    dom.addEventListener('mousedown', (e) => {
      if (!this.enabled) return;
      if (!this.locked && !this.touchMode && this.wantLock && !this.lockFailed && dom.requestPointerLock) {
        try { const r = dom.requestPointerLock(); if (r && r.catch) r.catch(() => { this.lockFailed = true; }); } catch (err) { this.lockFailed = true; }
      }
      // sense bloqueig del ratolí (p. ex. dins d'un iframe): arrossegar mou la càmera
      if (!this.locked) this.dragging = true;
      if (e.button === 0) { this.mouse.left = true; this.mouse.leftPressed = true; }
      if (e.button === 2) { this.mouse.right = true; this.mouse.rightPressed = true; }
    });
    addEventListener('mouseup', (e) => { if (e.button === 0) this.mouse.left = false; if (e.button === 2) this.mouse.right = false; if (!this.mouse.left && !this.mouse.right) this.dragging = false; });
    document.addEventListener('pointerlockerror', () => { this.lockFailed = true; });
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('mousemove', (e) => {
      if (this.locked) { this.mouse.dx += e.movementX; this.mouse.dy += e.movementY; }
      else if (this.dragging) { this.mouse.dx += e.movementX; this.mouse.dy += e.movementY; }
    });
    dom.addEventListener('wheel', (e) => { this.mouse.wheel += Math.sign(e.deltaY); }, { passive: true });
    document.addEventListener('pointerlockchange', () => { this.locked = document.pointerLockElement === dom; });
  }
  is(name) { return KEYS[name].some((k) => this.down.has(k)); }
  hit(name) { return KEYS[name].some((k) => this.pressed.has(k)); }
  up(name) { return KEYS[name].some((k) => this.released.has(k)); }
  endFrame() { this.pressed.clear(); this.released.clear(); this.mouse.dx = this.mouse.dy = 0; this.mouse.wheel = 0; this.mouse.leftPressed = this.mouse.rightPressed = false; }
}
function isTyping(e) { const t = e.target; return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable); }

const GRAV = 26;

export class LocalPlayer {
  constructor(game) {
    this.game = game;
    this.pos = new THREE.Vector3(0, 3, 12);
    this.vel = new THREE.Vector3();
    this.yaw = Math.PI; // orientació del personatge
    this.camYaw = Math.PI; this.camPitch = 0.28; this.camDist = 6.2; this.camDistT = 6.2;
    this.onGround = false; this.jumps = 0; this.gliding = false; this.launching = 0;
    this.rolling = 0; this.rollDir = new THREE.Vector3();
    this.dash = null;
    this.castLock = 0; // segons en què el personatge mira cap a l'objectiu
    this.anim = 'idle';
    this.stats = null;
    this.hp = 1; this.mhp = 1; this.mana = 1; this.mmana = 1; this.aura = 0;
    this.statuses = {};
    this.buffs = {};
    this.tr = null;
    this.dead = false;
    this.cds = {};
    this.stTimer = 0;
    this.lockTarget = null;
    this.aimPoint = new THREE.Vector3();
    this.aimDir = new THREE.Vector3(0, 0, 1);
    this.targeting = null; // habilitat de zona pendent
    this.lastAttack = -10;
    this.grid = getWorld().grid;
    this.knock = new THREE.Vector3();
    this.fallStart = null;
    this.emote = null;
  }

  get flags() {
    return (this.game.input.mouse.right && !this.dead ? 4 : 0) | (this.rolling > 0 ? 8 : 0) | (this.gliding ? 16 : 0) | (this.onGround ? 0 : 32);
  }

  speed() {
    const base = this.stats ? this.stats.speed : 7;
    let s = base;
    if (this.statuses.slow) s *= 0.6;
    if (this.tr) s *= (ABILITIES[this.tr.key] && ABILITIES[this.tr.key].speedMult) || 1;
    if (this.buffs.haste) s *= 1.25;
    return s;
  }

  // ---------------------------------------------------------------- update
  update(dt, input, camera) {
    const g = this.game;
    // càmera
    const sens = 0.0023 * (g.settings.sens || 1);
    this.camYaw -= input.mouse.dx * sens;
    this.camPitch += input.mouse.dy * sens * (g.settings.invertY ? -1 : 1);
    this.camPitch = Math.max(-0.6, Math.min(1.25, this.camPitch));
    this.camDistT = Math.max(2.5, Math.min(14, this.camDistT + input.mouse.wheel * 0.8));
    this.camDist += (this.camDistT - this.camDist) * Math.min(1, dt * 8);

    const pk = g.mode === 'parkour';
    const frozen = pk && g.matchState === 'countdown';
    const stunned = this.statuses.stun || this.statuses.freeze || frozen;
    const ui = g.ui.modalOpen();
    const ct = courseTime();
    const LV = pk ? activeLevel() : null;
    // parkour: la plataforma mòbil (o que gira) on ets t'arrossega
    const P = pk && this.onGround && this.plat !== null && this.plat !== undefined ? LV.platforms[this.plat] : null;
    if (P && (P.move || P.spin)) {
      platformState(P, ct, PA); platformState(P, this.platT === undefined ? ct : this.platT, PB);
      let ddx = PA.x - PB.x, ddz = PA.z - PB.z;
      if (P.spin) {
        const da = PA.a - PB.a, c = Math.cos(da), sn = Math.sin(da);
        const ox = this.pos.x - PB.x, oz = this.pos.z - PB.z;
        ddx += ox * c + oz * sn - ox; ddz += -ox * sn + oz * c - oz;
        this.yaw += da;
      }
      if (Math.abs(ddx) < 2 && Math.abs(ddz) < 2) { this.pos.x += ddx; this.pos.z += ddz; }
    }
    if (P && P.crumble) touchCrumble(P, ct);
    this.platT = ct;
    // moviment desitjat
    let mx = 0, mz = 0;
    if (!this.dead && !ui) {
      if (input.is('forward')) mz += 1; if (input.is('back')) mz -= 1;
      if (input.is('left')) mx -= 1; if (input.is('right')) mx += 1;
      if (input.touch.active) { mx += input.touch.move.x; mz += input.touch.move.y; }
    }
    const ml = Math.hypot(mx, mz);
    if (ml > 1) { mx /= ml; mz /= ml; }
    const fwd = new THREE.Vector3(Math.sin(this.camYaw), 0, Math.cos(this.camYaw));
    const right = new THREE.Vector3(-fwd.z, 0, fwd.x);
    const wish = new THREE.Vector3().addScaledVector(fwd, mz).addScaledVector(right, mx);
    const blocking = input.mouse.right && !this.dead && !ui && this.onGround;
    const sprint = input.is('sprint') && !blocking && ml > 0.1;
    let spd = this.speed() * (sprint ? 1.45 : 1) * (blocking ? 0.4 : 1);
    if (this.inUpdraft) spd = Math.min(spd, 4.5); // dins d'un corrent d'aire, et desplaces a poc a poc
    if (stunned || this.dead) spd = 0;

    // esquivar
    if (!this.dead && !ui && !stunned && input.hit('dodge') && this.rolling <= 0 && this.onGround && g.now - (this.lastRoll || -9) > 0.8) {
      this.rolling = 0.58; this.lastRoll = g.now;
      this.rollDir.copy(wish.lengthSq() > 0.01 ? wish.clone().normalize() : new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw)));
      this.yaw = Math.atan2(this.rollDir.x, this.rollDir.z);
      g.net.send('act', { k: 'dodge' });
      g.avatarAction('roll', { speed: 1.35 });
      g.audio.play('whoosh');
    }

    // velocitat horitzontal
    let hv = new THREE.Vector3();
    if (this.dash) {
      this.dash.t += dt;
      const k = Math.min(1, this.dash.t / this.dash.dur);
      const target = this.dash.from.clone().lerp(this.dash.to, this.dash.blink ? (k > 0.3 ? 1 : 0) : k);
      hv.set((target.x - this.pos.x) / dt, 0, (target.z - this.pos.z) / dt);
      if (k >= 1) this.dash = null;
    } else if (this.rolling > 0) {
      this.rolling -= dt;
      hv.copy(this.rollDir).multiplyScalar(10.5 * Math.min(1, this.rolling / 0.2 + 0.4));
    } else if (this.gliding) {
      const gd = wish.lengthSq() > 0.01 ? wish.clone().normalize() : new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
      const cur = new THREE.Vector3(this.vel.x, 0, this.vel.z);
      cur.lerp(gd.multiplyScalar(13), Math.min(1, dt * 2));
      hv.copy(cur);
    } else if (this.launching > 0) {
      hv.set(this.vel.x, 0, this.vel.z);
    } else {
      const target = wish.clone().multiplyScalar(spd);
      const cur = new THREE.Vector3(this.vel.x, 0, this.vel.z);
      const acc = this.onGround ? 14 : 4;
      cur.lerp(target, Math.min(1, dt * acc));
      hv.copy(cur);
    }
    hv.add(this.knock); this.knock.multiplyScalar(Math.max(0, 1 - dt * 6));
    // dins d'un corrent d'aire, el vent et frena perquè et puguis enlairar
    if (this.inUpdraft) { const hs0 = Math.hypot(hv.x, hv.z); if (hs0 > 5) { hv.x *= 5 / hs0; hv.z *= 5 / hs0; } }

    // salt / planar
    if (!this.dead && !ui && !stunned) {
      if (input.hit('jump')) {
        if (this.onGround) { this.vel.y = 10; this.onGround = false; this.jumps = 1; g.avatarBase('jump_start'); g.audio.play('jump'); }
        else if (this.jumps < 2 && this.launching <= 0) { this.vel.y = 9.2; this.jumps = 2; g.avatarAction('double_jump', { speed: 1.4 }); g.fx.parts.burst(this.pos.clone().setY(this.pos.y + 0.2), 16, new THREE.Color('#bff6ff'), { speed: 3, up: -1, size: 0.6, life: 0.5 }); g.audio.play('jump'); }
      }
    }
    this.gliding = !this.onGround && !this.dead && input.is('jump') && this.vel.y < -1.5 && this.launching <= 0 && !this.dash;
    // gravetat
    if (this.dash && !this.dash.blink) this.vel.y = 0;
    else this.vel.y -= GRAV * dt;
    if (this.gliding) this.vel.y = Math.max(this.vel.y, -2.4);
    // parkour: els corrents d'aire t'enlairen
    this.inUpdraft = pk && !this.dead && !!updraftAt(this.pos.x, this.pos.z, this.pos.y);
    if (this.inUpdraft) { this.vel.y = Math.min(Math.max(this.vel.y, -4) + (GRAV + 30) * dt, 7.5); this.launching = 0; }
    if (this.launching > 0) { this.launching -= dt; }

    // integració
    let nx = this.pos.x + hv.x * dt, nz = this.pos.z + hv.z * dt;
    let ny = this.pos.y + this.vel.y * dt;
    this.vel.x = hv.x; this.vel.z = hv.z;
    // col·lisions amb obstacles
    [nx, nz] = collide(this.grid, nx, nz, 0.45, this.pos.y);
    // límits del món i aigua profunda
    const inIsland = ISLANDS.some((is) => Math.hypot(nx - is.x, nz - is.z) < is.r + 2 && this.pos.y > is.top - 6);
    if (!inIsland && this.pos.y < 20) {
      const r = Math.hypot(nx, nz);
      if (r > WORLD.walkRadius && nz < 120) { nx *= WORLD.walkRadius / r; nz *= WORLD.walkRadius / r; }
      const th = height(nx, nz);
      if (th < -1.3 && this.onGround) { nx = this.pos.x; nz = this.pos.z; }
    }
    const gnd = groundAt(nx, nz, Math.max(this.pos.y, ny) + 0.6);
    // pendents massa forts: no s'hi pot pujar caminant
    if (this.onGround && gnd - this.pos.y > 1.4 && !this.dash) { nx = this.pos.x; nz = this.pos.z; }
    const g2 = groundAt(nx, nz, Math.max(this.pos.y, ny) + 0.6);
    if (ny <= g2 + 0.02 && this.vel.y <= 0.5) {
      if (!this.onGround) {
        const fall = this.fallStart !== null ? this.fallStart - g2 : 0;
        if (!this.dead) { g.avatarLand(fall); }
        this.fallStart = null;
      }
      ny = g2; this.vel.y = 0; this.onGround = true; this.jumps = 0; this.launching = 0;
    } else if (this.onGround && ny > g2 + 0.02 && ny - g2 < 0.7 && this.vel.y <= 0) {
      ny = g2; // enganxat a la pujada/baixada
    } else {
      if (this.onGround) this.fallStart = this.pos.y;
      this.onGround = false;
      if (this.fallStart === null || this.vel.y > 0) this.fallStart = Math.max(this.fallStart || ny, ny);
    }
    this.pos.set(nx, ny, nz);

    // parkour: trampolins i caigudes
    if (pk) {
      const r = this.onGround ? platformAt(nx, nz, ny + 0.3, ct) : null;
      this.plat = r && Math.abs(r.top - ny) < 0.35 ? r.p.id : null;
      if (r && r.p.pad && this.onGround && !this.dead && !frozen) {
        const pd = r.p.pad;
        this.vel.set(Math.sin(pd.dir) * pd.push, pd.vy, Math.cos(pd.dir) * pd.push);
        this.onGround = false; this.jumps = 2; this.launching = 0.9; this.plat = null; this.fallStart = ny;
        this.yaw = pd.dir;
        g.avatarBase('jump_start'); g.audio.play('launch');
        g.fx.parts.burst(this.pos.clone().setY(ny + 0.3), 40, new THREE.Color('#ffb347'), { speed: 5, up: 7, size: 0.7, life: 0.9 });
      }
      if (ny < LV.killY && !this.dead) {
        if (!this.pkReset || g.now - this.pkReset > 2) {
          this.pkReset = g.now;
          g.net.send('act', { k: 'pkReset' });
          g.ui.toast('Has caigut! Tornes al punt de control', 'warn');
        }
        this.pos.y = Math.max(this.pos.y, LV.killY - 3); this.vel.set(0, 0, 0);
      }
    }

    // orientació
    const moving = hv.lengthSq() > 0.5;
    if (this.castLock > 0) { this.castLock -= dt; this.yaw = turn(this.yaw, Math.atan2(this.aimDir.x, this.aimDir.z), dt * 16); }
    else if (this.lockTarget && !this.dead) { const t = this.lockTarget.obj.position; this.yaw = turn(this.yaw, Math.atan2(t.x - this.pos.x, t.z - this.pos.z), dt * 10); }
    else if (blocking) this.yaw = turn(this.yaw, this.camYaw, dt * 10);
    else if (moving && !this.dash && this.rolling <= 0) this.yaw = turn(this.yaw, Math.atan2(hv.x, hv.z), dt * 12);

    // estat d'animació
    let anim;
    const hs = Math.hypot(hv.x, hv.z);
    const strafe = (this.lockTarget || blocking) && hs > 0.5;
    if (this.dead) anim = 'dead';
    else if (stunned && !frozen) anim = 'stun';
    else if (this.rolling > 0) anim = 'roll';
    else if (this.gliding) anim = 'glide';
    else if (!this.onGround) anim = this.vel.y > 1 ? 'jump' : 'fall';
    else if (blocking) anim = 'block';
    else if (hs < 0.4) anim = 'idle';
    else if (strafe) {
      const la = Math.atan2(hv.x, hv.z) - this.yaw; const c = Math.cos(la), s = Math.sin(la);
      anim = c > 0.5 ? 'run' : c < -0.5 ? 'back' : s > 0 ? 'left' : 'right';
    } else anim = sprint ? 'sprint' : hs < spd * 0.6 ? 'walk' : 'run';
    this.anim = anim;
    this.moveSpeed = hs;

    // caiguda al buit
    if (this.pos.y < -25 && !this.dead) { this.vel.set(0, 0, 0); }

    // envia estat al servidor
    this.stTimer -= dt;
    if (this.stTimer <= 0) {
      this.stTimer = 1 / 15;
      g.net.send('st', { s: [r2(this.pos.x), r2(this.pos.y), r2(this.pos.z), r2(this.yaw), anim, this.flags] });
    }
  }

  updateCamera(camera, dt) {
    const head = this.pos.clone(); head.y += 1.6 * (this.scale || 1);
    // direcció de visió de la càmera
    const view = new THREE.Vector3(Math.sin(this.camYaw) * Math.cos(this.camPitch), -Math.sin(this.camPitch), Math.cos(this.camYaw) * Math.cos(this.camPitch));
    const right = new THREE.Vector3(-Math.cos(this.camYaw), 0, Math.sin(this.camYaw));
    const pivot = head.clone().addScaledVector(right, 0.55 * Math.min(1, this.camDist / 6));
    let dist = this.camDist * (this.scale || 1);
    // col·lisió amb el terreny
    for (let d = 0.8; d < dist; d += 0.5) {
      const p = pivot.clone().addScaledVector(view, -d);
      if (p.y < groundAt(p.x, p.z, p.y + 3) + 0.35) { dist = Math.max(1.2, d - 0.3); break; }
    }
    const target = pivot.clone().addScaledVector(view, -dist);
    if (!this._camInit) { camera.position.copy(target); this._camInit = true; }
    camera.position.lerp(target, Math.min(1, dt * 20));
    const gy = groundAt(camera.position.x, camera.position.z, camera.position.y + 3);
    if (camera.position.y < gy + 0.3) camera.position.y = gy + 0.3;
    camera.lookAt(camera.position.clone().add(view));
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 2.5);
      const s = this.shake * this.shake * 0.35;
      camera.position.x += (Math.random() - 0.5) * s; camera.position.y += (Math.random() - 0.5) * s;
    }
  }

  // punt on apunta la creu del centre de la pantalla
  computeAim(camera, enemies) {
    const o = camera.position.clone();
    const d = new THREE.Vector3(); camera.getWorldDirection(d);
    let best = null, bt = 90;
    for (const e of enemies) {
      if (e.dead) continue;
      const c = e.obj.position.clone(); c.y += e.def.height * 0.55;
      const t = c.clone().sub(o).dot(d);
      if (t < 0 || t > bt) continue;
      const p = o.clone().addScaledVector(d, t);
      if (p.distanceTo(c) < e.def.radius + 0.6 + t * 0.012) { bt = t; best = e; }
    }
    let hit = null;
    if (best) { hit = best.obj.position.clone(); hit.y += best.def.height * 0.55; }
    else {
      for (let t = 2; t < 90; t += 0.8) {
        const p = o.clone().addScaledVector(d, t);
        if (p.y < groundAt(p.x, p.z, p.y + 1)) { hit = p; break; }
      }
      if (!hit) hit = o.clone().addScaledVector(d, 60);
    }
    if (this.lockTarget && !this.lockTarget.dead) { hit = this.lockTarget.obj.position.clone(); hit.y += this.lockTarget.def.height * 0.55; }
    this.aimPoint.copy(hit);
    const from = this.pos.clone(); from.y += 1.35;
    this.aimDir.copy(hit).sub(from).normalize();
    this.aimTarget = best || (this.lockTarget && !this.lockTarget.dead ? this.lockTarget : null);
    return this.aimTarget;
  }

  startDash(ab, aim) {
    const d = new THREE.Vector3(aim[0], 0, aim[2]).normalize();
    const from = this.pos.clone();
    let to = from.clone().addScaledVector(d, ab.dist);
    // no travessar obstacles ni sortir de l'illa
    const steps = 12; let last = from.clone();
    for (let i = 1; i <= steps; i++) {
      const p = from.clone().lerp(to, i / steps);
      const [cx, cz] = collide(this.grid, p.x, p.z, 0.45, this.pos.y);
      if (Math.hypot(cx - p.x, cz - p.z) > 0.2) { to = last; break; }
      const g = groundAt(p.x, p.z, this.pos.y + 1.5);
      if (g < this.pos.y - 8 || g > this.pos.y + 2.5) { to = last; break; }
      if (height(p.x, p.z) < -1.3 && g < 0) { to = last; break; }
      last = p;
    }
    this.dash = { from, to, t: 0, dur: ab.kind === 'blink' ? 0.18 : 0.32, blink: ab.kind === 'blink' };
    this.yaw = Math.atan2(d.x, d.z);
  }

  launch(target) {
    // tir parabòlic exacte fins al punt de destinació
    const from = this.pos.clone();
    const to = new THREE.Vector3(target.x, target.y + 2, target.z);
    const dist = Math.hypot(to.x - from.x, to.z - from.z);
    const T = Math.max(1.8, Math.min(4.2, dist / 20));
    this.vel.set((to.x - from.x) / T, (to.y - from.y + 0.5 * GRAV * T * T) / T, (to.z - from.z) / T);
    this.launching = T * 0.92; this.onGround = false; this.jumps = 2;
    this.pos.y += 0.3;
  }
}

export function turn(a, b, max) {
  let d = b - a; d = Math.atan2(Math.sin(d), Math.cos(d));
  return a + Math.max(-max, Math.min(max, d));
}
const r2 = (v) => Math.round(v * 100) / 100;
